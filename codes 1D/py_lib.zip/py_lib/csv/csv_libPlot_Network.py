#!/usr/bin/python2.7

__author__      = "Arthur R. Ghigo"
__copyright__   = "Copyright 2015, UPMC IJLRDA"
__credits__     = ["Arthur R. Ghigo"]
__license__     = "GPL"
__version__     = "1.0.0"
__maintainer__  = "Arthur R. Ghigo"
__email__       = "arthur.ghigo@dalembert.upmc.fr"
__status__      = "Prototype"

from help_plot          import *
from scipy.interpolate  import interp1d

FFMpegWriter    = animation.writers['ffmpeg']
metadata        = dict(title='Movie', artist='Arthur Ghigo',comment='Awesome movie')

###########################################
# Define new colormaps
###########################################
Black = make_colormap(
    [colors.ColorConverter().to_rgb('black')],'Black')

plt.register_cmap(cmap=Black)

BlueRed = make_colormap(
    [colors.ColorConverter().to_rgb('navy'),
     colors.ColorConverter().to_rgb('mediumblue'),      0.1,    colors.ColorConverter().to_rgb('mediumblue'),
     colors.ColorConverter().to_rgb('dodgerblue'),      0.2,    colors.ColorConverter().to_rgb('dodgerblue'),
     colors.ColorConverter().to_rgb('deepskyblue'),     0.3,    colors.ColorConverter().to_rgb('deepskyblue'),
     colors.ColorConverter().to_rgb('darkturquoise'),   0.4,    colors.ColorConverter().to_rgb('darkturquoise'),
     colors.ColorConverter().to_rgb('paleturquoise'),   0.5,    colors.ColorConverter().to_rgb('gold'),
     colors.ColorConverter().to_rgb('orange'),          0.6,    colors.ColorConverter().to_rgb('orange'),
     colors.ColorConverter().to_rgb('orangered'),       0.7,    colors.ColorConverter().to_rgb('orangered'),
     colors.ColorConverter().to_rgb('red'),             0.8,    colors.ColorConverter().to_rgb('red'),
     colors.ColorConverter().to_rgb('firebrick'),       0.9,    colors.ColorConverter().to_rgb('firebrick'),
     colors.ColorConverter().to_rgb('darkred'),         0.95,   colors.ColorConverter().to_rgb('darkred')],'BlueRed')

plt.register_cmap(cmap=BlueRed)

BlueMidRed = make_colormap(
    [colors.ColorConverter().to_rgb('navy'),
     colors.ColorConverter().to_rgb('mediumblue'),      0.1,    colors.ColorConverter().to_rgb('mediumblue'),
     colors.ColorConverter().to_rgb('dodgerblue'),      0.2,    colors.ColorConverter().to_rgb('dodgerblue'),
     colors.ColorConverter().to_rgb('deepskyblue'),     0.3,    colors.ColorConverter().to_rgb('deepskyblue'),
     colors.ColorConverter().to_rgb('darkturquoise'),   0.4,    colors.ColorConverter().to_rgb('darkturquoise'),
     colors.ColorConverter().to_rgb('paleturquoise'),   0.499,    colors.ColorConverter().to_rgb('black'),
     colors.ColorConverter().to_rgb('black'),           0.501,    colors.ColorConverter().to_rgb('gold'),
     colors.ColorConverter().to_rgb('orange'),          0.6,    colors.ColorConverter().to_rgb('orange'),
     colors.ColorConverter().to_rgb('orangered'),       0.7,    colors.ColorConverter().to_rgb('orangered'),
     colors.ColorConverter().to_rgb('red'),             0.8,    colors.ColorConverter().to_rgb('red'),
     colors.ColorConverter().to_rgb('firebrick'),       0.9,    colors.ColorConverter().to_rgb('firebrick'),
     colors.ColorConverter().to_rgb('darkred'),         0.95,   colors.ColorConverter().to_rgb('darkred')],'BlueMidRed')

plt.register_cmap(cmap=BlueMidRed)

BlWh = make_colormap(
    [colors.ColorConverter().to_rgb('black'),
     colors.ColorConverter().to_rgb('black'),    0.49,   colors.ColorConverter().to_rgb('black'),
     colors.ColorConverter().to_rgb('black'),    0.51,   colors.ColorConverter().to_rgb('white'),
     colors.ColorConverter().to_rgb('white'),    1.,   colors.ColorConverter().to_rgb('white')],
     'BlWh')

plt.register_cmap(cmap=BlWh)

BlBlue = make_colormap(
    [colors.ColorConverter().to_rgb('black'),
     colors.ColorConverter().to_rgb('black'),    0.49,   colors.ColorConverter().to_rgb('black'),
     colors.ColorConverter().to_rgb('black'),    0.51,   colors.ColorConverter().to_rgb('royalblue'),
     colors.ColorConverter().to_rgb('royalblue'),    1.,   colors.ColorConverter().to_rgb('royalblue')],
     'BlBlue')

plt.register_cmap(cmap=BlBlue)

Segmented = make_colormap(
    [colors.ColorConverter().to_rgb('skyblue'),
     colors.ColorConverter().to_rgb('dodgerblue'),      0.08,   colors.ColorConverter().to_rgb('dodgerblue'),
     colors.ColorConverter().to_rgb('royalblue'),       0.16,   colors.ColorConverter().to_rgb('royalblue'),
     colors.ColorConverter().to_rgb('navy'),            0.25,   colors.ColorConverter().to_rgb('lightgreen'),
     colors.ColorConverter().to_rgb('limegreen'),       0.33,   colors.ColorConverter().to_rgb('limegreen'),
     colors.ColorConverter().to_rgb('forestgreen'),     0.41,   colors.ColorConverter().to_rgb('forestgreen'),
     colors.ColorConverter().to_rgb('darkgreen'),       0.5,    colors.ColorConverter().to_rgb('gold'),
     colors.ColorConverter().to_rgb('orangered'),       0.58,   colors.ColorConverter().to_rgb('orangered'),
     colors.ColorConverter().to_rgb('red'),             0.66,   colors.ColorConverter().to_rgb('red'),
     colors.ColorConverter().to_rgb('darkred'),         0.75,   colors.ColorConverter().to_rgb('plum'),
     colors.ColorConverter().to_rgb('orchid'),          0.83,   colors.ColorConverter().to_rgb('orchid'),
     colors.ColorConverter().to_rgb('blueviolet'),      0.91,   colors.ColorConverter().to_rgb('blueviolet'),
     colors.ColorConverter().to_rgb('indigo'),          1.00,   colors.ColorConverter().to_rgb('indigo')
    ],
    'Segmented')

plt.register_cmap(cmap=Segmented)

Segmented3 = make_colormap(
    [colors.ColorConverter().to_rgb('skyblue'),
     colors.ColorConverter().to_rgb('dodgerblue'),      0.11,   colors.ColorConverter().to_rgb('dodgerblue'),
     colors.ColorConverter().to_rgb('royalblue'),       0.22,   colors.ColorConverter().to_rgb('royalblue'),
     colors.ColorConverter().to_rgb('navy'),            0.33,   colors.ColorConverter().to_rgb('lightgreen'),
     colors.ColorConverter().to_rgb('limegreen'),       0.44,   colors.ColorConverter().to_rgb('limegreen'),
     colors.ColorConverter().to_rgb('forestgreen'),     0.55,   colors.ColorConverter().to_rgb('forestgreen'),
     colors.ColorConverter().to_rgb('darkgreen'),       0.66,    colors.ColorConverter().to_rgb('gold'),
     colors.ColorConverter().to_rgb('orangered'),       0.77,   colors.ColorConverter().to_rgb('orangered'),
     colors.ColorConverter().to_rgb('red'),             0.88,   colors.ColorConverter().to_rgb('red'),
     colors.ColorConverter().to_rgb('darkred'),         1.00,   colors.ColorConverter().to_rgb('darkred')
    ],
    'Segmented3')

plt.register_cmap(cmap=Segmented3)

###################################
# Class NetArt and NetPoint
###################################
class Pt()  :
    def __init__(self,X,Y) :
        self.x  = X
        self.y  = Y
    def __del__(self):
      class_name = self.__class__.__name__
    #   print class_name, "destroyed"

class NetArt(object) :
    def __init__(self,ID):
        self.ID     = ID
        self.mPt    = []
        self.Data   = []
    def __del__(self):
      class_name = self.__class__.__name__
    #   print class_name, "destroyed"

###################################
###################################
def plot_csv_network(pathStore,title,Time,lFile,lFileSep,liX,liY,cbLabel,lDag,lL,lR,lAngle,xStart,yStart,xRange,yRange,cbScale,cbRange,cbMid,colorMap,lText,lTextPos,lTextAlign,lTextColor,nf) :

    nfig=nf ; fig = plt.figure(nfig,figsize=(8.,10.)) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0., right=0.7, bottom=0., top=1., wspace=0.1, hspace=0., width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    # ax0.tick_params(top='off',bottom='off',left='off',right='off');
    ax0.tick_params(top='off',bottom='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=1) ; ax0.locator_params(axis='y',tight=True, nbins=2)
    # Remove x and y axis
    ax0.axis("off")

    nArt = len(lFile)
    if ( len(lL)<nArt or len(lDag)<nArt or len(lR)<nArt or len(lAngle)<nArt ) :
        print("plot_csv_network: Error in length of input lists")
        sys.exit()
    if ( len(lFileSep)<nArt or len(liX)<nArt or len(liY)<nArt ) :
        print("plot_csv_network: Error in length of input lists")
        sys.exit()

    # Create points
    NetPt = []
    # Add points ( max is nArt + 1)
    for ip in range(nArt + 1) :
        NetPt.append( Pt( X=float(xStart),Y=float(yStart) ) )
    # Define arteries
    arts    = [NetArt(i) for i in range(nArt)]
    tmpArt  = [0]

    # Define arteries properties
    while (len(tmpArt)!=0) :
        tmpArt = []
        for i in range(nArt) :
            arts[i].L       = lL[i]
            arts[i].R       = lR[i]
            arts[i].Angle   = 3./2. * np.pi + lAngle[i]

            arts[i].File    = lFile[i]
            arts[i].FileSep = lFileSep[i]
            arts[i].iX      = liX[i]
            arts[i].liY     = liY[i]
            arts[i].fh      = open(arts[i].File,'r')

            # Read Dag
            hPt = lDag[i][0]
            tPt = lDag[i][1]
            # Check if hPt exists
            if ( hPt > len(NetPt) -1 ) :
                print("plot_csv_network: Head point does not exist",hPt,len(NetPt))
                sys.exit()
            # Check if hPt is assigned
            if ( hPt != 0 and NetPt[hPt].x == float(xStart) and NetPt[hPt].y ==float(yStart) ) :
                tmpArt.append(i)
            else :
                if ( NetPt[tPt].x == float(xStart) and NetPt[tPt].y == float(yStart)  ) :
                    X = NetPt[hPt].x + arts[i].L * np.cos(arts[i].Angle)
                    Y = NetPt[hPt].y + arts[i].L * np.sin(arts[i].Angle)
                    NetPt[tPt] = Pt( X=X,Y=Y )

    # Create artery hPt and tPt and read data
    for i in range(nArt) :
        # Read Dag
        hPt = lDag[i][0]
        tPt = lDag[i][1]
        arts[i].hPt = NetPt[hPt]
        arts[i].tPt = NetPt[tPt]

        # Find and create intermidiate points
        line = arts[i].fh.readline()
        dline = line.split(arts[i].FileSep)
        for iy in range(len(dline[1:])) :
            X = arts[i].hPt.x + float(dline[iy+1]) * np.cos(arts[i].Angle)
            Y = arts[i].hPt.y + float(dline[iy+1]) * np.sin(arts[i].Angle)
            arts[i].mPt.append( Pt(X=X,Y=Y) )

        # Find specific time (first line already read)
        for line in arts[i].fh :
            if not line.startswith('#') and not line.isspace() :
                dline = line.split(arts[i].FileSep)
                # Find specific time
                t = float(dline[arts[i].iX]) ;
                if (t>=Time) :
                    for im in range(len(arts[i].mPt)) :
                        arts[i].Data.append( float( dline[ arts[i].liY[im] ] ) )
                    break

        if (len(arts[i].Data) == 0) :
            print("plot_csv_network:: Time ", Time," not found for artery ",i)
            sys.exit()

        # Rescale
        for ix in range(len(arts[i].Data)) :
            arts[i].Data[ix] = arts[i].Data[ix] / cbScale

        # Interpolate data over ten points
        X = [] ; Y = [] ; XY = [] ; Z = [] ;
        X.append(arts[i].hPt.x) ; Y.append(arts[i].hPt.y) ; Z.append(arts[i].Data[0]) ;
        XY.append(X[0] + Y[0]) ;

        for im in range(1,len(arts[i].mPt)-1) :
            X.append(arts[i].mPt[im].x) ; Y.append(arts[i].mPt[im].y) ; Z.append(arts[i].Data[im]) ;
            XY.append(X[im]+Y[im]) ;

        X.append(arts[i].tPt.x) ; Y.append(arts[i].tPt.y) ; Z.append(arts[i].Data[len(arts[i].mPt)-1]) ;
        XY.append(X[len(X)-1] + Y[len(Y)-1])

        fZ = interp1d(XY,Z,kind='nearest')

        arts[i].X   = np.linspace(X[0],  X[len(X)-1],   10 )
        arts[i].Y   = np.linspace(Y[0],  Y[len(Y)-1],   10 )
        XXYY        = np.linspace(XY[0], XY[len(XY)-1], 10 )
        arts[i].Z   = fZ(XXYY)

    # Find min and max of data
    dMin = np.min(arts[0].Data) ; dMax = np.max(arts[0].Data) ;
    for i in range(1,nArt) :
        dMin = min( dMin, np.min(arts[i].Data))
        dMax = max( dMax, np.max(arts[i].Data))
    dMean = (dMax + dMin) / 2.

    # Create colormap
    cm          = plt.get_cmap(str(colorMap))
    # Find start, mid and end points for colormap
    cStart  = 0.
    cEnd    = 1.

    if (cbMid == "0") :
        if (dMin < 0. and dMax > 0.) :
            cMid = abs(dMin)/(dMax + abs(dMin))
        elif (dMin < 0. and dMax <=0.) :
            cMid = 1.
        elif (dMin >=0. and dMax > 0.) :
            cMid = 0.
        else :
            cMid = 0.5
    else :
        cMid = cbMid

    shiftedcm   = shiftedColorMap(cm,start=cStart,midpoint=cMid,stop=cEnd)
    shiftedcm.set_over(    "black")
    shiftedcm.set_under(   "white")
    if (cbRange != []) :
        cNorm   = colors.Normalize(vmin=cbRange[0], vmax=cbRange[1])
    else :
        cNorm   = colors.Normalize(vmin=dMin, vmax=dMax)

    scalarMap   = cmx.ScalarMappable(norm=cNorm, cmap=shiftedcm)
    scalarMap.set_array([])
    # Create colorbar
    cbaxes      = fig.add_axes([0.73, 0.15, 0.03, 0.75])
    cb          = plt.colorbar(scalarMap, cbaxes, extend='both')
    cb.set_label(cbLabel)

    # Increase factor for radius size
    factR = 3#7#9.

    # Plot artery
    for i in range(nArt) :

        for im in range(1,len(arts[i].Z)) :
            colArt = scalarMap.to_rgba(0.5*(arts[i].Z[im-1]+arts[i].Z[im]))
            ax0.plot(
                    [arts[i].X[im-1],arts[i].X[im]],[arts[i].Y[im-1],arts[i].Y[im]],
                    color=colArt, linewidth=factR, #arts[i].R * factR, #, linewidth=factR,
                    mec = "black" , mfc="none", mew=0, marker="", markersize=0, markevery=0, linestyle="-" , alpha=1
                    )

    # Plot circle
    ##############
    # ax0.plot((arts[3].X[int(len(arts[3].X)/2.)]),(arts[3].Y[int(len(arts[3].Y)/2.)]),'o',markersize=15,color='black')
    # ax0.plot((arts[6].X[int(len(arts[6].X)/2.)]),(arts[6].Y[int(len(arts[6].Y)/2.)]),'o',markersize=15,color='black')
    # ax0.plot((arts[14].X[int(len(arts[14].X)/2.)]),(arts[14].Y[int(len(arts[14].Y)/2.)]),'o',markersize=15,color='black')
    # ax0.plot((arts[1].X[int(len(arts[1].X)/2.)]),(arts[1].Y[int(len(arts[1].Y)/2.)]),'o',markersize=15,color='black')

    # Set xrange & yrang
    ######################
    if (xRange != []) :
        ax0.set_xlim(xRange[0],xRange[1])
    if (yRange != []) :
        ax0.set_ylim(yRange[0],yRange[1])

    # Add text
    ######################
    nText = len(lText)
    for iT in range(nText) :
        xT = lTextPos[iT][0];
        yT = lTextPos[iT][1];
        text = str(lText[iT]);
        align = str(lTextAlign[iT]);
        colT = str(lTextColor[iT]) ;
        ax0.text(xT,yT,text,horizontalalignment=align,color=colT,transform=ax0.transAxes)

    # Title
    ######################
    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

###################################
###################################
def animate_csv_network(pathStore,title,lFile,lFileSep,liX,liY,cbLabel,lDag,lL,lR,lAngle,xStart,yStart,xRange,yRange,cbRange,cbMid,colorMap,TextPos,TextAlign,TextColor,speedUp,slowDownfps,nf) :

    matplotlib.rc('text', usetex='False', color='black')

    nfig=nf ; fig = plt.figure(nfig,figsize=(8.,10.)) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0., right=0.75, bottom=0., top=1., wspace=0.1, hspace=0., width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',bottom='off',left='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)
    # Remove x and y axis
    ax0.axis("off")

    nArt = len(lFile)
    if ( len(lL)<nArt or len(lDag)<nArt or len(lR)<nArt or len(lAngle)<nArt ) :
        print("plot_csv_network: Error in length of input lists")
        sys.exit()
    if ( len(lFileSep)<nArt or len(liX)<nArt or len(liY)<nArt ) :
        print("plot_csv_network: Error in length of input lists")
        sys.exit()

    # Time parameters
    fTime = open(lFile[0],'r') ; fTime.readline() ; fTime.readline() ;
    line0 = fTime.readline() ; dline0 = line0.split(lFileSep[0])
    line1 = fTime.readline() ; dline1 = line1.split(lFileSep[0])
    for line in fTime :
        dlinef = line.split(lFileSep[0])
    fTime.close()

    increaseSpeed   = int(speedUp)
    dt              = (float(dline1[0])-float(dline0[0])) * increaseSpeed
    tmin            = float(dline1[0])
    tmax            = float(dlinef[0])
    numFrames       = int( (tmax-tmin ) / dt )

    time_text   = ax0.text(TextPos[0],TextPos[1],'',horizontalalignment=str(TextAlign),color=str(TextColor),transform=ax0.transAxes)

    # Create points
    NetPt = []
    # Add points ( max is nArt + 1)
    for ip in range(nArt + 1) :
        NetPt.append( Pt( X=float(xStart),Y=float(yStart) ) )
    # Define arteries
    arts    = [NetArt(i) for i in range(nArt)]
    tmpArt  = []

    # Define arteries properties
    for i in range(nArt) :
        arts[i].L       = lL[i]
        arts[i].R       = lR[i]
        arts[i].Angle   = 3./2. * np.pi + lAngle[i]

        arts[i].File    = lFile[i]
        arts[i].FileSep = lFileSep[i]
        arts[i].iX      = liX[i]
        arts[i].liY     = liY[i]
        arts[i].fh      = open(arts[i].File,'r')

        # Read Dag
        hPt = lDag[i][0]
        tPt = lDag[i][1]
        # Check if hPt exists
        if ( hPt > len(NetPt) -1 ) :
            print("plot_csv_network: Head point does not exist")
            sys.exit()
        # Check if hPt is assigned
        if ( hPt != 0 and NetPt[hPt].x == float(xStart) and NetPt[hPt].y ==float(yStart) ) :
            tmpArt.append(i)
        else :
            if ( NetPt[tPt].x == float(xStart) and NetPt[tPt].y == float(yStart)  ) :
                X = NetPt[hPt].x + arts[i].L * np.cos(arts[i].Angle)
                Y = NetPt[hPt].y + arts[i].L * np.sin(arts[i].Angle)
                NetPt[tPt] = Pt( X=X,Y=Y )

    # Loop on untreated arteries
    for i in tmpArt :
        # Read Dag
        hPt = lDag[i][0]
        tPt = lDag[i][1]
        X = NetPt[hPt].x + arts[i].L * np.cos(arts[i].Angle)
        Y = NetPt[hPt].y + arts[i].L * np.sin(arts[i].Angle)
        NetPt[tPt] = Pt( X=X,Y=Y )

    # Create artery hPt and tPt and read data
    for i in range(nArt) :
        # Read Dag
        hPt = lDag[i][0]
        tPt = lDag[i][1]
        arts[i].hPt = NetPt[hPt]
        arts[i].tPt = NetPt[tPt]

        # Find and create intermidiate points
        line = arts[i].fh.readline()
        dline = line.split(arts[i].FileSep)
        for iy in range(len(dline[1:])) :
            X = arts[i].hPt.x + float(dline[iy+1]) * np.cos(arts[i].Angle)
            Y = arts[i].hPt.y + float(dline[iy+1]) * np.sin(arts[i].Angle)
            arts[i].mPt.append( Pt(X=X,Y=Y) )

        # Read first time
        arts[i].fh.readline()

        # Read data
        for line in arts[i].fh :
            dline           = line.split(arts[i].FileSep)
            tmp = []
            for im in range(len(arts[i].mPt)) :
                tmp.append( float( dline[ arts[i].liY[im] ] ) )
            arts[i].Data.append( tmp )

    # Create colormap
    cm          = plt.get_cmap(str(colorMap))
    shiftedcm   = remappedColorMap(cm,start=0,midpoint=cbMid,stop=1)
    shiftedcm.set_over(    "yellow")
    shiftedcm.set_under(   "fuchsia")
    cNorm       = colors.Normalize(vmin=cbRange[0], vmax=cbRange[1])
    scalarMap   = cmx.ScalarMappable(norm=cNorm, cmap=shiftedcm)
    scalarMap.set_array([])
    # Create colorbar
    cbaxes      = fig.add_axes([0.73, 0.15, 0.03, 0.75])
    cb          = plt.colorbar(scalarMap, cbaxes, extend='both')
    cb.set_label(cbLabel)

    # Increase factor for radius size
    factR = 6.

    def init_func() :
        time_text.set_text(r'$t$=$0$') ;
        return time_text,

    # Animate network
    def animate_movie(it):

        # Clear axe
        ax0.clear()
        ax0.axis("off")
        # ax0.set_aspect(0.9)
        # Set xrange & yrange
        if (xRange != []) :
            ax0.set_xlim(xRange[0],xRange[1])
        if (yRange != []) :
            ax0.set_ylim(yRange[0],yRange[1])

        # Plot artery
        for i in range(nArt) :

            # Create first line
            colArt = scalarMap.to_rgba(arts[i].Data[it*increaseSpeed][0])
            ax0.plot(
                    [arts[i].hPt.x,arts[i].mPt[0].x],[arts[i].hPt.y,arts[i].mPt[0].y],
                    color=colArt, linewidth=factR, #arts[i].R * factR,
                    mec = "black" , mfc="none", mew=0, marker="", markersize=0, markevery=0, linestyle="-" , alpha=1
                    )
            # Create intermidiate line
            for im in range(1,len(arts[i].mPt)) :
                colArt = scalarMap.to_rgba( 0.5 * (arts[i].Data[it*increaseSpeed][im-1] + arts[i].Data[it*increaseSpeed][im]) )
                ax0.plot(
                        [arts[i].mPt[im-1].x,arts[i].mPt[im].x],[arts[i].mPt[im-1].y,arts[i].mPt[im].y],
                        color=colArt, linewidth=factR, #arts[i].R * factR,
                        mec = "black" , mfc="none", mew=0, marker="", markersize=0, markevery=0, linestyle="-" , alpha=1
                        )
            # Create last line
            colArt = scalarMap.to_rgba(arts[i].Data[it*increaseSpeed][len(arts[i].mPt)-1])
            ax0.plot(
                    [arts[i].mPt[len(arts[i].mPt)-1].x,arts[i].tPt.x],[arts[i].mPt[len(arts[i].mPt)-1].y,arts[i].tPt.y],
                    color=colArt, linewidth=factR, #arts[i].R * factR,
                    mec = "black" , mfc="none", mew=0, marker="", markersize=0, markevery=0, linestyle="-" , alpha=1
                    )

        # Time
        t = tmin + it * dt
        print("t = ",t)
        ax0.text(TextPos[0],TextPos[1],r'$t$=' + str(t),horizontalalignment=str(TextAlign),color=str(TextColor),transform=ax0.transAxes)

        return time_text,

    # Run animation
    ###############
    interval = dt
    ani = animation.FuncAnimation(  fig, animate_movie,init_func = init_func,
                                    frames= numFrames, blit=True,
                                    interval = interval, repeat = False)

    # Write for animation
    #####################
    fps         = int(  1. / dt / float(slowDownfps) )
    writer      = FFMpegWriter(fps=fps, metadata=metadata, bitrate=-1, codec = "libx264", extra_args=['-pix_fmt', 'yuv420p'])

    movie_title = pathStore+str(title)
    ani.save(   movie_title, writer=writer, savefig_kwargs={})

    # Close file
    for i in range(nArt) :
        arts[i].fh.close()

    return nfig
