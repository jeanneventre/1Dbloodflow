#!/usr/bin/python2.7

__author__      = "Arthur R. Ghigo"
__copyright__   = "Copyright 2015, UPMC IJLRDA"
__credits__     = ["Arthur R. Ghigo"]
__license__     = "GPL"
__version__     = "1.0.0"
__maintainer__  = "Arthur R. Ghigo"
__email__       = "arthur.ghigo@dalembert.upmc.fr"
__status__      = "Prototype"

# import sys
# import numpy as np
# import math as mt
# import matplotlib
# # Font
# matplotlib.rc('font', family='serif', serif='cm', style='normal', weight='normal',size = '25')
# # Text
# matplotlib.rc('text', usetex='True', color='black')
# matplotlib.rcParams['text.latex.preamble'] = [r'\usepackage{amsmath}',r'\usepackage{amssymb}']
# # matplotlib.rcParams['text.latex.preamble'] = [r'\boldmath']
# # Mathtext (if usetex = false)
# # Lines
# matplotlib.rc('lines', linewidth='1', linestyle='-', markersize='5',markeredgewidth='0.5', antialiased='True')
# # Axes
# # matplotlib.rcParams['axes.formatter.use_mathtext'] = 'true'
# matplotlib.rcParams['axes.unicode_minus'] = 'true'
# matplotlib.rc('axes', grid='False', titlesize='20', labelsize='20', labelpad='5', labelweight='normal')
# matplotlib.rc('axes', xmargin='0.',ymargin='0.2')
# # Ticks
# matplotlib.rc('xtick', labelsize='20', direction='in')
# matplotlib.rcParams['xtick.major.size'] ='4' ; matplotlib.rcParams['xtick.minor.size'] ='2'
# matplotlib.rc('ytick', labelsize='20', direction='in')
# matplotlib.rcParams['ytick.major.size'] ='4' ; matplotlib.rcParams['ytick.minor.size'] ='2'
# # Legend
# matplotlib.rc('legend', fancybox='True', frameon='False', framealpha=0., fontsize='25',handletextpad="0.1",borderaxespad="0.",columnspacing="0.4",borderpad="0.2",handlelength="1.",handleheight="0.",labelspacing="0.1")
# matplotlib.rcParams['legend.numpoints'] = 1
# # Grid
# matplotlib.rc('grid', alpha='0.')
# # Figure
# matplotlib.rc('figure', figsize='8,6', dpi='1000')
# # TkAgg
# matplotlib.use('TkAgg')
# import matplotlib.pyplot as plt
# import matplotlib.cm as cmx
# import matplotlib.colors as colors
# import matplotlib.colorbar as mcolorbar
# from mpl_toolkits.mplot3d import Axes3D
# import matplotlib.gridspec as gridspec
# from scipy.interpolate import griddata
#
# from matplotlib.ticker import ScalarFormatter

from help_plot import *

# def align_yaxis(ax1, v1, ax2, v2):
#     """adjust ax2 ylimit so that v2 in ax2 is aligned to v1 in ax1"""
#     _, y1 = ax1.transData.transform((0, v1))
#     _, y2 = ax2.transData.transform((0, v2))
#     adjust_yaxis(ax2,(y1-y2)/2,v2)
#     adjust_yaxis(ax1,(y2-y1)/2,v1)
#
# def adjust_yaxis(ax,ydif,v):
#     """shift axis ax by ydiff, maintaining point v at the same location"""
#     inv = ax.transData.inverted()
#     _, dy = inv.transform((0, 0)) - inv.transform((0, ydif))
#     miny, maxy = ax.get_ylim()
#     miny, maxy = miny - v, maxy - v
#     if -miny>maxy or (-miny==maxy and dy > 0):
#         nminy = miny
#         nmaxy = miny*(maxy+dy)/(miny+dy)
#     else:
#         nmaxy = maxy
#         nminy = maxy*(miny+dy)/(maxy+dy)
#     ax.set_ylim(nminy+v, nmaxy+v)
#
# def get_cmap(N):
#
#     color_norm  = colors.Normalize(vmin=0, vmax=N-1)
#     scalar_map = cmx.ScalarMappable(norm=color_norm, cmap=cmx.jet)
#     def map_index_to_rgb_color(index):
#         return scalar_map.to_rgba(index)
#     return map_index_to_rgb_color
#
# def remappedColorMap(cmap, start=0, midpoint=0.5, stop=1.0,
# name='shiftedcmap'):
#     '''
#     Function to offset the median value of a colormap, and scale the
#     remaining color range. Useful for data with a negative minimum and
#     positive maximum where you want the middle of the colormap's dynamic
#     range to be at zero.
#     Input
#     -----
#       cmap : The matplotlib colormap to be altered
#       start : Offset from lowest point in the colormap's range.
#           Defaults to 0.0 (no lower ofset). Should be between
#           0.0 and 0.5; if your dataset mean is negative you should leave
#           this at 0.0, otherwise to (vmax-abs(vmin))/(2*vmax)
#       midpoint : The new center of the colormap. Defaults to
#           0.5 (no shift). Should be between 0.0 and 1.0; usually the
#           optimal value is abs(vmin)/(vmax+abs(vmin))
#       stop : Offset from highets point in the colormap's range.
#           Defaults to 1.0 (no upper ofset). Should be between
#           0.5 and 1.0; if your dataset mean is positive you should leave
#           this at 1.0, otherwise to (abs(vmin)-vmax)/(2*abs(vmin))
#     '''
#     cdict = {
#         'red': [],
#         'green': [],
#         'blue': [],
#         'alpha': []
#     }
#
#     # regular index to compute the colors
#     reg_index = np.hstack([
#         np.linspace(start, 0.5, 128, endpoint=False),
#         np.linspace(0.5, stop, 129)
#     ])
#
#     # shifted index to match the data
#     shift_index = np.hstack([
#         np.linspace(0.0, midpoint, 128, endpoint=False),
#         np.linspace(midpoint, 1.0, 129)
#     ])
#
#     for ri, si in zip(reg_index, shift_index):
#         r, g, b, a = cmap(ri)
#
#         cdict['red'].append((si, r, r))
#         cdict['green'].append((si, g, g))
#         cdict['blue'].append((si, b, b))
#         cdict['alpha'].append((si, a, a))
#
#     newcmap = matplotlib.colors.LinearSegmentedColormap(name, cdict)
#     plt.register_cmap(cmap=newcmap)
#
#     return newcmap
#
# def make_colormap(seq,name):
#     """Return a LinearSegmentedColormap
#     seq: a sequence of floats and RGB-tuples. The floats should be increasing
#     and in the interval (0,1).
#     """
#     seq = [(None,) * 3, 0.0] + list(seq) + [1.0, (None,) * 3]
#     cdict = {'red': [], 'green': [], 'blue': []}
#     for i, item in enumerate(seq):
#         if isinstance(item, float):
#             r1, g1, b1 = seq[i - 1]
#             r2, g2, b2 = seq[i + 1]
#             cdict['red'].append([item, r1, r2])
#             cdict['green'].append([item, g1, g2])
#             cdict['blue'].append([item, b1, b2])
#
#     return colors.LinearSegmentedColormap(name, cdict)
#
BlueRed = make_colormap(
    [colors.ColorConverter().to_rgb('navy'),
     colors.ColorConverter().to_rgb('mediumblue'),    0.1,   colors.ColorConverter().to_rgb('mediumblue'),
     colors.ColorConverter().to_rgb('Blue'),    0.2,   colors.ColorConverter().to_rgb('Blue'),
     colors.ColorConverter().to_rgb('royalblue'), 0.3,   colors.ColorConverter().to_rgb('royalblue'),
     colors.ColorConverter().to_rgb('dodgerblue'), 0.4,   colors.ColorConverter().to_rgb('dodgerblue'),
     colors.ColorConverter().to_rgb('deepskyblue'), 0.5,   colors.ColorConverter().to_rgb('coral'),
     colors.ColorConverter().to_rgb('darkorange'), 0.6,   colors.ColorConverter().to_rgb('darkorange'),
     colors.ColorConverter().to_rgb('orangered'), 0.7,   colors.ColorConverter().to_rgb('orangered'),
     colors.ColorConverter().to_rgb('tomato'), 0.8,   colors.ColorConverter().to_rgb('tomato'),
     colors.ColorConverter().to_rgb('red'), 0.9,   colors.ColorConverter().to_rgb('red'),
     colors.ColorConverter().to_rgb('darkred'), 0.95,   colors.ColorConverter().to_rgb('darkred')],'BlueRed')

plt.register_cmap(cmap=BlueRed)

#FIND MATCHING Indices
def findMatch(x1,x2) :

    n1 = len(x1); n2 = len(x2);
    if (n1 <= n2) :
        xS = x1 ; xL = x2;
        nS = n1 ; nL = n2;
    else :
        xS = x2 ; xL = x1;
        nS = n2 ; nL = n1;

    indice = []
    iS = 0;
    for ip in range(nL) :
        if ( iS < nS ) :

            xmatch = xS[iS] ;
            xp = xL[ip] ;

            if (ip == 0 and xp > xmatch) :
                errp = abs(xp-xmatch)/abs(xL[nL-1]);
                if ( errp < 0.01 ) :
                    indice.append(ip) ; iS += 1 ;
                else :
                    print(xp,xmatch)
                    print("findMatch: No match possible")
                    sys.exit()

            elif (xp == xmatch) :
                indice.append(ip) ; iS += 1 ;
            elif (xp > xmatch) :
                errp = abs(xp-xmatch)
                errm = abs(xm-xmatch)
                if (errp >= errm) :
                    indice.append(ip) ; iS += 1 ;
                else :
                    indice.append(im) ; iS += 1 ;
            xm = xp ; im = ip ;

    if (len(indice) != nS):
        print(len(indice) , nS)
        print("findMatch: Error in length of indice")
        sys.exit()

    return indice
#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_csv_Profile(pathStore,title,lFile,liX,liY,xLabel,yLabel,lLabel,LegLoc,LegPos,LegCol,lText,lTextPos,lTextAlign,lTextColor,lCol,lMark,lMarkSize,lMarkWidth,MarkPoints,lLineSize,lStyle,lAlpha,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)<nPlot or len(liY)<nPlot or len(lLabel)<nPlot or len(lCol)<nPlot or len(lMark)<nPlot or len(lStyle)<nPlot) :
        print("plot_csv_Profile: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=',')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Profile: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        col = lCol[i] ; mark=str(lMark[i]) ; style = str(lStyle[i]);
        mSize = int(lMarkSize[i]) ; mWidth = int(lMarkWidth[i]) ; lSize = int(lLineSize[i]) ;
        alpha = float(lAlpha[i]) ;

        npos = len(lData[i][:,0])

        ax0.plot(lData[i][1:,iX],lData[i][1:,iY],label=label, color=col, mec = col , mfc="none", mew=mWidth, marker=mark, markersize=mSize, markevery=max(1,int(float(npos)/float(MarkPoints))), linestyle=style , linewidth=lSize, alpha=alpha)

    # Vertical line in U=0
    ######################
    ax0.plot((0,0),(-1,1),color="grey",linewidth=1,linestyle="--")
    ax0.axhline(0,color="grey",linewidth=1,linestyle="--")

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=int(LegLoc),bbox_to_anchor=(float(LegPos[0]),float(LegPos[1])),ncol=int(LegCol),borderaxespad=0.)

    # Set xrange
    ######################
    # ax0.set_xlim(0.2,0.8  )

    # Add text
    ######################
    nText = len(lText)
    for iT in range(nText) :
        xT = lTextPos[iT][0];
        yT = lTextPos[iT][1];
        text = str(lText[iT]);
        align = str(lTextAlign[iT]);
        colT = str(lTextColor[iT]) ;
        ax0.text(xT,yT,text,horizontalalignment=align,color=colT,transform=ax0.transAxes)

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_csv_Profile_adim(pathStore,title,lFile,liX,liY,xLabel,yLabel,lLabel,lXScale,lYScale,xRange,yRange,xMargin,yMargin,lXOffset,lYOffset,LegLoc,LegPos,LegCol,lText,lTextPos,lTextAlign,lTextColor,lCol,lMark,lMarkSize,lMarkWidth,MarkPoints,lLineSize,lStyle,lAlpha,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=6) ; ax0.locator_params(axis='y',tight=True, nbins=2)

    nPlot = len(lFile)
    if (len(liX)<nPlot or len(liY)<nPlot or len(lLabel)<nPlot or len(lCol)<nPlot or len(lMark)<nPlot or len(lStyle)<nPlot) :
        print("plot_csv_Profile: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=',')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Profile: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        xScale = float(lXScale[i]) ; yScale = float(lYScale[i]) ;

        if (lXOffset[i] == "first") :
            xOffset = lData[i][1,iX]
        else :
            xOffset = float(lXOffset[i]) ;

        if (lYOffset[i] == "first") :
            yOffset = lData[i][1,iY]
        elif (lYOffset[i] == "last") :
            yOffset = lData[i][len(lData[i][:,iY])-2,iY]
        else :
            yOffset = float(lYOffset[i]) ;

        col = lCol[i] ; mark=str(lMark[i]) ; style = str(lStyle[i]);
        mSize = int(lMarkSize[i]) ; mWidth = int(lMarkWidth[i]) ; lSize = int(lLineSize[i]) ;
        alpha = float(lAlpha[i]) ;

        npos = len(lData[i][:,0])

        X = (lData[i][1:,iX] - xOffset ) / xScale
        Y = (lData[i][1:,iY] - yOffset ) / yScale

        ax0.plot(X,Y,label=label, color=col, mec = col , mfc="none", mew=mWidth, marker=mark, markersize=mSize, markevery=max(1,int(float(npos)/float(MarkPoints))), linestyle=style , linewidth=lSize, alpha=alpha)

    # # Flat velocity profile
    # #######################
    # ax0.plot(Y/Y,Y, color = "black", linestyle="--" , linewidth=2)
    # # Poiseuille velocity profile
    # #######################
    # ax0.plot(2.*(1-Y*Y),Y, label=r"$Poiseuille$",color = "black", linestyle="--" , linewidth=2)

    # Min and Max values
    ####################
    xmin, xmax = ax0.get_xlim()
    ymin, ymax = ax0.get_ylim()

    # Vertical line in U=0
    ######################
    if (xRange != []) :
        if (xRange[0] < 0) :
                ax0.plot((0,0),(-1,1),color="black",linewidth=2,linestyle="--")
    elif (xmin < 0) :
        ax0.plot((0,0),(-1,1),color="black",linewidth=2,linestyle="--")

    if (yRange != []) :
        if (yRange[0] < 0 and yRange[1] > 0) :
            ax0.axhline(0,color="black",linewidth=2,linestyle="--")
    elif (ymin < 0 and ymax > 0) :
        ax0.axhline(0,color="black",linewidth=2,linestyle="--")

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=int(LegLoc),bbox_to_anchor=(float(LegPos[0]),float(LegPos[1])),ncol=int(LegCol),borderaxespad=0.)

    # Set xrange & yrange
    ######################
    if (xRange != []) :
        dxRange     = abs(xRange[1]-xRange[0])
        xRangemin   = xRange[0] - float(xMargin) * dxRange
        xRangemax   = xRange[1] + float(xMargin) * dxRange
    else :
        dxRange     = abs(xmax-xmin)
        xRangemin   = xmin - float(xMargin) * dxRange
        xRangemax   = xmax + float(xMargin) * dxRange

    if (yRange != []) :
        dyRange     = abs(yRange[1]-yRange[0])
        yRangemin   = yRange[0] - float(yMargin) * dyRange
        yRangemax   = yRange[1] + float(yMargin) * dyRange
    else :
        dyRange     = abs(ymax-ymin)
        yRangemin   = ymin - float(yMargin) * dyRange
        yRangemax   = ymax + float(yMargin) * dyRange

    ax0.set_xlim(xRangemin,xRangemax)
    ax0.set_ylim(yRangemin,yRangemax)

    # Add text
    ######################
    nText = len(lText)
    for iT in range(nText) :
        xT = lTextPos[iT][0];
        yT = lTextPos[iT][1];
        text = str(lText[iT]);
        align = str(lTextAlign[iT]);
        colT = str(lTextColor[iT]) ;
        ax0.text(xT,yT,text,horizontalalignment=align,color=colT,transform=ax0.transAxes)

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

#########################################################################
# FULL ARTERY
#########################################################################
#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_csv_Streamlines_Ux(pathStore,title,PropFile,ProFile,lPropX,liY,nArrow,scArrow,Colormap,Umid,lText,lTextPos,lTextAlign,lTextColor,nf) :

    matplotlib.rc('xtick', direction='out') ; matplotlib.rc('ytick', direction='out')
    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.85, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=6) ; ax0.locator_params(axis='y',tight=True, nbins=2)

    if (len(lPropX) != 4) :
        print("plot_csv_Streamlines_Ux: Error in length of lPropX")
        sys.exit()

    # Indices
    #########
    it  = lPropX[0] ;
    ix  = lPropX[1] ;
    iR0 = lPropX[2] ;
    iR  = lPropX[3] ;

    # List of profile data
    ######################
    Profile = np.genfromtxt(ProFile, delimiter=',')

    # Propoerties of the artery
    ###########################
    Properties = np.genfromtxt(PropFile, delimiter=',')

    x = Profile[0,liY]
    r = Profile[1:,0]
    nX = len(x) ; nL = len(r) ;

    time = Properties[0,it]
    pos  = Properties[:,ix]
    R0   = Properties[:,iR0]
    R    = Properties[:,iR]

    Umax = np.amax(Profile[1:,liY]) ; Umin = np.amin(Profile[1:,liY])

    if (nX != len(liY)) :
        print(nX , len(liY))
        print("plot_csv_Streamlines_Ux: Error in length of liY")
        sys.exit()

    # Find indice of matching position
    ##################################
    ipos = findMatch(x,pos)
    if (len(ipos) != len(liY)) :
        print(len(ipos) , len(liY))
        print("plot_csv_Streamlines_Ux: Error in length of ipos")
        sys.exit()

    # Definie U and V
    #################
    U = np.zeros((nL,nX)) ; V = np.zeros((nL,nX)) ;
    for ip in range(nX) :
        U[:,ip] = Profile[1:,int(liY[ip])]
    # Define the scaling of the colors
    ##################################
    C = U

    # Define walls
    ################
    Rmax = np.amax(R) * 1.2 ; hwall = Rmax*0.1 ; wall = R + hwall

    # Define the interval beteewn the arrow
    ################
    nY = int(nArrow)
    interX = 1
    if (nL < nY) :
        interY = 1
    else :
        interY= int( float(nL)/float(nY))
    # Scale the length of the arrows:
    sc = float(scArrow) * Umax * float(nX)/float(interX)

    # COLORMAP
    ################
    start = 0. ;
    mid = Umid / (Umax + abs(Umin))
    stop = 1. ;
    colormap = plt.cm.get_cmap(str(Colormap))
    shiftedcolormap = shiftedColorMap(colormap, start = start , midpoint=mid, stop = stop , name='shifted')
    # Create the grid:
    ################
    xo,ro = np.meshgrid(x,r)
    # Modify Y
    Y = ro
    for ip in range(nX) :
        Y[:,ip] = ro[:,ip] * R[ipos[ip]]

    # PLOT
    ################
    quiv = ax0.quiver(  xo[::interY,::interX],Y[::interY,::interX],
                        U[::interY,::interX],V[::interY,::interX],
                        C[::interY,::interX],cmap=shiftedcolormap,
                        units='width',scale=sc,scale_units='width',
                        clim=(Umin,Umax),animated=True)

    # COLORBAR
    ################
    cbaxes = fig.add_axes([0.86, 0.1, 0.01, 0.8])
    cb = plt.colorbar(quiv, cax = cbaxes)
    cb.set_label(r'$U_x$ ($\frac{cm}{s}$)')

    # Plot initial geometry
    ################
    ax0.plot(pos,R0,    color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
    ax0.plot(pos,-R0,   color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
    # Plot arterial Wall (R0+h)
    ################
    ax0.plot(pos,wall,  color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
    ax0.plot(pos,-wall, color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
    # Plot instateneous arterial Wall
    ################
    ax0.plot(pos, R,    color='red',alpha=1,linestyle="-",linewidth=1)
    ax0.plot(pos,-R,    color='red',alpha=1,linestyle="-",linewidth=1)
    # Fill the Wall
    ################
    ax0.fill_between(pos,  R, wall, facecolor='grey', alpha=0.3)
    ax0.fill_between(pos, -R, -wall, facecolor='grey', alpha=0.3)

    # Labels
    ################
    ax0.set_xlabel(r"$x$ ($cm$)") ; ax0.set_ylabel(r"$r$ ($cm$)")
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Add text
    ######################
    nText = len(lText)
    for iT in range(nText) :
        xT = lTextPos[iT][0];
        yT = lTextPos[iT][1];
        text = str(lText[iT]);
        align = str(lTextAlign[iT]);
        colT = str(lTextColor[iT]) ;
        ax0.text(xT,yT,text,horizontalalignment=align,color=colT,transform=ax0.transAxes)

    # Create file
    #############
    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

def plot_csv_Streamlines_Ux_adim(pathStore,title,PropFile,ProFile,lPropX,liY,xLabel,yLabel,cbLabel,xScale,yScale,cbScale,cbRange,nArrow,scArrow,Colormap,Umid,lText,lTextPos,lTextAlign,lTextColor,nf) :

    matplotlib.rc('xtick', direction='out') ; matplotlib.rc('ytick', direction='out')
    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.85, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=6) ; ax0.locator_params(axis='y',tight=True, nbins=2)

    if (len(lPropX) != 4) :
        print("plot_csv_Streamlines_Ux: Error in length of lPropX")
        sys.exit()

    # Indices
    #########
    it  = lPropX[0] ;
    ix  = lPropX[1] ;
    iR0 = lPropX[2] ;
    iR  = lPropX[3] ;

    # List of profile data
    ######################
    Profile = np.genfromtxt(ProFile, delimiter=',')

    # Propoerties of the artery
    ###########################
    Properties = np.genfromtxt(PropFile, delimiter=',')

    x = Profile[0,liY] / float(xScale)
    r = Profile[1:,0]
    nX = len(x) ; nL = len(r) ;

    time = Properties[0,it]
    pos  = Properties[:,ix] / float(xScale)
    R0   = Properties[:,iR0] / float(yScale)
    R    = Properties[:,iR] / float(yScale)

    if (cbRange != []) :
        Umin = cbRange[0]
        Umax = cbRange[1]
    else :
        Umax = np.amax(Profile[1:,liY]) / float(cbScale) ;
        Umin = np.amin(Profile[1:,liY]) / float(cbScale)


    if (nX != len(liY)) :
        print(nX , len(liY))
        print("plot_csv_Streamlines_Ux: Error in length of liY")
        sys.exit()

    # Find indice of matching position
    ##################################
    ipos = findMatch(x,pos)
    if (len(ipos) != len(liY)) :
        print(len(ipos) , len(liY))
        print("plot_csv_Streamlines_Ux: Error in length of ipos")
        sys.exit()

    # Definie U and V
    #################
    U = np.zeros((nL,nX)) ; V = np.zeros((nL,nX)) ;
    for ip in range(nX) :
        U[:,ip] = Profile[1:,int(liY[ip])] / float(cbScale)
    # Define the scaling of the colors
    ##################################
    C = U

    # Define walls
    ################
    Rmax = np.amax(R) * 1.2 ; hwall = Rmax*0.1 ; wall = R + hwall

    # Define the interval beteewn the arrow
    ################
    nY = int(nArrow)
    interX = 1
    if (nL < nY) :
        interY = 1
    else :
        interY= int( float(nL)/float(nY))
    # Scale the length of the arrows:
    sc = float(scArrow) * Umax * float(nX)/float(interX)

    # COLORMAP
    ################
    start = 0. ;
    # if (Umid >= Umax) :
    if (Umin < 0.) :
        mid = (0 - Umin) / (Umax - Umin)
    else :
        mid = (Umid-Umin) / (Umax - Umin)
    stop = 1. ;
    colormap = plt.cm.get_cmap(str(Colormap))
    shiftedcolormap = shiftedColorMap(colormap, start = start , midpoint=mid, stop = stop , name='shifted')

    # Create the grid:
    ################
    xo,ro = np.meshgrid(x,r)
    # Modify Y
    Y = ro
    for ip in range(nX) :
        Y[:,ip] = ro[:,ip] * R[ipos[ip]]

    # PLOT
    ################
    quiv = ax0.quiver(  xo[::interY,::interX],Y[::interY,::interX],
                        U[::interY,::interX],V[::interY,::interX],
                        C[::interY,::interX],cmap=shiftedcolormap,
                        units='width',scale=sc,scale_units='width',
                        clim=(Umin,Umax),animated=True)

    # COLORBAR
    ################
    cbaxes = fig.add_axes([0.86, 0.1, 0.01, 0.8])
    cb = plt.colorbar(quiv, cax = cbaxes)
    cb.set_label(cbLabel)

    # Plot initial geometry
    ################
    # ax0.plot(pos,R0,    color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
    # ax0.plot(pos,-R0,   color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
    # Plot arterial Wall (R0+h)
    ################
    ax0.plot(pos,wall,  color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
    ax0.plot(pos,-wall, color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
    # Plot instateneous arterial Wall
    ################
    ax0.plot(pos, R,    color='red',alpha=1,linestyle="-",linewidth=1)
    ax0.plot(pos,-R,    color='red',alpha=1,linestyle="-",linewidth=1)
    # Fill the Wall
    ################
    ax0.fill_between(pos,  R, wall, facecolor='grey', alpha=0.3)
    ax0.fill_between(pos, -R, -wall, facecolor='grey', alpha=0.3)

    # Labels
    ################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel)
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Add text
    ######################
    nText = len(lText)
    for iT in range(nText) :
        xT = lTextPos[iT][0];
        yT = lTextPos[iT][1];
        text = str(lText[iT]);
        align = str(lTextAlign[iT]);
        colT = str(lTextColor[iT]) ;
        ax0.text(xT,yT,text,horizontalalignment=align,color=colT,transform=ax0.transAxes)

    # Create file
    #############
    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig
#########################################################################
# POISEUILLE
#########################################################################
#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_csv_Profile_Individual_x_Poiseuille(pathStore,title,lFile,iProf,xLabel,yLabel,lLabel,lCol,lMark,lStyle,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(lLabel)<nPlot or len(lCol)<nPlot or len(lMark)<nPlot or len(lStyle)<nPlot) :
        print("plot_csv_Profile: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=',')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Profile: Error in length of lData")

    # Get number of different profiles to plot
    ##########################################
    nProfile = len(lData[0][0,:])

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        col = lCol[i] ; mark=str(lMark[i]) ; style = str(lStyle[i])

        npos = len(lData[i][:,0])

        if (i == 0) :
            ax0.plot(lData[i][:,iProf],lData[i][:,0],label=label, color=col, mec = col , mfc="none", mew=0.5, marker=mark, markevery=1, markersize = 4, linestyle=style, alpha=0.7)
        else :
            Umax = np.amax(lData[i][1:,iProf])
            cU = Umax / 2.
            ax0.plot(lData[i][1:,iProf] / cU ,lData[i][1:,0],label=label, color=col, mec = col , mfc="none", mew=0.5, marker=mark, markevery=1, markersize = 4, linestyle=style, alpha=0.7)

    # Vertical line in U=0
    ######################
    ax0.axvline(0,color="grey",linewidth=1,linestyle="--")
    ax0.axhline(0,color="grey",linewidth=1,linestyle="--")

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    # ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=2,borderaxespad=0.)
    ax0.legend(loc=2,bbox_to_anchor=(1.01,1.),ncol=1,borderaxespad=0.)

    # Add text
    ##########
    ax0.text(0.5,1.05,r"$x=$"+str(lData[1][0,iProf]),horizontalalignment='center',transform=ax0.transAxes)


    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig
