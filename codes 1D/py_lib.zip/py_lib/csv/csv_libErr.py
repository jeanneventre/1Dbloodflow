#!/usr/local/bin/python3
import sys
import numpy as np

from scipy.interpolate import KroghInterpolator
from scipy.interpolate import interp1d

import help_Sum as hSum


def kahanSum(IN) :
    S = IN[0] ;
    c = 0. ; y = 0. ; t= 0. ;
    for i in range(1,len(IN)) :
        y = IN[i] - c  ;
        t = S + y ;
        c = (t - S) - y ;
        S = t ;
    return S

EPSILON = 1.e-15

######################################
# NORMAL
######################################
def csv_get_Error(lFile,lFileSep,lX,lY,lFact,xrType,Ltype) :

    # Get cummulative error for a given set of one reference file and one approximative file

    # LFact is a multplicative constant that can be used when to multiply the errors by constant values
    # Ex : for the multiring, provide number of rings

    # Number of different record points for the given set of files
    # Ex : Combine error at two positions or two times
    nPos = len(lX) ;

    if (len(lFile)!=2 or len(lFileSep)!=2) :
        print("csv_libErr:: csv_get_Error Error in length of lFile or lFileSep")
        sys.exit()
    if (len(lX)!=nPos or len(lY)!=nPos or len(lFact)!=nPos ) :
        print("csv_libErr:: csv_get_Error Error in length of lX or lY or lFact")
        sys.exit()
    if (len(lX[0])!=2 or len(lY[0])!=2) :
        print("csv_libErr:: csv_get_Error Error in length of lX[0] or lY[0] or lFact[0]")
        sys.exit()

    Ana = np.genfromtxt(lFile[0] , delimiter=lFileSep[0])
    Num = np.genfromtxt(lFile[1] , delimiter=lFileSep[1])

    # Create an array that contains the error at each record point for the given set of files
    Err = np.zeros(nPos)

    # Loop on record points for each raffinement level
    for ip in range(nPos) :

        iXA = lX[ip][0] ; iXN = lX[ip][1]
        iYA = lY[ip][0] ; iYN = lY[ip][1]

        # Get X & Y and skip first line
        if (np.isnan(Ana[0,0])) :
            XA = Ana[1:,iXA] ; YA = Ana[1:,iYA] ;
        else :
            XA = Ana[0:,iXA] ; YA = Ana[0:,iYA] ;
        if (np.isnan(Num[0,0])) :
            XN = Num[1:,iXN] ; YN = Num[1:,iYN] ;
        else :
            XN = Num[0:,iXN] ; YN = Num[0:,iYN] ;

        # Get length of approximative data set
        nN = len(YN)

        # Check the error type and compute the error for each record point
        if (xrType == "x") :
            Err[ip] = csv_Error_x(xA=XA,yA=YA,xN=XN,yN=YN,Ltype=Ltype)
        elif (xrType == "r") :
            Err[ip] = csv_Error_r(rA=XA,yA=YA,rN=XN,yN=YN,Ltype=Ltype)
        else :
            print("csv_libErr:: csv_get_Error Unknown xrType")
            sys.exit()

    # Modify Err with lFact
    for ip in range(nPos) :
        Err[ip] = Err[ip]*lFact[ip]

    # Compute error depending on Ltype
    # Here we combine the erros for the different recorded points
    if (Ltype == "L1") :
        LErr = kahanSum(Err)
    elif (Ltype == "L2") :
        LErr = np.sqrt(kahanSum(Err))
    elif (Ltype == "Linf") :
        LErr = np.amax(Err) ;
    else :
        print("csv_libErr:: csv_get_Error Unknown Ltype", Ltype)
        sys.exit()

    return nN,LErr

def csv_Error_x(xA,yA,xN,yN,Ltype) :

    # Check lengths
    if ( len(xA)!=len(yA) or len(xN)!=len(yN)) :
        print("csv_libErr::Err Error in length of input data")
        sys.exit()

    ERR = 0.

    # Analytic or numerical solution
    nA      = len(xA) ;
    LA      = xA[nA-1] + 0.5 * (xA[nA-1] - xA[nA-2]) ;
    xAnd    = xA
    yAmax   = max(abs(yA))
    yAav    = sum(abs(yA))/float(nA)
    yAnd    = yA

    # Numerical solution
    nN      = len(xN) ;
    LN      = xN[nN-1] + 0.5 * (xN[nN-1] - xN[nN-2]) ;
    xNnd    = xN
    yNmax   = max(abs(yN))
    yNav    = sum(abs(yN))/float(nN)
    yNnd    = yN

    if ( abs(LA - LN) > (xN[nN-1] - xN[nN-2]) ) :
        print("csv_libErr::Err LA != LN")
        sys.exit()

    if ( abs(yAmax - yNmax) > 2.*max(yAmax-yAav,yNmax-yNav) and abs(yAmax - yNmax) > 0.1 * max(abs(yAav),abs(yNav)) and max(abs(yAav),abs(yNav)) > 1.e-12 ) :
        print("csv_libErr::Err Scaling error for yA or yN")
        print(yAmax,yNmax,yAav,yNav,abs(yAmax - yNmax),max(yAmax-yAav,yNmax-yNav))
        sys.exit()

    if (nN > nA) :
        print("csv_libErr::Err nN>nA")
        sys.exit()

    # Define error vector
    Err = np.zeros(nN)

    # Index for end of previous cell
    iACellEnd = 0 ;
    # Loop on data points of analytic solution
    iN = 0 ;
    for iA in range (0,nA) :

        if (iN < nN) :
            if (xAnd[iA] >= xNnd[iN]) :

                # Check if enough analytic points are use
                if (iA < 3 or iA > nA - 3) :
                    print("csv_Error_x Not enough analytic points are used")
                    sys.exit()

                # Mesh size
                if (iN == 0) :
                    dx = (xNnd[iN+1]-xNnd[iN])
                elif (iN == nN-1) :
                    dx = (xNnd[iN]-xNnd[iN-1])
                else :
                    dx = (xNnd[iN+1]-xNnd[iN-1]) * 0.5

                # Define errors
                em2 = abs(yNnd[iN] - yAnd[iA-2]) ;
                if ( em2 <= EPSILON ) :
                    em2 = 0.
                em1 = abs(yNnd[iN] - yAnd[iA-1]) ;
                if ( em1 <= EPSILON ) :
                    em1 = 0.
                e = abs(yNnd[iN] - yAnd[iA]) ;
                if ( e <= EPSILON ) :
                    e = 0.
                ep1 = abs(yNnd[iN] - yAnd[iA+1]) ;
                if ( ep1 <= EPSILON ) :
                    ep1 = 0.

                # If same record point
                if ( xAnd[iA] == xNnd[iN] ) :
                    err = e
                elif ( xAnd[iA-1] == xNnd[iN] ) :
                    err = em1
                elif ( xAnd[iA-2] == xNnd[iN] ) :
                    err = em2
                # If different record point
                else :
                    # Interpolate the different errors
                    Interp = interp1d( [ xAnd[iA-2],xAnd[iA-1],xAnd[iA],xAnd[iA+1] ], [ em2,em1,e,ep1 ], kind='nearest', assume_sorted='true' )
                    err = Interp(xNnd[iN])

                # Get error at specific data point
                if (Ltype == "L1") :
                    Err[iN] = abs(err)  * dx / LN ;
                elif (Ltype == "L2") :
                    Err[iN] = (err*err) * dx / LN ;
                elif (Ltype == "Linf") :
                    Err[iN] = abs(err) ;
                else :
                    print("csv_libErr::Err Unknown Ltype",Ltype)
                    sys.exit()

                # Next data point
                iN += 1 ;

    # Compute error depending on Ltype
    if (Ltype == "L1") :
        LErr = kahanSum(Err) ;
    elif (Ltype == "L2") :
        LErr = kahanSum(Err) ;
    elif (Ltype == "Linf") :
        LErr = np.amax(Err)  ;
    else :
        print("csv_libErr::Err Unknown Ltype",Ltype)
        sys.exit()

    return LErr

def csv_Error_r(rA,yA,rN,yN,Ltype) :

    # Check lengths
    if ( len(rA)!=len(yA) or len(rN)!=len(yN)) :
        print("csv_libErr::Err Error in length of input data")
        sys.exit()

    ERR = 0.

    # Analytic or numerical solution
    nA      = len(rA) ;
    RA      = rA[nA-1] + 0.5 * (rA[nA-1] - rA[nA-2]) ;
    rAnd    = rA / RA
    yAmax   = max(abs(yA))
    yAav    = sum(abs(yA))/float(nA)
    yAnd    = yA

    # Numerical solution
    nN      = len(rN) ;
    RN      = rN[nN-1] + 0.5 * (rN[nN-1] - rN[nN-2]) ;
    rNnd    = rN / RN
    yNmax   = max(abs(yN))
    yNav    = sum(abs(yN))/float(nN)
    yNnd    = yN

    if ( abs(RA - RN) > (rN[nN-1] - rN[nN-2]) ) :
        print("csv_libErr::Err RA != RN")
        sys.exit()

    if ( abs(yAmax - yNmax) > 2.*max(yAmax-yAav,yNmax-yNav) ) :
        print("csv_libErr::Err Scaling error for yA or yN")
        print(yAmax,yNmax,yAav,yNav,abs(yAmax - yNmax),max(yAmax-yAav,yNmax-yNav))
        sys.exit()

    if (nN > nA) :
        print("csv_libErr::Err nN>nA")
        sys.exit()

    # Define error vector
    Err = np.zeros(nN)

    # Loop on data points of analytic solution
    iN = 0 ;
    for iA in range (0,nA) :

        if (iN < nN) :
            if (rAnd[iA] >= rNnd[iN]) :

                # Mesh size
                if (iN == 0) :
                    dr = (rNnd[iN+1]-rNnd[iN]) / RN
                elif (iN == nN-1) :
                    dr = (rNnd[iN]-rNnd[iN-1]) / RN
                else :
                    dr = (rNnd[iN+1]-rNnd[iN-1]) / 2. / RN

                # Define errors
                em2 = abs(yNnd[iN] - yAnd[iA-2]) ;
                if ( em2 <= EPSILON ) :
                    em2 = 0.
                em1 = abs(yNnd[iN] - yAnd[iA-1]) ;
                if ( em1 <= EPSILON ) :
                    em1 = 0.
                e = abs(yNnd[iN] - yAnd[iA]) ;
                if ( e <= EPSILON ) :
                    e = 0.
                ep1 = abs(yNnd[iN] - yAnd[iA+1]) ;
                if ( ep1 <= EPSILON ) :
                    ep1 = 0.

                # If same record point
                if ( rAnd[iA] == rNnd[iN] ) :
                    err = e
                elif ( rAnd[iA-1] == rNnd[iN] ) :
                    err = em1
                elif ( rAnd[iA-2] == rNnd[iN] ) :
                    err = em2
                # If different record point
                else :
                    # Interpolate the different errors
                    Krogh = KroghInterpolator([rAnd[iA-2],rAnd[iA-1],rAnd[iA],rAnd[iA+1]],[em2,em1,e,ep1])
                    err = Krogh(rNnd[iN])

                # Check positivity of interpolation
                if (err < 0.) :
                    print("csv_libErr::Err err is negative",iN,err)
                    sys.exit()

                # Get error at specific data point
                # Divide by two because of symmetry
                if (Ltype == "L1") :
                    Err[iN] = err       * np.pi * abs(rNnd[iN]) * abs(dr) ;
                elif (Ltype == "L2") :
                    Err[iN] = (err*err) * np.pi * abs(rNnd[iN]) * abs(dr) ;
                elif (Ltype == "Linf") :
                    Err[iN] = err ;
                else :
                    print("csv_libErr::Err Unknown Ltype",Ltype)
                    sys.exit()
                # Next data point
                iN += 1 ;

    # Compute error depending on Ltype
    if (Ltype == "L1") :
        LErr = kahanSum(Err) ;
    elif (Ltype == "L2") :
        LErr = kahanSum(Err) ;
    elif (Ltype == "Linf") :
        LErr = np.amax(Err)  ;
    else :
        print("csv_libErr::Err Unknown Ltype",Ltype)
        sys.exit()

    return LErr
