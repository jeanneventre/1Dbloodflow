#!/usr/bin/python2.7

__author__      = "Arthur R. Ghigo"
__copyright__   = "Copyright 2015, UPMC IJLRDA"
__credits__     = ["Arthur R. Ghigo"]
__license__     = "GPL"
__version__     = "1.0.0"
__maintainer__  = "Arthur R. Ghigo"
__email__       = "arthur.ghigo@dalembert.upmc.fr"
__status__      = "Prototype"

from help_plot import *

from csv_libErr import csv_Error_x

################################################
# PLOT CONTOUR
################################################
def plot_csv_contour(pathStore,title,xScale,yScale,File,FileSep,iX,iY,iZ,xLabel,yLabel,xRange,yRange,LegSize,xBins,yBins,lText,lTextPos,lTextAlign,lTextColor,colorMap,cbLabel,cbScale,cbRange,cbMid,lvN,lvColor,lvWidth,lPoint,lPointStyle,lPointSize,lPointColor,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x', tight=True, nbins=int(xBins)) ; ax0.locator_params(axis='y', tight=True, nbins=int(yBins))
    # Legend font size
    plt.rc('legend', fontsize=str(LegSize))
    # Tick size
    ax0.tick_params(axis='both',which='major',length=7,width=2)
    ax0.tick_params(axis='both',which='minor',length=3,width=1)
    ax0.tick_params(axis='both',which='minor',labelsize=15)

    # Get Flattened Data
    ######################
    Data    =   np.genfromtxt(  File,   delimiter=str(FileSep) )
    X       =   Data[0:,iX]
    Y       =   Data[0:,iY]
    Z       =   Data[0:,iZ]

    # Scales
    ##############
    Xmin = np.amin(X)  ; Xmax = np.amax(X) ;
    Ymin = np.amin(Y)  ; Ymax = np.amax(Y) ;
    Zmin = np.amin(Z)  ; Zmax = np.amax(Z) ;

    # Set levels
    ###############################
    if (cbScale == 'linear') :
        levels  = np.linspace(start=Zmin,stop=Zmax,num=lvN)
    elif (cbScale == 'log') :
        levels  = np.exp(np.linspace(start=np.log(Zmin),stop=np.log(Zmax),num=lvN))

    # Colormapmatplotlib.ticker.SymmetricalLogLocator
    ###############################
    cm      = plt.get_cmap(str(colorMap))
    # Find start, mid and end points for colormap
    cStart  = 0.
    cEnd    = 1.

    if (cbMid == "0") :
        if (Zmin < 0. and Zmax > 0.) :
            cMid = abs(Zmin)/(dMax + abs(Zmin))
        elif (Zmin < 0. and Zmax <=0.) :
            cMid = 1.
        elif (Zmin >=0. and Zmax > 0.) :
            cMid = 0.
        else :
            cMid = 0.5
    else :
        cMid = cbMid

    shiftedcm   = shiftedColorMap(cm,start=cStart,midpoint=cMid,stop=cEnd)
    shiftedcm.set_over(    "black")
    shiftedcm.set_under(   "white")

    if (cbScale == 'linear') :
        if (cbRange != []) :
            cbNorm   = colors.Normalize(vmin=cbRange[0],vmax=cbRange[1])
        else :
            cbNorm   = colors.Normalize(vmin=Zmin,vmax=Zmax)
    elif (cbScale == 'log') :
        if (cbRange != []) :
            cbNorm   = colors.LogNorm(vmin=cbRange[0],vmax=cbRange[1])
        else :
            cbNorm   = colors.LogNorm(vmin=Zmin,vmax=Zmax,clip=True)

    scalarMap   = cmx.ScalarMappable(norm=cbNorm,cmap=shiftedcm)
    scalarMap.set_array([])

    # Contour
    # ###############################
    CSF = ax0.tricontourf(  X,Y,Z,
                            levels=levels,
                            # hatches=["x","o"],
                            origin='lower',
                            cmap=shiftedcm,
                            aspect='auto',
                            norm=cbNorm
                         )
    CS  = ax0.tricontour(   X,Y,Z,
                            levels=levels,
                            origin="lower",
                            linewidths=lvWidth,
                            linestyles="solid",
                            colors = str(lvColor)
                         )

    # Add points
    #######################
    nP = len(lPoint)
    for iP in range(nP) :
        xP      = lPoint[iP][0];
        yP      = lPoint[iP][1];
        styleP  = str(lPointStyle[iP])
        sizeP   = float(lPointSize[iP])
        colP    = str(lPointColor[iP]) ;
        ax0.plot((xP),(yP),marker=styleP,markersize=sizeP,mew=1,color="none",mec="white",mfc=colP)

    # Colorbar
    ##################
    cb          = plt.colorbar(CSF, cmap=scalarMap, ax=ax0, format='%.1E', extend='both')
    cb.add_lines(CS)
    cb.set_label(cbLabel)

    # Set labels
    ##################
    ax0.set_xlabel(str(xLabel)) ; ax0.set_ylabel(str(yLabel));
    ax0.set_xscale(str(xScale)) ; ax0.set_yscale(str(yScale))

    # Set locator & formatter
    ##################
    if (xScale == 'linear') :
        ax0.yaxis.set_major_locator(LinearLocator(int(xBins)))
        ax0.xaxis.set_minor_formatter(FuncFormatter(log_10_decimal)) ;
        ax0.xaxis.set_major_formatter(FuncFormatter(log_10_product)) ;
    elif (xScale == 'log') :
        ax0.xaxis.set_minor_locator(LogLocator(subs='auto'))
        ax0.xaxis.set_minor_formatter(FuncFormatter(log_10_decimal)) ;
        ax0.xaxis.set_major_formatter(FuncFormatter(log_10_product)) ;
    if (yScale == 'linear') :
        ax0.yaxis.set_major_locator(LinearLocator(int(yBins)))
        ax0.yaxis.set_minor_formatter(FuncFormatter(log_10_decimal))
        ax0.yaxis.set_major_formatter(FuncFormatter(log_10_product))
    elif(yScale == 'log') :
        ax0.yaxis.set_minor_locator(LogLocator(subs='auto'))
        ax0.yaxis.set_minor_formatter(FuncFormatter(log_10_decimal))
        ax0.yaxis.set_major_formatter(FuncFormatter(log_10_product))

    # Rotate labels
    for label in ax0.get_xminorticklabels()  :
        label.set_rotation(50)
        label.set_horizontalalignment("right")
    for label in ax0.get_xmajorticklabels()  :
        label.set_rotation(50)
        label.set_horizontalalignment("right")

    # Set xrange & yrang
    ######################
    if (xRange != []) :
        plt.xlim([xRange[0],xRange[1]])
    else :
        plt.xlim([Xmin,Xmax])
    if (yRange != []) :
        plt.ylim([yRange[0],yRange[1]])
    else :
        plt.ylim([Ymin,Ymax])

    # Add text
    ######################
    nText = len(lText)
    for iT in range(nText) :
        xT = lTextPos[iT][0];
        yT = lTextPos[iT][1];
        text = str(lText[iT]);
        align = str(lTextAlign[iT]);
        colT = str(lTextColor[iT]) ;
        ax0.text(xT,yT,text,horizontalalignment=align,color=colT,transform=ax0.transAxes)

    # Set legend and title
    ######################
    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

################################################
# PLOT 2D SENSITIVITY MAP
################################################
def plot_csv_Sensitivity_Map_Profile(pathStore,title,llFile,lliX,lliY,lX,lY,FileAna,xAna,yAna,xLabel,yLabel,cbLabel,LegPos,text,textPos,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=10)

    nX = len(llFile[:]) ; nY = len(llFile[0][:])
    if ( len(lliX[:]) < nX or len(lliX[0][:]) < nY or len(lliY[:]) < nX or len(lliY[0][:]) < nY ) :
        print("plot_csv_Sensitivity_Map: Error in length of lliX or lliY")
    if ( len(lX[:]) < nX or len(lY[:]) < nY ) :
        print("plot_csv_Sensitivity_Map: Error in length of lX or lY")

    # List of list of data
    ######################
    llData = []
    for ix in range(nX) :
        tmp = [] ;
        for iy in range(nY) :
            Data = np.genfromtxt(llFile[ix][iy], delimiter=',')
            tmp.append(Data)
        llData.append(tmp)

    if (len(llData) != nX or len(llData[0][:]) != nY) :
        print("plot_csv_Sensitivity_Map: Error in length of llData")

    # Create error matrix
    #####################
    matErr = np.zeros((nX,nY))

    # Analytic solution (Womersley)
    ###############################
    Ana = np.genfromtxt(FileAna, delimiter=',')
    xA = Ana[:,xAna] ; yA = Ana[:,yAna] ;

    # Compute error
    #####################
    for ix in range(nX) :
        for iy in range(nY) :
            L1,L2,Linf = Err_Profile(xA,yA,llData[ix][iy][1:,lliX[ix][iy]],llData[ix][iy][1:,lliY[ix][iy]])
            matErr[ix,iy] = L1 ;

    # Convert matrix to 1D array
    # Rescale data for Womersley
    ###########################
    X = [] ; Y = [] ; Err = []
    for ix in range(nX) :
        for iy in range(nY) :
            X.append(lX[ix])
            Y.append(lY[iy])
            Err.append(matErr[ix,iy])

    # Plot
    ##############
    Xmin = min(X)  ; Xmax = max(X) ;
    Ymin = min(Y)  ; Ymax = max(Y)

    #INTERPOLATION
    ##############
    # Define grid.
    Xi, Yi = np.mgrid[Xmin:Xmax:complex(0,10.*nX), Ymin:Ymax:complex(0,10.*nX)]
    Err = np.asarray(Err)
    # Grid the data.
    Erri = griddata((X, Y), Err, (Xi, Yi), method='linear')
    Emin = np.amin(Erri)  ; Emax = np.amax(Erri) ;

    #Mask region
    ###############################
    Erri = np.ma.masked_where(Erri < 0., Erri )
    # Erri = np.ma.masked_where(Erri < Emin, Erri )
    # Erri = np.ma.masked_where(Erri > Emax, Erri )

    # Colormap
    ###############################
    colormap = plt.cm.get_cmap("gist_rainbow")
    colormap_contour = plt.cm.get_cmap("gray")

    # Set levels
    ###############################
    # Linear
    # levels = MaxNLocator(nbins=100).tick_values(Emin, Emax)
    # Log
    step = 1./float(nX*nY) * (np.ceil(np.log10(Emax)) - np.floor(np.log10(Emin)) )
    lev_exp = np.arange(np.floor(np.log10(Emin)), np.ceil(np.log10(Emax)),step)
    levels = np.power(10, lev_exp)

    # Contour
    ###############################
    CSF = ax0.contourf(Xi,Yi,Erri,levels=levels,origin='lower', cmap=colormap, aspect='auto',norm=colors.LogNorm())
    CS  = ax0.contour(CSF,levels=CSF.levels[::1],origin="lower",linewidths=0.5, colors = "white")

    # Discrete/Shifted colormap
    ###############################
    # colorbar_index(ncolors=11, cmap=colormap)
    # shiftedcolormap = remappedColorMap(colormap, midpoint=mid, name='shifted')


    #Colors of undefined regions
    ###############################
    CSF.cmap.set_under('black')
    CSF.cmap.set_over('grey')

    # Set labels
    ##################
    ax0.set_xlabel(str(xLabel)) ; ax0.set_ylabel(str(yLabel));
    ax0.set_xscale('log') ; ax0.set_yscale('log')

    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Define colorbar
    ####################
    cb=plt.colorbar(CSF, ticks=levels[::np.ceil(float(len(levels)/10.))], format='%.1E', shrink=0.8)
    cb.add_lines(CS)
    cb.set_label(str(cbLabel))

    # Add text
    ######################
    if (text[0] != "") :
        ax0.text(textPos[0][0],textPos[0][1],str(text[0]),horizontalalignment='left',transform=ax0.transAxes)
    if (text[1] != "") :
        ax0.text(textPos[1][0],textPos[1][1],str(text[1]),horizontalalignment='center',transform=ax0.transAxes)

    # Set legend and title
    ######################
    # if (int(LegPos) == 1) :
    #     ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    # elif (int(LegPos) == 2) :
    #     ax0.legend(loc=2,bbox_to_anchor=(0.,1.),ncol=1,borderaxespad=0.)
    # elif (int(LegPos) == 3) :
    #     ax0.legend(loc=3,bbox_to_anchor=(0.,0.),ncol=1,borderaxespad=0.)
    # else :
    #     ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)


    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

################################################
# PLOT 2D SENSITIVITY MAP: WOMERSLEY
################################################
def plot_csv_Sensitivity_Map_Wom(pathStore,title,llFile,lliX,lliY,lX,lY,FileAna,xAna,yAna,xLabel,yLabel,cbLabel,LegPos,lText,lTextPos,lTextAlign,lTextColor,Ltype,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=10)

    nX = len(llFile[:]) ; nY = len(llFile[0][:])
    if ( len(lliX[:]) < nX or len(lliX[0][:]) < nY or len(lliY[:]) < nX or len(lliY[0][:]) < nY ) :
        print("plot_csv_Sensitivity_Map: Error in length of lliX or lliY")
    if ( len(lX[:]) < nX or len(lY[:]) < nY ) :
        print("plot_csv_Sensitivity_Map: Error in length of lX or lY")

    # List of list of data
    ######################
    llData = []
    for ix in range(nX) :
        tmp = [] ;
        for iy in range(nY) :
            Data = np.genfromtxt(llFile[ix][iy], delimiter=',')
            tmp.append(Data)
        llData.append(tmp)

    if (len(llData) != nX or len(llData[0][:]) != nY) :
        print("plot_csv_Sensitivity_Map: Error in length of llData")

    # Create error matrix
    #####################
    matErr = np.zeros((nX,nY))

    # Analytic solution (Womersley)
    ###############################
    Ana = np.genfromtxt(FileAna, delimiter=',')
    xA = Ana[:,xAna] ; yA = Ana[:,yAna] ;

    # Compute error
    #####################
    for ix in range(nX) :
        for iy in range(nY) :
            xN = llData[ix][iy][:,lliX[ix][iy]]
            yN = llData[ix][iy][:,lliY[ix][iy]]
            Lerr = csv_Error_x(xA,yA,xN,yN,Ltype)
            if (Ltype == "L2") :
                Lerr = np.sqrt(Lerr)
            matErr[ix,iy] = Lerr ;

    # Convert matrix to 1D array
    # Rescale data for Womersley
    ###########################
    X = [] ; Y = [] ; Err = []
    for ix in range(nX) :
        for iy in range(nY) :
            X.append(lX[ix])
            Y.append(lY[iy])
            Err.append(matErr[ix,iy])

    # Plot
    ##############
    Xmin = min(X)  ; Xmax = max(X) ;
    Ymin = min(Y)  ; Ymax = max(Y)

    #INTERPOLATION
    ##############
    # Define grid.
    Xi, Yi = np.mgrid[Xmin:Xmax:complex(0,10*nX), Ymin:Ymax:complex(0,10*nY)]
    Err = np.asarray(Err)
    # Grid the data.
    Erri = griddata((X, Y), Err, (Xi, Yi), method='linear')
    Emin = np.amin(Erri)  ; Emax = np.amax(Erri) ;

    #Mask region
    ###############################
    # Erri = np.ma.masked_where(Erri < 0., Erri )
    # Erri = np.ma.masked_where(Erri < Emin, Erri )
    # Erri = np.ma.masked_where(Erri > Emax, Erri )

    # Colormap
    ###############################
    colormap = plt.cm.get_cmap("plasma")

    # Set levels
    ###############################
    # Linear
    # levels = MaxNLocator(nbins=100).tick_values(Emin, Emax)
    # Log
    step = 1./float(nX*nY) * (np.ceil(np.log10(Emax)) - np.floor(np.log10(Emin)) )
    lev_exp = np.arange(np.floor(np.log10(Emin)), np.ceil(np.log10(Emax)),step)
    levels = np.power(10, lev_exp)

    # Contour
    ###############################
    CSF = ax0.contourf(Xi,Yi,Erri,levels=levels,origin='lower', cmap=colormap, aspect='auto',norm=colors.LogNorm())
    CS  = ax0.contour(CSF,levels=CSF.levels[::1],origin="lower",linewidths=1, colors = "white")

    # Discrete/Shifted colormap
    ###############################
    # colorbar_index(ncolors=11, cmap=colormap)
    # shiftedcolormap = remappedColorMap(colormap, midpoint=mid, name='shifted')


    #Colors of undefined regions
    ###############################
    CSF.cmap.set_under('black')
    CSF.cmap.set_over('grey')

    # Set labels
    ##################
    ax0.set_xlabel(str(xLabel)) ; ax0.set_ylabel(str(yLabel));
    ax0.set_xscale('log') ; ax0.set_yscale('log')

    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set range
    ####################

    ax0.set_xlim(Xmin,Xmax)
    ax0.set_ylim(Ymin,Ymax)

    # Define colorbar
    ####################
    cb=plt.colorbar(CSF, ticks=levels[::int(np.ceil(float(len(levels))/10.))], format='%.1E', shrink=0.8)
    cb.add_lines(CS)
    cb.set_label(str(cbLabel))

    # Add text
    ######################
    nText = len(lText)
    for iT in range(nText) :
        xT = lTextPos[iT][0];
        yT = lTextPos[iT][1];
        text = str(lText[iT]);
        align = str(lTextAlign[iT]);
        colT = str(lTextColor[iT]) ;
        ax0.text(xT,yT,text,horizontalalignment=align,color=colT,transform=ax0.transAxes)

    # Set legend and title
    ######################

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

################################################
# PLOT 2D SENSITIVITY MAP: POISEUILLE
################################################
def plot_csv_Sensitivity_Map_Poiseuille(pathStore,title,llFile,lliX,lliY,lX,lY,FileAna,xAna,yAna,rho,mu,xLabel,yLabel,cbLabel,LegPos,text,textPos,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=10)

    nX = len(llFile[:]) ; nY = len(llFile[0][:])
    if ( len(lliX[:]) < nX or len(lliX[0][:]) < nY or len(lliY[:]) < nX or len(lliY[0][:]) < nY ) :
        print("plot_csv_Sensitivity_Map: Error in length of lliX or lliY")
    if ( len(lX[:]) < nX or len(lY[:]) < nY ) :
        print("plot_csv_Sensitivity_Map: Error in length of lX or lY")

    # List of list of data
    ######################
    llData = []
    for ix in range(nX) :
        tmp = [] ;
        for iy in range(nY) :
            Data = np.genfromtxt(llFile[ix][iy], delimiter=',')
            tmp.append(Data)
        llData.append(tmp)

    if (len(llData) != nX or len(llData[0][:]) != nY) :
        print("plot_csv_Sensitivity_Map: Error in length of llData")

    # Create error matrix
    #####################
    matErr = np.zeros((nX,nY))

    # Analytic solution (Womersley)
    ###############################
    Ana = np.genfromtxt(FileAna, delimiter=',')
    xA = Ana[:,xAna] ; yA = Ana[:,yAna] ;

    # Compute error
    #####################
    for ix in range(nX) :
        for iy in range(nY) :

            # Indices
            ######################
            iR = 5 ; iQ = 8 ; iU = 9 ; iU0 = 10 ; iTw = 14 ; iP = 11 ;
            # Reynolds
            ######################
            mu = float(mu) ; rho = float(rho) ; nu = mu/rho ;
            U = llData[ix][iy][0,iU] ; R = llData[ix][iy][0,iR] ; D = 2. * R ; P0 = llData[ix][iy][0,iP]
            Re = U * R / nu ; cX = Re * R
            cTw = mu * U / R ; cU0 = U ; cP = rho * (U ** 2.) ; cQ = np.pi * (R**2.) * U

            if (lliY[ix][iy] == iQ) :
                cY = cQ ; cYY = 0. ;
            elif (lliY[ix][iy] == iU0) :
                cY = cU0 ; cYY = 0. ;
            elif (lliY[ix][iy] == iTw) :
                cY = cTw ; cYY = 0. ;
            elif (lliY[ix][iy] == iP) :
                cY = cP ; cYY = P0 ;


            L1,L2,Linf = Err_Poiseuille(xA,yA,llData[ix][iy][:,lliX[ix][iy]],llData[ix][iy][:,lliY[ix][iy]],cX,cY,cYY)
            matErr[ix,iy] = L1 ;

    # Convert matrix to 1D array
    # Rescale data for Womersley
    ###########################
    X = [] ; Y = [] ; Err = []
    for ix in range(nX) :
        for iy in range(nY) :
            X.append(lX[ix])
            Y.append(lY[iy])
            Err.append(matErr[ix,iy])

    # Plot
    ##############
    Xmin = min(X)  ; Xmax = max(X) ;
    Ymin = min(Y)  ; Ymax = max(Y)

    #INTERPOLATION
    ##############
    # Define grid.
    Xi, Yi = np.mgrid[Xmin:Xmax:complex(0,10.*nX), Ymin:Ymax:complex(0,10.*nX)]
    Err = np.asarray(Err)
    # Grid the data.
    Erri = griddata((X, Y), Err, (Xi, Yi), method='linear')
    Emin = np.amin(Erri)  ; Emax = np.amax(Erri) ;

    #Mask region
    ###############################
    Erri = np.ma.masked_where(Erri < 0., Erri )
    # Erri = np.ma.masked_where(Erri < Emin, Erri )
    # Erri = np.ma.masked_where(Erri > Emax, Erri )

    # Colormap
    ###############################
    colormap = plt.cm.get_cmap("gist_rainbow")
    colormap_contour = plt.cm.get_cmap("gray")

    print(Emin,Emax)
    print(Err)
    print(Erri)

    # Set levels
    ###############################
    # Linear
    # levels = MaxNLocator(nbins=100).tick_values(Emin, Emax)
    # Log
    step = 1./float(nX*nY) * (np.ceil(np.log10(Emax)) - np.floor(np.log10(Emin)) )
    lev_exp = np.arange(np.floor(np.log10(Emin)), np.ceil(np.log10(Emax)),step)
    levels = np.power(10, lev_exp)

    # Contour
    ###############################
    CSF = ax0.contourf(Xi,Yi,Erri,levels=levels,origin='lower', cmap=colormap, aspect='auto',norm=colors.LogNorm())
    CS  = ax0.contour(CSF,levels=CSF.levels[::1],origin="lower",linewidths=0.5, colors = "white")

    # Discrete/Shifted colormap
    ###############################
    # colorbar_index(ncolors=11, cmap=colormap)
    # shiftedcolormap = remappedColorMap(colormap, midpoint=mid, name='shifted')


    #Colors of undefined regions
    ###############################
    CSF.cmap.set_under('black')
    CSF.cmap.set_over('black')

    # Set labels
    ##################
    ax0.set_xlabel(str(xLabel)) ; ax0.set_ylabel(str(yLabel));
    ax0.set_xscale('log') ; ax0.set_yscale('log')

    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Define colorbar
    ####################
    cb=plt.colorbar(CSF, ticks=levels[::np.ceil(float(len(levels)/10.))], format='%.1E', shrink=0.8)
    cb.add_lines(CS)
    cb.set_label(str(cbLabel))

    # Add text
    ######################
    if (text[0] != "") :
        ax0.text(textPos[0][0],textPos[0][1],str(text[0]),horizontalalignment='left',transform=ax0.transAxes)
    if (text[1] != "") :
        ax0.text(textPos[1][0],textPos[1][1],str(text[1]),horizontalalignment='center',transform=ax0.transAxes)

    # Set legend and title
    ######################
    # if (int(LegPos) == 1) :
    #     ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    # elif (int(LegPos) == 2) :
    #     ax0.legend(loc=2,bbox_to_anchor=(0.,1.),ncol=1,borderaxespad=0.)
    # elif (int(LegPos) == 3) :
    #     ax0.legend(loc=3,bbox_to_anchor=(0.,0.),ncol=1,borderaxespad=0.)
    # else :
    #     ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)


    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig
