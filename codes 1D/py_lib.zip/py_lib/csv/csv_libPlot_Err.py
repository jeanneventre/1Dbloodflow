#!/usr/bin/python2.7

__author__      = "Arthur R. Ghigo"
__copyright__   = "Copyright 2015, UPMC IJLRDA"
__credits__     = ["Arthur R. Ghigo"]
__license__     = "GPL"
__version__     = "1.0.0"
__maintainer__  = "Arthur R. Ghigo"
__email__       = "arthur.ghigo@dalembert.upmc.fr"
__status__      = "Prototype"

from help_plot import *
from csv_libErr import csv_get_Error

def plot_csv_Err_CV(   pathStore,title,lllFile,lllFileSep,lllX,lllY,lllFact,llFactOrder,xrType,Ltype,
                    pScale,
                    xLabel,yLabel,lLabel,
                    xRange,yRange,xBins,yBins,
                    lXScale,lYScale,lXOffset,lYOffset,
                    lHline,lHlineColor,lHlineWidth,lHlineStyle,lVline,lVlineColor,lVlineWidth,lVlineStyle,
                    LegLoc,LegPos,LegCol,
                    lText,lTextPos,lTextAlign,lTextColor,
                    lCol,lMark,lMarkSize,lMarkWidth,MarkPoints,lLineSize,lStyle,lAlpha,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=int(xBins)) ; ax0.locator_params(axis='y',tight=True, nbins=int(yBins))

    # Number of data series
    nPlot = len(lllFile)
    if (len(lllX)<nPlot or len(lllY)<nPlot or len(lllFact)<nPlot or len(llFactOrder)<nPlot) :
        print("plot_csv_Err: Error in length of input data")
        sys.exit()
    if (len(lllFileSep)<nPlot or len(lllX)<nPlot or len(lllY)<nPlot or len(lLabel)<nPlot or len(lCol)<nPlot or len(lMark)<nPlot or len(lStyle)<nPlot or len(lXScale)<nPlot or len(lYScale)<nPlot or len(lXOffset)<nPlot or len(lYOffset)<nPlot) :
        print("plot_csv_Err: Error in length of input lists")
        sys.exit()

    # Loop on data series
    for i in range(nPlot) :

        label = str(lLabel[i])

        xScale = float(lXScale[i]) ;
        yScale = float(lYScale[i])

        xOffset = float(lXOffset[i]) ;
        yOffset = float(lYOffset[i]) ;

        col = lCol[i] ; mark=str(lMark[i]) ; style = str(lStyle[i]);
        mSize = int(lMarkSize[i]) ; mWidth = int(lMarkWidth[i]) ; lSize = int(lLineSize[i]) ;
        alpha = float(lAlpha[i]) ;

        # Create X and Y
        X = []
        Y = []

        # Define new variables
        llFile  = lllFile[i]   ; llFileSep  = lllFileSep[i]
        llX     = lllX[i]      ; llY        = lllY[i]
        llFact  = lllFact[i]   ; lFactOrder = llFactOrder[i]

        # Number of levels of mesh raffinement
        nData = len(llFile) ;

        # Verification
        if (len(llX)<nData or len(llY)<nData):
            print("csv_libWrite_Err:: write_csv_Err_CV Error in length of lFile and llX and llY")
            sys.exit()
        if (len(llFact)<nData) :
            print("csv_libWrite_Err:: write_csv_Err_CV Error in length of lFact")
            sys.exit()
        if (len(lFactOrder)<nData) :
            print("csv_libWrite_Err:: write_csv_Err_CV Error in length of lFactOrder")
            sys.exit()

        N = 0 ;
        LErr = 0. ;
        # Loop on mesh raffinement levels:
        for iData in range(nData) :
            N,LErr     = csv_get_Error(llFile[iData],llFileSep[iData],llX[iData],llY[iData],llFact[iData],xrType,Ltype)
            X.append(N)
            Y.append(LErr)

        for iData in range(nData) :
            X[iData] = (X[iData] - xOffset ) / xScale
            Y[iData] = (Y[iData] - yOffset ) / yScale

        # Get regression
        ############################
        A = np.vstack([np.log10(X), np.ones(len(X))]).T
        m, c = np.linalg.lstsq(A, np.log10(Y))[0]

        # Modify label to write regression
        label = label + r", " + "{0:.2f}".format(m) + r"$x+$" + "{0:.2f}".format(c)

        ax0.plot(X,Y,label=label, color=col, mec = col , mfc="none", mew=mWidth, marker=mark, markersize=mSize, markevery=max(1,int(float(nData)/float(MarkPoints))), linestyle=style , linewidth=lSize, alpha=alpha)        # ax0.plot(lData[i][1:,iX],lData[i][1:,iY],label=label, color=col, mec = col , mfc="none", mew=2, marker=mark, markersize=mSize, markevery=max(1,int(float(npos)/500.)), linestyle=style , linewidth=lSize)

        # Start regression at first point
        #################################
        Xreg = X ; Yreg = Y ;
        for iData in range(nData) :
            Yreg[iData] =  Y[0] * ( (10.**c) * (Xreg[iData])**m ) / ( (10.**c) * (Xreg[0])**m )
        ax0.plot(Xreg ,Yreg, color=col, linestyle='--')


    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    yFmter = ScalarFormatter() ; yFmter.set_powerlimits((0,5))
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=int(LegLoc),bbox_to_anchor=(float(LegPos[0]),float(LegPos[1])),ncol=int(LegCol),borderaxespad=0.)

    # Set xrange & yrange
    ######################
    if (xRange != []) :
        ax0.set_xlim(xRange[0],xRange[1])
    if (yRange != []) :
        ax0.set_ylim(yRange[0],yRange[1])

    # Set logscale
    ######################
    plt.xscale(pScale)
    plt.yscale(pScale)

    # Horizontal line
    ######################
    nH = len(lHline)
    for iH in range(nH) :
        ax0.axhline(float(lHline[iH]),color=lHlineColor[iH],linewidth=float(lHlineWidth[iH]),linestyle=lHlineStyle[iH])

    # Vertical line
    ######################
    nV = len(lVline)
    for iV in range(nV) :
        ax0.axvline(float(lVline[iV]),color=lVlineColor[iV],linewidth=float(lVlineWidth[iV]),linestyle=lVlineStyle[iV])

    # Add text
    ######################
    nText = len(lText)
    for iT in range(nText) :
        xT = lTextPos[iT][0];
        yT = lTextPos[iT][1];
        text = str(lText[iT]);
        align = str(lTextAlign[iT]);
        colT = str(lTextColor[iT]) ;
        ax0.text(xT,yT,text,horizontalalignment=align,color=colT,transform=ax0.transAxes)

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig
