#!/usr/bin/python2.7

__author__      = "Arthur R. Ghigo"
__copyright__   = "Copyright 2015, UPMC IJLRDA"
__credits__     = ["Arthur R. Ghigo"]
__license__     = "GPL"
__version__     = "1.0.0"
__maintainer__  = "Arthur R. Ghigo"
__email__       = "arthur.ghigo@dalembert.upmc.fr"
__status__      = "Prototype"

from help_plot import *

def plot_csv_adim(pathStore,title,lFile,lFileSep,liX,liY,xLabel,yLabel,lLabel,xRange,yRange,xMargin,yMargin,xBins,yBins,lXScale,lYScale,pScale,lXOffset,lYOffset,lHline,lHlineColor,lHlineWidth,lHlineStyle,lVline,lVlineColor,lVlineWidth,lVlineStyle,lAffline,lAfflineColor,lAfflineWidth,lAfflineStyle,LegLoc,LegPos,LegCol,LegSize,lText,lTextPos,lTextAlign,lTextColor,lCol,lMark,lMarkSize,lMarkWidth,MarkPoints,lLineSize,lStyle,lAlpha,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x', tight=True, nbins=int(xBins)) ; ax0.locator_params(axis='y', tight=True, nbins=int(yBins))
    # Legend font size
    plt.rc('legend', fontsize=str(LegSize))

    nPlot = len(lFile)
    if (len(lFileSep)<nPlot or len(liX)<nPlot or len(liY)<nPlot or len(lLabel)<nPlot or len(lCol)<nPlot or len(lMark)<nPlot or len(lStyle)<nPlot or len(lXScale)<nPlot or len(lYScale)<nPlot or len(lXOffset)<nPlot or len(lYOffset)<nPlot) :
        print("plot_csv_adim: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt( lFile[i], delimiter=str(lFileSep[i]), comments="#" )
        lData.append(Data[0:,:])

    if (len(lData) != nPlot) :
        print("plot_csv_Wom: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        if (lXScale[i]=="last") :
            xScale = lData[i][len(lData[i][:,iX])-1,iX]
        elif (lXScale[i]=="max") :
            xScale = np.max(lData[i][:,iX])
        elif (lXScale[i]=="-max") :
            xScale = -np.max(lData[i][:,iX])
        elif (lXScale[i]=="unit") :
            xScale = np.max(lData[i][:,iX])-np.min(lData[i][:,iX])
        else :
            xScale = float(lXScale[i]) ;

        if (lYScale[i]=="first") :
            yScale = lData[i][1,iY]
        elif (lYScale[i]=="max") :
            yScale = np.max(lData[i][:,iY])
        elif (lYScale[i]=="-max") :
            yScale = -np.max(lData[i][:,iY])
        elif (lYScale[i]=="min") :
            yScale = np.min(lData[i][:,iY])
        elif (lYScale[i]=="-min") :
            yScale = -np.min(lData[i][:,iY])
        elif (lYScale[i]=="unit") :
            yScale = np.max(lData[i][:,iY])-np.min(lData[i][:,iY])
        else:
            yScale = float(lYScale[i])

        if (lXOffset[i] == "first") :
            xOffset = lData[i][0,iX]
        elif (lXOffset[i] == "unit") :
            xOffset = np.min(lData[i][:,iX])
        else :
            xOffset = float(lXOffset[i]) ;

        if (lYOffset[i] == "first") :
            yOffset = lData[i][0,iY]
        elif (lYOffset[i] == "last") :
            yOffset = lData[i][len(lData[i][:,iY])-1,iY]
        elif (lYOffset[i] == "unit") :
            yOffset = np.min(lData[i][:,iY])
        else :
            yOffset = float(lYOffset[i]) ;

        col = lCol[i] ; mark=str(lMark[i]) ; style = str(lStyle[i]);
        mSize = int(lMarkSize[i]) ; mWidth = int(lMarkWidth[i]) ; lSize = int(lLineSize[i]) ;
        alpha = float(lAlpha[i]) ;

        npos = len(lData[i][:,iX])

        X = (lData[i][:,iX] - xOffset ) / xScale
        Y = (lData[i][:,iY] - yOffset ) / yScale

        ax0.plot(X,Y,label=label, color=col, mec = col , mfc="none", mew=mWidth, marker=mark, markersize=mSize, markevery=max(1,int(float(npos)/float(MarkPoints))), linestyle=style , linewidth=lSize, alpha=alpha)

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    yFmter = ScalarFormatter() ; yFmter.set_powerlimits((3,3))
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=int(LegLoc),bbox_to_anchor=(float(LegPos[0]),float(LegPos[1])),ncol=int(LegCol),borderaxespad=0.)

    # Set plot scale
    ######################
    if (pScale == "log") :
        ax0.set_xscale(str(pScale)) ;
        ax0.set_yscale(str(pScale)) ;

    # Horizontal line
    ######################
    nH = len(lHline)
    ymin, ymax = ax0.get_ylim()
    for iH in range(nH) :
        ax0.axhline(float(lHline[iH]),color=lHlineColor[iH],linewidth=float(lHlineWidth[iH]),linestyle=lHlineStyle[iH])
        # Reset plot limits
        ymax = max( ymax, float(lHline[iH]) )
        ymin = min( ymin, float(lHline[iH]) )

    # Vertical line
    ######################
    nV = len(lVline)
    xmin, xmax = ax0.get_xlim()
    for iV in range(nV) :
        ax0.axvline(float(lVline[iV]),color=lVlineColor[iV],linewidth=float(lVlineWidth[iV]),linestyle=lVlineStyle[iV])
        # Reset plot limits
        xmax = max( xmax, float(lVline[iV]) )
        xmin = min( xmin, float(lVline[iV]) )

    # Affine line
    ######################
    nAff = len(lAffline)
    for iAff in range(nAff) :
        XAff = X
        YAff = lAffline[iAff][0]*X+ (lAffline[iAff][1][1] - lAffline[iAff][0]*lAffline[iAff][1][0])
        ax0.plot(XAff,YAff,color=lAfflineColor[iAff],marker="",linestyle=lAfflineStyle[iAff],linewidth=lAfflineWidth[iAff],alpha=1.)


    # Set xrange & yrange
    ######################
    if (xRange != []) :
        dxRange     = abs(xRange[1]-xRange[0])
        xRangemin   = xRange[0] - float(xMargin) * dxRange
        xRangemax   = xRange[1] + float(xMargin) * dxRange
    else :
        dxRange     = abs(xmax-xmin)
        xRangemin   = xmin - float(xMargin) * dxRange
        xRangemax   = xmax + float(xMargin) * dxRange

    if (yRange != []) :
        dyRange     = abs(yRange[1]-yRange[0])
        yRangemin   = yRange[0] - float(yMargin) * dyRange
        yRangemax   = yRange[1] + float(yMargin) * dyRange
    else :
        dyRange     = abs(ymax-ymin)
        yRangemin   = ymin - float(yMargin) * dyRange
        yRangemax   = ymax + float(yMargin) * dyRange

    ax0.set_xlim(xRangemin,xRangemax)
    ax0.set_ylim(yRangemin,yRangemax)

    # Add text
    ######################
    nText = len(lText)
    for iT in range(nText) :
        xT = lTextPos[iT][0];
        yT = lTextPos[iT][1];
        text = str(lText[iT]);
        align = str(lTextAlign[iT]);
        colT = str(lTextColor[iT]) ;
        ax0.text(xT,yT,text,horizontalalignment=align,color=colT,transform=ax0.transAxes)

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

####################################
# ERROR
####################################
def plot_csv_Convergence(pathStore,title,lllFile,llliX,llliY,llX,lPower,errType,LinLog,xLabel,yLabel,lLabel,LegLoc,LegPos,LegCol,lText,lTextPos,lTextAlign,lTextColor,lCol,lMark,lMarkSize,lMarkWidth,MarkPoints,lLineSize,lStyle,lAlpha,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lllFile)
    if (len(llliX)<nPlot or len(llliY)<nPlot or len(lLabel)<nPlot or len(lCol)<nPlot or len(lMark)<nPlot or len(lStyle)<nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    llErr = [] ;
    # Loop on data and compute error
    ################################
    for i in range(0,nPlot):
        lErr = [] ;
        nPoints = len(lllFile[i]) ;
        # Get Error
        ###########
        for ip in range(0,nPoints) :
            ix1     = llliX[i][ip][0] ; ix2 = llliX[i][ip][1] ;
            iy1     = llliY[i][ip][0] ; iy2 = llliY[i][ip][1] ;
            Data1   = np.genfromtxt(lllFile[i][ip][0], delimiter=',') ;
            Data2   = np.genfromtxt(lllFile[i][ip][1], delimiter=',') ;

            L1,L2,Linf = csv_Error(
                            Data1[:,ix1],Data1[:,iy1],
                            Data2[:,ix2],Data2[:,iy2],
                            xlim=0.
                            )

            if (errType == 'L1') :
                lErr.append(L1);
            elif (errType == 'L2') :
                lErr.append(L2);
            elif (errType == 'Linf') :
                lErr.append(Linf)
            else :
                print("plot_csv_Convergence: Unknown errType");
                sys.exit();

        llErr.append(lErr);

    # Check length of error
    #######################
    if (len(llErr) != nPlot):
        print("plot_csv_Convergence: Error in length of llErr");
        sys.exit();

    # Plot Error
    ############
    for i in range(0,nPlot) :

        label = str(lLabel[i])
        col = lCol[i] ; mark=str(lMark[i]) ; style = str(lStyle[i]);
        mSize = int(lMarkSize[i]) ; mWidth = int(lMarkWidth[i]) ; lSize = int(lLineSize[i]) ;
        alpha = float(lAlpha[i]) ;

        X = llX[i]; Y = llErr[i];
        nPoints = len(X)
        # Check length of error
        #######################
        if (len(X) != len(Y)):
            print("plot_csv_Convergence: Error in length of X or Y");
            sys.exit();

        ax0.plot(X,Y, label=label, color=col, mec = col , mfc="none", mew=mWidth, marker=mark, markersize=mSize, markevery=max(1,int(float(nPoints)/float(MarkPoints))), linestyle=style , linewidth=lSize, alpha=alpha)        # ax0.plot(lData[i][1:,iX],lData[i][1:,iY],label=label, color=col, mec = col , mfc="none", mew=2, marker=mark, markersize=mSize, markevery=max(1,int(float(npos)/500.)), linestyle=style , linewidth=lSize)

        # Get convergence rate
        ######################
        power = lPower[i]
        CV = np.zeros(nPoints);

        for ip in range(nPoints) :
            CV[ip] = Y[0] * (X[ip] / X[0] )**(power)
        ax0.plot(X,CV, color=col, mec = col , mfc="none", mew=mWidth, marker="", markersize=mSize, markevery=max(1,int(float(nPoints)/float(MarkPoints))), linestyle="--" , linewidth=lSize, alpha=alpha)

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    yFmter = ScalarFormatter() ; yFmter.set_powerlimits((0,5))
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=int(LegLoc),bbox_to_anchor=(float(LegPos[0]),float(LegPos[1])),ncol=int(LegCol),borderaxespad=0.)


    # Set xrange
    ######################
    if (LinLog == 'log') :
        plt.xscale('log')
        plt.yscale('log')

    # Add text
    ######################
    nText = len(lText)
    for iT in range(nText) :
        xT = lTextPos[iT][0];
        yT = lTextPos[iT][1];
        text = str(lText[iT]);
        align = str(lTextAlign[iT]);
        colT = str(lTextColor[iT]) ;
        ax0.text(xT,yT,text,horizontalalignment=align,color=colT,transform=ax0.transAxes)

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig
####################################
# POISEUILLE
####################################
def plot_csv_Poiseuille(pathStore,title,lFile,liX,liY,rho,mu,xLabel,yLabel,lLabel,LegPos,text,textPos,lCol,lMark,lMarkSize,lLineSize,lStyle,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=10)

    nPlot = len(lFile)
    if (len(liX)<nPlot or len(liY)<nPlot or len(lLabel)<nPlot or len(lCol)<nPlot or len(lMark)<nPlot or len(lStyle)<nPlot or len(text)!=2) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    Data = np.genfromtxt(lFile[0], delimiter=' ')
    lData.append(Data)

    for i in range(1,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=',')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Poiseuille: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        col = lCol[i] ; mark=str(lMark[i]) ; style = str(lStyle[i]);
        mSize = int(lMarkSize[i]) ; lSize = int(lLineSize[i]) ;

        npos = len(lData[i][:,iX])
        L = lData[i][npos-1,iX] + 0.5 * (lData[i][npos-1,iX] - lData[i][npos-2,iX])

        X = lData[i][0:,iX] ; Y = lData[i][0:,iY]

        # Multiring solution
        ####################
        if( i != 0) :
            # Indices
            ######################
            iR = 5 ; iQ = 8 ; iU = 9 ; iU0 = 10 ; iTw = 14 ; iP = 11 ;
            # Reynolds
            ######################
            mu = float(mu) ; rho = float(rho) ; nu = mu/rho ;
            U = lData[i][0,iU] ; R = lData[i][0,iR] ; D = 2. * R ; P0 = lData[i][0,iP]
            Re = U * R / nu ; cX = Re * R
            cTw = mu * U / R ; cU0 = U ; cP = rho * (U ** 2.) ;  cQ = np.pi * (R**2) * U

            X = X / cX

            if (iY == iQ) :
                Y = Y / cQ
            elif (iY == iU0) :
                Y = Y / cU0
            elif (iY == iTw) :
                Y = Y / cTw
            elif (iY == iP) :
                Y = (Y-P0) / cP

        ax0.plot(X,Y,label=label, color=col, mec = col , mfc="none", mew=2, marker=mark, markersize=mSize, markevery=max(1,int(float(npos)/10.)), linestyle=style , linewidth=lSize)

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    yFmter = ScalarFormatter() ; yFmter.set_powerlimits((0,5))
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set logscale
    ##############

    if (iY != iTw) :
        ax0.set_xlim(0,0.025)
    else :
        # ax0.set_xlim(1e-4,0.25)
        plt.xscale('log')

    # Set legend and title
    ######################
    if (int(LegPos) == 1) :
        ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    elif (int(LegPos) == 2) :
        ax0.legend(loc=2,bbox_to_anchor=(0.,1.),ncol=1,borderaxespad=0.)
    elif (int(LegPos) == 3) :
        ax0.legend(loc=3,bbox_to_anchor=(0.,0.),ncol=1,borderaxespad=0.)
    elif (int(LegPos) == 4) :
        ax0.legend(loc=4,bbox_to_anchor=(1.,0.),ncol=1,borderaxespad=0.)
    else :
        ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

    # Set xrange
    ######################
    # ax0.set_xlim(0.2,0.8  )

    # Add text
    ######################
    if (text[0] != "") :
        ax0.text(textPos[0][0],textPos[0][1],str(text[0]),horizontalalignment='left',transform=ax0.transAxes)
    if (text[1] != "") :
        ax0.text(textPos[1][0],textPos[1][1],str(text[1]),horizontalalignment='center',transform=ax0.transAxes)


    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig
####################################
# GEOMETRY
####################################

def plot_csv_R0_Artery_Shape(pathStore,title,File,iX,iY,xLabel,yLabel,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    Data = np.genfromtxt(File, delimiter=',')

    iX = int(iX) ; iY = int(iY) ;
    npos = len(Data[:,iX])
    L = Data[npos-1,iX] + 0.5 * (Data[npos-1,iX] - Data[npos-2,iX])

    # x & R0
    ################
    x = Data[:,iX] / L ; R0 = Data[:,iY]
    # Define walls
    ################
    R0max = np.amax(R0) * 1.2
    hwall = R0max*0.2
    wall = np.ones(len(R0)) * np.amax(R0) + hwall
    # Plot initial geometry
    ################
    ax0.plot(x,R0,color = 'red', alpha = 0.75, linestyle="-", linewidth=3)
    ax0.plot(x,-R0,color = 'red', alpha = 0.75, linestyle="-", linewidth=3)
    # Plot arterial Wall (R0+h)
    ################
    ax0.plot(x,wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=3)
    ax0.plot(x,-wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=3)
    # Fill the Wall
    ################
    ax0.fill_between(x,  R0, wall, facecolor='grey', alpha=0.3)
    ax0.fill_between(x, -R0, -wall, facecolor='grey', alpha=0.3)

    # Middle line
    ################
    ax0.axhline(0, color="black", linestyle="--", linewidth=1)

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set xrange
    ######################
    ax0.set_xlim(0,1)

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

def plot_csv_K(pathStore,title,lFile,liX,liY,xLabel,yLabel,lLabel,lCol,lMark,lStyle,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=',')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Wom: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i]) ;
        iX = int(liX[i]) ;
        iY = int(liY[i]) ;

        col = lCol[i] ; mark=str(lMark[i]) ; style = str(lStyle[i])

        npos = len(lData[i][:,iX])

        L = lData[i][npos-1,iX] + 0.5 * (lData[i][npos-1,iX] - lData[i][npos-2,iX])
        # Rigidity
        ax0.plot(lData[i][0:,iX]/L,lData[i][0:,iY],label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle=style)

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=2,bbox_to_anchor=(0.,1.),ncol=1,borderaxespad=0.)

    # Set xrange
    ######################
    ax0.set_xlim(0,1)

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

def plot_csv_A0K(pathStore,title,lFile,liX,liY,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    ax1 = ax0.twinx() ;

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=' ')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Wom: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        labelA = str(lLabel[i][0]) ; labelK = str(lLabel[i][1])
        iXA = int(liX[i][0]) ; iXK = int(liX[i][1])
        iYA = int(liY[i][0]) ; iYK = int(liY[i][1])

        colA = lCol[i][0] ; markA=str(lMark[i][0]) ;
        colK = lCol[i][1] ; markK=str(lMark[i][1]) ;

        npos = len(lData[i][:,iXA])

        LA = lData[i][npos-1,iXA] + 0.5 * (lData[i][npos-1,iXA] - lData[i][npos-2,iXA])
        LK = lData[i][npos-1,iXK] + 0.5 * (lData[i][npos-1,iXK] - lData[i][npos-2,iXK])
        # Section
        ax0.plot(lData[i][0:,iXA]/LA,lData[i][0:,iYA],label=labelA, color=colA, marker=markA, markevery=max(1,int(float(npos)/10.)), linestyle='-')
        # Rigidity
        ax1.plot(lData[i][0:,iXK]/LK,lData[i][0:,iYK],label=labelK, color=colK, marker=markK, markevery=max(1,int(float(npos)/10.)), linestyle='-')

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel[0]);
    ax1.set_ylabel(yLabel[1],labelpad=20)
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())
    yFmter = ScalarFormatter() ; yFmter.set_powerlimits((0,5))
    ax1.xaxis.set_major_formatter(ScalarFormatter()) ; ax1.yaxis.set_major_formatter(yFmter)

    # Set legend and title
    ######################
    ax0.legend(loc=2,bbox_to_anchor=(0.,1.),ncol=1,borderaxespad=0.)
    ax1.legend(loc=1,bbox_to_anchor=(1.,1),ncol=1,borderaxespad=0.)

    # Set xrange
    ######################
    ax0.set_xlim(0,1)

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

def plot_A0(pathStore,title,lFile,liX,liY,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)
    plt.rc('legend', fontsize='19')

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=',')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Wom: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        col = lCol[i] ; mark=str(lMark[i]) ;

        npos = len(lData[i][:,iX])

        ax0.plot(lData[i][1:,iX],lData[i][1:,iY],label=label, color=col, mec = col , mfc="none", mew=1, marker=mark, markersize='7',  markevery=max(1,int(float(npos)/50.)), linestyle='')
        # ax0.plot(lData[i][1:,iX],-lData[i][1:,iY],color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-')
        # ax0.plot(lData[i][:,iX],lData[i][:,iY],label=label, color=col, marker=mark, markevery=max(1,max(1,int(float(npos)/10.))), linestyle='-')

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set x & y limits
    ############################
    ax0.set_ylim(0.25,1);

    # Set legend and title
    ######################
    ax0.legend(loc=4,bbox_to_anchor=(1.,0),ncol=2,borderaxespad=0.)

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

####################################
# SPECIFIC PHYSICS PLOT
####################################

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_csv_Stenose(pathStore,title,lFile,pType,liX,liY,lnu,liP,liR0,liR,liU,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    if (int(liY[0]) == 1) :
        print("Wom data")
        Data = np.genfromtxt(lFile[0], delimiter=',')
    else :
        Data = np.genfromtxt(lFile[0], delimiter=' ')
    lData.append(Data)

    for i in range(1,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=' ')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Stenose: Error in length of lData")


    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        ######################

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])
        col = lCol[i] ; mark=str(lMark[i]) ;
        npos = len(lData[i][:,iX])

        # Steady Code
        if (i==0) :
            ax0.plot(lData[i][:,iX],lData[i][:,iY],label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='--')
        else :
            # Reynolds
            ######################
            nu = float(lnu[i-1])
            iR = int(liR[i-1])
            iR0 = int(liR0[i-1])
            iU = int(liU[i-1])
            iP = int(liP[i-1])
            U = lData[i][0,iU]
            Re = lData[i][0,iU] * lData[i][0,iR] / nu
            ReR = lData[i][0,iU] * lData[i][0,iR0] ** 2. / nu
            P0 = lData[i][0,iP]

            X = np.ones(npos)
            Y = np.ones(npos)
            corr = 1.
            if (pType == 'Tw') :
                # Get ylim
                ##############
                # ax0.set_ylim(-5,45)
                ax0.set_ylim(2.5,7.5)
                # ax0.set_ylim(3.8,4.3)
                # Get Correction
                ##############
                corr = U**2. / Re
                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] / ReR
                    Y[ip] = lData[i][ip,iY] / corr
            elif (pType == 'U0') :
                # Get ylim
                ##############
                # ax0.set_ylim(1.,7)
                ax0.set_ylim(1.8,2.5)
                # ax0.set_ylim(1.95,2.05)
                # Get Correction
                ##############
                corr = U
                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] / ReR
                    Y[ip] = lData[i][ip,iY] / corr
            elif (pType == 'P') :
                # Get ylim
                ##############
                # ax0.set_ylim(-12.,-2.)
                ax0.set_ylim(-8.,-1.)
                # ax0.set_ylim(-6.,-2.)
                # Get Correction
                ##############
                corr = U ** 2.
                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] / ReR
                    Y[ip] = (lData[i][ip,iY]-P0) / corr

            ax0.plot(X,Y,label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-')

    # Set xrange :
    ############################
    ax0.set_xlim(0.3,0.5)

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_csv_Stenose_Comp_1D(pathStore,title,lFile,pType,liX,liY,lnu,liP,liR0,liR,liU,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=' ')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Stenose: Error in length of lData")


    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        ######################

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])
        col = lCol[i] ; mark=str(lMark[i]) ;
        npos = len(lData[i][:,iX])


        # Reynolds
        ######################
        nu = float(lnu[i])
        iR = int(liR[i])
        iR0 = int(liR0[i])
        iU = int(liU[i])
        iP = int(liP[i])
        U = lData[i][0,iU]
        Re = lData[i][0,iU] * lData[i][0,iR] / nu
        ReR = lData[i][0,iU] * lData[i][0,iR0] ** 2. / nu
        P0 = lData[i][0,iP]

        X = np.ones(npos)
        Y = np.ones(npos)
        corr = 1.
        if (pType == 'Tw') :
            # Get ylim
            ##############
            ax0.set_ylim(-5,45)

            # Get Correction
            ##############
            corr = U**2. / Re
            for ip in range(npos) :
                X[ip] = lData[i][ip,iX] / ReR
                Y[ip] = lData[i][ip,iY] / corr

        elif (pType == 'U0') :
            # Get ylim
            ##############
            ax0.set_ylim(1.,7)
            # ax0.set_ylim(1.8,2.5)
            # ax0.set_ylim(1.95,2.05)
            # Get Correction
            ##############
            corr = U
            for ip in range(npos) :
                X[ip] = lData[i][ip,iX] / ReR
                Y[ip] = lData[i][ip,iY] / corr

        elif (pType == 'P') :
            # Get ylim
            ##############
            ax0.set_ylim(-10.,5.)

            # Get Poffset
            Poffset = 0.
            ip=0
            while (lData[i][ip,iX]/ReR < 0.3) :
                ip += 1 ;
            if (np.abs(lData[i][ip,iX]/ReR - 0.3) <= np.abs(lData[i][ip-1,iX]/ReR - 0.3) ) :
                Poffset = lData[i][ip,iY]
            else :
                Poffset = lData[i][ip-1,iY]

            # Get Correction
            ##############
            corr = U ** 2.
            for ip in range(npos) :
                X[ip] = lData[i][ip,iX] / ReR
                Y[ip] = (lData[i][ip,iY]-Poffset) / corr

        if (i % 2 ==0) :
            ax0.plot(X,Y, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='--')
        else :
            ax0.plot(X,Y,label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-')

    # Set xrange :
    ############################
    ax0.set_xlim(0.3,0.5)

    # Set xrange :
    ############################
    ax0.axvline(0.375,color="black",linestyle="-.")

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_csv_Stenose_Perturbation(pathStore,title,lFile,pType,liX,liY,lxmid,ldR,lnu,liP,liR0,liR,liU,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    if (int(liY[0]) == 2 or int(liY[0])== 3) :
        Data = np.genfromtxt(lFile[0], delimiter='\t')
    else :
        Data = np.genfromtxt(lFile[0], delimiter=' ')
    lData.append(Data)

    for i in range(1,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=' ')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Wom: Error in length of lData")


    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        ######################

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])
        col = lCol[i] ; mark=str(lMark[i]) ;
        npos = len(lData[i][:,iX])

        # Linear
        if (i==0) :
            ax0.plot(lData[i][:,iX],lData[i][:,iY],label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-.')
        # Steady
        elif(i==1) :
            if (pType == 'Tw') :
                # Get Uds
                ##############
                Uds = 0.
                ip=0
                while (lData[i][ip,iX] < 0.35) :
                    ip += 1 ;
                if (np.abs(lData[i][ip,iX] - 0.35) <= np.abs(lData[i][ip-1,iX] - 0.35) ) :
                    Uds = lData[i][ip,iY]
                else :
                    Uds = lData[i][ip-1,iY]

                X = np.ones(npos)
                Y = np.ones(npos)
                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] - float(lxmid[i-1])
                    Y[ip] = (lData[i][ip,iY] - Uds) / float(ldR[i-1])
            elif (pType == 'P') :
                # Get Poffset
                ##############
                ip=0
                while (lData[i][ip,iX] < 0.35) :
                    ip += 1 ;
                if (np.abs(lData[i][ip,iX] - 0.35) <= np.abs(lData[i][ip-1,iX] - 0.35) ) :
                    Poffset = (lData[i][ip,iY] + 8. * (lData[i][ip,iX]-float(lxmid[i-1]))) / float(ldR[i-1])
                else :
                    Poffset = (lData[i][ip-1,iY] + 8. * (lData[i][ip-1,iX]-float(lxmid[i-1]))) / float(ldR[i-1])

                X = np.ones(npos)
                Y = np.ones(npos)
                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] - float(lxmid[i-1])
                    Y[ip] = (lData[i][ip,iY] + 8. * X[ip]) / float(ldR[i-1]) - Poffset

            ax0.plot(X,Y,label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='--')
        else :
            # Reynolds
            ######################
            nu = float(lnu[i-2])
            iR = int(liR[i-2])
            iR0 = int(liR0[i-2])
            iU = int(liU[i-2])
            iP = int(liP[i-2])
            U = lData[i][0,iU]
            Re = lData[i][0,iU] * lData[i][0,iR] / nu
            ReR = lData[i][0,iU] * lData[i][0,iR0] ** 2. / nu
            P0 = lData[i][0,iP]

            X = np.ones(npos)
            Y = np.ones(npos)
            corr = 1.
            if (pType == 'Tw') :
                # Get ylim
                ##############
                ax0.set_ylim(-20,100)
                # Get Correction
                ##############
                corr = U**2. / Re
                # Get Uds
                ##############
                Uds = 0.
                ip=0
                while (lData[i][ip,iX]/ReR < 0.35) :
                    ip += 1 ;
                if (np.abs(lData[i][ip,iX]/ReR - 0.35) <= np.abs(lData[i][ip-1,iX]/ReR - 0.35) ) :
                    Uds = lData[i][ip,iY] / corr
                else :
                    Uds = lData[i][ip-1,iY] / corr

                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] / ReR - float(lxmid[i-1])
                    Y[ip] = (lData[i][ip,iY] / corr - float(Uds)) / float(ldR[i-1])
            elif (pType == 'P') :
                # Get ylim
                ##############
                ax0.set_ylim(-17.5,15)
                # Get Correction
                ##############
                corr = U ** 2.
                # Get Poffset
                ##############
                ip=0
                while (lData[i][ip,iX]/ReR< 0.35) :
                    ip += 1 ;
                if (np.abs(lData[i][ip,iX]/ReR - 0.35) <= np.abs(lData[i][ip-1,iX]/ReR - 0.35) ) :
                    Poffset = ((lData[i][ip,iY]-P0) / corr + 8. * (lData[i][ip,iX]/ReR-float(lxmid[i-1]))) / float(ldR[i-1])
                else :
                    Poffset = ((lData[i][ip-1,iY]-P0) / corr + 8. * (lData[i][ip-1,iX]/ReR-float(lxmid[i-1]))) / float(ldR[i-1])

                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] / ReR - float(lxmid[i-1])
                    Y[ip] = ((lData[i][ip,iY]-P0) / corr + 8. * X[ip]  ) /float(ldR[i-1]) - Poffset

            ax0.plot(X,Y,label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-')

    # Set xrange :
    ############################
    ax0.set_xlim(-0.05,0.05)

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_csv_Stenose_Comp_Perturbation(pathStore,title,lFile,pType,liX,liY,lxmid,ldR,lnu,liP,liR0,liR,liU,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    if (int(liY[0]) == 2 or int(liY[0])== 3) :
        Data = np.genfromtxt(lFile[0], delimiter='\t')
    else :
        Data = np.genfromtxt(lFile[0], delimiter=' ')
    lData.append(Data)

    for i in range(1,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=' ')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Wom: Error in length of lData")


    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        ######################

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])
        col = lCol[i] ; mark=str(lMark[i]) ;
        npos = len(lData[i][:,iX])

        # Linear
        if (i==0) :
            ax0.plot(lData[i][:,iX],lData[i][:,iY],label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-.',linewidth='1.5 ', )
        elif (i % 2 != 0) :
            if (pType == 'Tw') :
                # Get Uds
                ##############
                Uds = 0.
                ip=0
                while (lData[i][ip,iX] < 0.35) :
                    ip += 1 ;
                if (np.abs(lData[i][ip,iX] - 0.35) <= np.abs(lData[i][ip-1,iX] - 0.35) ) :
                    Uds = lData[i][ip,iY]
                else :
                    Uds = lData[i][ip-1,iY]

                X = np.ones(npos)
                Y = np.ones(npos)
                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] - float(lxmid[i-1])
                    Y[ip] = (lData[i][ip,iY] - Uds) / float(ldR[i-1])
            elif (pType == 'P') :
                # Get Poffset
                ##############
                ip=0
                while (lData[i][ip,iX] < 0.35) :
                    ip += 1 ;
                if (np.abs(lData[i][ip,iX] - 0.35) <= np.abs(lData[i][ip-1,iX] - 0.35) ) :
                    Poffset = (lData[i][ip,iY] + 8. * (lData[i][ip,iX]-float(lxmid[i-1]))) / float(ldR[i-1])
                else :
                    Poffset = (lData[i][ip-1,iY] + 8. * (lData[i][ip-1,iX]-float(lxmid[i-1]))) / float(ldR[i-1])

                X = np.ones(npos)
                Y = np.ones(npos)
                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] - float(lxmid[i-1])
                    Y[ip] = (lData[i][ip,iY] + 8. * X[ip]) / float(ldR[i-1]) - Poffset

            ax0.plot(X,Y,color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='--', linewidth='0.5 ', alpha=0.8)
        else :
            # Reynolds
            ######################
            nu = float(lnu[2])
            iR = int(liR[2])
            iR0 = int(liR0[2])
            iU = int(liU[2])
            iP = int(liP[2])
            U = lData[i][0,iU]
            Re = lData[i][0,iU] * lData[i][0,iR] / nu
            ReR = lData[i][0,iU] * lData[i][0,iR0] ** 2. / nu
            P0 = lData[i][0,iP]

            X = np.ones(npos)
            Y = np.ones(npos)
            corr = 1.
            if (pType == 'Tw') :
                # Set ylim
                ##############
                ax0.set_ylim(-20,100)
                # Get Correction
                ##############
                corr = U**2. / Re
                # Get Uds
                ##############
                Uds = 0.
                ip=0
                while (lData[i][ip,iX]/ReR < 0.35) :
                    ip += 1 ;
                if (np.abs(lData[i][ip,iX]/ReR - 0.35) <= np.abs(lData[i][ip-1,iX]/ReR - 0.35) ) :
                    Uds = lData[i][ip,iY] / corr
                else :
                    Uds = lData[i][ip-1,iY] / corr

                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] / ReR - float(lxmid[i-1])
                    Y[ip] = (lData[i][ip,iY] / corr - float(Uds)) / float(ldR[i-1])
            elif (pType == 'P') :
                # Set ylim
                ##############
                ax0.set_ylim(-17.5,15)
                # Get Correction
                ##############
                corr = U ** 2.
                # Get Poffset
                ##############
                ip=0
                while (lData[i][ip,iX]/ReR< 0.35) :
                    ip += 1 ;
                if (np.abs(lData[i][ip,iX]/ReR - 0.35) <= np.abs(lData[i][ip-1,iX]/ReR - 0.35) ) :
                    Poffset = ((lData[i][ip,iY]-P0) / corr + 8. * (lData[i][ip,iX]/ReR-float(lxmid[i-1]))) / float(ldR[i-1])
                else :
                    Poffset = ((lData[i][ip-1,iY]-P0) / corr + 8. * (lData[i][ip-1,iX]/ReR-float(lxmid[i-1]))) / float(ldR[i-1])

                for ip in range(npos) :
                    X[ip] = lData[i][ip,iX] / ReR - float(lxmid[i-1])
                    Y[ip] = ((lData[i][ip,iY]-P0) / corr + 8. * X[ip]  ) /float(ldR[i-1]) - Poffset

            ax0.plot(X,Y,label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-')

    # Set xrange :
    ############################
    ax0.set_xlim(-0.05,0.05)

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_csv_Japan(pathStore,title,lFile,liX,liY,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    gcms2ToPa = 10.
    PaTommHg = 0.00750061683

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    if (int(liY[0]) == 1) :
        print("Wom data")
        Data = np.genfromtxt(lFile[0], delimiter=',')
    else :
        Data = np.genfromtxt(lFile[0], delimiter=' ')
    lData.append(Data)

    for i in range(1,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=' ')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Wom: Error in length of lData")


    # Plot different data blocks
    ############################
    for i in range(nPlot) :
        corr= 1. ;
        Poffset = 25000.
        if (i==0) :
            Poffset = 0.
            corr = 10000.

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        col = lCol[i] ; mark=str(lMark[i]) ;

        npos = len(lData[i][:,iX])

        ax0.plot(lData[i][:,iX],(lData[i][:,iY]+Poffset)*corr,label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-')

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_csv_Jump(pathStore,title,lFile,liX,liY,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=' ')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Wom: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        col = lCol[i] ; mark=str(lMark[i]) ;

        npos = len(lData[i][:,iX])

        ax0.plot(lData[i][:,iX],lData[i][:,iY],label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-')

    # ax0.plot(lData[0][:,iX],0.1*lData[0][:,iX])
    # ax0.plot(lData[0][:,iX],0.1*lData[0][:,iX]**(0.5))

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())


    # Set range and scale
    ############################
    # ax0.set_xlim(98,100.)
    ax0.set_ylim(0.,1.4)
    # plt.xscale('log')
    # plt.yscale('log')

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=3,borderaxespad=0.)

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

def plot_csv_Err(Order,pathStore,title,lFile,liX,liY,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=' ')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Err: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        col = lCol[i] ; mark=str(lMark[i]) ;

        npos = len(lData[i][:,iX])

        ax0.plot(lData[i][:,iX],lData[i][:,iY],label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-')

        # Get error tendancy (with last point or first point)
        ############################
        if (Order == 1) :
            Coeff = lData[i][npos-1,iY] / ( lData[i][npos-1,iX] ** (-int(Order))  )
            errTendancy = Coeff * (lData[i][:,iX]**(-int(Order)))
        if (Order == 2) :
            Coeff = lData[i][0,iY] / ( lData[i][0,iX] ** (-int(Order))  )
            errTendancy = Coeff * (lData[i][:,iX]**(-int(Order)))

            Coeff = lData[i][0,iY] / ( lData[i][0,iX] ** (-1.5)  )
            errTendancy_1p5 = Coeff * (lData[i][:,iX]**(-1.5))
            ax0.plot(lData[i][:,iX],errTendancy_1p5[:],color=col,linestyle='-.')
        ax0.plot(lData[i][:,iX],errTendancy[:],color=col,linestyle='--')

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

    # Set logscale
    ######################
    plt.xscale('log')
    plt.yscale('log')



    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

def plot_csv_Err_dR(Order,pathStore,title,lFile,liX,liY,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=' ')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Err: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        col = lCol[i] ; mark=str(lMark[i]) ;

        npos = len(lData[i][:,iX])

        ax0.plot(lData[i][:,iX],lData[i][:,iY],label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-')

        # Get error tendancy (with last point or first point)
        ############################
        # if (Order == 1) :
        #     Coeff = lData[i][npos-1,iY] / ( lData[i][npos-1,iX] ** (-int(Order))  )
        #     errTendancy = Coeff * (lData[i][:,iX]**(-int(Order)))
        # if (Order == 2) :
        #     Coeff = lData[i][0,iY] / ( lData[i][0,iX] ** (-int(Order))  )
        #     errTendancy = Coeff * (lData[i][:,iX]**(-int(Order)))
        #
        #     Coeff = lData[i][0,iY] / ( lData[i][0,iX] ** (-1.5)  )
        #     errTendancy_1p5 = Coeff * (lData[i][:,iX]**(-1.5))
        #     ax0.plot(lData[i][:,iX],errTendancy_1p5[:],color=col,linestyle='-.')
        # ax0.plot(lData[i][:,iX],errTendancy[:],color=col,linestyle='--')

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

    # Set logscale
    ######################
    # plt.xscale('log')
    plt.yscale('log')

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

def plot_csv_Err_Fr(Order,pathStore,title,lFile,liX,liY,xLabel,yLabel,lLabel,lCol,lMark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)!=nPlot or len(liY)!=nPlot or len(lLabel)!=nPlot or len(lCol)!=nPlot or len(lMark)!=nPlot) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=' ')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Err: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        col = lCol[i] ; mark=str(lMark[i]) ;

        npos = len(lData[i][:,iX])

        ax0.plot(lData[i][:,iX],lData[i][:,iY],label=label, color=col, marker=mark, markevery=max(1,int(float(npos)/10.)), linestyle='-')

        # Get error tendancy (with last point or first point)
        ############################
        # if (Order == 1) :
        #     Coeff = lData[i][npos-1,iY] / ( lData[i][npos-1,iX] ** (-int(Order))  )
        #     errTendancy = Coeff * (lData[i][:,iX]**(-int(Order)))
        # if (Order == 2) :
        #     Coeff = lData[i][0,iY] / ( lData[i][0,iX] ** (-int(Order))  )
        #     errTendancy = Coeff * (lData[i][:,iX]**(-int(Order)))
        #
        #     Coeff = lData[i][0,iY] / ( lData[i][0,iX] ** (-1.5)  )
        #     errTendancy_1p5 = Coeff * (lData[i][:,iX]**(-1.5))
        #     ax0.plot(lData[i][:,iX],errTendancy_1p5[:],color=col,linestyle='-.')
        # ax0.plot(lData[i][:,iX],errTendancy[:],color=col,linestyle='--')

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

    # Set logscale
    ######################
    plt.xscale('log')
    plt.yscale('log')

    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig

##########################################
# 55 Arteries frequency comparison
##########################################
def plot_csv_Frequency(pathStore,title,lFile,liX,liY,lFreq,xLabel,yLabel,lLabel,LegPos,text,textPos,lCol,lMark,lMarkSize,lLineSize,lStyle,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.9, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    nPlot = len(lFile)
    if (len(liX)<nPlot or len(liY)<nPlot or len(lLabel)<nPlot or len(lCol)<nPlot or len(lMark)<nPlot or len(lStyle)<nPlot or len(text)!=2) :
        print("plot_csv_Wom: Error in length of input lists")
        sys.exit()

    # List of data
    ################
    lData = []

    for i in range(0,nPlot):
        Data = np.genfromtxt(lFile[i], delimiter=',')
        lData.append(Data)

    if (len(lData) != nPlot) :
        print("plot_csv_Wom: Error in length of lData")

    # Plot different data blocks
    ############################
    for i in range(nPlot) :

        label = str(lLabel[i])
        iX = int(liX[i])
        iY = int(liY[i])

        col = lCol[i] ; mark=str(lMark[i]) ; style = str(lStyle[i]);
        mSize = int(lMarkSize[i]) ; lSize = int(lLineSize[i]) ;

        npos = len(lData[i][:,iX])

        X = []
        for ip in range(npos) :
            if (lData[i][ip,iX]>= lData[i][npos-1,iX]-lFreq[i]) :
                X.append(lData[i][ip,iX])
        n = npos - len(X)

        Xp = (X[:] - X[0]) / (X[len(X)-1]-X[0])

        ax0.plot(Xp,lData[i][n:,iY],label=label, color=col, mec = col , mfc="none", mew=2, marker=mark, markersize=mSize, markevery=max(1,int(float(npos)/50.)), linestyle=style , linewidth=lSize)

    # Set label and ticks format
    ############################
    ax0.set_xlabel(xLabel) ; ax0.set_ylabel(yLabel);
    yFmter = ScalarFormatter() ; yFmter.set_powerlimits((0,5))
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    if (int(LegPos) == 1) :
        ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    elif (int(LegPos) == 2) :
        ax0.legend(loc=2,bbox_to_anchor=(0.,1.),ncol=1,borderaxespad=0.)
    elif (int(LegPos) == 3) :
        ax0.legend(loc=3,bbox_to_anchor=(0.,0.),ncol=1,borderaxespad=0.)
    else :
        ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

    # Set xrange
    ######################
    # ax0.set_xlim(lData[0][1,iX],lData[0][len(lData[0][:,iX])-1,iX])

    # Add text
    ######################
    if (text[0] != "") :
        ax0.text(textPos[0][0],textPos[0][1],str(text[0]),horizontalalignment='left',transform=ax0.transAxes)
    if (text[1] != "") :
        ax0.text(textPos[1][0],textPos[1][1],str(text[1]),horizontalalignment='center',transform=ax0.transAxes)


    fig_title = pathStore+str(title)
    fig.savefig(fig_title, format='eps', bbox_inches='tight')

    return nfig
