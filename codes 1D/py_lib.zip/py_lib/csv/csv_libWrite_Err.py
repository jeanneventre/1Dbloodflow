#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

from csv_libErr import csv_get_Error,csv_Error_x, csv_Error_r

def kahanSum(IN) :
    S = IN[0] ;
    c = 0. ; y = 0. ; t= 0. ;
    for i in range(1,len(IN)) :
        y = IN[i] - c  ;
        t = S + y ;
        c = (t - S) - y ;
        S = t ;
    return S

def latex_power(num, decimal_digits=1, precision=None, exponent=None):
    """
    Returns a string representation of the scientific
    notation of the given number formatted for use with
    LaTeX or Mathtext, with specified number of significant
    decimal digits and precision (number of decimal digits
    to show). The exponent to be used can also be specified
    explicitly.
    """
    if (num == 0.) :
        return "$0$"
    else :
        if not exponent:
            exponent = int(np.floor(np.log10(abs(num))))
        coeff = round(num / float(10.**exponent), decimal_digits)
        if not precision:
            precision = decimal_digits

        return r"${0:.{2}f} \times 10^{{{1:d}}}$".format(coeff, exponent, precision)

def write_csv_Err_Cv(pathStore,title,llFile,llFileSep,llX,llY,llFact,lFactOrder,xrType,Ltype) :

    # Number of levels of mesh raffinement
    nData = len(llFile) ;

    # Verification
    if (len(llX)<nData or len(llY)<nData):
        print("csv_libWrite_Err:: write_csv_Err_CV Error in length of lFile and llX and llY")
        sys.exit()
    if (len(llFact)<nData) :
        print("csv_libWrite_Err:: write_csv_Err_CV Error in length of lFact")
        sys.exit()
    if (len(lFactOrder)<nData) :
        print("csv_libWrite_Err:: write_csv_Err_CV Error in length of lFactOrder")
        sys.exit()

    # Open file
    fileName = pathStore + title
    fh = open(fileName,'w',1)
    # Write first line
    fh.write("#%s,\t %s,\t "%("N","Err"))

    # Initialize
    nN      = 0;
    LErr    = 0;

    # Store data
    ############################
    X = [] ; Y = []
    # Loop on mesh raffinement levels:
    for iData in range(nData) :

        nNm1        = nN ;
        LErrm1      = LErr ;
        nN,LErr     = csv_get_Error(llFile[iData],llFileSep[iData],llX[iData],llY[iData],llFact[iData],xrType,Ltype)
        X.append(nN*float(lFactOrder[iData]))
        Y.append(LErr)

    # Get global order of convergence
    ############################
    A = np.vstack([np.log10(X), np.ones(len(X))]).T
    m, c = np.linalg.lstsq(A, np.log10(Y))[0]
    fh.write("%s, \t %s \n"%(str(m)+"x+"+str(c),"Order"))

    # Start regression at first point
    #################################
    Xreg = X ; Yreg = Y ;
    for iData in range(nData) :
        Yreg[iData] =  Y[0] * ( (10.**c) * (Xreg[iData])**m ) / ( (10.**c) * (Xreg[0])**m )

    # Initialize
    nN      = 0;
    LErr    = 0;

    # Loop on mesh raffinement levels:
    for iData in range(nData) :

        nNm1        = nN ;
        LErrm1      = LErr ;
        nN,LErr     = csv_get_Error(llFile[iData],llFileSep[iData],llX[iData],llY[iData],llFact[iData],xrType,Ltype)

        if (iData == 0) :
            fh.write("%d, \t %.2E, \t %.2E, \t %s \n"%(nN*float(lFactOrder[iData]),LErr,Yreg[iData],"" ) )
            # fh.write("%d$& \t %s& \t %s \n"%(nN,latex_power(num=LErr, decimal_digits=1,precision=1),"$-$&" ) )
        else :
            # Get order of convergence
            ############################
            m = np.log(LErr/LErrm1) / np.log(float(nN*float(lFactOrder[iData]))/float(nNm1*float(lFactOrder[iData-1])))

            fh.write("%d, \t %.2E, \t %.2E, \t %.4f \n"%(nN*float(lFactOrder[iData]),LErr,Yreg[iData],m) )
            # fh.write("$%d$& \t %s& \t $%.2f$& \n"%(nN,latex_power(num=LErr, decimal_digits=1,precision=1),m) )

        # Store data
        X.append(nN*float(lFactOrder[iData]))
        Y.append(LErr)

    # Get global order of convergence
    ############################
    A = np.vstack([np.log10(X), np.ones(len(X))]).T
    m, c = np.linalg.lstsq(A, np.log10(Y))[0]
    fh.write("%s, \t %s, \t %s, \t %.4f \n"%("","","",m) )

    fh.close()
