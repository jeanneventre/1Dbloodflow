#!/usr/local/bin/python3
import sys
import numpy as np

def cmk(RHO,K,A) :
    return np.sqrt( 0.5 * K / RHO * np.sqrt(A) )

def data_csv_Slope(File,iX,iY) :

    Data    = np.genfromtxt(File, delimiter=',')
    Slope   = (Data[1,iY] - Data[0,iY] ) / (Data[1,iX]-Data[0,iX])
    print(Slope)

def data_csv_Slope_adim(File,iX,iY,xScale,yScale) :

    Data    = np.genfromtxt(File, delimiter=',')
    Slope   = (Data[2,iY] - Data[1,iY] ) / (Data[2,iX]-Data[1,iX])
    SlopeAdim = Slope * xScale/yScale ;
    print(SlopeAdim)
