#!/usr/local/bin/python3
from help_plot          import *
from bfS_libBlock       import *

FFMpegWriter    = animation.writers['ffmpeg']
metadata        = dict(title='Movie', artist='Arthur Ghigo',
                    comment='Awesome movie')

def findMinMax(lBlock,iX) :
    Min = 0. ; Max = 0. ;
    for iT in range(len(lBlock)) :
        Mi = np.amin(lBlock[iT][:,int(iX)])
        Ma = np.amax(lBlock[iT][:,int(iX)])
        if (Ma > Max) :
            Max=Ma
        if (Mi < Min) :
            Min = Mi
    return Min,Max

###########################################
# Define new colormaps
###########################################
BlueRed = make_colormap(
    [colors.ColorConverter().to_rgb('navy'),
     colors.ColorConverter().to_rgb('mediumblue'),    0.1,   colors.ColorConverter().to_rgb('mediumblue'),
     colors.ColorConverter().to_rgb('Blue'),    0.2,   colors.ColorConverter().to_rgb('Blue'),
     colors.ColorConverter().to_rgb('royalblue'), 0.3,   colors.ColorConverter().to_rgb('royalblue'),
     colors.ColorConverter().to_rgb('dodgerblue'), 0.4,   colors.ColorConverter().to_rgb('dodgerblue'),
     colors.ColorConverter().to_rgb('deepskyblue'), 0.5,   colors.ColorConverter().to_rgb('coral'),
     colors.ColorConverter().to_rgb('darkorange'), 0.6,   colors.ColorConverter().to_rgb('darkorange'),
     colors.ColorConverter().to_rgb('orangered'), 0.7,   colors.ColorConverter().to_rgb('orangered'),
     colors.ColorConverter().to_rgb('tomato'), 0.8,   colors.ColorConverter().to_rgb('tomato'),
     colors.ColorConverter().to_rgb('red'), 0.9,   colors.ColorConverter().to_rgb('red'),
     colors.ColorConverter().to_rgb('darkred'), 0.95,   colors.ColorConverter().to_rgb('darkred')],'BlueRed')

plt.register_cmap(cmap=BlueRed)

# BlueRed = make_colormap(
#     [colors.ColorConverter().to_rgb('navy'),
#      colors.ColorConverter().to_rgb('mediumblue'),    0.1,   colors.ColorConverter().to_rgb('mediumblue'),
#      colors.ColorConverter().to_rgb('Blue'),    0.2,   colors.ColorConverter().to_rgb('Blue'),
#      colors.ColorConverter().to_rgb('royalblue'), 0.3,   colors.ColorConverter().to_rgb('royalblue'),
#      colors.ColorConverter().to_rgb('dodgerblue'), 0.4,   colors.ColorConverter().to_rgb('dodgerblue'),
#      colors.ColorConverter().to_rgb('deepskyblue'), 0.499,   colors.ColorConverter().to_rgb('green'),
#      colors.ColorConverter().to_rgb('green'), 0.5,   colors.ColorConverter().to_rgb('green'),
#      colors.ColorConverter().to_rgb('green'), 0.501,   colors.ColorConverter().to_rgb('darkorange'),
#      colors.ColorConverter().to_rgb('darkorange'), 0.6,   colors.ColorConverter().to_rgb('darkorange'),
#      colors.ColorConverter().to_rgb('orangered'), 0.7,   colors.ColorConverter().to_rgb('orangered'),
#      colors.ColorConverter().to_rgb('tomato'), 0.8,   colors.ColorConverter().to_rgb('tomato'),
#      colors.ColorConverter().to_rgb('red'), 0.9,   colors.ColorConverter().to_rgb('red'),
#      colors.ColorConverter().to_rgb('darkred'), 0.95,   colors.ColorConverter().to_rgb('darkred')],'BlueRed')
#
# plt.register_cmap(cmap=BlueRed)

######################################
# Average quantities
######################################
def animate_x(cls,numArt,pType,TextPos,TextAlign,TextColor,speedUp,slowDownfps,nf) :

    nfig = nf ; fig = plt.figure(nfig) ; nfig += 1

    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.2, right=0.95, bottom=0.15, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Define second line: Ur
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ;

    # Get data block
    ################
    lBlock = cls.readBlock(nArt=art)

    nt = len(lBlock)
    nx = len(lBlock[0][:,0])

    x = lBlock[0][:,1]

    # Find min and max
    ##################
    pMin = 0.; pMax = 0. ;
    for it in range(nt) :
        pLabel, pData = plotBlock(cls=cls,Block=lBlock[it],pType=pType)
        if (np.max(pData) > pMax) :
            pMax = np.max(pData)
        if (np.min(pData) < pMin) :
            pMin = np.min(pData)

    # Set labels
    ############
    ax0.set_xlabel(r"$x$ $\left[cm\right]$") ; ax0.set_ylabel(pLabel)
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())
    # Set limits
    ############
    ax0.set_xlim(x[0],x[nx-1]) ; ax0.set_ylim(pMin,pMax)
    ax0.axhline(0, color='grey',linestyle='--')
    # Set legend
    ############
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

    # Set artists
    #############
    line0, = ax0.plot([],[],color="blue",label=str(pType),linewidth=1.5,linestyle='-')
    time_text = ax0.text(TextPos[0],TextPos[1],'',horizontalalignment=str(TextAlign),color=str(TextColor),transform=ax0.transAxes)

    # TIME PARAMETERS :
    increaseSpeed = int(speedUp)
    dt = cls.dtrec * increaseSpeed
    tmin = lBlock[1][0,0]
    tmax = lBlock[nt-1][0,0]
    numFrames = int( (tmax-tmin ) / dt )

    def init_movie():
        line0.set_data([],[]) ;
        time_text.set_text('') ;
        return line0, time_text,

    def animate_movie(i):
        # i=i+1 as first Block not taken into account
        i = i+1
        pLabel, pData = plotBlock(cls=cls,Block=lBlock[i*increaseSpeed],pType=pType)
        line0.set_data(x,pData)
        ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

        time = tmin + float(i) * dt
        print("i/i_tot= ",i*increaseSpeed/(nt-1.),", t = ",time)
        time_text.set_text(r'$t=$ %.3f $s$' % time) ;

        return line0,time_text

    # Run animation
    ###############
    interval = dt
    ani = animation.FuncAnimation(  fig, animate_movie, init_func = init_movie,
                                    frames= numFrames, blit=True,
                                    interval = interval, repeat = False)

    # Write for animation
    #####################
    fps = int(  float(numFrames)/(tmax-tmin) / float(slowDownfps) )
    writer = FFMpegWriter(fps=fps, metadata=metadata, bitrate=-1, codec="libx264")


    # Save animation
    ################
    # ani.save(cls.path+"Movies/" + str(pType) + "_Art_" + str(art) + ".mp4", writer=writer,savefig_kwargs={},extra_args=['--verbose-debug','-pix_fmt', 'yuv420p'])
    ani.save(cls.path+"Movies/" + str(pType) + "_Art_" + str(art) + ".mp4", writer=writer,savefig_kwargs={},extra_args=['-pix_fmt', 'yuv420p'])

    return nfig

def animate_noframe_x(cls,numArt,pType,speedUp,slowDownfps,nf) :

    nfig = nf ; fig = plt.figure(nfig) ; nfig += 1

    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.2, right=0.95, bottom=0.15, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Define second line: Ur
    # Remove tick_params
    ax0.tick_params(top='off',bottom='off',left='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=0) ; ax0.locator_params(axis='y',tight=True, nbins=0)
    # Remove frame
    fig.patch.set_visible(False)
    ax0.axis('off')

    art = int(numArt) ;

    # Get data block
    ################
    lBlock = cls.readBlock(nArt=art)

    nt = len(lBlock)
    nx = len(lBlock[0][:,0])

    x = lBlock[0][:,1]

    # Find min and max
    ##################
    pMin = 0.; pMax = 0. ;
    for it in range(nt) :
        pLabel, pData = plotBlock(cls=cls,Block=lBlock[it],pType=pType)
        if (np.max(pData) > pMax) :
            pMax = np.max(pData)
        if (np.min(pData) < pMin) :
            pMin = np.min(pData)

    # Set limits
    ############
    ax0.set_xlim(x[0],x[nx-1]) ; ax0.set_ylim(pMin,pMax)
    # Set legend
    ############
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

    # Set artists
    #############
    line0, = ax0.plot([],[],color="blue",linewidth=3,linestyle='-')

    # TIME PARAMETERS :
    increaseSpeed = int(speedUp)
    dt = cls.dtrec * increaseSpeed
    tmin = lBlock[1][0,0]
    tmax = lBlock[nt-1][0,0]
    numFrames = int( (tmax-tmin ) / dt )

    def init_movie():
        line0.set_data([],[]) ;
        return line0,

    def animate_movie(i):
        # i=i+1 as first Block not taken into account
        i = i+1
        pLabel, pData = plotBlock(cls=cls,Block=lBlock[i*increaseSpeed],pType=pType)
        line0.set_data(x,pData)

        time = tmin + float(i) * dt
        print("i/i_tot= ",i*increaseSpeed/(nt-1.),", t = ",time)

        return line0,

    # Run animation
    ###############
    interval = dt
    ani = animation.FuncAnimation(  fig, animate_movie, init_func = init_movie,
                                    frames= numFrames, blit=True,
                                    interval = interval, repeat = False)

    # Write for animation
    #####################
    fps = int(  float(numFrames)/(tmax-tmin) / float(slowDownfps) )
    writer = FFMpegWriter(fps=fps, metadata=metadata, bitrate=-1, codec="libx264")


    # Save animation
    ################
    # ani.save(cls.path+"Movies/" + str(pType) + "_Art_" + str(art) + ".mp4", writer=writer,savefig_kwargs={},extra_args=['--verbose-debug','-pix_fmt', 'yuv420p'])
    ani.save(cls.path+"Movies/" + str(pType) + "_Art_" + str(art) + ".mp4", writer=writer,savefig_kwargs={},extra_args=[])

    return nfig
