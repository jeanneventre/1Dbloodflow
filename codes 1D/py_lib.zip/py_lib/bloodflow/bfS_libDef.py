#!/usr/local/bin/python3
import os
import sys

from decimal import *
import numpy as np

EPSILON = 1.e-12

def kahanSum(IN) :
    S = IN[0] ;
    c = 0. ; y = 0. ; t= 0. ;
    for i in range(1,len(IN)) :
        y = IN[i] - c  ;
        t = S + y ;
        c = (t - S) - y ;
        S = t ;
        # if (c==0.) :
            # print("Error in kahanSum, c==0",c)
    return S

class artery(object):
    def __init__(self, ID):
        self.ID=ID
        self.daughterArts=[]
        self.parentArts=[]
        self.headPt=[]
        self.tailPt=[]
    def __del__(self):
      class_name = self.__class__.__name__
    #   print class_name, "destroyed"

    # First artery
    def iDAG(self,hConj,dArts,xType,xData,FData,HData,tConj,nt) :
        # Generic tail junction
        tlConj = self.ID+1
        # Daughter arteries
        self.daughterArts=dArts
        for arts in dArts :
            arts.parentArts.append(self)
        # Head point
        self.headPt.append(point(int(hConj)))
        self.headPt[0].type     = xType
        self.headPt[0].data     = xData
        self.headPt[0].typeF    = "inF"
        self.headPt[0].dataF    = FData
        self.headPt[0].typeH    = "inH"
        self.headPt[0].dataH    = HData
        # Tail point
        self.tailPt.append(point(int(tlConj)))
        self.tailPt[0].type = tConj
        self.tailPt[0].data = []

    def jDAG(self,hConj,dArts,tConj,nt) :
        # Generic tail junction
        tlConj = self.ID+1
        # Daughter arteries
        self.daughterArts=dArts
        for arts in dArts :
            arts.parentArts.append(self)
        # Head point
        self.headPt.append(point(int(hConj)))
        self.headPt[0].type = tConj
        self.headPt[0].data = []
        # Tail point
        self.tailPt.append(point(int(tlConj)))
        self.tailPt[0].type = tConj
        self.tailPt[0].data = []

    # Anastomosis
    def aDAG(self,hConj,tlConj,dArts,tConj,nt) :
        # Daughter arteries
        self.daughterArts=dArts
        for arts in dArts :
            arts.parentArts.append(self)
        # Head point
        self.headPt.append(point(int(hConj)))
        self.headPt[0].type = tConj
        self.headPt[0].data = []
        # Tail point
        self.tailPt.append(point(int(tlConj)))
        self.tailPt[0].type = tConj
        self.tailPt[0].data = []

    def RtDAG(self,hConj,Rt,tConj,nt) :
        # Generic tail junction
        tlConj = self.ID+1
        # Daughter arteries
        self.daughterArts=[]
        # Head point
        self.headPt.append(point(int(hConj)))
        self.headPt[0].type = tConj
        self.headPt[0].data = []#np.zeros(int(nt))
        # Tail point
        self.tailPt.append(point(int(tlConj)))
        self.tailPt[0].type = "outRt"
        self.tailPt[0].data = [float(Rt)]

    def RDAG(self,hConj,R1,tConj,nt) :
        # Generic tail junction
        tlConj = self.ID+1
        # Daughter arteries
        self.daughterArts=[]
        # Head point
        self.headPt.append(point(int(hConj)))
        self.headPt[0].type = tConj
        self.headPt[0].data = []#np.zeros(int(nt))
        # Tail point
        self.tailPt.append(point(int(tlConj)))
        self.tailPt[0].type = "outR1"
        self.tailPt[0].data = [float(R1)]

    def RCRDAG(self,hConj,R1,C1,R2,tConj,nt) :
        # Generic tail junction
        tlConj = self.ID+1
        # Daughter arteries
        self.daughterArts=[]
        # Head point
        self.headPt.append(point(int(hConj)))
        self.headPt[0].type = tConj
        self.headPt[0].data = []#np.zeros(int(nt))
        # Tail point
        self.tailPt.append(point(int(tlConj)))
        self.tailPt.append(point(int(tlConj)))
        self.tailPt.append(point(int(tlConj)))

        self.tailPt[0].type = "outR1"
        self.tailPt[0].data = [float(R1)]

        self.tailPt[1].type = "outC1"
        self.tailPt[1].data = [float(C1)]

        self.tailPt[2].type = "outR2"
        self.tailPt[2].data = [float(R2)]

class point() :
    def __init__(self,ID):
        self.ID=ID
        self.bc=""
        self.dataJ = []
        self.dataH = []
        self.dataF = []
        self.dataC = []
        self.dataO = []
    def __del__(self):
      class_name = self.__class__.__name__
    #   print class_name, "destroyed"

class timeSetup(): pass

class network():
    def __init__(self,ARTS,tS):
        self.arts=ARTS
        self.tS=tS
    def __del__(self):
      class_name = self.__class__.__name__
    #   print class_name, "destroyed"

    #####################################
    #####################################
    def writeParam(self,folder="."):

        print("paramters printed in folder: \"%s/\"\n"%folder)

        fileName = folder+"/DAG.csv"
        with open(fileName,'w') as fh:
            for art in self.arts:
                fh.write("%d,%d"%(art.headPt[0].ID,art.tailPt[0].ID) + "\n")

        fileName = folder+"/inout.csv"
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#Artery","BC Type"))
            for it in range (len(self.tS.tt)) :
                fh.write(",%20.20f"%(self.tS.tt[it]))
            fh.write("\n")

            for art in self.arts:

                if (len(art.headPt) != 0) :
                    for ip in range(len(art.headPt)) :

                        fh.write("%d,%s"%(art.ID,art.headPt[ip].type))
                        if (art.headPt[ip].type != "jS" and art.headPt[ip].type != "jA") :
                            if (len(art.headPt[ip].data) == 1 ) :
                                fh.write(",%20.20f"%(art.headPt[ip].data[0]))
                            elif (len(art.headPt[ip].data) == len(self.tS.tt)) :
                                for it in range (len(self.tS.tt)) :
                                    fh.write(",%20.20f"%(art.headPt[ip].data[it]))
                            else :
                                print(art.ID,art.headPt[ip].ID,art.tailPt[ip].ID,art.headPt[ip].type)
                                print("inout.csv Error in the length of head point data")
                                sys.exit()

                        fh.write("\n")

                        # Hematocrit
                        if (len(art.headPt[ip].dataH)!=0) :
                            fh.write("%d,%s"%(art.ID,art.headPt[ip].typeH))
                            for it in range (len(self.tS.tt)) :
                                fh.write(",%20.20f"%(art.headPt[ip].dataH[it]))
                            fh.write("\n")
                        # Aggregation
                        if (len(art.headPt[ip].dataF)!=0) :
                            fh.write("%d,%s"%(art.ID,art.headPt[ip].typeF))
                            for it in range (len(self.tS.tt)) :
                                fh.write(",%20.20f"%(art.headPt[ip].dataF[it]))
                            fh.write("\n")
                        # Concentration
                        if (len(art.headPt[ip].dataC)!=0) :
                            fh.write("%d,%s"%(art.ID,art.headPt[ip].typeC))
                            for it in range (len(self.tS.tt)) :
                                fh.write(",%20.20f"%(art.headPt[ip].dataC[it]))
                            fh.write("\n")
                        # Oxygen
                        if (len(art.headPt[ip].dataO)!=0) :
                            fh.write("%d,%s"%(art.ID,art.headPt[ip].typeO))
                            for it in range (len(self.tS.tt)) :
                                fh.write(",%20.20f"%(art.headPt[ip].dataO[it]))
                            fh.write("\n")

                if (len(art.tailPt) != 0) :
                    for ip in range(len(art.tailPt)) :

                        fh.write("%d,%s"%(art.ID,art.tailPt[ip].type))

                        if (art.tailPt[ip].type != "jS" and art.tailPt[ip].type != "jA") :
                            if (len(art.tailPt[ip].data)==1) :
                                fh.write(",%20.20f"%(art.tailPt[ip].data[0]))
                            elif (len(art.tailPt[ip].data) == len(self.tS.tt)) :
                                for it in range (len(self.tS.tt)) :
                                    fh.write(",%20.20f"%(art.tailPt[ip].data[it]))
                            else :
                                print(art.ID,len(art.tailPt[ip].data))
                                print("inout.csv Error in the length of tail point data")
                                sys.exit()

                        fh.write("\n")

                        # Hematocrit
                        if (len(art.tailPt[ip].dataH)!=0) :
                            fh.write("%d,%s"%(art.ID,art.tailPt[ip].typeH))
                            for it in range (len(self.tS.tt)) :
                                fh.write(",%20.20f"%(art.tailPt[ip].dataH[it]))
                            fh.write("\n")
                        # Aggregation
                        if (len(art.tailPt[ip].dataF)!=0) :
                            fh.write("%d,%s"%(art.ID,art.tailPt[ip].typeF))
                            for it in range (len(self.tS.tt)) :
                                fh.write(",%20.20f"%(art.tailPt[ip].dataF[it]))
                            fh.write("\n")
                        # Concentration
                        if (len(art.tailPt[ip].dataC)!=0) :
                            fh.write("%d,%s"%(art.ID,art.tailPt[ip].typeC))
                            for it in range (len(self.tS.tt)) :
                                fh.write(",%20.20f"%(art.tailPt[ip].dataC[it]))
                            fh.write("\n")
                        # Oxygen
                        if (len(art.tailPt[ip].dataO)!=0) :
                            fh.write("%d,%s"%(art.ID,art.tailPt[ip].typeO))
                            for it in range (len(self.tS.tt)) :
                                fh.write(",%20.20f"%(art.tailPt[ip].dataO[it]))
                            fh.write("\n")

        fileName = folder+"/Parameters/initA.csv"
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<A> [cm^2]") + "\n")
            for art in self.arts:

                fh.write("%d"%(art.ID))
                for ix in range(len(art.initA)) :
                    fh.write(",%20.20f"%(art.initA[ix]))
                fh.write("\n")

        fileName = folder+"/Parameters/initQ.csv"
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<Q> [cm^3/s]") + "\n")
            for art in self.arts:

                fh.write("%d"%(art.ID))
                for ix in range(len(art.initQ)) :
                    fh.write(",%20.20f"%(art.initQ[ix]))
                fh.write("\n")

        fileName = folder+"/Parameters/initF.csv"
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<f>") + "\n")
            for art in self.arts:

                fh.write("%d"%(art.ID))
                for ix in range(len(art.initF)) :
                    fh.write(",%20.20f"%(art.initF[ix]))
                fh.write("\n")

        fileName = folder+"/Parameters/initH.csv"
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<H> []") + "\n")
            for art in self.arts:

                fh.write("%d"%(art.ID))
                for ix in range(len(art.initH)) :
                    fh.write(",%20.20f"%(art.initH[ix]))
                fh.write("\n")

        fileName = folder+"/Parameters/initC.csv"
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<C> []") + "\n")
            for art in self.arts:

                fh.write("%d"%(art.ID))
                for ix in range(len(art.initC)) :
                    fh.write(",%20.20f"%(art.initC[ix]))
                fh.write("\n")

        fileName = folder+"/Parameters/initO.csv"
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<O> []") + "\n")
            for art in self.arts:

                fh.write("%d"%(art.ID))
                for ix in range(len(art.initO)) :
                    fh.write(",%20.20f"%(art.initO[ix]))
                fh.write("\n")

        fileName = folder +'/Parameters/systemic_network.csv'
        with open(fileName,'w') as fh:
            fh.write( "%s,%s,%s,%s,%s,%s,%s"%('#Artery', '<Nx>', '<L> [cm]', '<rho> [g/cm^3]', '<Solver>', '<Order>', '<HR>') + "\n" );
            for art in self.arts :
                fh.write("%d,%d,%20.20f,%20.20f,%s,%f,%s"%(art.ID, art.N, art.L, art.rho, art.solver, art.solverOrder, art.HR ) + "\n" )

        fileName = folder + '/Parameters/dx.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<dx> [cm]") + "\n")
            for art in self.arts:
                if (art.N != len(art.dx)) :
                    print("In networkdef dx: Error in the number cells for artery ",art.ID)
                    sys.exit()
                if (abs(kahanSum(art.dx)-art.L) > EPSILON) :
                    print("In network_def dx: Error in the mesh size of artery ",art.ID)
                    print(kahanSum(art.dx),art.L,abs(kahanSum(art.dx)-art.L))
                fh.write("%d"%(art.ID))
                for i in range(len(art.dx)) :
                    fh.write(",%20.20f"%(art.dx[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/A0.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<A0> [cm^2]") + "\n")
            for art in self.arts:
                if (art.N != len(art.R)) :
                    print("In networkdef A0: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.R)) :
                    fh.write(",%20.20f"%(np.pi * art.R[i] * art.R[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/K.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<K> [g/cm^2/s^2]") + "\n")
            for art in self.arts:
                if (art.N != len(art.K)) :
                    print("In networkdef K: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.K)) :
                    fh.write(",%20.20f"%(art.K[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/Cv.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<Cv> [cm^2/s]") + "\n")
            for art in self.arts:
                if (art.N != len(art.Cv)) :
                    print("In networkdef Cv: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.Cv)) :
                    fh.write(",%20.20f"%(art.Cv[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/Knl.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<Knl> [g/cm^3/s^2]") + "\n")
            for art in self.arts:
                if (art.N != len(art.Knl)) :
                    print("In networkdef Knl: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.Knl)) :
                    fh.write(",%20.20f"%(art.Knl[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/phi.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<phi>") + "\n")
            for art in self.arts:
                if (art.N != len(art.phi)) :
                    print("In networkdef phi: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.phi)) :
                    fh.write(",%20.20f"%(art.phi[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/mu0.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<mu0> [g/cm/s]") + "\n")
            for art in self.arts:
                if (art.N != len(art.mu0)) :
                    print("In networkdef mu0: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.mu0)) :
                    fh.write(",%20.20f"%(art.mu0[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/mu1.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<mu1> [g/cm/s]") + "\n")
            for art in self.arts:
                if (art.N != len(art.mu1)) :
                    print("In networkdef mu1: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.mu1)) :
                    fh.write(",%20.20f"%(art.mu1[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/kmu.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<kmu> [s^-1]") + "\n")
            for art in self.arts:
                if (art.N != len(art.kmu)) :
                    print("In networkdef kmu: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.kmu)) :
                    fh.write(",%20.20f"%(art.kmu[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/amu.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<amu>") + "\n")
            for art in self.arts:
                if (art.N != len(art.amu)) :
                    print("In networkdef amu: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.amu)) :
                    fh.write(",%20.20f"%(art.amu[i]))
                fh.write("\n")

        fileName = folder +'/Parameters/inoutParam.csv'
        with open(fileName,'w') as fh:
            fh.write( "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s"%('#Artery', '<A0_in> [cm^2]', '<A0_out> [cm^2]', '<K_in> [g/cm^2/s^2]', '<K_out> [g/cm^2/s^2]', '<dx_in> [cm]', '<dx_out> [cm]', '<angle_in> [deg]', '<angle_out> [deg]', '<P_out> [g/cm/s^2]' ) + "\n" );
            for art in self.arts :
                if (art.angleout > 3./2.*np.pi or art.angleout < np.pi/2.) :
                    print("In networkdef inoutParam: Error in outlet angleout ",art.angleout)
                    sys.exit()
                if ( art.anglein > np.pi/2. and art.anglein < 3./2.*np.pi) :
                    print("In networkdef inoutParam: Error in inlet anglein ",art.anglein)
                    sys.exit()
                fh.write("%d,%20.20f,%20.20f,%20.20f,%20.20f,%20.20f,%20.20f,%20.20f,%20.20f,%20.20f"%(art.ID, art.Ain, art.Aout, art.Kin, art.Kout, art.dxin, art.dxout, art.anglein, art.angleout, art.Pout) + "\n" )

        inputFile=folder + '/output.csv'
        with open(inputFile, 'w') as fh:
            fh.write("%s,%s"%('#<numArtery>','<numMeshPoint>')+"\n")
            for art in self.arts:
                for meshPt in art.outPut:
                    fh.write("%d,%d"%( art.ID, meshPt) + "\n" )

        fileName = folder+'/time.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s,%s,%s,%s,%s,%s"%('#<tS> [s]', '<tE> [s]', '<t_step> [s]', '<Nt>', '<Nstore>', '<CFL>', '<Order>') + "\n" )
            fh.write("%20.20f,%20.20f,%20.20f,%d,%d,%20.20f,%d"%(self.tS.t_start, self.tS.t_end, self.tS.dt, self.tS.Nt,self.tS.storeStep,self.tS.CFL,self.tS.timeOrder) + "\n" )
