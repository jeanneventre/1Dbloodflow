#!/usr/local/bin/python3
import numpy as np
import os
import sys

from help_Interpolate import *

####################################
class dataS_Opt() :

    # Get Block for specific times
    def readBlock(self,nArt) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "Artery_" + str(nArt) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Artery_" + str(nArt) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        lBlock = [] ; #List of block for different times
        block = [];

        #Find number of record nodes
        recPoints = self.recNum(nArt)

        #Loop on lines
        emptyline = 0;
        iT = 0 ;
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if line.isspace() :
                    emptyline += 1;
                    # If first empty line -> Store block
                    if (emptyline == 1) :
                        # Convert block to numpy array
                        block = np.array(block)
                        # Verify integrity of block
                        if (len(block[:,0])!=recPoints) :
                            print("Error in the size of the block",len(block[:,0]),recPoints)
                            sys.exit();
                        if (block[0,0] != block[recPoints-1,0] ) :
                            print("Error in recorded times of the block", block[0,0], block[recPoints-1,0])
                            sys.exit();


                        lBlock.append(block) ;

                    # If second empty line -> New block
                    elif (emptyline == 2) :
                        block = [] ;
                    else :
                        print("Too many empty lines:",emptyline)
                        sys.exit();
                # If non empty line
                ###################
                else :
                    emptyline = 0 ;
                    block.append(map(float,line.split(",")))

        return lBlock

    def readBlock_t(self,nArt,lTime) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "Artery_" + str(nArt) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Artery_" + str(nArt) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        lBlock = [] ; #List of block for different times
        blockm1 = []; block = [];

        #Find number of record nodes
        recPoints = self.recNum(nArt)

        #Loop on lines
        emptyline = 0;
        iT = 0 ;
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if line.isspace() :
                    emptyline += 1;
                    # If first empty line -> Store block
                    if (emptyline == 1) :
                        # Convert block to numpy array
                        block = np.array(block)
                        # Verify integrity of block
                        if (len(block[:,0])!=recPoints) :
                            print("Error in the size of the block",len(block[:,0]),recPoints)
                            sys.exit();
                        if (block[0,0] != block[recPoints-1,0] ) :
                            print("Error in recorded times of the block", block[0,0], block[recPoints-1,0])
                            sys.exit();

                        ############
                        # Check time
                        ############
                        t = block[0,0] ;
                        if (t>lTime[iT]) :
                            if (len(blockm1)==0) :
                                lBlock.append(block)
                            else :
                                lBlock.append( interpBlock_t(blockm1,block,lTime[iT]) )
                            iT += 1;

                        if (iT == len(lTime)) :
                            return lBlock ;
                        #############
                        #############

                        blockm1 = block ;
                    # If second empty line -> New block
                    elif (emptyline == 2) :
                        block = [] ;
                    else :
                        print("Too many empty lines:",emptyline)
                        sys.exit();
                # If non empty line
                ###################
                else :
                    emptyline = 0 ;
                    block.append(map(float,line.split(",")))

    # Get Block for specific times
    def readBlock_x(self,nArt,lX) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "Artery_" + str(nArt) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Artery_" + str(nArt) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        lBlock = [] ; #List of block for different x
        block = [];

        #Define sublist
        nX = len(lX)
        for iX in range(nX) :
            lBlock.append([])

        #Find number of record nodes
        recPoints = self.recNum(nArt)

        #Loop on lines
        emptyline = 0;
        iT = 0 ;
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if line.isspace() :
                    emptyline += 1;
                    # If first empty line -> Store block
                    if (emptyline == 1) :
                        # Convert block to numpy array
                        block = np.array(block)
                        # Verify integrity of block
                        if (len(block[:,0])!=recPoints) :
                            print("Error in the size of the block",len(block[:,0]),recPoints)
                            sys.exit();
                        if (block[0,0] != block[recPoints-1,0] ) :
                            print("Error in recorded times of the block", block[0,0], block[recPoints-1,0])
                            sys.exit();

                        ############
                        # Find X
                        ############
                        pX = 0
                        for iX in range(recPoints) :
                            x = block[iX,1]
                            if (pX < nX and x>=lX[pX]) :
                                if (iX == 0) :
                                    lBlock[pX].append(block[iX,:])
                                else :
                                    lBlock[pX].append( interpLine_x(block[iX-1,:],block[iX,:],lX[pX]))
                                pX += 1 ;
                            elif (pX < nX and x < lX[pX] and iX == recPoints-1) :
                                if ( abs(x-lX[pX]) <= 0.1 * lX[pX] ) :
                                    lBlock[pX].append(block[iX,:])
                                    pX += 1 ;


                        if( pX != nX) :
                            if (x < lX[pX] and iX == recPoints-1 and abs(x-lX[pX]) <= 0.25 * lX[pX] ) :
                                lBlock[pX].append(block[iX,:])
                            else :
                                print("Not all points were found for artery ",nArt)
                                print("pX=",pX,", nX=",nX)
                                print("x=",x,"L=",lX[pX],"|x-L|=",abs(x-lX[pX]),"0.25L=",0.25*lX[pX])
                                sys.exit()

                    # If second empty line -> New block
                    elif (emptyline == 2) :
                        block = [] ;
                    else :
                        print("Too many empty lines:",emptyline)
                        sys.exit();
                # If non empty line
                ###################
                else :
                    emptyline = 0 ;
                    block.append(map(float,line.split(",")))

        for iX in range(nX) :
            lBlock[iX] = np.array(lBlock[iX])

        return lBlock

    def readBlock_Conj(self,nConj,lTime) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "Junction_" + str(nConj) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Junction_" + str(nConj) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        Block = []; line = [] ; linem1 = [] ;
        iT = 0 ;
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if not line.isspace() :
                    # Convert block to numpy array
                    line = map(float,line.split(","))
                    ############
                    # Check time
                    ############
                    t = line[0] ;
                    if (t>lTime[iT]) :
                        if (len(Block)==0) :
                            Block.append(line)
                        else :
                            Block.append( interpLine_t(linem1,line,lTime[iT]) )
                        iT += 1;

                    if (iT == len(lTime)) :
                        return np.array(Block) ;
                    #############
                    #############
                    linem1 = line ;

    def readBlock_Conj_x(self,nConj) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "Junction_" + str(nConj) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Junction_" + str(nConj) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        Block = [];
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if not line.isspace() :
                    # Convert block to numpy array
                    line = map(float,line.split(","))
                    Block.append(line)

        return np.array(Block) ;

    def recNum(self,nArt) :
        iNum = 0
        for i in range(len(self.output[:,0])) :
            if (self.output[i,0] == int(nArt)) :
                iNum += 1 ;
        return iNum

    # Get Block for specific times
    def getData(self,vect,fileName) :
        cV = len(vect[0,:])
        lV = len(vect[:,0])
        #Open file of Artery
        fh = open(fileName,'r') ;

        iV = 0
        nL = 0
        for line in fh:
            if not line.startswith('#') and not line.isspace() :
                data = map(float,line.split(","))
                lenData = len(data);
                # Check length of data:
                if (lenData-1 > cV) : #Remove first column that is the number of arteries
                    print("Error in the number of columns of vect. --> Exit",lenData,cV)
                    print(data)
                    sys.exit();
                if (nL > lV) :
                    print("Error in the number of lines of vect. --> Exit",nL,lV)
                    print(data)
                    sys.exit();

                for iD in range(1,lenData) :
                    vect[iV,iD-1] = data[iD] ;
                iV += 1 ;
                nL += 1 ;

        return vect

    def __init__(self,folderPath,folderPath_store,logo) :

        #Logo :
        self.logo = logo
        # Pa to mmHg :
        self.PaTommHg = 0.00750061683
        self.gcms2ToPa=0.1
        # Peak Systolic velocity shape factor (Poiseuill Max Value) :
        self.factPSV = 3./2.
        # CAPILLARY PRESSURE :
        self.Pcap = 0.
        # MEAN CORPUSCULAR VOLUM (volume of RBC)
        self.MCV = 1.e2 * 1.e-12 # (cm^3)

        #########################
        # PATH TO FILE
        #########################
        self.path = folderPath
        self.pathStore = folderPath_store
        self.dataPath = self.path + 'data/'

        #########################
        # DATA
        #########################
        self.output = np.genfromtxt(self.path + "parameters_"+self.logo+"/output.csv", delimiter=',')
        self.param = np.genfromtxt(self.path + "parameters_"+self.logo+"/Parameters/systemic_network.csv", delimiter=',')

        self.DAG = np.genfromtxt(self.path + "parameters_"+self.logo+"/DAG.csv", delimiter=',') ;
        if (len(self.DAG)>2) :
            self.DAG = self.DAG[self.DAG[:,0].argsort()]

        #########################
        # NUMBER OF ARTERIES
        #########################
        if (len(self.DAG)==2) :
            if ( isinstance(self.DAG[0],float) ) :
                self.nArt = 1 ;
            else :
                self.nArt = 2 ;
        else :
            self.nArt = len(self.DAG)
            if (self.nArt == 1) :
                print("bfs_libData: Error in definition of nArt")
                sys.exit()

        ###################
        #LENGTH OF EACH ARTERY:
        ###################
        if (self.nArt == 1) :
            self.N = self.param[1]
            self.Lart = self.param[2] # (cm)
        else :
            self.N = self.param[:,1]
            self.Lart = self.param[:,2] # (cm)

        ###################
        #NUMERICS:
        ###################
        if (self.nArt == 1) :
            self.order = int(self.param[5])
        else :
            self.order = int(self.param[0,5])

        with open(self.path + "parameters_"+self.logo+"/Parameters/systemic_network.csv", 'r') as f:
            first_line = f.readline()
            line = first_line.split(',')
        self.HR = str(line[6])
        self.HR = self.HR[:-1]

        ###################
        #NUMBER OF ARTERIES
        ###################
        if (self.nArt==1):
            Nmax = int(self.N)
        else:
            Nmax = int(max(self.N))

        self.dx = np.zeros(shape=(self.nArt,Nmax))
        self.A0 = np.zeros(shape=(self.nArt,Nmax))
        self.K = np.zeros(shape=(self.nArt,Nmax))
        self.Cv = np.zeros(shape=(self.nArt,Nmax))


        self.getData(self.dx,self.path + "parameters_"+self.logo+"/Parameters/dx.csv")
        self.getData(self.A0,self.path + "parameters_"+self.logo+"/Parameters/A0.csv")
        self.getData(self.K,self.path + "parameters_"+self.logo+"/Parameters/K.csv")
        self.getData(self.Cv,self.path + "parameters_"+self.logo+"/Parameters/Cv.csv")

        ###################
        # BLOOD RHEOLOGIE :
        ###################
        self.phi = np.zeros(shape=(self.nArt,Nmax))
        self.mu0 = np.zeros(shape=(self.nArt,Nmax))
        self.mu1 = np.zeros(shape=(self.nArt,Nmax))
        self.kmu = np.zeros(shape=(self.nArt,Nmax))
        self.amu = np.zeros(shape=(self.nArt,Nmax))

        self.getData(self.phi,self.path + "parameters_"+self.logo+"/Parameters/phi.csv")
        self.getData(self.mu0,self.path + "parameters_"+self.logo+"/Parameters/mu0.csv")
        self.getData(self.mu1,self.path + "parameters_"+self.logo+"/Parameters/mu1.csv")
        self.getData(self.kmu,self.path + "parameters_"+self.logo+"/Parameters/kmu.csv")
        self.getData(self.amu,self.path + "parameters_"+self.logo+"/Parameters/amu.csv")

        if (self.nArt == 1) :
            self.rho    = self.param[3] # (g/cm^3)
        else :
            self.rho    = self.param[0,3] # (g/cm^3)

        ###################
        # BOUNDARY CONDITIONS :
        ###################

        ###################
        # TIME PARAMETERS :
        ###################
        self.time = np.genfromtxt(self.path + "parameters_"+self.logo+"/time.csv", delimiter=',')
        self.dt = self.time[2]
        self.trecStart = self.time[0]
        self.trecEnd = self.time[1]

        self.deltaRec = self.time[4]
        self.dtrec = self.dt*self.deltaRec

    def __del__(self):
      class_name = self.__class__.__name__
      print(class_name, "destroyed")
