#!/usr/local/bin/python3
import sys
import numpy as np

from    help_Inlet      import viscoelasticity
from    help_Network    import network_h

def plotBlock(cls,Block,pType) :
    iX = 1; iK = 2; iA0 = 3; iA = 4; iQ = 5 ; iP = 6;
    iG = 7 ; iH = 8; ifst = 9 ; iTmu = 10 ; iT = 11 ;
    iC = 12; iO = 13 ;

    npos = len(Block[:,0])
    # Rigidity
    ##########
    if (pType == 'K') :
        Bl = Block[:,iK]
        ylabel = r'$K$ $\left[\frac{g}{cm^2.s^2}\right]$'
    # Section
    ##########
    elif (pType == 'A0') :
        Bl = Block[:,iA0]
        ylabel = r'$A0$ $\left[cm^2\right]$'
    # Viscoelasticity
    ###########
    elif (pType == 'Cv') :
        Bl = np.ones(npos)
        R  = np.ones(npos)
        phi = 5.e4 * np.ones(npos)
        for i in range(npos) :
            R[i] = np.sqrt(Block[i,iA0] / np.pi )
        h = network_h(R)
        Bl = viscoelasticity(cls.rho,phi,h,R)
        ylabel = r'$C_\nu$ $\left[\frac{cm^{2}}{s}\right]$'
        
    # Flow
    ##########
    elif (pType == 'Q') :
        Bl = Block[:,iQ]
        ylabel = r'$Q$ $\left[\frac{cm^3}{s}\right]$'
    # Section
    ##########
    elif (pType == 'A') :
        Bl = Block[:,iA]
        ylabel = r'$A$ $\left[cm^2\right]$'
    # Radius
    ##########
    elif (pType == 'R') :
        Bl = np.ones(npos) ;
        for i in range(0,npos) :
            Bl[i] = np.sqrt(Block[i,iA] / np.pi )
        ylabel = r'$R$ $\left[cm\right]$'
    # Pressure
    ##########
    elif (pType == 'P') :
        Bl = Block[:,iP]
        ylabel = r'$P$ $\left[\frac{g}{cm.s^2}\right]$'
    # Gamma
    ##########
    elif (pType == 'G') :
        Bl = Block[:,iG]
        ylabel = r'$\dot{\gamma}$ $\left[s^{-1}}\right]$'
    # H
    ##########
    elif (pType == 'H') :
        Bl = Block[:,iH]
        ylabel = r'$H$ $\left[cm^{-3}\right]$'
    # Nrbc
    ##########
    elif (pType == 'NH') :
        Bl = np.ones(npos) ;
        # Time series
        if ((Block[1,iX]-Block[0,iX]) == 0. ) :
            for i in range(0,npos) :
                Bl[i] = 1./cls.MCV * Block[i,iH] * Block[i,iA] * np.amin( cls.dx )
        # Space series
        else :
            Bl[0] = 1./cls.MCV * Block[0,iH] * Block[0,iA] * ( Block[1,iX]-Block[0,iX] )
            Bl[npos-1] = 1./cls.MCV * Block[npos-1,iH] * Block[npos-1,iA] * ( Block[npos-1,iX] - Block[npos-2,iX] )
            for i in range(1,npos-1):
                Bl[i] = 1./cls.MCV * Block[i,iH] * Block[i,iA] * ( (Block[i+1,iX]-Block[i-1,iX])/2. )
        ylabel = r'$Nrbc$'
    # F
    ##########
    elif (pType == 'F') :
        Bl = Block[:,ifst]
        ylabel = r'$F$'
    # Tmu
    ##########
    elif (pType == 'Tmu') :
        Bl = Block[:,iTmu]
        ylabel = r'$\T_{st}$ $\left[\frac{g}{cm.s^2}\right]$'
    # T
    ##########
    elif (pType == 'T') :
        Bl = Block[:,iT]
        ylabel = r'$\T$ $\left[\frac{g}{cm.s^2}\right]$'
    # C
    ##########
    elif (pType == 'C') :
            Bl = Block[:,iC]
            ylabel = r'$C$ $\left[cm^{-3}\right]$'
    # NC
    ##########
    elif (pType == 'NC') :
        Bl = np.ones(npos) ;
        # Time series
        if ((Block[1,iX]-Block[0,iX]) == 0. ) :
            for i in range(0,npos) :
                Bl[i] = Block[i,iC] * Block[i,iA] * np.amin( cls.dx )
        # Space series
        else :
            Bl[0] = Block[0,iC] * Block[0,iA] * ( Block[1,iX]-Block[0,iX] )
            Bl[npos-1] = Block[npos-1,iC] * Block[npos-1,iA] * ( Block[npos-1,iX] - Block[npos-2,iX] )
            for i in range(1,npos-1):
                Bl[i] = Block[i,iC] * Block[i,iA] * ( (Block[i+1,iX]-Block[i-1,iX])/2. )
        ylabel = r'$NC$'
    # O
    ##########
    elif (pType == 'O') :
            Bl = Block[:,iO]
            ylabel = r'$O$ $\left[cm^{-3}\right]$'
    # NC
    ##########
    elif (pType == 'NO') :
        Bl = np.ones(npos) ;
        # Time series
        if ((Block[1,iX]-Block[0,iX]) == 0. ) :
            for i in range(0,npos) :
                Bl[i] = Block[i,iO] * Block[i,iA] * np.amin( cls.dx )
        # Space series
        else :
            Bl[0] = Block[0,iO] * Block[0,iA] * ( Block[1,iX]-Block[0,iX] )
            Bl[npos-1] = Block[npos-1,iO] * Block[npos-1,iA] * ( Block[npos-1,iX] - Block[npos-2,iX] )
            for i in range(1,npos-1):
                Bl[i] = Block[i,iO] * Block[i,iA] * ( (Block[i+1,iX]-Block[i-1,iX])/2. )
        ylabel = r'$NO$'
    # Pressure gradient
    ##########
    elif (pType == 'gradP') :
        Bl = np.ones(npos) ;
        Bl[0] = (Block[1,iP]-Block[0,iP]) / (Block[1,iX]-Block[0,iX])
        Bl[npos-1] = (Block[npos-1,iP]-Block[npos-2,iP]) / (Block[npos-1,iX]-Block[npos-2,iX])
        for i in range(1,npos-1):
            Bl[i] = (Block[i+1,iP]-Block[i-1,iP]) / (Block[i+1,iX]-Block[i-1,iX])
        ylabel = r'$\nabla_x P$ $\left[\frac{g}{cm^2.s^2}\right]$'
    # Pressure difference between inlet and outlet
    ##########
    elif (pType == 'deltaP') :
        Bl = np.ones(npos) ;
        Bl[0] = (Block[1,iP]-Block[0,iP]) / (Block[1,iX]-Block[0,iX])
        Bl[npos-1] = (Block[npos-1,iP]-Block[npos-2,iP]) / (Block[npos-1,iX]-Block[npos-2,iX])
        for i in range(1,npos-1):
            Bl[i] = (Block[i+1,iP]-Block[i-1,iP]) / (Block[i+1,iX]-Block[i-1,iX])
        ylabel = r'$\nabla_x P$ $\left[\frac{g}{cm^2.s^2}\right]$'
    # Speed
    ##########
    elif (pType == 'U') :
        Bl = np.ones(npos);
        for i in range(npos) :
            #Check if Q=0
            if (Block[i,iQ]==0.) :
                Bl[i] = 0.;
            #Check if A=0
            elif (Block[i,iA]==0.) :
                Bl[i] = 0.;
            else :
                Bl[i] = Block[i,iQ] / Block[i,iA];
        ylabel = r'$U$ $\left[\frac{cm}{s}\right]$'
    # R-R0
    ##########
    elif (pType == 'RmR0') :
        Bl = 1. / np.sqrt(np.pi) * (np.sqrt(Block[:,iA]) - np.sqrt(Block[:,iA0]))
        ylabel = r'$R-R_0$ $\left[cm\right]$'
    # E
    ##########
    elif (pType == 'E') :
        U = np.zeros(npos);
        for i in range(npos) :
            #Check if Q=0
            if (Block[i,iQ]==0.) :
                U[i] = 0.;
            #Check if A=0
            elif (Block[i,iA]==0.) :
                U[i] = 0.;
            else :
                U[i] = Block[i,iQ] / Block[i,iA];
        Bl = 0.5 * cls.rho * U * U + Block[:,iP] ;
        ylabel = r'$E$ $\left[\frac{g}{cm.s^2}\right]$'
    # Sh
    ##########
    elif (pType == 'Sh') :
        Sh = np.ones(npos);
        for i in range(npos) :
            #Check if U=0
            if (Block[i,iQ]==0.) :
                Sh[i] = 0.;
            #Check if A=0
            elif (Block[i,iA]==0.) :
                Sh[i] = 0.;
            else :
                c = np.sqrt( np.abs( 0.5 * Block[i,iK] / cls.rho *  np.sqrt(Block[i,iA]) ) )
                Sh[i] = np.abs(Block[i,iQ] / Block[i,iA]) / c ;
        Bl = Sh ;
        ylabel = r'$S_h$'
    # Re
    ##########
    elif (pType == 'Re') :
        Re = np.ones(npos);
        for i in range(npos) :
            #Check if U=0
            if (Block[i,iQ]==0.) :
                Re[i] = 0.;
            #Check if A=0
            elif (Block[i,iA]==0.) :
                Re[i] = 0.;
            #Check if nu=0
            elif (cls.mu1[i]==0.) :
                Re[i] = -1. ;
            else :
                Re[i] = np.abs(Block[i,iQ] / Block[i,iA]) * np.sqrt( Block[i,iA] / np.pi ) * cls.rho / cls.mu1[i] ;
        Bl = Re ;
        ylabel = r'$R_{e,R}$'
    else :
        print("bfS_libBlock : Unknown data type")
        sys.exit

    return ylabel,Bl
