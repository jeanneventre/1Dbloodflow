#!/usr/bin/python2.7

__author__      = "Arthur R. Ghigo"
__copyright__   = "Copyright 2015, UPMC IJLRDA"
__credits__     = ["Arthur R. Ghigo"]
__license__     = "GPL"
__version__     = "1.0.0"
__maintainer__  = "Arthur R. Ghigo"
__email__       = "arthur.ghigo@dalembert.upmc.fr"
__status__      = "Prototype"

import sys
import numpy as np
import math as mt

from bfS_libBlock import *

def write_Opt_x_All(cls,numArt,lTime) :

    art = int(numArt) ; nPlot = len(lTime) ;

    # BLOCK DATA
    ################
    lBlock = cls.readBlock_t(nArt=numArt,lTime=lTime)
    if (len(lBlock) != nPlot) :
        print("plot_Opt_x: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_x.csv"
    fh = open(fileName,'w')

    for iT in range(nPlot) :
        Block = lBlock[iT]
        t = Block[:,0]
        x = Block[:,1]

        label,A0        = plotBlock(cls=cls,Block=Block,pType='A0')
        label,K         = plotBlock(cls=cls,Block=Block,pType='K')
        label,A         = plotBlock(cls=cls,Block=Block,pType='A')

        R0              = 1./np.sqrt(np.pi) * np.sqrt(A0)
        R               = 1./np.sqrt(np.pi) * np.sqrt(A)
        RmR0            = R-R0

        label,Q         = plotBlock(cls=cls,Block=Block,pType='Q')
        label,U         = plotBlock(cls=cls,Block=Block,pType='U')
        label,P         = plotBlock(cls=cls,Block=Block,pType='P')
        label,gradxP    = plotBlock(cls=cls,Block=Block,pType='gradxP')
        label,E         = plotBlock(cls=cls,Block=Block,pType='E')
        label,Hrbc      = plotBlock(cls=cls,Block=Block,pType='H')
        label,Nrbc      = plotBlock(cls=cls,Block=Block,pType='NH')
        label,G         = plotBlock(cls=cls,Block=Block,pType='G')
        label,fst       = plotBlock(cls=cls,Block=Block,pType='F')
        label,Twst      = plotBlock(cls=cls,Block=Block,pType='Tmu')
        label,Tw        = plotBlock(cls=cls,Block=Block,pType='T')
        label,Sh        = plotBlock(cls=cls,Block=Block,pType='Sh')
        label,Cpt       = plotBlock(cls=cls,Block=Block,pType='C')
        label,Opt       = plotBlock(cls=cls,Block=Block,pType='O')

        npos = len(Block[:,0])

        for ip in range(npos) :
            fh.write("%.20f,\t %.20f,\t %.20f,\t %.20f, %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f"%(t[ip],x[ip],R0[ip],A0[ip],K[ip],R[ip],RmR0[ip],A[ip],Q[ip],U[ip],P[ip],gradxP[ip],E[ip],Hrbc[ip],Nrbc[ip],G[ip],fst[ip],Twst[ip],Tw[ip],Sh[ip],Cpt[ip],Opt[ip]) + "\n")
        fh.write("\n");
        fh.write("\n");

    fh.close()

def write_Opt_t_All(cls,numArt,lX) :

    art = int(numArt) ; nPlot = len(lX) ;

    # BLOCK DATA
    ################
    lBlock = cls.readBlock_x(nArt=numArt,lX=lX)
    if (len(lBlock) != nPlot) :
        print("plot_Opt_x: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_t.csv"
    fh = open(fileName,'w')

    for iX in range(nPlot) :
        Block = lBlock[iX]
        t = Block[:,0]
        x = Block[:,1]

        label,A0        = plotBlock(cls=cls,Block=Block,pType='A0')
        label,K         = plotBlock(cls=cls,Block=Block,pType='K')
        label,A         = plotBlock(cls=cls,Block=Block,pType='A')

        R0              = 1./np.sqrt(np.pi) * np.sqrt(A0)
        R               = 1./np.sqrt(np.pi) * np.sqrt(A)
        RmR0            = R-R0

        label,Q         = plotBlock(cls=cls,Block=Block,pType='Q')
        label,U         = plotBlock(cls=cls,Block=Block,pType='U')
        label,P         = plotBlock(cls=cls,Block=Block,pType='P')
        label,E         = plotBlock(cls=cls,Block=Block,pType='E')
        label,Hrbc      = plotBlock(cls=cls,Block=Block,pType='H')
        label,Nrbc      = plotBlock(cls=cls,Block=Block,pType='NH')
        label,G         = plotBlock(cls=cls,Block=Block,pType='G')
        label,fst       = plotBlock(cls=cls,Block=Block,pType='F')
        label,Twst      = plotBlock(cls=cls,Block=Block,pType='Tmu')
        label,Tw        = plotBlock(cls=cls,Block=Block,pType='T')
        label,Sh        = plotBlock(cls=cls,Block=Block,pType='Sh')
        label,Cpt       = plotBlock(cls=cls,Block=Block,pType='C')
        label,Opt       = plotBlock(cls=cls,Block=Block,pType='O')

        mu = np.zeros(len(G))

        for i in range(len(mu)) :
            if (abs(G[i]==0)) :
                mu[i] = 4.e-2
            else :
                mu[i] = Tw[i]/G[i]

        npos = len(Block[:,0])

        for ip in range(npos) :
            fh.write("%.20f,\t %.20f,\t %.20f,\t %.20f, %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f,\t %.20f"%(t[ip],x[ip],R0[ip],A0[ip],K[ip],R[ip],RmR0[ip],A[ip],Q[ip],U[ip],P[ip],E[ip],Hrbc[ip],Nrbc[ip],G[ip],fst[ip],Twst[ip],Tw[ip],mu[ip],Sh[ip],Cpt[ip],Opt[ip]) + "\n")
        fh.write("\n");
        fh.write("\n");

    fh.close()

def write_Opt_x(cls,numArt,lTime,pType) :

    art = int(numArt) ; nPlot = len(lTime) ;

    # BLOCK DATA
    ################
    lBlock = cls.readBlock_t(nArt=numArt,lTime=lTime)
    if (len(lBlock) != nPlot) :
        print("plot_Opt_x: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_x_"+str(pType)+".csv"
    fh = open(fileName,'w')

    fh.write("%s"%("t [s]"))

    # Get number of spatial points
    ##############################
    npos = len(lBlock[0][:,0])

    # Indicate plot time in first line
    ##################################
    for iT in range(nPlot) :
        Block = lBlock[iT]
        t = Block[0,0]
        fh.write(", \t %.20f"%(t))
    fh.write("\n")

    # Write quantity of interest in columns
    #######################################
    for ip in range(npos) :
        for iT in range(nPlot) :
            Block = lBlock[iT]
            x = Block[ip,1]
            label,X = plotBlock(cls=cls,Block=Block,pType=str(pType))
            if (iT == 0) :
                fh.write("%.20f"%(x))

            fh.write(", \t %.20f"%(X[ip]))

        fh.write("\n")

    fh.close()

def write_Opt_t(cls,numArt,lX,pType) :

    art = int(numArt) ; nPlot = len(lX) ;

    # BLOCK DATA
    ################
    lBlock = cls.readBlock_x(nArt=numArt,lX=lX)
    if (len(lBlock) != nPlot) :
        print("plot_Opt_x: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_t_"+str(pType)+".csv"
    fh = open(fileName,'w')

    fh.write("%s"%("x [cm]"))

    # Get number of spatial points
    ##############################
    npos = len(lBlock[0][:,0])

    # Indicate plot time in first line
    ##################################
    for iT in range(nPlot) :
        Block = lBlock[iT]
        t = Block[0,1]
        fh.write(", \t %.20f"%(t))
    fh.write("\n")

    # Write quantity of interest in columns
    #######################################
    for ip in range(npos) :
        for iT in range(nPlot) :
            Block = lBlock[iT]
            x = Block[ip,0]
            label,X = plotBlock(cls=cls,Block=Block,pType=str(pType))
            if (iT == 0) :
                fh.write("%.20f"%(x))

            fh.write(", \t %.20f"%(X[ip]))

        fh.write("\n")

    fh.close()

def write_Opt_Conj(cls,numConj,lTime,pType) :

    conj = int(numConj) ; nPlot = len(lTime) ;

    # BLOCK DATA
    ################
    Block = cls.readBlock_Conj(nConj=numConj,lTime=lTime)
    if (len(Block) != nPlot) :
        print("plot_Opt_x: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Junction_"+str(conj)+"_"+str(pType)+".csv"
    fh = open(fileName,'w')

    # Indicate plot time in first line
    ##################################
    fh.write("%s"%("t [s]"))
    for iT in range(nPlot) :
        t = Block[iT,0]
        fh.write(", \t %.20f"%(t))
    fh.write("\n")

    # Write quantity of interest in columns
    #######################################
    label,X = plotBlock(cls=cls,Block=Block,pType=str(pType))
    for iT in range(nPlot) :
        if (iT == 0) :
            fh.write("%.20f"%(0.))

        fh.write(", \t %.20f"%(X[iT]))

    fh.write("\n")

    fh.close()

def write_Opt_Conj_t(cls,numConj,pType) :

    conj = int(numConj) ;

    # BLOCK DATA
    ################
    Block = cls.readBlock_Conj_x(nConj=numConj)

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Junction_"+str(conj)+"_t_"+str(pType)+".csv"
    fh = open(fileName,'w')

    # Indicate plot time in first line
    ##################################
    fh.write("%s, \t %.20f\n"%("x [cm]",0.))

    # Write quantity of interest in columns
    #######################################
    label,X = plotBlock(cls=cls,Block=Block,pType=str(pType))
    for iT in range(len(X)) :
        fh.write("%.20f, \t %.20f\n"%( Block[iT,0], X[iT] ))

    fh.close()
