#!/usr/bin/python2.7

__author__      = "Arthur R. Ghigo"
__copyright__   = "Copyright 2015, UPMC IJLRDA"
__credits__     = ["Arthur R. Ghigo"]
__license__     = "GPL"
__version__     = "1.0.0"
__maintainer__  = "Arthur R. Ghigo"
__email__       = "arthur.ghigo@dalembert.upmc.fr"
__status__      = "Prototype"

import sys
import numpy as np
import math as mt

import matplotlib
import matplotlib.pyplot    as plt
import matplotlib.cm        as cmx
import matplotlib.colors    as colors
import matplotlib.colorbar  as mcolorbar
import matplotlib.animation as animation
import matplotlib.image     as mpimg
import matplotlib.ticker    as ticker
import matplotlib.gridspec as gridspec

from matplotlib.ticker          import FuncFormatter
from matplotlib.ticker          import ScalarFormatter
from matplotlib.ticker          import LogFormatter

from matplotlib.ticker          import AutoLocator
from matplotlib.ticker          import LinearLocator
from matplotlib.ticker          import LogLocator
from matplotlib.ticker          import SymmetricalLogLocator
from matplotlib.ticker          import MaxNLocator

from mpl_toolkits.mplot3d       import Axes3D
from mpl_toolkits.axes_grid1    import make_axes_locatable

from scipy.interpolate          import griddata

from time import time

# Font
matplotlib.rc('font', family='serif', serif='cm', style='normal', weight='normal',size = '25')

# Text
matplotlib.rc('text', usetex='True', color='black')
matplotlib.rcParams['text.latex.preamble'] = [r'\usepackage{amsmath}',r'\usepackage{amssymb}',r'\usepackage{xcolor}']

# Lines
matplotlib.rc('lines', linewidth='1', linestyle='-', markersize='7',markeredgewidth='0.5', antialiased='True')

# Axes
matplotlib.rcParams['axes.unicode_minus'] = 'true'
matplotlib.rc('axes', grid='False', titlesize='20', labelsize='20', labelpad='5', labelweight='normal')
matplotlib.rc('axes', xmargin='0.',ymargin='0.25')

# Ticks
matplotlib.rc('xtick', labelsize='20', direction='in')
matplotlib.rcParams['xtick.major.size'] ='4' ; matplotlib.rcParams['xtick.minor.size'] ='2'
matplotlib.rc('ytick', labelsize='20', direction='in')
matplotlib.rcParams['ytick.major.size'] ='4' ; matplotlib.rcParams['ytick.minor.size'] ='2'

# Legend
matplotlib.rc('legend', fancybox='True', frameon='False', framealpha=0., fontsize='25',handletextpad="0.1",borderaxespad="0.",columnspacing="0.4",borderpad="0.2",handlelength="1.",handleheight="0.",labelspacing="0.1")
matplotlib.rcParams['legend.numpoints'] = 1

# Grid
matplotlib.rc('grid', alpha='0.')

# Figure
matplotlib.rc('figure', figsize='8,6', dpi='1000')

# Animation
# matplotlib.rcParams['animation.ffmpeg_args'] = '-report'

# TkAgg
matplotlib.use('TkAgg')

# Formatter
def log_10_product(x, pos):
    return "%.1E" %(x)

def log_10_decimal(x, pos):
    # # Find the number of decimal places required
    d = int(np.maximum(-np.log10(x),0))     # =0 for numbers >=1
    return "%.*f" %(d+1,x)

def get_cmap(N):

    color_norm  = colors.Normalize(vmin=0, vmax=N-1)
    scalar_map = cmx.ScalarMappable(norm=color_norm, cmap=cmx.jet)
    def map_index_to_rgb_color(index):
        return scalar_map.to_rgba(index)
    return map_index_to_rgb_color

def shiftedColorMap(cmap, start=0, midpoint=0.5, stop=1.0, name='shiftedcmap'):
    '''
    Function to offset the "center" of a colormap. Useful for
    data with a negative min and positive max and you want the
    middle of the colormap's dynamic range to be at zero

    Input
    -----
      cmap : The matplotlib colormap to be altered
      start : Offset from lowest point in the colormap's range.
          Defaults to 0.0 (no lower ofset). Should be between
          0.0 and midpoint.
      midpoint : The new center of the colormap. Defaults to
          0.5 (no shift). Should be between 0.0 and 1.0. In
          general, this should be  1 - vmax/(vmax + abs(vmin))
          For example if your data range from -15.0 to +5.0 and
          you want the center of the colormap at 0.0, `midpoint`
          should be set to  1 - 5/(5 + 15)) or 0.75
      stop : Offset from highets point in the colormap's range.
          Defaults to 1.0 (no upper ofset). Should be between
          midpoint and 1.0.
    '''
    cdict = {
        'red': [],
        'green': [],
        'blue': [],
        'alpha': []
    }

    # regular index to compute the colors
    reg_index = np.linspace(start, stop, 260)

    # shifted index to match the data
    shift_index = np.hstack([
        np.linspace(0.0, midpoint, 130, endpoint=False),
        np.linspace(midpoint, 1.0, 130, endpoint=True)
    ])

    for ri, si in zip(reg_index, shift_index):
        r, g, b, a = cmap(ri)

        cdict['red'].append((si, r, r))
        cdict['green'].append((si, g, g))
        cdict['blue'].append((si, b, b))
        cdict['alpha'].append((si, a, a))

    newcmap = matplotlib.colors.LinearSegmentedColormap(name, cdict)
    plt.register_cmap(cmap=newcmap)

    return newcmap

def make_colormap(seq,name):
    """Return a LinearSegmentedColormap
    seq: a sequence of floats and RGB-tuples. The floats should be increasing
    and in the interval (0,1).
    """
    seq = [(None,) * 3, 0.0] + list(seq) + [1.0, (None,) * 3]
    cdict = {'red': [], 'green': [], 'blue': []}
    for i, item in enumerate(seq):
        if isinstance(item, float):
            r1, g1, b1 = seq[i - 1]
            r2, g2, b2 = seq[i + 1]
            cdict['red'].append([item, r1, r2])
            cdict['green'].append([item, g1, g2])
            cdict['blue'].append([item, b1, b2])

    return colors.LinearSegmentedColormap(name, cdict)

def cmap_discretize(cmap, N):
    """Return a discrete colormap from the continuous colormap cmap.

        cmap: colormap instance, eg. cm.jet.
        N: number of colors.

    Example
        x = resize(arange(100), (5,100))
        djet = cmap_discretize(cm.jet, 5)
        imshow(x, cmap=djet)
    """

    if type(cmap) == str:
        cmap = plt.get_cmap(cmap)
    colors_i = np.concatenate((np.linspace(0, 1., N), (0.,0.,0.,0.)))
    colors_rgba = cmap(colors_i)
    indices = np.linspace(0, 1., N+1)
    cdict = {}
    for ki,key in enumerate(('red','green','blue')):
        cdict[key] = [ (indices[i], colors_rgba[i-1,ki], colors_rgba[i,ki])
                       for i in xrange(N+1) ]
    # Return colormap object.
    return colors.LinearSegmentedColormap(cmap.name + "_%d"%N, cdict, 1024)

def align_yaxis(ax1, v1, ax2, v2):
    """adjust ax2 ylimit so that v2 in ax2 is aligned to v1 in ax1"""
    _, y1 = ax1.transData.transform((0, v1))
    _, y2 = ax2.transData.transform((0, v2))
    adjust_yaxis(ax2,(y1-y2)/2,v2)
    adjust_yaxis(ax1,(y2-y1)/2,v1)

def adjust_yaxis(ax,ydif,v):
    """shift axis ax by ydiff, maintaining point v at the same location"""
    inv = ax.transData.inverted()
    _, dy = inv.transform((0, 0)) - inv.transform((0, ydif))
    miny, maxy = ax.get_ylim()
    miny, maxy = miny - v, maxy - v
    if -miny>maxy or (-miny==maxy and dy > 0):
        nminy = miny
        nmaxy = miny*(maxy+dy)/(miny+dy)
    else:
        nmaxy = maxy
        nminy = maxy*(miny+dy)/(maxy+dy)
    ax.set_ylim(nminy+v, nmaxy+v)

def findExtrema(x,histX,xmin,xmax) :

    if (xmin >= xmax) :
        print("Error in findExtrema",xmin,xmax)

    X = histX
    n = len(X[:])
    if (len(x) != n) :
        print("Error in findExtrema",n,len(x))

    # Find min
    xm = x[0]
    m = X[0]
    for i in range(1,n) :
        if (xmin <= x[i] and x[i] <= xmax) :
            if( X[i] < m ) :
                xm = x[i] ;
                m = X[i] ;

    # Find max
    xp = x[0]
    p = X[0]
    for i in range(1,n) :
        if (xmin <= x[i] and x[i] <= xmax) :
            if( X[i] > p ) :
                xp = x[i] ;
                p = X[i] ;
    if (abs(m)> abs(p)) :
        return xm , m ;
    elif (abs(p)> abs(m)) :
        return xp , p ;
    else :
        print("Error in findExtrema",m,p)
