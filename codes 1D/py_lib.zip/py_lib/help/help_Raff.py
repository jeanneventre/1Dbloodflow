#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

from help_Sum               import *

# Define mesh size
def mesh_Axial(N,Nmax,c,L,i) :
    LsLambda    = min( L / c)
    Nx          = int(N) * int( L[i] / c[i] / LsLambda)
    if (Nmax=="") :
        return L[i] / float(Nx)
    else :
        return max( L[i] / float(Nmax), L[i] / float(Nx) )
# Layer raffinement in geometric series
def geometricRaffinement_Radial(Lmax,Lmin) :

    if (Lmax == Lmin) :

        nL      = round(1./Lmax,0)
        layer   = np.ones(nL)*Lmax

        # Check layer length
        if (kahanSum(layer) != 1) :
            print("Error in geometricRadialRaffinement",kahanSum(layer))
            sys.exit()

        return layer

    else :

        # Compute coefficients
        q   = ( 1. - Lmax ) / ( 1. - Lmin/Lmax )
        nL  = int(1. +  np.log(Lmin/Lmax) / np.log(q) )
        # Define layer proportion
        layer = np.ones(nL)
        for iL in range(nL) :
            layer[iL] = Lmax * ( q**iL )

        # Correct the proportion of the layer
        while ( kahanSum(layer) != 1. ) :

            # Compute error of length
            err = kahanSum(layer) - 1.
            # Find number of layers bigger than error
            nErr = 0
            while (nErr < nL and layer[nErr] > err ) :
                nErr += 1;
            # Correct layer proportion
            for iL in range(nErr) :
                layer[iL] -= err * layer[iL] / kahanSum(layer[0:nErr])

        # Check layer length
        if (kahanSum(layer) != 1) :
            print("Error in geometricRadialRaffinement",kahanSum(layer))
            sys.exit()

        # Check if layers are in decreasing order
        for iL in range(1,nL) :
            if (layer[iL]>layer[iL-1]) :
                print("Error in geometricRadialRaffinement",layer[iL-1],layer[iL])
                sys.exit()

        return layer

def geometricRaffinement_Axial(L,L1,L2,Lbuf,dxmax,dxmin) :

    if (dxmax == dxmin) :

        nx = int(round(L / dxmax,0))
        # Choose best integer
        dx = np.ones(nx) * dxmax

        # Correct the proportion of dx
        nit = 0
        while ( kahanSum(dx) != L and nit < 100 ) :
            nit += 1;
            # Compute error of length
            err = kahanSum(dx) - L
            # Correct layer proportion
            for ix in range(int(nx)) :
                dx[ix] -= err / float(nx)

        # Check layer length
        if (abs(kahanSum(dx) - L) > 1.e-14) :
            print("Error in geometricRaffinement_Axial",L-kahanSum(dx),nx)
            print(dx)
            sys.exit()

        return dx

    else :

        # Compute coefficients
        q   = ( Lbuf - dxmax ) / ( Lbuf - dxmin/dxmax )
        nx  = int(1. +  np.log(dxmin/dxmax) / np.log(q) )

        # Define positions
        n1  = int( (L1-Lbuf)/dxmax )
        n2  = int(n1 + nx)
        n3  = int(n2 + int( (L2-L1)/dxmin ) )
        n4  = int(n3 + nx)
        n5  = int(n4 + ( L - (L2+Lbuf) ) /dxmax )

        # Define dx
        dx = np.ones(n5)
        for ix in range(0,n1) :
            dx[ix] = dxmax
        for ix in range(n1,n2) :
            dx[ix] = dxmax * ( q**(ix-n1) )
        for ix in range(n2,n3) :
            dx[ix] = dxmin
        for ix in range(n3,n4) :
            dx[ix] = dxmax * ( q**( nx-1 - (ix-n3) ) )
        for ix in range(n4,n5) :
            dx[ix] = dxmax

        # Correct the proportion of dx
        nit = 0
        while ( kahanSum(dx) != L and nit < 100 ) :
            nit += 1;
            # Compute error of length
            err = kahanSum(dx) - L

            # Find number of cells bigger than error

            nErr = 0
            while (nErr < nx and dx[n1+nErr] > abs(err) ) :
                nErr += 1;
            # Correct layer proportion
            for ix in range(n1,n1+nErr) :
                dx[ix] -= err/2. * dx[ix] / kahanSum(dx[n1:n1+nErr])

            nErr = 0
            while (nErr < nx and dx[n4-1-nErr] > abs(err) ) :
                nErr += 1;
            # Correct layer proportion
            for ix in range(n4-1-nErr,n4) :
                dx[ix] -= err/2. * dx[ix] / kahanSum(dx[n4-1-nErr:n4])

        # Check layer length
        if (kahanSum(dx) != L) :
            print("Error in geometricRaffinement_Axial",L-kahanSum(dx))
            print(dx)
            sys.exit()

        return dx
