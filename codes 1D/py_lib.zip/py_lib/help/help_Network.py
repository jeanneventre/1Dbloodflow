#!/usr/local/bin/python3
import sys, getopt
import os

import numpy as np

##############################
# Mean values
##############################
def meanR(R1,R2) :
    n = len(R1)
    R = np.ones(n)

    if (len(R2) != n) :
        print("meanR: Error in length of input parameters")
        sys.exit()

    for i in range(n) :
        R[i] = 0.5 * (R1[i]+R2[i])

    return R
def meanK(K1,K2) :
    n = len(K1)
    K = np.ones(n)

    if (len(K2) != n) :
        print("meanK: Error in length of input parameters")
        sys.exit()

    for i in range(n) :
        K[i] = 0.5 * (K1[i]+K2[i])

    return K
##############################
# Network definition functions
##############################

# Define the width of the wall in physiological conditions (Avolio 1980, Blanco 2014)
def network_h(R) :
    a = 0.2802
    b = -5.053
    c = 0.1324
    d = - 0.1114

    n = len(R)
    h = np.ones(n)

    for i in range(n) :
        h[i] = R[i] * ( a*np.exp(b*R[i]) + c*np.exp(d*R[i]) )

    return h

# Define the rigidity of the wall in physiological conditions (Olufsen 1999)
def network_E(R,h) :
    k1 = 2.e7
    k2 = -22.53
    k3 = 8.65e5

    n = len(R)
    E = np.ones(n)

    for i in range(n) :
        E[i] = R[i] / h[i] * ( k1*np.exp(k2*R[i]) + k3 )

    return E

# Define the rigidity of the wall in physiological conditions (Olufsen 1999)
def network_K(R) :
    k1 = 2.e7
    k2 = -22.53
    k3 = 8.65e5

    n = len(R)
    K = np.ones(n)

    for i in range(n) :
        K[i] = 4./3. / R[i] / np.sqrt(np.pi) * ( k1*np.exp(k2*R[i]) + k3 )

    return K

# Define radius of asymmetric bifurcation
def bifurcationAsym_R(eta,gamma,R) :
    # Values from Olufsen
    # eta = 1.16, gamma = 0.41

    R1 = np.sqrt( eta/(1.+gamma) ) * R
    R2 = np.sqrt(eta) * R1

    return R1,R2

###################################
# Idealized asymmetric arterial tree
###################################
def asymTree_L(R0) :
    # See Iberall 1967
    return R0 * 50.

def asymTree_R(R0,a,b) :
    # See Olufsen (2000)
    # a = 0.9 ; b = 0.6 ;
    return a*R0, b*R0
