#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

########################
# Tapper
########################
def xi(c,T,t,x) :
    return x/c/T - t/T ;
def phi(c,T,t,x) :
    return x/c/T + t/T ;
def Q_Pulse(c,T,t,x) :
    return 0.5 * (1. +  np.cos( np.pi + 2.*np.pi * xi(c,T,t,x) ) )
def dQ_Pulse(c,T,t,x) :
    return - np.pi  *   np.sin( np.pi + 2.*np.pi * xi(c,T,t,x) )
def Q_Tapper(dr,c,T,t,x):
    return Q_Pulse(c,T,t,x) + dr * ( -3./8. * phi(c,T,t,x) * Q_Pulse(c,T,t,x) + 1./16. * phi(c,T,t,x) * (2.*phi(c,T,t,x) + xi(c,T,t,x)) * dQ_Pulse(c,T,t,x) )
