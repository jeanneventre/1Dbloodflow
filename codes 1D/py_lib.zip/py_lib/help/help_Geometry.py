#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

from help_Wave import *

########################
# Shapes
########################
def Tapper(dr,xs,xe,x) :
    if (x<xs) :
        return 1. ;
    elif (x>=xs and x<=xe) :
        return 1. + dr * ( x-xs )/( xe-xs )
    else :
        return 1. + dr
def TapperTriangle(dr,xs,xms,xme,xe,x) :
    if (x>=xs and x<=xms) :
        return 1. + dr * ( xms-x )/( xms-xs )
    elif (x>xms and x<xme) :
        return 1. ;
    elif (x>=xme and x<=xe) :
        return 1. + dr * ( x-xme )/( xe-xme )
    else :
        return 1. + dr

def TapperAsymptotic(dr,x) :
    return 1. + dr * x
def TapperAsymptoticTriangle(dr,xms,xme,x) :
    if ( x<=xms) :
        return 1. + dr * ( xms-x )
    elif (x>xms and x<xme) :
        return 1. ;
    elif (x>=xme) :
        return 1. + dr * ( x-xme )

def cosStenosis(dr,xs,xe,x) :
    if (x>xs and x<xe) :
        return 1. + dr * 0.5 *( 1. + np.cos( np.pi + 2. * np.pi * ( x-xs )/( xe-xs ) ) )
    else :
        return 1.
def cosDoubleStenosis(dr,xs,xm,xe,x) :
    if (x>xs and x<xm) :
        return 1. + dr * 0.5 *( 1. + np.cos( np.pi + 2. * np.pi * ( x-xs )/( xm-xs ) ) )
    elif (x>=xm and x<xe) :
        return 1. - dr * 0.5 *( 1. + np.cos( np.pi + 2. * np.pi * ( x-xm )/( xe-xm ) ) )
    else :
        return 1.

def sinStenosis(dr,xs,xe,x) :
    if (x>xs and x<xe) :
        return 1. + dr * np.sin( np.pi * ( x-xs )/( xe-xs ) )
    else :
        return 1.

def step(dr,xm,x) :
    if (x<xm) :
        return 1.
    else :
        return 1. + dr
def decreasingStep(dr,xm,x) :
    if (x<xm) :
        return 1. + dr
    else :
        return 1.
def increasingStep(dr,xm,x) :
    if (x<xm) :
        return 1.
    else :
        return 1. + dr
