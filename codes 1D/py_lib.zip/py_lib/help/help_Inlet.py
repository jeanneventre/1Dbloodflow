#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

import scipy.signal as signal

########################
# Wall properties
########################
def rigidity(E,h,R) :
    return 4./3. * E * h / np.sqrt(np.pi) / (R * R)

def viscoelasticity(RHO,nu,h,R) :
    return 4./3./2. * nu * h / RHO / (R)

def celerity(RHO,K,A0) :
    return np.sqrt( 0.5 * K / RHO * np.sqrt(A0) )
########################
# Convert
########################
def Reynolds(rho,mu,R,U) :
    return U * R * rho / mu
def Womersley(rho,mu,R,T) :
    return R * np.sqrt( 2. * np.pi / T * rho / mu )
def WomtoT(rho,mu,R,wom) :
    return 2.*np.pi * rho/mu * (R/wom)**2.
########################
# Convert
########################
def ShtoR(Sh,R0) :
    return R0 * (1. + Sh)

def ShtoA(Sh,R0) :
    return np.pi * (ShtoR(Sh,R0) ** 2.)

def ShtoQ(Sh,RHO,K,R0) :
    return Sh * celerity(RHO,K,ShtoA(Sh,R0)) * ShtoA(Sh,R0)

def ShtoP(Sh,K,R0) :
    return Sh * K * np.sqrt(np.pi) * R0

def RttoR(Rt,Z) :
    # Z is the impedance
    if (Rt > 0.99 ) :
        return Z * 2. * 1.e2 # Formula for Rt=0.999
    else :
        return Z * (1.+Rt)/(1.-Rt) ;

def GtoQ(phi,A,G) :
    return G / abs(phi) / np.sqrt(np.pi) * ( A )** (3./2.)

########################
# Inlet
########################
def PulseSin(T,tt) :
    return np.maximum( 0., np.sin( 2. * np.pi / T * tt ) )

def PulseCos(T,tt) :
    return np.maximum( 0., 0.5 *( 1. + np.cos( np.pi + 2. * np.pi / T * tt ) ) )

def PulseBackflow(T,Tp,Qp,Tb,Qb,Td,tt) :
    n = len(tt)
    Pulse = np.zeros(n)
    for i in range(n) :
        if (tt[i] % T < Tp+Td and tt[i] % T >= Td) :
            Pulse[i] = Qp * np.maximum( 0., np.sin( np.pi / Tp * (tt[i]%T-Td) ) )
        elif (tt[i] % T >= Tp+Td and tt[i] % T < Tp+Td+Tb) :
            Pulse[i] = Qb * np.maximum(0., np.sin( np.pi / Tb * (tt[i]%T-Tp-Td) ))

    # plt.plot(tt,Pulse)
    # plt.show()

    return Pulse

def Step(T,tt)  :
    return 1. * ( np.sin( 2. * np.pi / T * tt ) > 0. )

def TwoStep(T,Ts,Td,tt)  :
    x = np.ones(len(tt)) ;
    x[ tt < Ts]            = 0.
    x[ tt > Ts+T ]         = 0. ;
    x[ tt > Ts+T+Td ]      = 1. ;
    x[ tt > Ts+2.*T+Td ]   = 0. ;
    return x

def Triangle(T,tt)  :
    # width = 0.5 * T / (2.*np.pi) ;
    # return signal.sawtooth( 2.*np.pi / T * (tt) , width )
    return (T - abs(tt % (2.*T) - T))/T
########################
# Heart model
########################
def StrokeVolume(EF) :
    # End diastolic Volume
    EDV = 120. # cm^3
    return EF * EDV
