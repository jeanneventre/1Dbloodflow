#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

########################
# Help functions
########################
def lambda_d(delta,gamma) :
    return 1./delta/abs(gamma) ;

########################
# Non Newtonian Steady
########################
def F_NN_Steady(la,ld):
    return 1. / (1. + la/ld) ;
