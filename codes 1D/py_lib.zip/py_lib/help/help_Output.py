#!/usr/local/bin/python3
import numpy    as np
import math     as mt

def latex_power(num, decimal_digits=1, precision=None, exponent=None):
    """
    Returns a string representation of the scientific
    notation of the given number formatted for use with
    LaTeX or Mathtext, with specified number of significant
    decimal digits and precision (number of decimal digits
    to show). The exponent to be used can also be specified
    explicitly.
    """
    if (num == 0.) :
        return r"$0$"
    else :
        if not exponent:
            exponent = int(np.floor(np.log10(abs(num))))
        coeff = round(num / float(10.**exponent), decimal_digits)
        if not precision:
            precision = decimal_digits

        if (exponent == 0) :
            return r"${0:.{1}f}$".format(coeff,precision)
        elif (coeff == 1.) :
            return r"$10^{{{0:d}}}$".format(exponent)
        else :
            return r"${0:.{2}f} \cdot 10^{{{1:d}}}$".format(coeff, exponent, precision)

def getType(pType) :

    if (pType == "A0") :
        pName = "A0.csv"
        pLabel = r"$A_0$ $\left[cm^2\right]$"
    if (pType == "K") :
        pName = "K.csv"
        pLabel = r"$K$ $\left[\frac{g}{cm^{2}.s^{2}}\right]$"
    if (pType == "Cv") :
        pName = "Cv.csv"
        pLabel = r"$C_\nu$ $\left[\frac{cm^{2}}{s}\right]$"

    if (pType == "Q") :
        pName = "Q.csv"
        pLabel = r"$Q$ $\left[\frac{cm^3}{s}\right]$"
    if (pType == "U") :
        pName = "U.csv"
        pLabel = r"$U$ $\left[\frac{cm}{s}\right]$"
    if (pType == "P") :
        pName = "P.csv"
        pLabel = r"$p$ $\left[\frac{g}{cm.s^{2}}\right]$"
    if (pType == "A") :
        pName = "A.csv"
        pLabel = r"$A$ $\left[cm^{2}\right]$"
    if (pType == "R") :
        pName = "R.csv"
        pLabel = r"$R$ $\left[cm\right]$"
    if (pType == "RmR0") :
        pName = "RmR0.csv"
        pLabel = r"$R-R_0$ $\left[cm\right]$"
    if (pType == "E") :
        pName = "E.csv"
        pLabel = r"$E$ $\left[\frac{g}{cm.s^{2}}\right]$"
    if (pType == "Sh") :
        pName = "Sh.csv"
        pLabel = r"$Sh$"
    if (pType == "Re") :
        pName = "Re.csv"
        pLabel = r"$Re$"

    if (pType == "G") :
        pName = "G.csv"
        pLabel = r"$\dot{\gamma}$ $\left[s^{-1}\right]$"
    if (pType == "F") :
        pName = "F.csv"
        pLabel = r"$F$"
    if (pType == "Tmu") :
        pName = "Tmu.csv"
        pLabel = r"$\tau_{st}$ $\left[\frac{g}{cm.s^{2}}\right]$"
    if (pType == "T") :
        pName = "T.csv"
        pLabel = r"$\tau$ $\left[\frac{g}{cm.s^{2}}\right]$"
    if (pType == "H") :
        pName = "H.csv"
        pLabel = r"$H$ $\left[cm^{-3}\right]$"
    if (pType == "NH") :
        pName = "NH.csv"
        pLabel = r"$NH$"
    if (pType == "C") :
        pName = "C.csv"
        pLabel = r"$C$ $\left[cm^{-3}\right]$"
    if (pType == "NC") :
        pName = "NC.csv"
        pLabel = r"$NC$"
    if (pType == "O") :
        pName = "O.csv"
        pLabel = r"$O$ $\left[cm^{-3}\right]$"
    if (pType == "NO") :
        pName = "NO.csv"
        pLabel = r"$NO$"

    return pName,pLabel
