#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt
import scipy.integrate as scpInt

def kahanSum(IN) :
    S = IN[0] ;
    c = 0. ; y = 0. ; t= 0. ;
    for i in range(1,len(IN)) :
        y = IN[i] - c  ;
        t = S + y ;
        c = (t - S) - y ;
        S = t ;
        # if (c==0.) :
            # print("Error in kahanSum, c==0",c)
    return S

# Integrate sampled data
def integrate(x,y) :

    if (len(x)!=len(y)) :
        print("integral: Error in length of input")
        sys.exit()

    intTrap     = scpInt.trapz(y,x)
    intSimps    = scpInt.simps(y,x)
    # intRomb     = scpInt.romb(y,x)

    return intSimps
