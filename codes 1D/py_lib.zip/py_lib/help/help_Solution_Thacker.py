#!/usr/local/bin/python3
import sys
import numpy as np

########################
# Thacker Viscous
########################
def U_Thacker(Cf,tau,Ath,t) :
    return Ath * np.sin(t/tau) * np.exp( - Cf / 2. * t) ;
def R0_Thacker(R0,dR,a,x) :
    return R0 * ( 1. + dR * ( 1. - ((x/a)**2.) ) )
def A0_Thacker(R0,dR,a,x) :
    return np.pi * R0_Thacker(R0,dR,a,x) * R0_Thacker(R0,dR,a,x)
def H_Thacker(Cf,tau,t) :
    return ( np.cos(t/tau) + Cf * tau / 2. * np.sin(t/tau) ) * np.exp( - Cf / 2. * t) ;
def P_Thacker(R0,dR,rho,Cf,tau,Ath,x,t) :
    return -1./2. * rho * (Ath**2.) / (1. + ((Cf*tau/2.)**2.)) * ((H_Thacker(Cf,tau,t))**2.) - rho * Ath / tau * H_Thacker(Cf,tau,t) * x
def R_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x,t) :
    return  1./K * P_Thacker(R0,dR,rho,Cf,tau,Ath,x,t) + R0_Thacker(R0,dR,a,x) ;
def A_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x,t) :
    return np.pi * R_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x,t) * R_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x,t) ;
def Q_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x,t) :
    return U_Thacker(Cf,tau,Ath,t) * A_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x,t)

def R0_Int_Thacker(R0,dR,a,x1,x2) :
    return 1./(x2-x1) * ( R0 * ( (x2-x1) + dR * ( (x2-x1)  - (x2**3.-x1**3.)/3./a**2. ) ) )
def A0_Int_Thacker(R0,dR,a,x1,x2) :
    return 1./(x2-x1) * ( np.pi * R0**2. * ( (x2-x1) + 2.*dR*( (x2-x1)  - (x2**3.-x1**3.)/3./a**2 ) + dR**2. * ( (x2-x1) - 2./(a**2.)*(x2**3.-x1**3.)/3. + (x2**5. - x1**5.)/5./a**4. )  ) )
def P_Int_Thacker(R0,dR,rho,Cf,tau,Ath,x1,x2,t) :
    return 1./(x2-x1) * ( -1./2. * rho * (Ath**2.) / (1. + ((Cf*tau/2.)**2.)) * ((H_Thacker(Cf,tau,t))**2.) * (x2-x1) - rho * Ath / tau * H_Thacker(Cf,tau,t) * (x2**2. - x1**2.) / 2. )
def R_Int_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x1,x2,t) :
    return  1./K * P_Int_Thacker(R0,dR,rho,Cf,tau,Ath,x1,x2,t) + R0_Int_Thacker(R0,dR,a,x1,x2) ;
def A_Int_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x1,x2,t) :
    return 1./2. * ( A_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x1,t) + A_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x2,t) );
def Q_Int_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x1,x2,t) :
    return U_Thacker(Cf,tau,Ath,t) * A_Int_Thacker(R0,dR,a,rho,Cf,K,tau,Ath,x1,x2,t)

########################
# Thacker Inviscid
########################
def U_Inviscid_Thacker(tau,Ath,t) :
    return Ath * np.sin(t/tau) ;
def R0_Inviscid_Thacker(R0,dR,a,x) :
    return R0 * ( 1. + dR * ( 1. - ((x/a)**2.) ) )
def A0_Inviscid_Thacker(R0,dR,a,x) :
    return np.pi * R0_Inviscid_Thacker(R0,dR,a,x) * R0_Inviscid_Thacker(R0,dR,a,x)
def P_Inviscid_Thacker(R0,dR,rho,tau,Ath,x,t) :
    return -1./4. * rho * (Ath**2.) * np.cos(2.*t/tau) - rho * Ath * x / tau * np.cos(t/tau)
def R_Inviscid_Thacker(R0,dR,a,rho,K,tau,Ath,x,t) :
    return 1./K * P_Inviscid_Thacker(R0,dR,rho,tau,Ath,x,t) + R0_Inviscid_Thacker(R0,dR,a,x) ;
def A_Inviscid_Thacker(R0,dR,a,rho,K,tau,Ath,x,t) :
    return np.pi * R_Inviscid_Thacker(R0,dR,a,rho,K,tau,Ath,x,t) * R_Inviscid_Thacker(R0,dR,a,rho,K,tau,Ath,x,t) ;
def Q_Inviscid_Thacker(R0,dR,a,rho,K,tau,Ath,x,t) :
    return U_Inviscid_Thacker(tau,Ath,t) * A_Inviscid_Thacker(R0,dR,a,rho,K,tau,Ath,x,t)

def R0_Inviscid_Int_Thacker(R0,dR,a,x1,x2) :
    return 1./(x2-x1) * ( R0 * ( (x2-x1) + dR * ( (x2-x1)  - (x2**3.-x1**3.)/3./a**2. ) ) )
def A0_Inviscid_Int_Thacker(R0,dR,a,x1,x2) :
    return 1./(x2-x1) * ( np.pi * R0**2. * ( (x2-x1) + 2.*dR*( (x2-x1)  - (x2**3.-x1**3.)/3./a**2 ) + dR**2. * ( (x2-x1) - 2./(a**2.)*(x2**3.-x1**3.)/3. + (x2**5. - x1**5.)/5./a**4. )  ) )
def A_Inviscid_Int_Thacker(R0,dR,a,rho,K,tau,Ath,x1,x2,t) :
    return 1./2. * ( A_Inviscid_Thacker(R0,dR,a,rho,K,tau,Ath,x1,t) + A_Inviscid_Thacker(R0,dR,a,rho,K,tau,Ath,x2,t) );
def Q_Inviscid_Int_Thacker(R0,dR,a,rho,K,tau,Ath,x1,x2,t) :
    return U_Inviscid_Thacker(tau,Ath,t) * A_Inviscid_Int_Thacker(R0,dR,a,rho,K,tau,Ath,x1,x2,t)
