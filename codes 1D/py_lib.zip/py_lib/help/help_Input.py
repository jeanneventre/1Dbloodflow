#!/usr/local/bin/python3
import sys, getopt
import os

import numpy as np

import help_Raff as mesh
import help_Wave as wave

class header():

    def __init__(self):

        self.PATH       = "" ;
        self.LOGO       = "" ;
        self.SOLVER     = "" ;
        self.HR         = "" ;
        self.CONJ       = "" ;

        self.Nxstr      = "" ;
        self.Nxmax      = "" ;
        self.xOrderstr  = "" ;
        self.dtstr      = "" ;
        self.tOrderstr  = "" ;

        self.Kstr       = "" ;
        self.NNstr      = "" ;
        self.phistr     = "" ;
        self.Cvstr      = "" ;
        self.Knlstr     = "" ;

        self.Shstr      = "" ;
        self.Restr      = "" ;
        self.Womstr     = "" ;

        self.Astr       = "" ;
        self.Qstr       = "" ;
        self.Ustr       = "" ;
        self.Pstr       = "" ;

        self.Rtstr      = "" ;
        self.Cstr       = "" ;

        self.dRstr      = "" ;
        self.dKstr      = "" ;

        self.P1         = "" ;
        self.P2         = "" ;
        self.P3         = "" ;
        self.P4         = "" ;
        self.P5         = "" ;

    def __del__(self):
      class_name = self.__class__.__name__
    #   print class_name, "destroyed"

    def headerFile(self) :

        if not os.path.exists(str(self.PATH)+"parameters_"+str(self.LOGO)) :
            os.makedirs(str(self.PATH)+"/parameters_"+str(self.LOGO))
        if not os.path.exists(str(self.PATH)+"parameters_"+str(self.LOGO)+"/Parameters") :
            os.makedirs(str(self.PATH)+"/parameters_"+str(self.LOGO)+"/Parameters")
        if not os.path.exists(str(self.PATH)+"/data"):
            os.makedirs(str(self.PATH)+"/data")
        if not os.path.exists(str(self.PATH)+"/Figures"):
            os.makedirs(str(self.PATH)+"/Figures")
        if not os.path.exists(str(self.PATH)+"/Movies"):
            os.makedirs(str(self.PATH)+"/Movies")

    def headerInput(self,argv) :

        # COMMAND LINE ARGUMENTS
        #############################
        try :
            opts, args = getopt.getopt(argv,"a:b:c:d:e:f:g:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:y:z:p1:p2:p3:p4:p5:h",["Path=","Logo=","Conj=","Solver","HR","Nx=","xOrder=","dt=","tOrder=","K=","NN=","Phi=","Cv=","Knl=","Sh=","Re=","Wom=","A=","Q=","U=","P=","Rt=","C=","dR=","dK=","P1=","P2=","P3=","P4=","P5="])
        except getopt.GetoptError:
            print ('writeParameter.py -a <path> -b <logo> -c <conj> -d <solver> -e <hr> -f <nx> -g <xorder> -i <dt> -j <torder> -k <k> -l <nn> -m <phi> -n <cv> -o <knl> -p <sh> -q <re> -r <wom> -s <A> -t <Q> -u <U> -v <P> -w <Rt> -x <C> -y <dR> -z <dK> -p1 <P1> -p2 <P2> -p3 <P3> -p4 <P4> -p5 <P5>')
            sys.exit()
        for opt, arg in opts:
            if opt == '-h':
                print ('writeParameter.py -a <path> -b <logo> -c <conj> -d <solver> -e <hr> -f <nx> -g <xorder> -i <dt> -j <torder> -k <k> -l <nn> -m <phi> -n <cv> -o <knl> -p <sh> -q <re> -r <wom> -s <A> -t <Q> -u <U> -v <P> -w <Rt> -x <C> -y <dR> -z <dK> -p1 <P1> -p2 <P2> -p3 <P3> -p4 <P4> -p5 <P5>')
                sys.exit()
            if opt in ("-a", "--path"):
                self.PATH = arg
            if opt in ("-b", "--logo"):
                self.LOGO = arg
            if opt in ("-c", "--conj"):
                self.CONJ = arg
            if opt in ("-d", "--solver"):
                self.SOLVER = arg
            if opt in ("-e", "--hr"):
                self.HR = arg
            if opt in ("-f", "--nx"):
                self.Nxstr = arg
            if opt in ("-g", "--xorder"):
                self.xOrderstr = arg
            if opt in ("-i", "--dt"):
                self.dtstr = arg
            if opt in ("-j", "--torder"):
                self.tOrderstr = arg
            if opt in ("-k", "--k"):
                self.Kstr = arg
            if opt in ("-l", "--nn"):
                self.NNstr = arg
            if opt in ("-m", "--phi"):
                self.phistr = arg
            if opt in ("-n", "--cv"):
                self.Cvstr = arg
            if opt in ("-o", "--knl"):
                self.Knlstr = arg
            if opt in ("-p", "--sh"):
                self.Shstr = arg
            if opt in ("-q", "--re"):
                self.Restr = arg
            if opt in ("-r", "--wom"):
                self.Womstr = arg
            if opt in ("-s", "--a"):
                self.Astr = arg
            if opt in ("-t", "--q"):
                self.Qstr = arg
            if opt in ("-u", "--u"):
                self.Ustr = arg
            if opt in ("-v", "--p"):
                self.Pstr = arg
            if opt in ("-w", "--rt"):
                self.Rtstr = arg
            if opt in ("-x", "--ct"):
                self.Cstr = arg
            if opt in ("-y", "--dr"):
                self.dRstr = arg
            if opt in ("-z", "--dk"):
                self.dKstr = arg

            if opt in ("-p1", "--P1"):
                self.P1 = arg
            if opt in ("-p2", "--P2"):
                self.P2 = arg
            if opt in ("-p3", "--P3"):
                self.P3 = arg
            if opt in ("-p4", "--P4"):
                self.P4 = arg
            if opt in ("-p5", "--P5"):
                self.P5 = arg


        print("---------------------")
        print("UNITS : cm, g, s")
        print("---------------------")
        print

    #############################
    # Default artery setup
    #############################

    def headerNum(self,arts,L,c) :
        for i in range(len(arts)) :
            # Create the mesh
            arts[i].dxCoarse    = mesh.mesh_Axial(int(float(self.Nxstr)),self.Nxmax,c,L,i)
            arts[i].dx          = mesh.geometricRaffinement_Axial(L=L[i],L1=0,L2=0,Lbuf=0,dxmax=arts[i].dxCoarse,dxmin=arts[i].dxCoarse)
            arts[i].x           = space(arts[i].dx)
            arts[i].N           = len(arts[i].dx)
            # Define numerical parameters
            arts[i].solver      = self.SOLVER
            arts[i].HR          = self.HR
            arts[i].solverOrder = float(self.xOrderstr)

    def headerProp(self,arts,rho,L,R,K,Cv,Knl) :
        for i in range(len(arts)) :
            # Geometrical and mechanical parameters
            arts[i].rho = rho
            arts[i].L   = L[i]
            arts[i].R   = R[i]   * shape_R   (arts[i].x)
            arts[i].K   = K[i]   * shape_K   (arts[i].x)
            arts[i].Cv  = Cv[i]  * shape_Cv  (arts[i].x)
            arts[i].Knl = Knl[i] * shape_Knl (arts[i].x)
            # Verification of the length
            if( abs(arts[i].x[arts[i].N-1] + arts[i].dx[arts[i].N-1]/2. - arts[i].L) > 1.e-10) :
                print("Error in the geometrical parameters",arts[i].x[arts[i].N-1] + arts[i].dx[arts[i].N-1]/2., arts[i].L)
                sys.exit()

    def headerRheo(self,arts,phi,mu0,mu1,kmu,amu) :
        for i in range(len(arts)) :
            # Rheology
            arts[i].phi = phi[i] * shape_phi(arts[i].x)
            arts[i].mu0 = mu0[i] * shape_mu0(arts[i].x)
            arts[i].mu1 = mu1[i] * shape_mu1(arts[i].x)
            arts[i].kmu = kmu[i] * shape_kmu(arts[i].x)
            arts[i].amu = amu[i] * shape_amu(arts[i].x)

    def headerInit(self,arts,F,H,C,O) :
        for i in range(len(arts)) :
            # Initial condition
            arts[i].initA   = np.pi * arts[i].R * arts[i].R
            arts[i].initQ   = np.zeros(arts[i].N)
            # Initial aggregation condition
            arts[i].initF   = F * np.ones(arts[i].N)
            arts[i].initH   = H * np.ones(arts[i].N)
            # Initial passive transport condition
            arts[i].initC   = C * np.ones(arts[i].N)
            arts[i].initO   = O * np.ones(arts[i].N)

    def headerBC(self,arts,fact,P) :
        for i in range(len(arts)) :
            # Boundary properties
            if  (len(arts[i].daughterArts) != 0 and len(arts[i].parentArts) != 0) :
                arts[i].dxin        = fact * arts[i].dx[0]
                arts[i].dxout       = fact * arts[i].dx[arts[i].N-1]
            elif(len(arts[i].daughterArts) != 0 and len(arts[i].parentArts) == 0) :
                arts[i].dxin        = arts[i].dx[0]
                arts[i].dxout       = fact * arts[i].dx[arts[i].N-1]
            elif(len(arts[i].daughterArts) == 0 and len(arts[i].parentArts) != 0) :
                arts[i].dxin        = fact * arts[i].dx[0]
                arts[i].dxout       = arts[i].dx[arts[i].N-1]
            else :
                arts[i].dxin        = arts[i].dx[0]
                arts[i].dxout       = arts[i].dx[arts[i].N-1]
            arts[i].Ain         = np.pi * arts[i].R[0] * arts[i].R[0]
            arts[i].Aout        = np.pi * arts[i].R[arts[i].N-1] * arts[i].R[arts[i].N-1]
            arts[i].Kin         = arts[i].K[0]
            arts[i].Kout        = arts[i].K[arts[i].N-1]
            arts[i].anglein     = 0.
            arts[i].angleout    = np.pi
            arts[i].Pout        = P

    def headerOutput(self,arts) :
        for i in range(len(arts)) :
            #Output points
            arts[i].outPut=[0]
            for ix in range(1,arts[i].N-1) :
                arts[i].outPut.append( ix )
            arts[i].outPut.append( arts[i].N-1 )

    def headerCFL(self,arts,Ct) :
        dt = 1.e3
        for i in range(len(arts)) :
            dt = min( dt , Ct * min( arts[i].dx / wave.celerity( arts[i].rho,arts[i].K,arts[i].initA ) ) )
        return dt

#############################
# Shapes (Well-balance)
#############################

def space(dx) :
    N = len(dx) ;
    shape = np.zeros(N) ;
    shape[0] = dx[0]/2.
    for i in range(1,N) :
        shape[i] = shape[i-1] + (dx[i-1]+dx[i])/2.
    return shape

def shape_R(x) :
    N = len(x)
    shape = np.ones(N)
    return shape ;

def shape_K(x) :
    N = len(x)
    shape = np.ones(N)
    return shape ;

def shape_Cv(x) :
    N = len(x)
    shape = np.ones(N)
    return shape ;

def shape_Knl(x) :
    N = len(x)
    shape = np.ones(N)
    return shape ;

def shape_phi(x) :
    N = len(x)
    shape = np.ones(N)
    return shape ;

def shape_mu0(x) :
    N = len(x)
    shape = np.ones(N)
    return shape ;

def shape_mu1(x) :
    N = len(x)
    shape = np.ones(N)
    return shape ;

def shape_kmu(x) :
    N = len(x)
    shape = np.ones(N)
    return shape ;

def shape_amu(x) :
    N = len(x)
    shape = np.ones(N)
    return shape ;

def shape_f(x) :
    N = len(x)
    shape = np.ones (N)
    return shape ;

def shape_H(x) :
    N = len(x)
    shape = np.np.ones(N)
    return shape ;

def shape_C(x) :
    N = len(x)
    shape = np.ones (N)
    return shape ;

def shape_O(x) :
    N = len(x)
    shape = np.np.ones(N)
    return shape ;

###################################################
# Read column of a CSV file and print a numpy array
###################################################
def csvTOarray(csvFile,csvOut,tp,ic,nc) :

    # Output
    out = [] ;
    # Open file
    fcsv = open(csvFile,'r')
    # Read line
    for line in fcsv :
        if not line.startswith('#') :
            if not line.isspace() :
                arr = map(float,line.split(","))
                out.append(arr[ic])
    fcsv.close()
    n = len(out)
    # Print
    fout = open(csvOut,'w')

    fout.write("np.array([\n\t")
    for i in range(n) :



        if (i%nc == 0 and i !=0) :
            fout.write("\n \t")

        if (tp == "int") :
            fout.write( "%d, \t"%(out[i]))
        if (tp == "float") :
            fout.write( "%.8f, \t"%(out[i]))

    fout.write("\n]) ;\n")
    fout.close()
