#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

########################
# Delestre Inviscid
########################
def A_Delestre_Inviscid(C1,C2,t):
    return C2 / (C1 - t)

def U_Delestre_Inviscid(C1,C3,x,t):
    return (x - C3) / (t - C1)

def Q_Delestre_Inviscid(C1,C2,C3,x,t):
    return A_Delestre_Inviscid(C1,C2,t) * U_Delestre_Inviscid(C1,C3,x,t)

def U_Int_Delestre_Inviscid(C1,C3,x1,x2,t):
    return -C3 / (t - C1) + 1. / (t - C1) * ( x2 + x1 ) / 2.

def Q_Int_Delestre_Inviscid(C1,C2,C3,x1,x2,t):
    return A_Delestre_Inviscid(C1,C2,t) * U_Int_Delestre_Inviscid(C1,C3,x1,x2,t)

########################
# Delestre Viscous
########################
def A_Delestre_Viscous(C1,C2,Cf,t):
    return C2 * np.exp(Cf*t)/ (-C1 + np.exp(Cf*t))

def U_Delestre_Viscous(C1,C3,Cf,x,t):
    return (C1 * Cf * x - C3)/  (-C1 + np.exp(Cf*t))

def Q_Delestre_Viscous(C1,C2,C3,Cf,x,t):
    return A_Delestre_Viscous(C1,C2,Cf,t) * U_Delestre_Viscous(C1,C3,Cf,x,t)

def U_Int_Delestre_Viscous(C1,C3,Cf,x1,x2,t):
    return 0.5 * (U_Delestre_Viscous(C1,C3,Cf,x1,t)+U_Delestre_Viscous(C1,C3,Cf,x2,t))

def Q_Int_Delestre_Viscous(C1,C2,C3,Cf,x1,x2,t):
    return A_Delestre_Viscous(C1,C2,Cf,t) * U_Int_Delestre_Viscous(C1,C3,Cf,x1,x2,t)
