#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

from    help_Inlet  import  celerity

def Admittance(RHO,K,A) :
    return A / RHO / celerity(RHO,K,A)

def Impedance(RHO,K,A) :
    return 1. / Admittance(RHO,K,A)

def Reflection_2Arteries(RHO,AP,AD,KP,KD) :

    YP = Admittance(RHO,KP,AP) ;
    YD = Admittance(RHO,KD,AD) ;
    Rt = (YP-YD)/(YP+YD) ;
    Tt = 1. + Rt ;

    return Rt , Tt

def Reflection_3Arteries(RHO,AP,AD1,AD2,KP,KD1,KD2) :

    YP  = Admittance(RHO,KP,AP) ;
    YD1 = Admittance(RHO,KD1,AD1) ;
    YD2 = Admittance(RHO,KD2,AD2) ;
    Rt  = (YP-YD1-YD2)/(YP+YD1+YD2) ;
    Tt  = 1. + Rt ;

    return Rt , Tt
