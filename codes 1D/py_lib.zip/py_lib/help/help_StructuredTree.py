#!/usr/local/bin/python3
import sys, getopt
import os

import numpy            as np
import cmath            as cm

import scipy.optimize       as opt
import scipy.interpolate    as interp

# import numdifftools     as nd
# import matplotlib.pyplot as plt

mmHG = 1./0.0007500615613026439

###################################
# Help classes
###################################
class Network():
    def __init__(self,RHO,MU,ETA,RMIN,EPS,GAMMA,LAMBDA,ZLEAF):

        # Tree properties
        self.Rmin       = float(RMIN)
        self.eps        = float(EPS)
        self.gamma      = float(GAMMA)
        self.alpha      = (1. + self.gamma**(self.eps/2.))**(-1./self.eps)
        self.beta       = self.alpha * np.sqrt(self.gamma)
        self.lbda       = float(LAMBDA)

        # Fluid properties
        self.rho        = float(RHO)
        self.mu         = float(MU)
        self.nu         = self.mu/self.rho
        # Velocity profile & friction
        self.eta        = float(ETA)
        self.cf         = 2. * np.pi * (self.eta + 2.) * self.nu

        self.zLeaf      = float(ZLEAF)


        self.nArtery    = 0.
        self.V          = 0.
        self.A          = 0.
        self.L          = 0.

        self.R          = []
        self.Daughter   = []
        self.Parent     = []
        self.Leaf       = []

        self.tmpParent  = []
        self.tmpR       = []

        self.zIn        = []
        self.zOut       = []
        self.zRoot      = []
        self.modzRoot   = []
        self.argzRoot   = []

    # Construction functions
    def RtoX(self,R) :
        # if (R >= 5.e-3) :
        #     return 15.75 * R**1.1
        # elif (R < 5.e-3) :
        #     return 1.79 * R**0.47
        return R * self.lbda

    def RtoK(self,R) :
        if (R < 500.e-4) :
            R = 500.e-4
        k1  = 2.e7 ;
        k2  = -22.53 ;
        k3  = 8.65e5 ;
        return 4./3. / R / np.sqrt(np.pi) * ( k1 * np.exp( k2*R ) + k3 )

    # Build the structured tree
    def build(self,R) :

        print
        print("Root radius          : ", R)
        # print("Root Rigidity        : ", K)
        print("Alpha                : ", self.alpha)
        print("Beta                 : ", self.beta)
        print

        # Artery counter
        iArt = 0 ;
        # Ramification counter
        iRam    = 0 ;
        iAlpha  = 0 ;
        iBeta   = 0 ;

        # Root artery
        self.R.append(R) ;
        self.zIn.append(0.)
        self.zOut.append(0.)

        self.V += np.pi * self.R[0]**2. * self.RtoX(self.R[0])
        self.A += np.pi * self.R[0]**2.
        self.L += self.RtoX(self.R[0])

        self.Parent.append([])
        self.Daughter.append([])

        # Temporary parent arteries
        self.tmpParent.append(iArt)
        self.tmpR.append(R)

        # Branch out until minimum radius is reached
        while (len(self.tmpR) > 0) :

            iRam += 1
            if (self.alpha * np.amax(self.tmpR) >= self.Rmin ) :
                iAlpha += 1
            if (self.beta * np.amin(self.tmpR) >= self.Rmin ) :
                iBeta += 1

            tParent = []
            tR      = []

            for art in self.tmpParent :

                R1 = self.alpha * self.R[art]
                R2 = self.beta  * self.R[art]

                # R1
                if ( R1 > self.Rmin ) :
                    self.R.append( R1 )
                    self.Parent.append(art)
                    self.Daughter[art].append( iArt+1 )
                    self.Daughter.append([])
                    self.V += np.pi * self.R[iArt+1]**2. * self.RtoX(self.R[iArt+1])
                    self.A += self.RtoX(self.R[0])
                    self.L += self.RtoX(self.R[iArt+1])
                    # Temporary parent arteries
                    tParent.append(iArt+1)
                    tR.append(self.R[iArt+1])
                    iArt += 1

                else :
                # Include last artery
                    self.R.append( R1 )
                    self.Parent.append(art)
                    self.Daughter[art].append( iArt+1 )
                    self.Daughter.append([])
                    self.V += np.pi * self.R[iArt+1]**2. * self.RtoX(self.R[iArt+1])
                    self.A += self.RtoX(self.R[0])
                    self.L += self.RtoX(self.R[iArt+1])
                    # Leaf
                    self.Leaf.append( iArt+1 )
                    iArt += 1

                # Don't include last artery
                    # self.Leaf.append(art)

                # R2
                if ( R2 > self.Rmin ) :
                    self.R.append( R2 )
                    self.Parent.append(art)
                    self.Daughter[art].append( iArt+1 )
                    self.Daughter.append([])
                    self.V += np.pi * self.R[iArt+1]**2. * self.RtoX(self.R[iArt+1])
                    self.A += self.RtoX(self.R[0])
                    self.L += self.RtoX(self.R[iArt+1])
                    # Temporary parent arteries
                    tParent.append(iArt+1)
                    tR.append(self.R[iArt+1])
                    iArt += 1 ;
                else :
                # Include last artery
                    self.R.append( R2 )
                    self.Parent.append(art)
                    self.Daughter[art].append( iArt+1 )
                    self.Daughter.append([])
                    self.V += np.pi * self.R[iArt+1]**2. * self.RtoX(self.R[iArt+1])
                    self.A += self.RtoX(self.R[0])
                    self.L += self.RtoX(self.R[iArt+1])
                    # Leaf
                    self.Leaf.append( iArt+1 )
                    iArt += 1 ;
                # Don't include last artery

            self.tmpParent  = tParent
            self.tmpR       = tR

        self.nArtery = len(self.R)

        print
        print("Level of ramification        : ", iRam)
        print("Total number of arteries     : ", self.nArtery)
        print("Expected number of arteries  : ", int(2.**((iRam-1.)+1.)-1.))
        print("Number of leafs              : ", len(self.Leaf))
        print("Number of alpha branches     : ", iAlpha)
        print("Expected number of alpha     : ", np.log(self.Rmin/R)/np.log(self.alpha))
        print("Number of beta branches      : ", iBeta)
        print("Expected number of beta      : ", np.log(self.Rmin/R)/np.log(self.beta))
        print("Maximum radius               : ", np.amax(self.R))
        print("Minimum radius               : ", np.amin(self.R))
        print("Cutoff radius                : ", self.Rmin)
        print

    # Compute the root impedance
    def RootImpedance(self,w) :

        n           = len(w)
        self.zIn    = np.zeros((self.nArtery,n),dtype=complex)
        self.zOut   = np.zeros((self.nArtery,n),dtype=complex)

        for iArt in reversed(range(self.nArtery)) :

            # Leaf artery
            if (self.Daughter[iArt] == []) :
                if (iArt not in self.Leaf) :
                    print("Artery ", iArt, " is not a leaf")
                    sys.exit()
                self.zOut[iArt,:] = self.zLeaf * np.ones(n)

            # One daughter artery
            elif (len(self.Daughter[iArt]) == 1) :
                dArt1 = self.Daughter[iArt][0]
                self.zOut[iArt,:] = self.zIn[dArt1,:]

            # Two daughter artery
            elif (len(self.Daughter[iArt]) == 2) :
                dArt1 = self.Daughter[iArt][0]
                dArt2 = self.Daughter[iArt][1]
                self.zOut[iArt,:] = zJunction(  self.zIn[dArt1,:],
                                                self.zIn[dArt2,:]
                                             )
            else :
                print("Unkown number of daughter arteries :", len(self.Daughter[iArt]) )

            # Compute the inlet impedance
            for i in range(n) :
                self.zIn[iArt,i] = zOuttoIn(w=w[i],
                                            R=Resistance( self.rho, self.R[iArt], self.cf ),
                                            C=Compliance( self.rho, self.R[iArt], self.RtoK(self.R[iArt]) ),
                                            L=Inductance( self.rho, self.R[iArt] ),
                                            Z=self.zOut[iArt,i],
                                            X=self.RtoX( self.R[iArt] )
                                            )

        self.zRoot      = self.zOut[0,:]
        self.modzRoot   = np.ones(n)
        self.argzRoot   = np.ones(n)
        for i in range(n) :
            self.modzRoot[i] = np.sqrt( self.zRoot[i].real**2. + self.zRoot[i].imag**2. )
            self.argzRoot[i] = cm.phase( self.zRoot[i])

    # Compute the root impedance
    def RootImpedanceNonNewtonian(self,w) :

        n           = len(w)
        self.zIn    = np.zeros((self.nArtery,n),dtype=complex)
        self.zOut   = np.zeros((self.nArtery,n),dtype=complex)

        for iArt in reversed(range(self.nArtery)) :

            # Leaf artery
            if (self.Daughter[iArt] == []) :
                if (iArt not in self.Leaf) :
                    print("Artery ", iArt, " is not a leaf")
                    sys.exit()
                self.zOut[iArt,:] = self.zLeaf * np.ones(n)

            # One daughter artery
            elif (len(self.Daughter[iArt]) == 1) :
                dArt1 = self.Daughter[iArt][0]
                self.zOut[iArt,:] = self.zIn[dArt1,:]

            # Two daughter artery
            elif (len(self.Daughter[iArt]) == 2) :
                dArt1 = self.Daughter[iArt][0]
                dArt2 = self.Daughter[iArt][1]
                self.zOut[iArt,:] = zJunction(  self.zIn[dArt1,:],
                                                self.zIn[dArt2,:]
                                             )
            else :
                print("Unkown number of daughter arteries :", len(self.Daughter[iArt]) )

            # Compute the inlet impedance
            for i in range(n) :
                self.zIn[iArt,i] = zOuttoIn(w=w[i],
                                            R=Resistance( self.rho, self.R[iArt], self.cf ),
                                            C=Compliance( self.rho, self.R[iArt], self.RtoK(self.R[iArt]) ),
                                            L=Inductance( self.rho, self.R[iArt] ),
                                            Z=self.zOut[iArt,i],
                                            X=self.RtoX( self.R[iArt] )
                                            )

        self.zRoot      = self.zOut[0,:]
        self.modzRoot   = np.ones(n)
        self.argzRoot   = np.ones(n)
        for i in range(n) :
            self.modzRoot[i] = np.sqrt( self.zRoot[i].real**2. + self.zRoot[i].imag**2. )
            self.argzRoot[i] = cm.phase( self.zRoot[i])

    def __del__(self):
      class_name = self.__class__.__name__

###################################
# Help functions
###################################
def zOuttoIn(w,R,C,L,Z,X) :
    if (w != 0.) :
        xl = cm.sqrt( w*C * ( w*L - 1j * R ) )
        dl = cm.sqrt( ( w*L - 1j * R ) / ( w*C ) )
        cc = cm.cos( X*xl )
        cs = cm.sin( X*xl )
        return ( Z * cc + 1j * dl * cs ) / ( cc + Z * 1j / dl * cs ) ;
    else :
        return Z + X*R

def zJunction(zD1,zD2) :
    return zD1*zD2 / (zD1+zD2) ;

###################################
# Vessel properties
###################################
def cmk(rho,R,K) :
    A = np.pi * R * R ;
    return np.sqrt( K / 2. / rho * np.sqrt(A) )

def Resistance(rho,R,cf) :
    A = np.pi * R * R ;
    return rho * cf / A / A

def Compliance(rho,R,K) :
    A = np.pi * R * R ;
    return A / rho / (cmk(rho,R,K)*cmk(rho,R,K))

def Inductance(rho,R) :
    A = np.pi * R * R ;
    return rho / A ;

def Impedance(rho,R,K) :
    A = np.pi * R * R ;
    return rho * cmk(rho,R,K) / A

###################################
# Impedance Windkessel & ST
###################################
def zWindkessel(w,R1,R2,C,L) :
    return R1 + (R2 + 1j*w*L)/(1. + 1j*w*R2*C - w*w*L*C)

def zStructuredTree(fileName,Sample,RHO,MU,ETA,RMIN,EPS,GAMMA,LAMBDA,ZLEAF,T,R) :

    # Define sample size
    N = int(Sample)
    # Define w
    bInf = 0
    bSup = N-1
    w =  2. * np.pi / T * np.linspace(bInf,bSup,N)

    # Create network
    net = Network(RHO=RHO,MU=MU,ETA=ETA,RMIN=RMIN,EPS=EPS,GAMMA=GAMMA,LAMBDA=LAMBDA,ZLEAF=ZLEAF)
    net.build(R)
    # Compute impedance
    net.RootImpedance( w )

    # Write
    # Structured Tree w, mod(Z), arg(Z)
    fhZst = open(fileName+"ST-Z.csv",'w')
    fhZst.write("#%s,\t %s,\t %s\n"%("w []", "|Zst| []", "arg(Zst) [rad]"))
    for i in range(N) :
        fhZst.write("%.20f,\t %.20f,\t %.20f\n"%(w[i],
                                                np.absolute(net.zRoot[i]),cm.phase(net.zRoot[i])
                                                ))
    fhZst.close()

def zStructuredTreeNonNewtonian(fileName,Sample,RHO,MU,ETA,RMIN,EPS,GAMMA,LAMBDA,ZLEAF,T,R) :

    # Define sample size
    N = int(Sample)
    # Define w
    bInf = 0
    bSup = N-1
    w =  2. * np.pi / T * np.linspace(bInf,bSup,N)

    # Create network
    net = Network(RHO=RHO,MU=MU,ETA=ETA,RMIN=RMIN,EPS=EPS,GAMMA=GAMMA,LAMBDA=LAMBDA,ZLEAF=ZLEAF)
    net.build(R)
    # Compute impedance
    net.RootImpedanceNonNewtonian( w )

    # Write
    # Structured Tree w, mod(Z), arg(Z)
    fhZst = open(fileName+"ST-Z.csv",'w')
    fhZst.write("#%s,\t %s,\t %s\n"%("w []", "|Zst| []", "arg(Zst) [rad]"))
    for i in range(N) :
        fhZst.write("%.20f,\t %.20f,\t %.20f\n"%(w[i],
                                                np.absolute(net.zRoot[i]),cm.phase(net.zRoot[i])
                                                ))
    fhZst.close()

###################################
# Minimization
###################################
# def jac_costFunction(x,C,L,w,Z) :
#     return nd.Jacobian(lambda x: costFunction(x,C,L,w,Z))(x).ravel()

def costFunction(x,C,L,w,Z) :
    R1,R2 = x
    # L2 error on the modulus
    n   = len(Z)
    L2  = 0.
    for i in range(n) :
        err = ( np.absolute(zWindkessel(w[i],R1,R2,C,L) - Z[i])  )**2.
        L2  += err
    return np.sqrt(L2)

def costFunctionC(C,R1,R2,L,w,Z) :
    # L2 error on the modulus
    n   = len(Z)
    L2  = 0.
    for i in range(n) :
        err = ( np.absolute(zWindkessel(w[i],R1,R2,C,L) - Z[i]) / np.amax(np.absolute(Z)) )**2.
        L2  += err
    return np.sqrt(L2) / float(n)

def costFunctionL(L,R1,R2,C,w,Z) :
    # L2 error on the modulus
    n   = len(Z)
    L2  = 0.
    for i in range(n) :
        err = ( np.absolute(zWindkessel(w[i],R1,R2,C,L) - Z[i]) / np.amax(np.absolute(Z)) )**2.
        L2  += err
    return np.sqrt(L2) / float(n)

def getRLC(fileName,fileWrite,RHO,MU,ETA,RMIN,EPS,GAMMA,LAMBDA,ZLEAF,T,R) :

    # Read from file
    dataZ = np.genfromtxt( fileName+"ST-Z.csv" , delimiter=",", dtype = np.float64)

    # Get w
    w = dataZ[:,0]
    # Define sample size
    N = len(w)

    # Get Zst
    zRoot = np.zeros(N,dtype=np.complex128)
    for i in range(N) :
        zRoot[i] = dataZ[i,1] * np.cos(dataZ[i,2]) + 1j * dataZ[i,1] * np.sin(dataZ[i,2])#cm.rect(dataZ[i,1],dataZ[i,2])
        if ( abs(np.absolute(zRoot[i]) - dataZ[i,1])/abs(dataZ[i,1]) > 1.e-14 or abs(cm.phase(zRoot[i]) - dataZ[i,2])/abs(dataZ[i,2]) > 1.e-14 ) :
            print("Error in conversion from polar to rect")
            print(np.absolute(zRoot[i]),dataZ[i,1])
            print(cm.phase(zRoot[i]),dataZ[i,2])
            sys.exit()

    # Create network
    net = Network(RHO=RHO,MU=MU,ETA=ETA,RMIN=RMIN,EPS=EPS,GAMMA=GAMMA,LAMBDA=LAMBDA,ZLEAF=ZLEAF)
    net.build(R)

    # Compute the terminal resistance
    R1 = 1.e4
    # Compute second resistance
    R2 = float(zRoot[0] - R1)
    # Compliance
    C = 1.
    # Inductance
    L = 0.

    # Define target data
    wR = w
    wC = w
    wL = w
    ZR = zRoot
    ZC = zRoot
    ZL = zRoot

    # Find minimum recursvely, as parameters are of different scales
    nLoop = 10
    for i in range(nLoop) :

        # Find R1,R2,
        # Initial guess
        x0 = np.array([R1,R2])
        resR = opt.minimize(
                    costFunction, x0, args=(C,L,wR,ZR),
                    method = 'L-BFGS-B',
                    bounds = [(1.,None),(1.,None)],
                    tol    = 1.e-14,
                    options = dict(
                                ftol = 1.e-14,
                                gtol = 1.e-14,
                                maxiter = 10000,
                                maxls = 50
                              )
                    )
        R1 = resR.x[0]
        R2 = resR.x[1]

        # Find  C
        resC =   opt.minimize_scalar(
                    costFunctionC, args=(R1,R2,L,wC,ZC),
                    method = 'bounded',
                    bounds = (0.,1.e-3),
                    tol    = 1.e-14,
                    options = dict(
                                xatol = 1.e-14,
                                maxiter = 10000#,
                                # disp = True
                              )
                    )
        C   = resC.x ;

        Lmax = (R2**2.) * C / 4.
        resL =   opt.minimize_scalar(
                    costFunctionL, args=(R1,R2,C,wL,ZL),
                    method = 'bounded',
                    bounds = (0.,Lmax),
                    tol    = 1.e-14,
                    options = dict(
                                xatol = 1.e-14,
                                maxiter = 10000
                                # disp = True
                              )
                    )
        L   = resL.x

    # Check succsess
    if (resR.success == False) :
        print("Resistance minimization unsuccessfull")
        print("R1 = ",resR.x[0],", R2 = ",resR.x[1],", C = ", resC.x, ", L= ",resL.x)
        print(resR.fun/np.amax(np.absolute(zRoot)))
        print(resR.message)
        sys.exit()
    if (resC.success == False) :
        print("Compliance minimization unsuccessfull")
        print("R1 = ",resR.x[0],", R2 = ",resR.x[1],", C = ", resC.x, ", L= ",resL.x)
        print(resC.fun)
        print(resC.message)
        sys.exit()
    if (resL.success == False) :
        print("Inductance minimization unsuccessfull")
        print("R1 = ",resR.x[0],", R2 = ",resR.x[1],", C = ", resC.x, ", L= ",resL.x)
        print(resL.fun)
        print(resL.message)
        sys.exit()

    # Check characteristic times
    print("Succsess             : ", resR.success,resC.success,resL.success)
    print("Cost function        : ", resR.fun/np.amax(np.absolute(zRoot)),resC.fun,resL.fun)
    print("Total resistance     : ", R1+R2)
    print("R1                   : ", R1)
    print("R2                   : ", R2)
    print("C                    : ", C)
    print("L                    : ", L)
    print("Compliant time       : ", R2*C)
    print("Inertial time        : ", L/R2)
    print("tL/tC                : ", L/R2 / R2 / C)

    # Write
    # L,A,V
    fhLAV = open(fileWrite+"LAV.csv",'w')
    fhLAV.write("#%s,\t %s,\t %s \n"%("L [cm]", "A [cm^2]", "V [cm^3]"))
    fhLAV.write("%.20f,\t %.20f,\t %.20f\n"%(net.L,net.A,net.V))
    fhLAV.close()
    # R1,R2,L,C
    fhRLC = open(fileWrite+"RLC.csv",'w')
    fhRLC.write("#%s,\t %s,\t %s,\t %s \n"%("R1 []", "R2 []", "C []", "I []"))
    fhRLC.write("%.20f,\t %.20f,\t %.20f,\t %.20f\n"%(R1,R2,C,L))
    fhRLC.close()
    # Windkessel w, mod(Z), arg(Z)
    fhZwk = open(fileWrite+"WK-Z.csv",'w')
    fhZwk.write("#%s,\t %s,\t %s\n"%("w []", "|Zst| []", "arg(Zst) [rad]"))
    for i in range(N) :
        fhZwk.write("%.20f,\t %.20f,\t %.20f\n"%(w[i],
                                                np.absolute(zWindkessel(w[i],R1,R2,C,L)),cm.phase(zWindkessel(w[i],R1,R2,C,L))
                                                ))
    fhZwk.close()

    return net.L,net.A,net.V,R1,R2,C,L,resL.fun,resR.success,resC.success,resL.success

def interpRLC(fileName,Rr,Rc,iRr,iRc,iZ) :

    # Get data
    Data    = np.genfromtxt( fileName , delimiter=",", dtype = np.float64)
    Rrv     = Data[0:,int(iRr)]
    Rcv     = Data[0:,int(iRc)]
    Z       = Data[0:,int(iZ)]

    # Find bounds
    Rrmin = np.amin(Rrv) ; Rrmax = np.amax(Rrv)
    Rcmin = np.amin(Rcv) ; Rcmax = np.amax(Rcv)

    # Create interpolation function
        # If in the grid
    if ( Rrmin <= Rr <= Rrmax and Rcmin <= Rc <= Rcmax ) :
        RLC = interp.interp2d( Rrv,Rcv,Z, kind='linear', bounds_error=True )
        # If outside the grid
    else :
        RLC = interp.Rbf( Rrv,Rcv,Z, function='multiquadric', smooth=0 )

    return float(RLC(Rr,Rc))

def curveRLC(fileName,iRr,iZ,fit,p0) :

    # Get data
    Data    = np.genfromtxt( fileName , delimiter=",", dtype = np.float64)
    Rrv     = Data[0:,int(iRr)]
    Z       = Data[0:,int(iZ)]

    # Find bounds
    Rrmin = np.amin(Rrv) ; Rrmax = np.amax(Rrv)

    if (len(p0) != 0) :
        fitcoeff,cov = opt.curve_fit(fit,Rrv,Z,p0=p0,maxfev=1000)
    else :
        fitcoeff,cov = opt.curve_fit(fit,Rrv,Z,maxfev=1000)

    print(fitcoeff)
    print(cov)

    return fitcoeff
