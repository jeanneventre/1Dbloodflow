#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

from scipy.interpolate import interp1d

from help_Sum import *

def interpBlock_t(blockm1,block,t):

    outBlock = []

    # Verify length of blocks
    if (len(blockm1)!=len(block) or len(blockm1[:,0])!=len(block[:,0])) :
        print("interpBlock_t: Error in the length of the blocks",len(blockm1),len(block),len(blockm1[:,0]),len(block[:,0]))
        sys.exit()

    # Interpolate the data
    for iL in range(len(block)):
        lLine = []
        #Time
        lLine.append(float(t));
        #Other variables
        for iC in range(1,len(block[iL,:])) :
            Interp = interp1d( [ blockm1[iL,0],block[iL,0] ], [ blockm1[iL,iC],block[iL,iC] ], kind='nearest', assume_sorted='true' )
            lLine.append (Interp( float(t) ) )

        outBlock.append(lLine)

    return np.array(outBlock)

def interpBlock_x(blockm1,block,x):

    outBlock = []

    # Verify length of blocks
    if (len(blockm1)!=len(block) or len(blockm1[:,0])!=len(block[:,0])) :
        print("interpBlock_x: Error in the length of the blocks",len(blockm1),len(block),len(blockm1[:,0]),len(block[:,0]))
        sys.exit()

    # Interpolate the data
    for iL in range(len(block)):
        lLine = []
        #Time
        lLine.append(block[0,0]);
        #Space
        lLine.append(float(x))
        #Other variables
        for iC in range(2,len(block[iL,:])) :
            Interp = interp1d( [ blockm1[iL,1],block[iL,1] ], [ blockm1[iL,iC],block[iL,iC] ], kind='nearest', assume_sorted='true' )
            lLine.append (Interp( float(x) ) )

        outBlock.append(lLine)

    return np.array(outBlock)

def interpLine_t(linem1,line,t):

        # Verify length of blocks
    if (len(linem1)!=len(line)) :
        print("interpLine_t: Error in the length of the lines")
        sys.exit()

    lLine = []
    #Time
    lLine.append(float(t));
    #Other variables
    for iC in range(1,len(line)) :
        Interp = interp1d( [ linem1[0],line[0] ], [ linem1[iC],line[iC] ], kind='nearest', assume_sorted='true'  )
        lLine.append (Interp( float(t) ) )

    return lLine


def interpLine_x(linem1,line,x):

    outBlock = []

    # Verify length of blocks
    if (len(linem1)!=len(line)) :
        print("interpLine_x: Error in the length of the Lines")
        sys.exit()

    lLine = []
    #Time
    lLine.append(line[0]);
    #Space
    lLine.append(float(x))
    #Other variables
    for iC in range(2,len(line)) :
        Interp = interp1d( [ linem1[1],line[1] ], [ linem1[iC],line[iC] ], kind='nearest', assume_sorted='true' )
        lLine.append( Interp( float(x) ) )

    return lLine
