#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt
