#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

from multiS_libBlock import *

def get_errL2(cls,Block,pType,Xana) :

    err = 0 ;

    x = Block[:,0]
    U = plotBlock(cls,Block,pType)

    xana = Xana[:,0] ;
    Uana = Xana[:,1] ;

    n = len(x) ; nana = len(xana) ;

    if (n > nana) :
        nS = len(xana) ; nL = len(x)
        xL = x ; L = U;
        xS = xana ; S = Uana
    else :
        nS = len(x) ; nL = len(xana)
        xS = x ; S = U
        xL = xana ; L = Uana

    iL = 0
    for iS in range(nS) :
        xtarget = xS[iS]; Utarget = S[iS] ;
        while(xL[iL] < xtarget and iL < nL) :
            iL += 1;

        if (iL == 0) :
            Udata = xL[il]
        elif ( np.abs(xL[iL] - xtarget) <= np.abs(xL[iL-1] - xtarget)  ) :
            Udata = xL[il]
        else :
            Udata = xL[iL-1]

        err += (Udata-Utarget)**2.

    return err / nS

def write_x_All(cls,numArt,lTime) :

    art = int(numArt) ; nPlot = len(lTime) ;

    # BLOCK DATA
    ################
    lBlock = cls.readBlock_t(nArt=numArt,lTime=lTime)
    lBlock_Profile = cls.readBlock_Profil_t(nArt=numArt,lTime=lTime)
    if (len(lBlock) != nPlot) :
        print("write_x: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_x.csv"
    fh = open(fileName,'w')

    for iT in range(nPlot) :
        Block = lBlock[iT]
        npos = len(Block[:,0])
        Block_Profile = lBlock_Profile[iT]

        ylabel, t = plotBlock(cls=cls,Block=Block,pType='t')
        ylabel, x = plotBlock(cls=cls,Block=Block,pType='x')
        ylabel, R0 = plotBlock(cls=cls,Block=Block,pType='R0')
        ylabel, A0 = plotBlock(cls=cls,Block=Block,pType='A0')
        ylabel, K = plotBlock(cls=cls,Block=Block,pType='K')
        ylabel, R = plotBlock(cls=cls,Block=Block,pType='R')
        ylabel, RmR0 = plotBlock(cls=cls,Block=Block,pType='RmR0')
        ylabel, A = plotBlock(cls=cls,Block=Block,pType='A')
        ylabel, Q = plotBlock(cls=cls,Block=Block,pType='Q')
        ylabel, U = plotBlock(cls=cls,Block=Block,pType='U')
        ylabel, U0 = plotBlock(cls=cls,Block=Block,pType='U0')
        ylabel, P = plotBlock(cls=cls,Block=Block,pType='P')
        ylabel, gradxP = plotBlock(cls=cls,Block=Block,pType='gradxP')
        ylabel, E = plotBlock(cls=cls,Block=Block,pType='E')
        ylabel, Tw = plotBlock(cls=cls,Block=Block,pType='Tw')
        ylabel, Cf = plotBlock(cls=cls,Block=Block,pType='Cf')
        ylabel, a = get_alpha(cls=cls,Block=Block,Block_Profil=Block_Profile)

        for ip in range(npos) :
            fh.write("%20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f"
                    %(t[ip],x[ip],R0[ip],A0[ip],K[ip],R[ip],RmR0[ip],A[ip],Q[ip],U[ip],U0[ip],P[ip],gradxP[ip],E[ip],Tw[ip],Cf[ip],a[ip]) + "\n")
        fh.write("\n");
        fh.write("\n");

    fh.close()

def write_t_All(cls,numArt,lX) :

    art = int(numArt) ; nPlot = len(lX) ;

    # BLOCK DATA
    ################
    lBlock = cls.readBlock_x(nArt=numArt,lX=lX)

    if (len(lBlock) != nPlot) :
        print("write_t: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_t.csv"
    fh = open(fileName,'w')

    for iX in range(nPlot) :
        Block = lBlock[iX]
        npos = len(Block[:,0])

        ylabel, t = plotBlock(cls=cls,Block=Block,pType='t')
        ylabel, x = plotBlock(cls=cls,Block=Block,pType='x')
        ylabel, R0 = plotBlock(cls=cls,Block=Block,pType='R0')
        ylabel, A0 = plotBlock(cls=cls,Block=Block,pType='A0')
        ylabel, K = plotBlock(cls=cls,Block=Block,pType='K')
        ylabel, R = plotBlock(cls=cls,Block=Block,pType='R')
        ylabel, RmR0 = plotBlock(cls=cls,Block=Block,pType='RmR0')
        ylabel, A = plotBlock(cls=cls,Block=Block,pType='A')
        ylabel, Q = plotBlock(cls=cls,Block=Block,pType='Q')
        ylabel, U = plotBlock(cls=cls,Block=Block,pType='U')
        ylabel, U0 = plotBlock(cls=cls,Block=Block,pType='U0')
        ylabel, P = plotBlock(cls=cls,Block=Block,pType='P')
        ylabel, gradxP = plotBlock(cls=cls,Block=Block,pType='gradxP')
        ylabel, E = plotBlock(cls=cls,Block=Block,pType='E')
        ylabel, Tw = plotBlock(cls=cls,Block=Block,pType='Tw')
        ylabel, Cf = plotBlock(cls=cls,Block=Block,pType='Cf')

        for ip in range(npos) :
            fh.write("%20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f"
                    %(t[ip],x[ip],R0[ip],A0[ip],K[ip],R[ip],RmR0[ip],A[ip],Q[ip],U[ip],U0[ip],P[ip],gradxP[ip],E[ip],Tw[ip],Cf[ip]) + "\n")
        fh.write("\n");
        fh.write("\n");

    fh.close()

def write_x(cls,numArt,lTime,pType) :

    art = int(numArt) ; nPlot = len(lTime) ;

    # BLOCK DATA
    ################
    lBlock = cls.readBlock_t(nArt=numArt,lTime=lTime)
    if (len(lBlock) != nPlot) :
        print("write_x: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_x_" + str(pType) + ".csv"
    fh = open(fileName,'w')

    # Get number of space points
    ##############################
    npos = len(lBlock[0][:,0])

    # Indicate plot positions in first line
    ##################################
    for iT in range(nPlot) :
        t= lBlock[iT][0,0]
        fh.write(", \t %.20f"%(t))
    fh.write("\n")

    # Write quantity of interest in columns
    #######################################
    for ip in range(npos) :
        for iT in range(nPlot) :
            x = lBlock[iT][ip,1]
            label,Y = plotBlock(cls=cls,Block=lBlock[iT],pType=str(pType))
            if (iT == 0) :
                fh.write("%.20f"%(x))
            fh.write(", \t %.20f"%(Y[ip]))

        fh.write("\n")

    fh.close()

def write_t(cls,numArt,lX,pType) :

    art = int(numArt) ; nPlot = len(lX) ;

    # BLOCK DATA
    ################
    lBlock = cls.readBlock_x(nArt=numArt,lX=lX)
    if (len(lBlock) != nPlot) :
        print("write_t: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_t_"+str(pType)+".csv"
    fh = open(fileName,'w')

    # Get number of time points
    ##############################
    npos = len(lBlock[0][:,0])

    # Indicate plot positions in first line
    ##################################
    for iX in range(nPlot) :
        x = lBlock[iX][0,1]
        fh.write(", \t %.20f"%(x))
    fh.write("\n")

    # Write quantity of interest in columns
    #######################################
    for ip in range(npos) :
        for iX in range(nPlot) :
            t = lBlock[iX][ip,0]
            label,Y = plotBlock(cls=cls,Block=lBlock[iX],pType=str(pType))
            if (iX == 0) :
                fh.write("%.20f"%(t))
            fh.write(", \t %.20f"%(Y[ip]))

        fh.write("\n")

    fh.close()

def write_t_r_Ux(cls,Utype,numArt,X,lR) :

    if (Utype == "Ux") :
        fName = "Ux.csv"
        iU = 1
    if (Utype == "Ur") :
        fName = "Ur.csv"
        iU = 2
    if (Utype == "UxUr") :
        fName = "UxUr.csv"
        iU = 3

    art = int(numArt) ; nPlot = len(lR) ;

    # BLOCK DATA
    ################
    Block = cls.readBlock_Profil_x_r(nArt=numArt,xPos=X,lR=lR)

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_t_r_" + fName
    fh = open(fileName,'w')

    # WRITE POSITION
    fh.write("#%20.20f"%(float(Block[0][0])))
    for iR in range(1, (len(Block[0]) -1)/3 + 1 ) :
        fh.write(",\t %20.20f"%(Block[0][ (iR-1) * 3 + 1 ]))
    fh.write("\n")

    for iT in range(1,len(Block)) :
        fh.write("%20.20f"%(Block[iT][0]))
        for iR in range(1, (len(Block[0]) -1)/3 + 1 ) :
            fh.write("\t, %20.20f"%(Block[iT][ (iR-1) * 3 + iU]))
        fh.write("\n");

    fh.close()

def write_t_Ux(cls,numArt,xPos,lTime) :

    art = int(numArt) ; nPlot = len(lTime) ;

    # BLOCK DATA
    ################
    lBlock_Profile = cls.readBlock_Profil_t(nArt=numArt,lTime=lTime)
    if (len(lBlock_Profile) != nPlot) :
        print("write_t_Ux: Error in the size of lBlock")
        sys.exit()

    # GET SUBBLOCK FOR xPos
    #######################
    SubBlock = [] ;
    for iT in range(nPlot):
        Sub = cls.readSubBlock_Profile_x(nArt=art,xPos=float(xPos),Block=lBlock_Profile[iT])
        SubBlock.append(Sub)

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_t_r_Ux.csv"
    fh = open(fileName,'w')

    #WRITE TIME
    fh.write("%s"%("t [s]"))
    for iT in range(nPlot) :
        fh.write(",\t %20.20f"%(float(lTime[iT])))
    fh.write("\n")

    #GET NUMBER OF LAYERS
    nl = len(SubBlock[0][:,0])
    #GET RADIUS
    R = SubBlock[0][:,2]
    #GET DIMENSIONLESS RADIUS
    dr = (abs(R[nl-1]) - abs(R[nl-2]))/2.
    r = R[:] / (abs(R[nl-1]) + dr)

    for il in range(nl) :

        fh.write("%20.20f"%(r[il]))

        for iT in range(nPlot) :

            Ux = SubBlock[iT][il,3]
            Ur = SubBlock[iT][il,4]
            fh.write("\t, %20.20f"%(Ux))

        fh.write("\n");

    fh.close()

def write_x_Ux(cls,numArt,lX,Time) :

    art = int(numArt) ; nPlot = len(lX) ;

    # BLOCK DATA
    ################
    lBlock_Profile = cls.readBlock_Profil_t(nArt=numArt,lTime=[Time])
    if (len(lBlock_Profile) != 1) :
        print("write_x_Ux: Error in the size of lBlock")
        sys.exit()

    # GET SUBBLOCK FOR lX
    #######################
    SubBlock = [] ;
    for iX in range(nPlot):
        Sub = cls.readSubBlock_Profile_x(nArt=art,xPos=float(lX[iX]),Block=lBlock_Profile[0])
        SubBlock.append(Sub)

    #WRITE TO FILE
    ##############
    fileName = cls.pathStore + "Artery_"+str(art)+"_x_r_Ux.csv"
    fh = open(fileName,'w')

    #WRITE TIME
    fh.write("%s"%("x [cm]"))
    for iX in range(nPlot) :
        fh.write(",\t %20.20f"%(float(lX[iX])))
    fh.write("\n")

    #GET NUMBER OF LAYERS
    nl = len(SubBlock[0][:,0])
    #GET RADIUS
    R = SubBlock[0][:,2]
    #GET DIMENSIONLESS RADIUS
    dr = (abs(R[nl-1]) - abs(R[nl-2]))/2.
    r = R[:] / (abs(R[nl-1]) + dr)

    for il in range(nl) :

        fh.write("%20.20f"%(r[il]))

        for iX in range(nPlot) :

            Ux = SubBlock[iX][il,3]
            Ur = SubBlock[iX][il,4]
            fh.write("\t, %20.20f"%(Ux))

        fh.write("\n");

    fh.close()

##########################################
# Write with changing file name
##########################################
def write_ChangeName_x_All(cls,numArt,lTime,lLabel) :

    art = int(numArt) ; nPlot = len(lTime) ;

    # BLOCK DATA
    ################
    lBlock = cls.readBlock_t(nArt=numArt,lTime=lTime)
    # lBlock_Profile = cls.readBlock_Profil_t(nArt=numArt,lTime=lTime)
    if (len(lBlock) != nPlot) :
        print("write_x: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############

    for iT in range(nPlot) :

        fileName = cls.pathStore + "Artery_"+str(art)+"_" +str(lLabel[iT])+"_x_R0_A0_K_R_RmR0_A_Q_U_U0_P_gradP_E_Tw_Cf_a_Sh.csv"
        fh = open(fileName,'w')

        Block = lBlock[iT]
        npos = len(Block[:,0])
        # Block_Profile = lBlock_Profile[iT]

        ylabel, t = plotBlock(cls=cls,Block=Block,pType='t')
        ylabel, x = plotBlock(cls=cls,Block=Block,pType='x')
        ylabel, R0 = plotBlock(cls=cls,Block=Block,pType='R0')
        ylabel, A0 = plotBlock(cls=cls,Block=Block,pType='A0')
        ylabel, K = plotBlock(cls=cls,Block=Block,pType='K')
        ylabel, R = plotBlock(cls=cls,Block=Block,pType='R')
        ylabel, RmR0 = plotBlock(cls=cls,Block=Block,pType='RmR0')
        ylabel, A = plotBlock(cls=cls,Block=Block,pType='A')
        ylabel, Q = plotBlock(cls=cls,Block=Block,pType='Q')
        ylabel, U = plotBlock(cls=cls,Block=Block,pType='U')
        ylabel, U0 = plotBlock(cls=cls,Block=Block,pType='U0')
        ylabel, P = plotBlock(cls=cls,Block=Block,pType='P')
        ylabel, gradxP = plotBlock(cls=cls,Block=Block,pType='gradxP')
        ylabel, E = plotBlock(cls=cls,Block=Block,pType='E')
        ylabel, Tw = plotBlock(cls=cls,Block=Block,pType='Tw')
        # ylabel, Cf = plotBlock(cls=cls,Block=Block,pType='Cf')
        ylabel, Cf = plotBlock(cls=cls,Block=Block,pType='phi')
        # ylabel, a = get_alpha(cls=cls,Block=Block,Block_Profil=Block_Profile)
        ylabel, a = plotBlock(cls=cls,Block=Block,pType='alpha')
        ylabel, Sh = plotBlock(cls=cls,Block=Block,pType='Sh')

        for ip in range(npos) :
            fh.write("%20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f"
                    %(t[ip],x[ip],R0[ip],A0[ip],K[ip],R[ip],RmR0[ip],A[ip],Q[ip],U[ip],U0[ip],P[ip],gradxP[ip],E[ip],Tw[ip],Cf[ip],a[ip],Sh[ip]) + "\n")
        fh.write("\n");
        fh.write("\n");

        fh.close()

def write_ChangeName_x_Ux(cls,numArt,lX,lTime,lLabel) :

    art = int(numArt) ; nX = len(lX) ; nPlot = len(lTime)

    # BLOCK DATA
    ################
    lBlock_Profile = cls.readBlock_Profil_t(nArt=numArt,lTime=lTime)
    if (len(lBlock_Profile) != nPlot) :
        print("write_ChangeName_x_Ux: Error in the size of lBlock")
        sys.exit()

    for iT in range(nPlot) :

        # GET SUBBLOCK FOR lX
        #######################
        SubBlock = [] ;
        for iX in range(nX):
            Sub = cls.readSubBlock_Profile_x(nArt=art,xPos=float(lX[iX]),Block=lBlock_Profile[iT])
            SubBlock.append(Sub)

        #WRITE TO FILE
        ##############
        fileName = cls.pathStore + "Artery_"+str(art)+"_"+str(lLabel[iT])+"_x_r_Ux.csv"
        fh = open(fileName,'w')

        #WRITE TIME
        fh.write("%s"%("x [cm]"))
        for iX in range(nX) :
            fh.write(",\t %20.20f"%(float(lX[iX])))
        fh.write("\n")

        #GET NUMBER OF LAYERS
        nl = len(SubBlock[0][:,0])
        #GET RADIUS
        R = SubBlock[0][:,2]
        #GET DIMENSIONLESS RADIUS
        dr = (abs(R[nl-1]) - abs(R[nl-2]))/2.
        r = R[:] / (abs(R[nl-1]) + dr)

        for il in range(nl) :

            fh.write("%20.20f"%(r[il]))

            for iX in range(nX) :

                Ux = SubBlock[iX][il,3]
                Ur = SubBlock[iX][il,4]
                fh.write("\t, %20.20f"%(Ux))

            fh.write("\n");

        fh.close()

def write_ChangeName_t_All(cls,numArt,lX,lLabel) :

    art = int(numArt) ; nPlot = len(lX) ;

    # BLOCK DATA
    ################
    lBlock = cls.readBlock_x(nArt=numArt,lX=lX)

    if (len(lBlock) != nPlot) :
        print("write_t: Error in the size of lBlock")
        sys.exit()

    #WRITE TO FILE
    ##############

    for iX in range(nPlot) :

        fileName = cls.pathStore + "Artery_"+str(art)+"_" +str(lLabel[iX])+ "_t_R0_A0_K_R_RmR0_A_Q_U_U0_P_gradP_E_Tw_Cf_Sh.csv"
        fh = open(fileName,'w')

        Block = lBlock[iX]
        npos = len(Block[:,0])

        ylabel, t = plotBlock(cls=cls,Block=Block,pType='t')
        ylabel, x = plotBlock(cls=cls,Block=Block,pType='x')
        ylabel, R0 = plotBlock(cls=cls,Block=Block,pType='R0')
        ylabel, A0 = plotBlock(cls=cls,Block=Block,pType='A0')
        ylabel, K = plotBlock(cls=cls,Block=Block,pType='K')
        ylabel, R = plotBlock(cls=cls,Block=Block,pType='R')
        ylabel, RmR0 = plotBlock(cls=cls,Block=Block,pType='RmR0')
        ylabel, A = plotBlock(cls=cls,Block=Block,pType='A')
        ylabel, Q = plotBlock(cls=cls,Block=Block,pType='Q')
        ylabel, U = plotBlock(cls=cls,Block=Block,pType='U')
        ylabel, U0 = plotBlock(cls=cls,Block=Block,pType='U0')
        ylabel, P = plotBlock(cls=cls,Block=Block,pType='P')
        ylabel, gradxP = plotBlock(cls=cls,Block=Block,pType='gradxP')
        ylabel, E = plotBlock(cls=cls,Block=Block,pType='E')
        ylabel, Tw = plotBlock(cls=cls,Block=Block,pType='Tw')
        ylabel, Cf = plotBlock(cls=cls,Block=Block,pType='phi')
        ylabel, Sh = plotBlock(cls=cls,Block=Block,pType='Sh')

        for ip in range(npos) :
            fh.write("%20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f,\t %20.20f"
                    %(t[ip],x[ip],R0[ip],A0[ip],K[ip],R[ip],RmR0[ip],A[ip],Q[ip],U[ip],U0[ip],P[ip],gradxP[ip],E[ip],Tw[ip],Cf[ip],Sh[ip]) + "\n")
        fh.write("\n");
        fh.write("\n");

    fh.close()
