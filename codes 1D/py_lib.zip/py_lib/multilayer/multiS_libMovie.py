#!/usr/local/bin/python3
from help_plot          import *
from multiS_libBlock    import *

FFMpegWriter    = animation.writers['ffmpeg']
metadata        = dict(title='Movie', artist='Arthur Ghigo',
                    comment='Awesome movie')

def findMinMax(lBlock,iX) :
    Min = 0. ; Max = 0. ;
    for iT in range(len(lBlock)) :
        Mi = np.amin(lBlock[iT][:,int(iX)])
        Ma = np.amax(lBlock[iT][:,int(iX)])
        if (Ma > Max) :
            Max=Ma
        if (Mi < Min) :
            Min = Mi
    return Min,Max

###########################################
# Define new colormaps
###########################################
BlueRed = make_colormap(
    [colors.ColorConverter().to_rgb('navy'),
     colors.ColorConverter().to_rgb('mediumblue'),    0.1,   colors.ColorConverter().to_rgb('mediumblue'),
     colors.ColorConverter().to_rgb('Blue'),    0.2,   colors.ColorConverter().to_rgb('Blue'),
     colors.ColorConverter().to_rgb('royalblue'), 0.3,   colors.ColorConverter().to_rgb('royalblue'),
     colors.ColorConverter().to_rgb('dodgerblue'), 0.4,   colors.ColorConverter().to_rgb('dodgerblue'),
     colors.ColorConverter().to_rgb('deepskyblue'), 0.5,   colors.ColorConverter().to_rgb('coral'),
     colors.ColorConverter().to_rgb('darkorange'), 0.6,   colors.ColorConverter().to_rgb('darkorange'),
     colors.ColorConverter().to_rgb('orangered'), 0.7,   colors.ColorConverter().to_rgb('orangered'),
     colors.ColorConverter().to_rgb('tomato'), 0.8,   colors.ColorConverter().to_rgb('tomato'),
     colors.ColorConverter().to_rgb('red'), 0.9,   colors.ColorConverter().to_rgb('red'),
     colors.ColorConverter().to_rgb('darkred'), 0.95,   colors.ColorConverter().to_rgb('darkred')],'BlueRed')

plt.register_cmap(cmap=BlueRed)

# BlueRed = make_colormap(
#     [colors.ColorConverter().to_rgb('navy'),
#      colors.ColorConverter().to_rgb('mediumblue'),    0.1,   colors.ColorConverter().to_rgb('mediumblue'),
#      colors.ColorConverter().to_rgb('Blue'),    0.2,   colors.ColorConverter().to_rgb('Blue'),
#      colors.ColorConverter().to_rgb('royalblue'), 0.3,   colors.ColorConverter().to_rgb('royalblue'),
#      colors.ColorConverter().to_rgb('dodgerblue'), 0.4,   colors.ColorConverter().to_rgb('dodgerblue'),
#      colors.ColorConverter().to_rgb('deepskyblue'), 0.499,   colors.ColorConverter().to_rgb('green'),
#      colors.ColorConverter().to_rgb('green'), 0.5,   colors.ColorConverter().to_rgb('green'),
#      colors.ColorConverter().to_rgb('green'), 0.501,   colors.ColorConverter().to_rgb('darkorange'),
#      colors.ColorConverter().to_rgb('darkorange'), 0.6,   colors.ColorConverter().to_rgb('darkorange'),
#      colors.ColorConverter().to_rgb('orangered'), 0.7,   colors.ColorConverter().to_rgb('orangered'),
#      colors.ColorConverter().to_rgb('tomato'), 0.8,   colors.ColorConverter().to_rgb('tomato'),
#      colors.ColorConverter().to_rgb('red'), 0.9,   colors.ColorConverter().to_rgb('red'),
#      colors.ColorConverter().to_rgb('darkred'), 0.95,   colors.ColorConverter().to_rgb('darkred')],'BlueRed')
#
# plt.register_cmap(cmap=BlueRed)

######################################
# Average quantities
######################################
def animate_x(cls,numArt,pType,TextPos,TextAlign,TextColor,speedUp,slowDownfps,nf) :

    nfig = nf ; fig = plt.figure(nfig) ; nfig += 1

    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.2, right=0.95, bottom=0.15, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Define second line: Ur
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ;

    # Get data block
    ################
    lBlock = cls.readBlock(nArt=art)

    nt = len(lBlock)
    nx = len(lBlock[0][:,0])

    x = lBlock[0][:,1]

    # Find min and max
    ##################
    pMin = 0.; pMax = 0. ;
    for it in range(nt) :
        pLabel, pData = plotBlock(cls=cls,Block=lBlock[it],pType=pType)
        if (np.max(pData) > pMax) :
            pMax = np.max(pData)
        if (np.min(pData) < pMin) :
            pMin = np.min(pData)

    # Set labels
    ############
    ax0.set_xlabel(r"$x$ $\left[cm\right]$") ; ax0.set_ylabel(pLabel)
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())
    # Set limits
    ############
    ax0.set_xlim(x[0],x[nx-1]) ; ax0.set_ylim(pMin,pMax)
    ax0.axhline(0, color='grey',linestyle='--')
    # Set legend
    ############
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

    # Set artists
    #############
    line0, = ax0.plot([],[],color="blue",label=str(pType),linewidth=1.5,linestyle='-')
    time_text = ax0.text(TextPos[0],TextPos[1],'',horizontalalignment=str(TextAlign),color=str(TextColor),transform=ax0.transAxes)

    # TIME PARAMETERS :
    increaseSpeed = int(speedUp)
    dt = cls.dtrec * increaseSpeed
    tmin = lBlock[1][0,0]
    tmax = lBlock[nt-1][0,0]
    numFrames = int( (tmax-tmin ) / dt )

    def init_movie():
        line0.set_data([],[]) ;
        time_text.set_text('') ;
        return line0, time_text,

    def animate_movie(i):
        # i=i+1 as first Block not taken into account
        i = i+1
        pLabel, pData = plotBlock(cls=cls,Block=lBlock[i*increaseSpeed],pType=pType)
        line0.set_data(x,pData)
        ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

        time = tmin + float(i) * dt
        print("i/i_tot= ",i*increaseSpeed/(nt-1.),", t = ",time)
        time_text.set_text(r'$t=$ %.3f $s$' % time) ;

        return line0,time_text

    # Run animation
    ###############
    interval = dt
    ani = animation.FuncAnimation(  fig, animate_movie, init_func = init_movie,
                                    frames= numFrames, blit=True,
                                    interval = interval, repeat = False)

    # Write for animation
    #####################
    fps = int(  float(numFrames)/(tmax-tmin) / float(slowDownfps) )
    writer = FFMpegWriter(fps=fps, metadata=metadata, bitrate=-1, codec="libx264")


    # Save animation
    ################
    ani.save(cls.path+"Movies/" + str(pType) + "_Art_" + str(art) + ".mp4", writer=writer,savefig_kwargs={},extra_args=['--verbose-debug','-pix_fmt', 'yuv420p'])

    return nfig

######################################
# Velocity profile at specific position
######################################
def animate_Profile(cls,numArt,xPos,nStore,TextPos,TextAlign,TextColor,speedUp,slowDownfps,nf) :

    nfig = nf ; fig = plt.figure(nfig) ; nfig += 1

    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.2, right=0.95, bottom=0.15, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Define second line: Ur
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ;

    # Get data block for specific xPos
    ##################################
    lBlock  = cls.readBlock_x(nArt=art,lX=[xPos])
    Block   = lBlock[0]

    nt = len(Block[:,0])
    ny = int(cls.nLayer[art])

    y = cls.rArt(art)

    # Find max and min velocity at specific xPos
    ############################################
    UPmax = 0. ; UPmin = 0.;
    for i in range(nt) :
        U0Label, U0 = plotBlock(cls=cls,Block=Block,pType="U0")
        Umax = np.max(U0) ; Umin = np.min(U0)
        if (Umax > UPmax) :
            UPmax = Umax
        if (Umin < UPmin) :
            UPmin = Umin

    # Definie U and V
    ################
    U = np.zeros(2*ny) ; V = np.zeros(2*ny)

    # Set labels
    ############
    ax0.set_xlabel(r"$u_x$ $\left[\frac{cm}{s}\right]$") ; ax0.set_ylabel(r"$\frac{r}{R}$")
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())
    # Set limits
    ############
    ax0.set_xlim(UPmin,UPmax) ; ax0.set_ylim(-1,1)
    ax0.axvline(0, color='grey',linestyle='--')
    # Set legend
    ############
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

    # Set artists
    ######################
    line0,      = ax0.plot([],[],color="black",linewidth=1.5,linestyle='-')
    time_text   = ax0.text(TextPos[0],TextPos[1],'',horizontalalignment=str(TextAlign),color=str(TextColor),transform=ax0.transAxes)

    # TIME PARAMETERS :
    increaseSpeed = int(speedUp)
    dt = cls.dtrec * increaseSpeed

    # CHOOSE NUMBER OF FRAMES PER SECOND : MAX IS THE NUMBER OF TIMES RECORDED :
    tmin = Block[0,0]
    tmax = Block[nt-1,0]
    numFrames = int( (tmax-tmin ) / dt )

    def init_movie():
        line0.set_data([],[]) ;
        time_text.set_text('') ;
        return line0, time_text,

    Block_Profile = []

    def animate_movie(i):

        # i=i+1 as first Block not taken into account
        i = i+1

        global Block_Profile

        # Get data block Profile
        ########################
        if ( i == 1 ) :
            liTime = []; lTime = []
            for iS in range( min( nStore , nt-1) ) :
                liTime.append((iS)*increaseSpeed) ;
                lTime.append(tmin + float(iS)*dt) ;
            Block_Profile = cls.readBlock_Profil_t_Animation(nArt=numArt,liTime=liTime,lTime=lTime)

        elif ( (i+1)%nStore == 0 ) :
            liTime = []; lTime = []
            for iS in range( min( nStore , nt-i-1 ) ) :
                liTime.append((i+iS)*increaseSpeed) ;
                lTime.append(tmin + float(i+iS)*dt) ;
            Block_Profile = cls.readBlock_Profil_t_Animation(nArt=numArt,liTime=liTime,lTime=lTime)

        SubBlock    =   cls.readSubBlock_Profile_x(nArt=art,xPos=xPos,Block=Block_Profile[(i+1)%nStore])

        # Modify Y, U, V and C
        ######################
        U[:] = SubBlock[:,3]
        V[:] = SubBlock[:,4]

        line0.set_data(U,y)

        # Legends
        ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)

        time = tmin + float(i) * dt
        print("i/i_tot= ",i*increaseSpeed/float(nt-1),", t = ",time,dt,tmin,tmax,nt)
        time_text = ax0.text(TextPos[0],TextPos[1],r'$t=$ %.3f $s$' % time,horizontalalignment=str(TextAlign),color=str(TextColor),transform=ax0.transAxes)

        return line0,time_text

    # Run animation
    ###############
    interval = dt
    ani = animation.FuncAnimation(  fig, animate_movie, init_func = init_movie,
                                    frames= numFrames, blit=True,
                                    interval = interval, repeat = False)

    # Write for animation
    #####################
    fps = int(  float(numFrames)/(tmax-tmin) / float(slowDownfps) )
    writer = FFMpegWriter(fps=fps, metadata=metadata, bitrate=-1, codec="libx264")

    # Save animation
    ################
    ani.save(cls.path+"Movies/Profile_Art_" + str(art) + ".mp4", writer=writer,savefig_kwargs={},extra_args=['--verbose-debug','-pix_fmt', 'yuv420p'])

    return nfig


######################################
# Velocity profiles in artery
######################################
def animate_Arrow_UUr(cls,numArt,nArrowX,nArrowY,scArrow,nStore,Umid,Colormap,TextPos,TextAlign,TextColor,speedUp,slowDownfps,nf) :

    nfig = nf ; fig = plt.figure(nfig) ; nfig += 1

    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.15, right=0.79, bottom=0.15, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Define second line: Ur
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ;

    # Get data block
    ################
    lBlock = cls.readBlock(nArt=art)

    nt = len(lBlock)
    nx = len(lBlock[0][:,0])
    ny = int(cls.nLayer[art])

    x = lBlock[0][:,1]
    y = cls.rArt(art)
    R0Label, R0 = plotBlock(cls=cls,Block=lBlock[0],pType='R0')

    # Find max and min velocity
    ################
    UPmax = 0. ; UPmin = 0.;
    for i in range(nt) :
        U0Label, U0 = plotBlock(cls=cls,Block=lBlock[i],pType="U0")
        Umax = np.max(U0) ; Umin = np.min(U0)
        if (Umax > UPmax) :
            UPmax = Umax
        if (Umin < UPmin) :
            UPmin = Umin

    # Definie U and V
    ################
    U = np.zeros((2*ny,nx)) ; V = np.zeros((2*ny,nx))

    # Define the interval beteewn the arrow
    ################
    if (nx < int(nArrowX)) :
        interX = 1
    else :
        interX= int( float(nx)/float(nArrowX))
    if (2*ny < int(nArrowY)) :
        interY = 1
    else :
        interY= int( float(2*ny)/float(nArrowY))

    # Scale the length of the arrows:
    sc = float(scArrow) * UPmax * float(nx)/float(interX)

    # Add text
    ######################
    time_text = ax0.text(TextPos[0],TextPos[1],'',horizontalalignment=str(TextAlign),color=str(TextColor),transform=ax0.transAxes)

    # TIME PARAMETERS :
    increaseSpeed = int(speedUp)
    dt = cls.dtrec * increaseSpeed

    # CHOOSE NUMBER OF FRAMES PER SECOND : MAX IS THE NUMBER OF TIMES RECORDED :
    tmin = lBlock[1][0,0]
    tmax = lBlock[nt-1][0,0]
    numFrames = int( (tmax-tmin ) / dt )

    # COLORMAP
    ################
    start = 0. ;
    if (Umid >= UPmax) :
        mid = (0 - UPmin) / (UPmax - UPmin)
    else :
        mid = (Umid-UPmin) / (UPmax - UPmin)
    stop = 1. ;
    colormap = plt.cm.get_cmap(str(Colormap))
    shiftedcolormap = remappedColorMap(colormap, start = start , midpoint=mid, stop = stop , name='shifted')

    def init_movie():

        global Block_Profile

        # Get data block
        ################
        Block = lBlock[0]
        # Get data block Profile
        ########################
        liTime = [] ; lTime = [] ;
        for iS in range( min( nStore , nt-1) ) :
            liTime.append((iS)*increaseSpeed) ;
            lTime.append(tmin + float(iS)*dt) ;
        Block_Profile = cls.readBlock_Profil_t_Animation(nArt=numArt,liTime=liTime,lTime=lTime)

        lSubBlock = cls.readSubBlock_Profile(nArt=art,Block=Block_Profile[0])
        if (len(lSubBlock) != nx) :
            print("animate_Arrow_UUr: Error in the size of lSubBlock")
            sys.exit()

        # Define walls
        ##############
        RLabel, R = plotBlock(cls=cls,Block=Block,pType='R')
        Rmax    = np.amax(R) * 1.2
        hwall   = Rmax * 0.1
        wall    = R + hwall

        # Modify Y, U, V and C
        ######################
        for ip in range(nx) :
            SubBlock  = lSubBlock[ip]
            U[:,ip] = SubBlock[:,3]
            V[:,ip] = SubBlock[:,4]

        # Define the scaling of the colors
        ##################################
        C = U

        # Create the grid:
        ################
        Xo,Yo = np.meshgrid(x,y)
        Y = Yo
        for ip in range(nx) :
            Y[:,ip] = Yo[:,ip] * R[ip]

        # QUIVER
        ################
        quiv = ax0.quiver(  Xo[::interY,::interX],Y[::interY,::interX],
                            U[::interY,::interX],V[::interY,::interX],
                            C[::interY,::interX],cmap=shiftedcolormap,
                            units='width',scale=sc,
                            scale_units='width',clim=(UPmin,UPmax),
                            animated=True)

        # COLORBAR
        ################
        # Left bottom width height
        cbaxes = fig.add_axes([0.81, 0.15, 0.02, 0.75])
        cb = plt.colorbar(quiv, cax = cbaxes)
        cb.set_label(r'$u_x$ $\left[\frac{cm}{s}\right]$')

        # Plot initial geometry
        #######################
        ax0.plot(x, R0,color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
        ax0.plot(x,-R0,color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
        # Plot arterial Wall (R0+h)
        ##########################
        ax0.plot(x, wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
        ax0.plot(x,-wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
        # Plot instateneous arterial Wall
        ################
        ax0.plot(x, R,color='red',alpha=1,linestyle="-",linewidth=1)
        ax0.plot(x,-R,color='red',alpha=1,linestyle="-",linewidth=1)
        # Fill the Wall
        ################
        ax0.fill_between(x,  R, wall, facecolor='grey', alpha=0.3)
        ax0.fill_between(x, -R, -wall, facecolor='grey', alpha=0.3)

        # Labels
        ################
        ax0.set_xlabel(r"$x$ $\left[cm\right]$") ; ax0.set_ylabel(r"$r$ $\left[cm\right]$")
        ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

        # Plot limits
        #############
        ax0.set_xlim(x[0],x[nx-1])
        ax0.set_ylim(-2.*np.max(R0),2.*np.max(R0))

        return quiv,

    Block_Profile = []

    def animate_movie(i):

        # i=i+1 as first Block not taken into account
        i = i+1

        global Block_Profile

        # Get data block
        ################
        Block = lBlock[i * increaseSpeed]
        # Get data block Profile
        ########################
        if ( (i+1)%nStore == 0 ) :
            liTime = []; lTime = []
            for iS in range( min( nStore , nt-i-1 ) ) :
                liTime.append((i+iS)*increaseSpeed) ;
                lTime.append(tmin + float(i+iS)*dt) ;
            Block_Profile = cls.readBlock_Profil_t_Animation(nArt=numArt,liTime=liTime,lTime=lTime)

        lSubBlock = cls.readSubBlock_Profile(nArt=art,Block=Block_Profile[(i+1)%nStore])

        if (len(lSubBlock) != nx) :
            print("animate_Arrow_UUr: Error in the size of lSubBlock")
            sys.exit()

        # Define walls
        ##############
        RLabel, R = plotBlock(cls=cls,Block=Block,pType='R')
        Rmax    = np.amax(R) * 1.2
        hwall   = Rmax * 0.1
        wall    = R + hwall

        # Modify Y, U, V and C
        ######################
        for ip in range(nx) :
            SubBlock  = lSubBlock[ip]
            U[:,ip] = SubBlock[:,3]
            V[:,ip] = SubBlock[:,4]

        # Define the scaling of the colors
        ##################################
        C = U

        # Create the grid:
        ################
        Xo,Yo = np.meshgrid(x,y)
        Y = Yo
        for ip in range(nx) :
            Y[:,ip] = Yo[:,ip] * R[ip]

        # CLEAR
        ################
        ax0.clear() ;

        # QUIVER
        ################
        quiv = ax0.quiver(  Xo[::interY,::interX],Y[::interY,::interX],
                            U[::interY,::interX],V[::interY,::interX],
                            C[::interY,::interX],cmap=shiftedcolormap,
                            units='width',scale=sc,
                            scale_units='width',clim=(UPmin,UPmax),
                            animated=True)

        # COLORBAR
        ################
        # Left bottom width height
        cbaxes = fig.add_axes([0.81, 0.15, 0.02, 0.75])
        cb = plt.colorbar(quiv, cax = cbaxes)
        cb.set_label(r'$u_x$ $\left[\frac{cm}{s}\right]$')

        # Plot initial geometry
        #######################
        ax0.plot(x, R0,color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
        ax0.plot(x,-R0,color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
        # Plot arterial Wall (R0+h)
        ##########################
        ax0.plot(x, wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
        ax0.plot(x,-wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
        # Plot instateneous arterial Wall
        ################
        ax0.plot(x, R,color='red',alpha=1,linestyle="-",linewidth=1)
        ax0.plot(x,-R,color='red',alpha=1,linestyle="-",linewidth=1)
        # Fill the Wall
        ################
        ax0.fill_between(x,  R, wall, facecolor='grey', alpha=0.3)
        ax0.fill_between(x, -R, -wall, facecolor='grey', alpha=0.3)

        # Labels
        ################
        ax0.set_xlabel(r"$x$ $\left[cm\right]$") ; ax0.set_ylabel(r"$r$ $\left[cm\right]$")
        ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

        # Plot limits
        #############
        ax0.set_xlim(x[0],x[nx-1])
        ax0.set_ylim(-2.*np.max(R0),2.*np.max(R0))

        time = tmin + float(i) * dt
        print("i/i_tot= ",i*increaseSpeed/float(nt-1),", t = ",time,dt,tmin,tmax,nt)
        time_text = ax0.text(TextPos[0],TextPos[1],r'$t=$ %.3f $s$' % time,horizontalalignment=str(TextAlign),color=str(TextColor),transform=ax0.transAxes)

        return quiv,

    # Run animation
    ###############
    interval = dt
    ani = animation.FuncAnimation(  fig, animate_movie, init_func = init_movie,
                                    frames= numFrames, blit=True,
                                    interval = interval, repeat = False)

    # Write for animation
    #####################
    fps = int(  float(numFrames)/(tmax-tmin) / float(slowDownfps) )
    writer = FFMpegWriter(fps=fps, metadata=metadata, bitrate=-1, codec="libx264")

    # Save animation
    ################
    ani.save(cls.path+"Movies/Arrow_UUr_Art_" + str(art) + ".mp4", writer=writer,savefig_kwargs={},extra_args=['--verbose-debug','-pix_fmt', 'yuv420p'])

    return nfig

######################################
# Colormap of the artery
######################################
def animate_Colormap_UUr(cls,numArt,nStore,Umid,Colormap,TextPos,TextAlign,TextColor,speedUp,slowDownfps,nf) :

    nfig = nf ; fig = plt.figure(nfig) ; nfig += 1

    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.15, right=0.79, bottom=0.15, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Define second line: Ur
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ;

    # Get data block
    ################
    lBlock = cls.readBlock(nArt=art)

    nt = len(lBlock)
    nx = len(lBlock[0][:,0])
    ny = int(cls.nLayer[art])

    x = lBlock[0][:,1]
    y = cls.rArt(art)

    # Find max and min velocity
    ################
    UPmax = 0. ; UPmin = 0.;
    for i in range(nt) :
        U0Label, U0 = plotBlock(cls=cls,Block=lBlock[i],pType="U0")
        Umax = np.max(U0) ; Umin = np.min(U0)
        if (Umax > UPmax) :
            UPmax = Umax
        if (Umin < UPmin) :
            UPmin = Umin

    # Definie U and V
    ################
    U = np.zeros((2*ny,nx)) ; V = np.zeros((2*ny,nx))

    # Add text
    ######################
    time_text = ax0.text(TextPos[0],TextPos[1],'',horizontalalignment=str(TextAlign),color=str(TextColor),transform=ax0.transAxes)

    # TIME PARAMETERS :
    increaseSpeed = int(speedUp)
    dt = cls.dtrec * increaseSpeed

    # CHOOSE NUMBER OF FRAMES PER SECOND : MAX IS THE NUMBER OF TIMES RECORDED :
    tmin = lBlock[1][0,0]
    tmax = lBlock[nt-1][0,0]
    numFrames = int( (tmax-tmin ) / dt )

    # COLORMAP
    ################
    start = 0. ;
    if (Umid >= UPmax) :
        mid = (0 - UPmin) / (UPmax - UPmin)
    else :
        mid = (Umid-UPmin) / (UPmax - UPmin)
    stop = 1. ;
    colormap = plt.cm.get_cmap(str(Colormap))
    shiftedcolormap = remappedColorMap(colormap, start = start , midpoint=mid, stop = stop , name='shifted')

    def init_movie():

        global Block_Profile

        # Get data block Profile
        ########################
        liTime = [] ; lTime = [] ;
        for iS in range( min( nStore , nt-1) ) :
            liTime.append((iS)*increaseSpeed) ;
            lTime.append(tmin + float(iS)*dt) ;
        Block_Profile = cls.readBlock_Profil_t_Animation(nArt=numArt,liTime=liTime,lTime=lTime)

        lSubBlock = cls.readSubBlock_Profile(nArt=art,Block=Block_Profile[0])
        if (len(lSubBlock) != nx) :
            print("animate_Arrow_UUr: Error in the size of lSubBlock")
            sys.exit()

        # Modify Y, U, V and C
        ######################
        for ip in range(nx) :
            SubBlock  = lSubBlock[ip]
            U[:,ip] = SubBlock[:,3]
            V[:,ip] = SubBlock[:,4]

        # Define the scaling of the colors
        ##################################
        C = U

        # IMSHOW
        ################
        im = ax0.imshow(    U,
                            cmap=shiftedcolormap,
                            extent=[x[0],x[nx-1],-1,1],
                            vmin=UPmin,vmax=UPmax,
                            aspect='auto',animated=True)

        # COLORBAR
        ################
        # Left bottom width height
        cbaxes  = fig.add_axes([0.81, 0.15, 0.02, 0.75])
        cb      = plt.colorbar(im, cax = cbaxes)
        cb.set_label(r'$u_x$ $\left[\frac{cm}{s}\right]$')

        # Labels
        ################
        ax0.set_xlabel(r"$x$ $\left[cm\right]$") ; ax0.set_ylabel(r"$\frac{r}{R}$")
        ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

        # Plot limits
        #############
        ax0.set_xlim(x[0],x[nx-1])
        ax0.set_ylim(-1,1)

        return im,

    Block_Profile = []

    def animate_movie(i):

        # i=i+1 as first Block not taken into account
        i = i+1

        global Block_Profile

        # Get data block Profile
        ########################
        if ( (i+1)%nStore == 0 ) :
            liTime = []; lTime = []
            for iS in range( min( nStore , nt-i-1 ) ) :
                liTime.append((i+iS)*increaseSpeed) ;
                lTime.append(tmin + float(i+iS)*dt) ;
            Block_Profile = cls.readBlock_Profil_t_Animation(nArt=numArt,liTime=liTime,lTime=lTime)

        lSubBlock = cls.readSubBlock_Profile(nArt=art,Block=Block_Profile[(i+1)%nStore])

        if (len(lSubBlock) != nx) :
            print("animate_Arrow_UUr: Error in the size of lSubBlock")
            sys.exit()

        # Modify Y, U, V and C
        ######################
        for ip in range(nx) :
            SubBlock  = lSubBlock[ip]
            U[:,ip] = SubBlock[:,3]
            V[:,ip] = SubBlock[:,4]

        # Define the scaling of the colors
        ##################################
        C = U

        # CLEAR
        ################
        ax0.clear() ;

        # IMSHOW
        ################
        im = ax0.imshow(    U,
                            cmap=shiftedcolormap,
                            extent=[x[0],x[nx-1],-1,1],
                            vmin=UPmin,vmax=UPmax,
                            aspect='auto',animated=True)


        # COLORBAR
        ################
        # Left bottom width height
        cbaxes  = fig.add_axes([0.81, 0.15, 0.02, 0.75])
        cb      = plt.colorbar(im, cax = cbaxes)
        cb.set_label(r'$u_x$ $\left[\frac{cm}{s}\right]$')

        # Labels
        ################
        ax0.set_xlabel(r"$x$ $\left[cm\right]$") ; ax0.set_ylabel(r"$\frac{r}{R}$")
        ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

        # Plot limits
        #############
        ax0.set_xlim(x[0],x[nx-1])
        ax0.set_ylim(-1,1)

        time = tmin + float(i) * dt
        print("i/i_tot= ",i*increaseSpeed/float(nt-1),", t = ",time,dt,tmin,tmax,nt)
        time_text = ax0.text(TextPos[0],TextPos[1],r'$t=$ %.3f $s$' % time,horizontalalignment=str(TextAlign),color=str(TextColor),transform=ax0.transAxes)

        return im,

    # Run animation
    ###############
    interval = dt
    ani = animation.FuncAnimation(  fig, animate_movie, init_func = init_movie,
                                    frames= numFrames, blit=True,
                                    interval = interval, repeat = False)

    # Write for animation
    #####################
    fps = int(  float(numFrames)/(tmax-tmin) / float(slowDownfps) )
    writer = FFMpegWriter(fps=fps, metadata=metadata, bitrate=-1, codec="libx264")

    # Save animation
    ################
    ani.save(cls.path+"Movies/Colormap_UUr_Art_" + str(art) + ".mp4", writer=writer,savefig_kwargs={},extra_args=['--verbose-debug','-pix_fmt', 'yuv420p'])

    return nfig
