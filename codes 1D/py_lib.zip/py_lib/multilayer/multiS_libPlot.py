#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt
import matplotlib
# Font
matplotlib.rc('font', family='serif', serif='cm', style='normal', weight='normal',size = '25')
# Text
matplotlib.rc('text', usetex='True', color='black')
# matplotlib.rcParams['text.latex.preamble'] = [r'\boldmath']
# Mathtext (if usetex = false)
# Lines
matplotlib.rc('lines', linewidth='1', linestyle='-', markersize='5',markeredgewidth='0.5', antialiased='True')
# Axes
# matplotlib.rcParams['axes.formatter.use_mathtext'] = 'true'
matplotlib.rcParams['axes.unicode_minus'] = 'true'
matplotlib.rc('axes', grid='False', titlesize='20', labelsize='20', labelpad='5', labelweight='normal')
matplotlib.rc('axes', xmargin='0.',ymargin='0.2')
# Ticks
matplotlib.rc('xtick', labelsize='20', direction='in')
matplotlib.rcParams['xtick.major.size'] ='4' ; matplotlib.rcParams['xtick.minor.size'] ='2'
matplotlib.rc('ytick', labelsize='20', direction='in')
matplotlib.rcParams['ytick.major.size'] ='4' ; matplotlib.rcParams['ytick.minor.size'] ='2'
# Legend
matplotlib.rc('legend', fancybox='True', frameon='False', framealpha=0., fontsize='25',handletextpad="0.1",borderaxespad="0.",columnspacing="0.4",borderpad="0.2",handlelength="1.",handleheight="0.",labelspacing="0.1")
matplotlib.rcParams['legend.numpoints'] = 1
# Grid
matplotlib.rc('grid', alpha='0.')
# Figure
matplotlib.rc('figure', figsize='8,6', dpi='1000')
# TkAgg
matplotlib.use('TkAgg')

import matplotlib.pyplot as plt
import matplotlib.cm as cmx
import matplotlib.colors as colors
import matplotlib.colorbar as mcolorbar
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.gridspec as gridspec
from scipy.interpolate import griddata

from matplotlib.ticker import ScalarFormatter

from multiS_libBlock import *

def align_yaxis(ax1, v1, ax2, v2):
    """adjust ax2 ylimit so that v2 in ax2 is aligned to v1 in ax1"""
    _, y1 = ax1.transData.transform((0, v1))
    _, y2 = ax2.transData.transform((0, v2))
    adjust_yaxis(ax2,(y1-y2)/2,v2)
    adjust_yaxis(ax1,(y2-y1)/2,v1)

def adjust_yaxis(ax,ydif,v):
    """shift axis ax by ydiff, maintaining point v at the same location"""
    inv = ax.transData.inverted()
    _, dy = inv.transform((0, 0)) - inv.transform((0, ydif))
    miny, maxy = ax.get_ylim()
    miny, maxy = miny - v, maxy - v
    if -miny>maxy or (-miny==maxy and dy > 0):
        nminy = miny
        nmaxy = miny*(maxy+dy)/(miny+dy)
    else:
        nmaxy = maxy
        nminy = maxy*(miny+dy)/(maxy+dy)
    ax.set_ylim(nminy+v, nmaxy+v)

def get_cmap(N):

    color_norm  = colors.Normalize(vmin=0, vmax=N-1)
    scalar_map = cmx.ScalarMappable(norm=color_norm, cmap=cmx.jet)
    def map_index_to_rgb_color(index):
        return scalar_map.to_rgba(index)
    return map_index_to_rgb_color

def remappedColorMap(cmap, start=0, midpoint=0.5, stop=1.0,
name='shiftedcmap'):
    '''
    Function to offset the median value of a colormap, and scale the
    remaining color range. Useful for data with a negative minimum and
    positive maximum where you want the middle of the colormap's dynamic
    range to be at zero.
    Input
    -----
      cmap : The matplotlib colormap to be altered
      start : Offset from lowest point in the colormap's range.
          Defaults to 0.0 (no lower ofset). Should be between
          0.0 and 0.5; if your dataset mean is negative you should leave
          this at 0.0, otherwise to (vmax-abs(vmin))/(2*vmax)
      midpoint : The new center of the colormap. Defaults to
          0.5 (no shift). Should be between 0.0 and 1.0; usually the
          optimal value is abs(vmin)/(vmax+abs(vmin))
      stop : Offset from highets point in the colormap's range.
          Defaults to 1.0 (no upper ofset). Should be between
          0.5 and 1.0; if your dataset mean is positive you should leave
          this at 1.0, otherwise to (abs(vmin)-vmax)/(2*abs(vmin))
    '''
    cdict = {
        'red': [],
        'green': [],
        'blue': [],
        'alpha': []
    }

    # regular index to compute the colors
    reg_index = np.hstack([
        np.linspace(start, 0.5, 128, endpoint=False),
        np.linspace(0.5, stop, 129)
    ])

    # shifted index to match the data
    shift_index = np.hstack([
        np.linspace(0.0, midpoint, 128, endpoint=False),
        np.linspace(midpoint, 1.0, 129)
    ])

    for ri, si in zip(reg_index, shift_index):
        r, g, b, a = cmap(ri)

        cdict['red'].append((si, r, r))
        cdict['green'].append((si, g, g))
        cdict['blue'].append((si, b, b))
        cdict['alpha'].append((si, a, a))

    newcmap = matplotlib.colors.LinearSegmentedColormap(name, cdict)
    plt.register_cmap(cmap=newcmap)

    return newcmap

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_x(cls,numArt,pType,lTime,lcol,lmark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.85, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ; nPlot = len(lTime) ;

    # Get data block
    ################
    lBlock = cls.readBlock_t(nArt=numArt,lTime=lTime)
    if (len(lBlock) != nPlot) :
        print("plot_x: Error in the size of lBlock")
        sys.exit()

    # Plot different data blocks
    ############################
    iBlock = 0
    for Block in lBlock :
        ylabel, Bl = plotBlock(cls,Block,pType)
        npos = len(Bl) ;
        col = lcol[iBlock] ; mark=str(lmark[iBlock]) ;
        label_Art = r"$t=$" + str(Block[0,0])
        ax0.plot(Block[:,1],Bl,label=label_Art, color=col, marker=mark, markevery=int(float(npos)/10.), linestyle='-')
        ax0.plot(Block[:,1],(100.-Block[:,1])**(1./5.))
        iBlock += 1 ;

    # Set label and ticks format
    ############################
    ax0.set_xlabel(r'$x$ ($cm$)') ; ax0.set_ylabel(ylabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # ax0.set_xlim(0.,5.)

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    fig_title = cls.pathStore+str(pType)+"_x_Artery_"+str(art)+"_t_"+str(lTime)+"_"+str(cls.logo)+".pdf"
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_x_Topo(cls,numArt,pType,lTime,lcol,lmark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.85, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Define second line: Ur
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ; nPlot = len(lTime) ;

    # Get data block
    ################
    lBlock = cls.readBlock_t(nArt=numArt,lTime=lTime)
    if (len(lBlock) != nPlot) :
        print("plot_x: Error in the size of lBlock")
        sys.exit()

    # Plot different data blocks
    ############################
    iBlock = 0
    for Block in lBlock :
        ylabel, Bl = plotBlock(cls,Block,pType)
        npos = len(Bl) ;
        col = lcol[iBlock] ; mark=str(lmark[iBlock]) ;
        label_Art = r"$t=$" + str(Block[0,0])
        ax0.plot(Block[:,1],Bl,label=label_Art, color=col, marker=mark, markevery=int(float(npos)/10.), linestyle='-')

        iBlock += 1 ;

    # Set label and ticks format
    ############################
    ax0.set_xlabel(r'$x$ ($cm$)') ; ax0.set_ylabel(ylabel);
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())


    #Topography
    ###########
    axA = ax0.twinx()
    axK = ax0.twinx()
    if (len(cls.DAG)>2) :
        A0 = cls.A0[art]
        K = cls.K[art]
    else :
        A0 = cls.A0
        K = cls.K
    xmin = lBlock[0][0,1]
    xmax = lBlock[0][len(lBlock[0][:,0])-1,1]
    xTop = np.linspace(xmin,xmax,len(A0))
    axA.plot(xTop,A0, color = "red", linewidth=1,alpha=0.5,linestyle="-.",label=r"$A_0$")
    axK.plot(xTop,K, color = "orange", linewidth=1,alpha=0.5,linestyle="--",label=r"$K$")

    axA.set_ylim(0.,2.*A0[0]) ; axK.set_ylim(0.,2.*K[0])

    plt.setp(axA.get_yticklabels(), visible=False) ; plt.setp(axA.get_yticklines(), visible=False)
    plt.setp(axK.get_yticklabels(), visible=False) ; plt.setp(axK.get_yticklines(), visible=False)
    axA.xaxis.set_major_formatter(ScalarFormatter()) ; axA.yaxis.set_major_formatter(ScalarFormatter())
    axK.xaxis.set_major_formatter(ScalarFormatter()) ; axK.yaxis.set_major_formatter(ScalarFormatter())

    # Set legend and title
    ######################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.1),ncol=1,borderaxespad=0.)
    axA.legend(loc=2,bbox_to_anchor=(0.0,1.1),ncol=1,borderaxespad=0.)
    axK.legend(loc=2,bbox_to_anchor=(0.15,1.1),ncol=1,borderaxespad=0.)

    fig_title = cls.pathStore+str(pType)+"_x_Topo_Artery_"+str(art)+"_t_"+str(lTime)+"_"+str(cls.logo)+".pdf"
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

#PLOT PROFIL
def plot_t_Profil(cls,numArt,xPos,lTime,lcol,lmark,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.85, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ; nL = int(cls.nLayer[art]) ; nPlot = len(lTime) ;

    # Get data block
    ################
    lBlock_Profile = cls.readBlock_Profil_t(nArt=art,lTime=lTime)
    if (len(lBlock_Profile) != nPlot) :
        print("plot_x: Error in the size of lBlock")
        sys.exit()

    # Plot
    ################
    for i in range(nPlot) :
        SubBlock = cls.readSubBlock_Profile_x(nArt=art,xPos=float(xPos),Block=lBlock_Profile[i])
        npos = len(SubBlock[:,0])
        col = lcol[i] ; mark=str(lmark[i]) ;
        label_Art =r"$x=$"+str(SubBlock[0,1])+r", $t=$"+str(SubBlock[0,0])
        ax0.plot(SubBlock[:,3],SubBlock[:,2], label=label_Art, color=col, marker=mark, markevery=int(float(npos)/10.), linestyle='-')


    # Draw line U=0 and line r/R=0
    ################
    ax0.axvline(0, color='grey',linestyle='-.')
    ax0.axhline(0, color='grey',linestyle='-.')

    # LABEL
    ################
    ax0.set_ylabel(r'$R$ ($cm$)') ;
    ax0.set_xlabel(r'$U$ ($\frac{cm}{s}$)');
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # LEGEND
    ################
    ax0.legend(loc=2,bbox_to_anchor=(0.,1.),ncol=2,borderaxespad=0.)
    fig_title = cls.pathStore+"UProfil_Artery_"+str(art)+"_x_"+str(SubBlock[0,1])+"_t_"+str(lTime)+"_"+str(cls.logo)+".pdf"
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_UUr_Arrow_Artery(cls,numArt,nX,tTime,nf) :

    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.85, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ; nL = int(cls.nLayer[art])

    # Get data block
    ################
    lBlock = cls.readBlock_t(nArt=numArt,lTime=[float(tTime)])
    npos = len(lBlock[0][:,0])
    if (len(lBlock) != 1) :
        print("plot_UUr_Arrow_Artery: Error in the size of lBlock")
        sys.exit()
    t = lBlock[0][0,0]
    x = lBlock[0][:,1]
    y = cls.rArt(art)

    R0 = 1./np.sqrt(np.pi) * np.sqrt(lBlock[0][:,3])
    R = 1./np.sqrt(np.pi) * np.sqrt(lBlock[0][:,4])


    lBlock_Profile = cls.readBlock_Profil_t(nArt=numArt,lTime=[float(tTime)])
    lSubBlock = cls.readSubBlock_Profile(nArt=art,Block=lBlock_Profile[0])
    if (len(lBlock_Profile) != 1) :
        print("plot_UUr_Arrow_Artery: Error in the size of lBlock_Profile")
        sys.exit()
    if (len(lSubBlock) != npos) :
        print("plot_UUr_Arrow_Artery: Error in the size of lSubBlock")
        sys.exit()
    UPmax = np.amax(lBlock_Profile[0][:,3])
    UPmin = np.amin(lBlock_Profile[0][:,3])

    # Definie U and V
    ################
    U = np.zeros((2*nL,npos)) ; V = np.zeros((2*nL,npos))
    for ip in range(npos) :
        SubBlock  = lSubBlock[ip]
        U[:,ip] = SubBlock[:,3]
        V[:,ip] = SubBlock[:,4]
    # Define the scaling of the colors: L2 norm of the Velocity
    # C = np.sqrt(np.power(U, 2) + np.power(V, 2))
    C = U


    # Define walls
    ################
    Rmax = np.amax(R) * 1.2
    hwall = Rmax*0.1
    wall = R + hwall

    # Define the interval beteewn the arrow
    ################
    numX = int(nX) ; numY = 100
    if (npos < numX) :
        interX = 1
    else :
        interX = int( float(npos)/float(numX))
    if (2*nL< numY) :
        interY = 1
    else :
        interY= int( float(2*nL)/float(numY))
    # Scale the length of the arrows:
    sc = UPmax * float(npos)/float(interX)

    # COLORMAP
    ################
    start = (UPmax-abs(UPmin))/(2.*UPmax)
    mid = 0.5 #abs(UPmin ) / (UPmax + abs(UPmin))
    stop = 1. ;
    colormap = plt.cm.get_cmap("coolwarm")
    shiftedcolormap = remappedColorMap(colormap, start = start , midpoint=mid, stop = stop , name='shifted')

    # Create the grid:
    ################
    Xo,Yo = np.meshgrid(x,y)
    # Modify Y
    Y = Yo
    for i in range(npos) :
        Y[:,i] = Yo[:,i] * R[i]

    # PLOT
    ################
    label_Art = "t=" + str(t)
    quiv = ax0.quiver(Xo[::interY,::interX],Y[::interY,::interX],U[::interY,::interX],V[::interY,::interX],C[::interY,::interX],label=label_Art,cmap=shiftedcolormap,units='width',scale=sc,scale_units='width',clim=(UPmin,UPmax),animated=True)

    # COLORBAR
    ################
    cbaxes = fig.add_axes([0.86, 0.1, 0.01, 0.8])
    cb = plt.colorbar(quiv, cax = cbaxes)
    # cb.set_label(r'$\sqrt{U^2+V^2}$ ($\frac{cm}{s}$)')
    cb.set_label(r'$U$ ($\frac{cm}{s}$)')


    # Plot initial geometry
    ################
    ax0.plot(x,R0,color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
    ax0.plot(x,-R0,color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
    # Plot arterial Wall (R0+h)
    ################
    ax0.plot(x,wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
    ax0.plot(x,-wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
    # Plot instateneous arterial Wall
    ################
    ax0.plot(x, R,color='red',alpha=1,linestyle="-",linewidth=1)
    ax0.plot(x,-R,color='red',alpha=1,linestyle="-",linewidth=1)
    # Fill the Wall
    ################
    ax0.fill_between(x,  R, wall, facecolor='grey', alpha=0.3)
    ax0.fill_between(x, -R, -wall, facecolor='grey', alpha=0.3)

    # Labels
    ################
    ax0.set_xlabel(r"$x$ ($cm$)") ; ax0.set_ylabel(r"$r$ ($cm$)")
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # LEGEND
    ################
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    fig_title = cls.pathStore+"Arrow_UUr_Artery_"+str(art)+ "_Time_"+str(tTime)+"_"+str(cls.logo)+".pdf"
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

def plot_Arrow_Tw_P_Q_U(cls,numArt,nX,tTime,nf) :

    nfig = nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=3,ncols=1,left=0.1, right=0.85, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1,2,1])
    # Define first line: FLOW
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    ax0b = ax0.twinx() ;
    # Define middle line: Speed
    ax1 = plt.Subplot(fig, col1[1]) ; fig.add_subplot(ax1)
    # Define last line: Tw and P
    ax2 = plt.Subplot(fig, col1[2]) ; fig.add_subplot(ax2)
    ax2b = ax2.twinx() ;

    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    ax1.tick_params(top='off',right='off');
    ax2.tick_params(top='off',right='off');

    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)
    ax0b.locator_params(axis='x',tight=True, nbins=10) ; ax0b.locator_params(axis='y',tight=True, nbins=6)
    ax1.locator_params(axis='x',tight=True, nbins=10) ; ax1.locator_params(axis='y',tight=True, nbins=6)
    ax2.locator_params(axis='x',tight=True, nbins=10) ; ax2.locator_params(axis='y',tight=True, nbins=6)
    ax2b.locator_params(axis='x',tight=True, nbins=10) ; ax2b.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ; nL = int(cls.nLayer[art])

    # Get data block
    ################
    lBlock = cls.readBlock_t(nArt=numArt,lTime=[float(tTime)])
    npos = len(lBlock[0][:,0])
    if (len(lBlock) != 1) :
        print("plot_UUr_Arrow_Artery: Error in the size of lBlock")
        sys.exit()
    t = lBlock[0][0,0]
    x = lBlock[0][:,1]
    y = cls.rArt(art)

    R0 = 1./np.sqrt(np.pi) * np.sqrt(lBlock[0][:,3])
    R = 1./np.sqrt(np.pi) * np.sqrt(lBlock[0][:,4])

    lBlock_Profile = cls.readBlock_Profil_t(nArt=numArt,lTime=[float(tTime)])
    lSubBlock = cls.readSubBlock_Profile(nArt=art,Block=lBlock_Profile[0])
    if (len(lBlock_Profile) != 1) :
        print("plot_UUr_Arrow_Artery: Error in the size of lBlock_Profile")
        sys.exit()
    if (len(lSubBlock) != npos) :
        print("plot_UUr_Arrow_Artery: Error in the size of lSubBlock")
        sys.exit()
    UPmax = np.amax(lBlock_Profile[0][:,3])
    UPmin = np.amin(lBlock_Profile[0][:,3])

    # Definie U and V
    ################
    U = np.zeros((2*nL,npos)) ; V = np.zeros((2*nL,npos))
    for ip in range(npos) :
        SubBlock  = lSubBlock[ip]
        U[:,ip] = SubBlock[:,3]
        V[:,ip] = SubBlock[:,4]
    # Define the scaling of the colors: L2 norm of the Velocity
    C = np.sqrt(np.power(U, 2) + np.power(V, 2))

    # Define walls
    ################
    Rmax = np.amax(R) * 1.2
    hwall = Rmax*0.1
    wall = R + hwall

    # Define the interval beteewn the arrow
    ################
    numX = int(nX) ; numY = 100
    if (npos < numX) :
        interX = 1
    else :
        interX = int( float(npos)/float(numX))
    if (2*nL< numY) :
        interY = 1
    else :
        interY= int( float(2*nL)/float(numY))
    # Scale the length of the arrows:
    sc = UPmax * float(npos)/float(interX)

    # Create the grid:
    ################
    Xo,Yo = np.meshgrid(x,y)
    # Modify Y
    Y = Yo
    for i in range(npos) :
        Y[:,i] = Yo[:,i] * R[i]

    ########### VARYING PARAMS #####################

    # Flow
    ################
    ylabel, Bl = plotBlock(cls,lBlock[0],'Q')
    ax0.set_xlabel(r"$x$ ($cm$)") ; ax0.set_ylabel(ylabel)
    # ax0.set_xlim(xmin,xmax) ; ax0.set_ylim(cls.Qmin-0.3*np.abs(cls.Qmax),cls.Qmax+0.3*np.abs(cls.Qmax))
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())
    ax0.axhline(0, color='black',linestyle='--')
    ax0.plot(x,Bl,color="red",label=r"$Q$",marker='s', markevery=int(float(npos)/10.),alpha=1)
    ax0.legend(loc=1,bbox_to_anchor=(0.8,1.37),ncol=1,borderaxespad=0.)

    # PRESSURE
    ################
    ylabel, Bl = plotBlock(cls,lBlock[0],'U')
    ax0b.set_ylabel(ylabel)
    # ax0b.set_xlim(xmin,xmax) ; ax0b.set_ylim(cls.Umin-0.3*np.abs(cls.Umax),cls.Umax+0.3*np.abs(cls.Umax))
    ax0b.yaxis.set_major_formatter(ScalarFormatter())
    ax0b.axhline(0, color='black',linestyle='--')
    ax0b.plot(x,Bl,color = "black",label=r"$U$",marker='*', markevery=int(float(npos)/10.),alpha=0.7)
    ax0b.legend(loc=1,bbox_to_anchor=(1.,1.37),ncol=1,borderaxespad=0.)

    align_yaxis(ax0, 0., ax0b, 0.)

    # PROFIL
    ################
    quiv = ax1.quiver(Xo[::interY,::interX],Y[::interY,::interX],U[::interY,::interX],V[::interY,::interX],C[::interY,::interX],cmap='jet',units='width',scale=sc,scale_units='width',clim=(UPmin,UPmax),animated=True)

    # COLORBAR
    ################
    cbaxes = fig.add_axes([0.86, 0.35, 0.01, 0.3])
    cb = plt.colorbar(quiv, cax = cbaxes)
    cb.set_label(r'$\sqrt{U^2+V^2}$ ($\frac{cm}{s}$)')

    # Plot initial geometry
    ################
    ax1.plot(x,R0,color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
    ax1.plot(x,-R0,color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
    # Plot arterial Wall (R0+h)
    ################
    ax1.plot(x,wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
    ax1.plot(x,-wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
    # Plot instateneous arterial Wall
    ################
    ax1.plot(x, R,color='red',alpha=1,linestyle="-",linewidth=1)
    ax1.plot(x,-R,color='red',alpha=1,linestyle="-",linewidth=1)
    # Fill the Wall
    ################
    ax1.fill_between(x,  R, wall, facecolor='grey', alpha=0.3)
    ax1.fill_between(x, -R, -wall, facecolor='grey', alpha=0.3)

    # Labels
    ################
    ax1.set_xlabel(r"$x$ ($cm$)") ; ax1.set_ylabel(r"$r$ ($cm$)")
    ax1.xaxis.set_major_formatter(ScalarFormatter()) ; ax1.yaxis.set_major_formatter(ScalarFormatter())

    # WSS
    ################
    ylabel, Bl = plotBlock(cls,lBlock[0],'Tw')
    ax2.set_xlabel(r"$x$ ($cm$)") ; ax2.set_ylabel(ylabel)
    # ax2.set_xlim(xmin,xmax) ; ax2.set_ylim(cls.Twmin-0.6*np.abs(cls.Twmax),cls.Twmax+0.3*np.abs(cls.Twmax))
    ax2.xaxis.set_major_formatter(ScalarFormatter()) ; ax2.yaxis.set_major_formatter(ScalarFormatter())
    ax2.axhline(0, color='black',linestyle='--')
    ax2.plot(x,Bl,color="blue",label=r"$\tau_w$",marker='o', markevery=int(float(npos)/10.),alpha=1)
    ax2.legend(loc=1,bbox_to_anchor=(1.,1.37),ncol=1,borderaxespad=0.)

    # PRESSURE
    ################
    ylabel, Bl = plotBlock(cls,lBlock[0],'P')
    ax2b.set_ylabel(ylabel)
    # ax2b.set_xlim(xmin,xmax) ; ax2b.set_ylim(cls.Pmin-0.3*np.abs(cls.Pmax),cls.Pmax+0.3*np.abs(cls.Pmax))
    ax2b.yaxis.set_major_formatter(ScalarFormatter())
    ax2b.plot(x,Bl,color = "green",label=r"$P$",marker='^', markevery=int(float(npos)/10.),alpha=0.7)
    ax2b.legend(loc=1,bbox_to_anchor=(0.8,1.37),ncol=1,borderaxespad=0.)

    # align_yaxis(ax2, 0., ax2b, 0.)

    # LEGEND
    ################
    time_text = ax0.text(0.3, 1.1,r'$t=$ %.3f ($s$)' % float(tTime), transform=ax0.transAxes) ;
    fig_title = cls.pathStore+"Arrow_Tw_P_Q_U_Artery_"+str(art)+ "_Time_"+str(tTime)+"_"+str(cls.logo)+".pdf"
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig

#PLOT SPECIFIC ARTERY AT SPECIFIC LOCATION -- Case by Case plot :
def plot_Streamlines_UUr(cls,numArt,tTime,nf) :

    matplotlib.rc('xtick', direction='out') ; matplotlib.rc('ytick', direction='out')
    nfig=nf ; fig = plt.figure(nfig) ; nfig += 1
    # Create a gridspec
    col1 = gridspec.GridSpec(nrows=1,ncols=1,left=0.1, right=0.85, bottom=0.1, top=0.9, wspace=0.1, hspace=0.5, width_ratios=[1],height_ratios=[1])
    # Define first line: Ux
    ax0 = plt.Subplot(fig, col1[0]) ; fig.add_subplot(ax0)
    # Remove tick_params
    ax0.tick_params(top='off',right='off');
    # Reduce number of Ticks
    ax0.locator_params(axis='x',tight=True, nbins=10) ; ax0.locator_params(axis='y',tight=True, nbins=6)

    art = int(numArt) ; nL = int(cls.nLayer[art])

    # Get data block
    ################
    lBlock = cls.readBlock_t(nArt=numArt,lTime=[float(tTime)])
    npos = len(lBlock[0][:,0])
    if (len(lBlock) != 1) :
        print("plot_UUr_Arrow_Artery: Error in the size of lBlock")
        sys.exit()
    t = lBlock[0][0,0]
    x = lBlock[0][:,1]
    y = cls.rArt(art)

    R0 = 1./np.sqrt(np.pi) * np.sqrt(lBlock[0][:,3])
    R = 1./np.sqrt(np.pi) * np.sqrt(lBlock[0][:,4])


    lBlock_Profile = cls.readBlock_Profil_t(nArt=numArt,lTime=[float(tTime)])
    lSubBlock = cls.readSubBlock_Profile(nArt=art,Block=lBlock_Profile[0])
    if (len(lBlock_Profile) != 1) :
        print("plot_UUr_Arrow_Artery: Error in the size of lBlock_Profile")
        sys.exit()
    if (len(lSubBlock) != npos) :
        print("plot_UUr_Arrow_Artery: Error in the size of lSubBlock")
        sys.exit()
    UPmax = np.amax(lBlock_Profile[0][:,3])
    UPmin = np.amin(lBlock_Profile[0][:,3])

    # Definie U and V
    ################
    U = np.zeros((2*nL,npos)) ; V = np.zeros((2*nL,npos))
    for ip in range(npos) :
        SubBlock  = lSubBlock[ip]
        U[:,ip] = SubBlock[:,3]
        V[:,ip] = SubBlock[:,4]
    # Define the scaling of the colors: L2 norm of the Velocity
    C = np.sqrt(np.power(U, 2) + np.power(V, 2))

    Unorm = U / C
    Vnorm = V / C
    Cnorm = np.sqrt(np.power(Unorm, 2) + np.power(Vnorm, 2))

    # Define walls
    ################
    Rmax = np.amax(R) * 1.2
    hwall = Rmax*0.1
    wall = R + hwall

    # Define the interval beteewn the arrow
    ################
    numX = 100 ; numY = 100
    if (npos < numX) :
        interX = 1
    else :
        interX = int( float(npos)/float(numX))
    if (2*nL< numY) :
        interY = 1
    else :
        interY= int( float(2*nL)/float(numY))
    # Scale the length of the arrows:
    sc = 1. * float(npos)/float(interX)

    # Create the grid:
    ################
    Xo,Yo = np.meshgrid(x,y)
    # Modify Y
    Y = Yo
    for i in range(npos) :
        Y[:,i] = Yo[:,i] * R[i]

    # PLOT
    ################
    label_Art = "t=" + str(t)
    quiv = ax0.quiver(Xo[::interY,::interX],Y[::interY,::interX],Unorm[::interY,::interX],Vnorm[::interY,::interX],C[::interY,::interX],label=label_Art,cmap='jet',units='width',scale=sc,scale_units='width',clim=(UPmin,UPmax),animated=True,headwidth=1.,headlength=1.)

    # COLORBAR
    ################
    cbaxes = fig.add_axes([0.86, 0.1, 0.01, 0.8])
    cb = plt.colorbar(quiv, cax = cbaxes)
    cb.set_label(r'$\sqrt{U^2+V^2}$ ($\frac{cm}{s}$)')

    # Plot initial geometry
    ################
    ax0.plot(x,R0,color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
    ax0.plot(x,-R0,color = 'black', alpha = 0.75, linestyle="--", linewidth=1)
    # Plot arterial Wall (R0+h)
    ################
    ax0.plot(x,wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
    ax0.plot(x,-wall,color = 'black', alpha = 0.75, linestyle="-", linewidth=2)
    # Plot instateneous arterial Wall
    ################
    ax0.plot(x, R,color='red',alpha=1,linestyle="-",linewidth=1)
    ax0.plot(x,-R,color='red',alpha=1,linestyle="-",linewidth=1)
    # Fill the Wall
    ################
    ax0.fill_between(x,  R, wall, facecolor='grey', alpha=0.3)
    ax0.fill_between(x, -R, -wall, facecolor='grey', alpha=0.3)

    # Labels
    ################
    ax0.set_xlabel(r"$x$ ($cm$)") ; ax0.set_ylabel(r"$r$ ($cm$)")
    ax0.xaxis.set_major_formatter(ScalarFormatter()) ; ax0.yaxis.set_major_formatter(ScalarFormatter())

    # LEGEND
    ###############
    ax0.legend(loc=1,bbox_to_anchor=(1.,1.),ncol=1,borderaxespad=0.)
    fig_title = cls.pathStore+"Streamlines_UUr_Artery_"+str(art)+ "_Time_"+str(tTime)+"_"+str(cls.logo)+".pdf"
    fig.savefig(fig_title, format='pdf', bbox_inches='tight')

    return nfig
