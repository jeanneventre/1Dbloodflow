#!/usr/local/bin/python3
import os
import sys
import math as mt
import numpy as np
from scipy.interpolate import interp1d

from help_Interpolate import *

####################################
class dataS() :

    # Get Block for specific times
    def readBlock(self,nArt) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "Artery_" + str(nArt) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Artery_" + str(nArt) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        lBlock = [] ; #List of block for different times
        block = [];

        #Find number of record nodes
        recPoints = self.recNum(nArt)

        #Loop on lines
        emptyline = 0;
        iT = 0 ;
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if line.isspace() :
                    emptyline += 1;
                    # If first empty line -> Store block
                    if (emptyline == 1) :
                        # Convert block to numpy array
                        block = np.array(block)
                        # Verify integrity of block
                        if (len(block[:,0])!=recPoints) :
                            print("Error in the size of the block",len(block[:,0]),recPoints)
                            sys.exit();
                        if (block[0,0] != block[recPoints-1,0] ) :
                            print("Error in recorded times of the block", block[0,0], block[recPoints-1,0])
                            sys.exit();


                        lBlock.append(block) ;

                    # If second empty line -> New block
                    elif (emptyline == 2) :
                        block = [] ;
                    else :
                        print("Too many empty lines:",emptyline)
                        sys.exit();
                # If non empty line
                ###################
                else :
                    emptyline = 0 ;
                    block.append(map(float,line.split(",")))

        return lBlock

    # Get Block for specific times
    def readBlock_t(self,nArt,lTime) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "Artery_" + str(nArt) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Artery_" + str(nArt) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        lBlock = [] ; #List of block for different times
        blockm1 = []; block = [];

        #Find number of record nodes
        recPoints = self.recNum(nArt)

        #Loop on lines
        emptyline = 0;
        iT = 0 ;
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if line.isspace() :
                    emptyline += 1;
                    # If first empty line -> Store block
                    if (emptyline == 1) :
                        # Convert block to numpy array
                        block = np.array(block)
                        # Verify integrity of block
                        if (len(block[:,0])!=recPoints) :
                            print("Error in the size of the block",len(block[:,0]),recPoints)
                            sys.exit();
                        if (block[0,0] != block[recPoints-1,0] ) :
                            print("Error in recorded times of the block", block[0,0], block[recPoints-1,0])
                            sys.exit();

                        ############
                        # Check time
                        ############
                        t = block[0,0] ;
                        if (t>lTime[iT]) :
                            if (len(blockm1)==0) :
                                lBlock.append(block)
                            else :
                                lBlock.append( interpBlock_t(blockm1,block,lTime[iT]) )
                            iT += 1;

                        if (iT == len(lTime)) :
                            return lBlock ;
                        #############
                        #############

                        blockm1 = block ;
                    # If second empty line -> New block
                    elif (emptyline == 2) :
                        block = [] ;
                    else :
                        print("Too many empty lines:",emptyline)
                        sys.exit();
                # If non empty line
                ###################
                else :
                    emptyline = 0 ;
                    block.append(map(float,line.split(",")))

    # Get Block for specific times
    def readBlock_x(self,nArt,lX) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "Artery_" + str(nArt) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Artery_" + str(nArt) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        lBlock = [] ; #List of block for different x
        block = [];

        #Define sublist
        nX = len(lX)
        for iX in range(nX) :
            lBlock.append([])

        #Find number of record nodes
        recPoints = self.recNum(nArt)

        #Loop on lines
        emptyline = 0;
        iT = 0 ;
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if line.isspace() :
                    emptyline += 1;
                    # If first empty line -> Store block
                    if (emptyline == 1) :
                        # Convert block to numpy array
                        block = np.array(block)
                        # Verify integrity of block
                        if (len(block[:,0])!=recPoints) :
                            print("Error in the size of the block",len(block[:,0]),recPoints)
                            sys.exit();
                        if (block[0,0] != block[recPoints-1,0] ) :
                            print("Error in recorded times of the block", block[0,0], block[recPoints-1,0])
                            sys.exit();

                        ############
                        # Find X
                        ############
                        pX = 0
                        for iX in range(recPoints) :
                            x = block[iX,1]
                            if (pX < nX and x>lX[pX]) :
                                if (iX == 0) :
                                    lBlock[pX].append(block[iX,:])
                                else :
                                    lBlock[pX].append( interpLine_x(block[iX-1,:],block[iX,:],lX[pX]))
                                pX += 1 ;

                        if( pX != nX) :
                            print("Not all points were found")
                            sys.exit()

                    # If second empty line -> New block
                    elif (emptyline == 2) :
                        block = [] ;
                    else :
                        print("Too many empty lines:",emptyline)
                        sys.exit();
                # If non empty line
                ###################
                else :
                    emptyline = 0 ;
                    block.append(map(float,line.split(",")))

        for iX in range(nX) :
            lBlock[iX] = np.array(lBlock[iX])

        return lBlock

    # Get Block_Profil for specific times
    def readBlock_Profil_t(self,nArt,lTime) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "_Profil_Artery_" + str(nArt) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Profil_Artery_" + str(nArt) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        lBlock = [] ; #List of block for different times
        blockm1 = []; block = [];

        #Find number of record nodes
        recPoints = int(self.recNumProfile(nArt))
        nL = int(self.nLayer[nArt])

        #Loop on lines
        emptyline = 0;
        iT = 0 ;
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if line.isspace() :
                    emptyline += 1;
                    # If first empty line -> Store block
                    if (emptyline == 1) :
                        # Convert block to numpy array
                        block = np.array(block)
                        # Verify integrity of block
                        if (len(block[:,0])!=2*nL*recPoints) :
                            print("Error in the size of the block",len(block[:,0]),2*nL*recPoints)
                            sys.exit();
                        if (block[0,0] != block[2*nL*recPoints-1,0] ) :
                            print("Error in recorded times of the block", block[0,0], block[2*nL*recPoints-1,0])
                            sys.exit();

                        ############
                        # Check time
                        ############
                        t = block[0,0] ;
                        if (t>=lTime[iT]) :
                            # First time
                            if (len(blockm1)==0) :
                                lBlock.append(block)
                            elif (blockm1[0,0] <= lTime[iT]) :
                                lBlock.append( interpBlock_t(blockm1,block,lTime[iT]) )
                            else :
                                print("Recorder points are coarser than desired points")
                                sys.exit()

                            iT += 1;

                        if (iT == len(lTime)) :
                            return lBlock ;
                        #############
                        #############

                        blockm1 = block ;
                    # If second empty line -> New block
                    elif (emptyline == 2) :
                        block = [] ;
                    else :
                        print("Too many empty lines:",emptyline)
                        sys.exit();
                # If non empty line
                ###################
                else :
                    emptyline = 0 ;
                    block.append(map(float,line.split(",")))

    # Get Block_Profil for specific times
    def readBlock_Profil_t_Animation(self,nArt,liTime,lTime) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "_Profil_Artery_" + str(nArt) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Profil_Artery_" + str(nArt) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        lBlock = []
        block = [];

        #Find number of record nodes
        recPoints = int(self.recNumProfile(nArt))
        nL = int(self.nLayer[nArt])

        #Loop on lines
        emptyline = 0;
        iT = 0 ;
        nTime = len(liTime)
        iTime = 0 ;
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if line.isspace() :
                    emptyline += 1;
                    # If first empty line -> Store block
                    if (emptyline == 1) :

                        # If time indice correspond
                        if (iTime < nTime) :
                            if (iT == liTime[iTime]) :
                                # Convert block to numpy array
                                block = np.array(block)
                                # Verify integrity of block
                                if (len(block[:,0])!=2*nL*recPoints) :
                                    print("Error in the size of the block",len(block[:,0]),2*nL*recPoints)
                                    sys.exit();
                                if (block[0,0] != block[2*nL*recPoints-1,0] ) :
                                    print("Error in recorded times of the block", block[0,0], block[2*nL*recPoints-1,0])
                                    sys.exit();
                                # Check time
                                t = block[0,0] ;
                                if ((t-lTime[iTime]) > self.dt) :
                                    print("Error in recorded times of the block", t,lTime[iTime],cls.dt)
                                else :
                                     lBlock.append(block)
                                iTime += 1 ;
                        else :
                            return lBlock

                        iT += 1;
                    # If second empty line -> New block
                    elif (emptyline == 2) :
                        block = [] ;
                    else :
                        print("Too many empty lines:",emptyline)
                        sys.exit();
                # If non empty line
                ###################
                else :
                    emptyline = 0 ;
                    block.append(map(float,line.split(",")))

    # Get Block_Profil for different x positions at one radius for all times
    def readBlock_Profil_x_r(self,nArt,xPos,lR) :
        #Open file of Artery
        if (self.logo == "") :
            fileName = self.dataPath + "_Profil_Artery_" + str(nArt) + ".csv" ;
        else :
            fileName = self.dataPath + self.logo + "_Profil_Artery_" + str(nArt) + ".csv" ;
        fh = open(fileName,'r') ;

        #Define block
        lBlock  = [] ; #List of block for different times
        lLine   = []
        block   = [];

        #Write x & r posisions
        lLine.append(xPos)
        for iR in range(len(lR)) :
            lLine.append(lR[iR]);
            lLine.append("")
            lLine.append("")
        lBlock.append(lLine)

        #Find number of record nodes
        recPoints = int(self.recNumProfile(nArt))
        nL = int(self.nLayer[nArt])

        #Loop on lines
        emptyline = 0;
        iT = 0 ;
        for line in fh:
            if not line.startswith('#') :
                # If empty line
                ###############
                if line.isspace() :
                    emptyline += 1;
                    # If first empty line -> Store block
                    if (emptyline == 1) :
                        # Convert block to numpy array
                        block = np.array(block)
                        # Verify integrity of block
                        if (len(block[:,0])!=2*nL*recPoints) :
                            print("Error in the size of the block",len(block[:,0]),2*nL*recPoints)
                            sys.exit();
                        if (block[0,0] != block[2*nL*recPoints-1,0] ) :
                            print("Error in recorded times of the block", block[0,0], block[2*nL*recPoints-1,0])
                            sys.exit();

                        ############
                        # Find xPos & rPos
                        ############
                        xblock = self.readSubBlock_Profile_x(nArt=nArt,xPos=xPos,Block=block)
                        if (len(xblock) != 2 * nL) :
                            print("Error in size of xblock",len(xblock), 2 * nL)
                            sys.exit()

                        lLine = []
                        # Write time
                        lLine.append(xblock[0,0])
                        # Interpolate profile
                        UxKrogh = interp1d( xblock[:,2], xblock[:,3], kind='cubic' )
                        UrKrogh = interp1d( xblock[:,2], xblock[:,4], kind='cubic' )
                        for iR in range(len(lR)) :
                            lLine.append( float(UxKrogh(lR[iR])) )
                            lLine.append( float(UrKrogh(lR[iR])) )
                            lLine.append( np.sqrt( float(UxKrogh(lR[iR]))**2. + float(UrKrogh(lR[iR]))**2. ) )

                        if (len(lLine) != 3*len(lR) + 1) :
                            print("Error in length of lLine",len(lLine),len(lR)+1)
                            sys.exit()

                        lBlock.append(lLine)
                        #############
                        #############

                    # If second empty line -> New block
                    elif (emptyline == 2) :
                        block = [] ;
                    else :
                        print("Too many empty lines:",emptyline)
                        sys.exit();
                # If non empty line
                ###################
                else :
                    emptyline = 0 ;
                    block.append(map(float,line.split(",")))

        return lBlock

    # Read Block_Profil for specific x position
    def readSubBlock_Profile_x(self,nArt,xPos,Block) :

        #Define output
        outBlock = [] ;
        #Define subblock
        subBlock = [] ; subBlockm1 = []

        #Find number of record nodes
        recPoints = int(self.recNumProfile(nArt))
        nL = int(self.nLayer[nArt])

        if (len(Block[:,0]) != 2 * nL * recPoints) :
            print("Error in size of block", len(Block[:,0]),  2 * nL * recPoints)
            sys.exit()
        if (Block[0,0] != Block[2 * nL * recPoints-1,0]) :
            print("Error in time of block", Block[0,0] , Block[2 * nL * recPoints -1,0])
            sys.exit()

        #Loop on lines
        emptyline = 0;
        iX = 0 ;
        for iP in range(recPoints) :
            iS = iP * 2 * nL ; iE = (iP + 1) * 2 * nL ;
            subBlock = Block[iS:iE,:]
            if (len(subBlock) != 2 * nL) :
                print("Error in size of sublock",len(subBlock), 2 * nL)
                sys.exit()
            if (subBlock[0,1] != subBlock[2 * nL-1,1]) :
                print("Error in x of sublock", subBlock[0,1], subBlock[2 * nL-1,1])
                sys.exit()
            if (subBlock[0,2] != -subBlock[2 * nL-1,2]) :
                print("Error in y of sublock", subBlock[0,2], subBlock[2 * nL-1,2])
                sys.exit()

            x = subBlock[0,1]

            if (x>=xPos) :
                if (len(subBlockm1)==0) :
                    return subBlock
                else :
                    return interpBlock_x(subBlockm1,subBlock,xPos)

            subBlockm1 = subBlock

    # Read Block_Profil for all x positions
    def readSubBlock_Profile(self,nArt,Block) :

        #Define subblock
        lBlock = [] ;
        subBlock = [] ;

        #Find number of record nodes
        recPoints = int(self.recNumProfile(nArt))
        nL = int(self.nLayer[nArt])

        if (len(Block[:,0]) != 2 * nL * recPoints) :
            print("Error in size of block", len(Block[:,0]),  2 * nL * recPoints)
            sys.exit()
        if (Block[0,0] != Block[2 * nL * recPoints-1,0]) :
            print("Error in time of block", Block[0,0] , Block[2 * nL * recPoints -1,0])
            sys.exit()

        #Loop on lines
        emptyline = 0;
        iX = 0 ;
        for iP in range(recPoints) :
            iS = iP * 2 * nL ; iE = (iP + 1) * 2 * nL ;
            subBlock = Block[iS:iE,:]
            if (len(subBlock) != 2 * nL) :
                print("Error in size of sublock",len(subBlock), 2 * nL)
                sys.exit()
            if (subBlock[0,1] != subBlock[2 * nL-1,1]) :
                print("Error in x of sublock", subBlock[0,1], subBlock[2 * nL-1,1])
                sys.exit()
            if (subBlock[0,2] != -subBlock[2 * nL-1,2]) :
                print("Error in y of sublock", subBlock[0,2], subBlock[2 * nL-1,2])
                sys.exit()

            lBlock.append(subBlock)

        return lBlock

    def recNum(self,numArt) :
        iNum = 0
        for i in range(len(self.output[:,0])) :
            if (self.output[i,0] == int(numArt)) :
                iNum += 1 ;
        return iNum

    def recNumProfile(self,numArt) :
        iNum = 0
        for i in range(len(self.outputProfile[:,0])) :
            if (self.outputProfile[i,0] == int(numArt)) :
                iNum += 1 ;
        return iNum

    def rArt(self,numArt) :
        art = int(numArt)
        nL = int(self.nLayer[art]);
        r = np.zeros(2*nL)

        nLprop = self.nLprop[art]

        if (len(nLprop) != nL):
            print("In L_art, dx and N+1 don t have the same length")
            sys.exit()


        r[0] = -1. + 0.5 * nLprop[nL-1]
        for i in range(1,nL) :
            r[i] = r[i-1] + 0.5 * (nLprop[nL-i] + nLprop[nL-i-1])
        r[nL] = r[nL-1] + 0.5 * (nLprop[0] + nLprop[0])
        for i in range(nL+1,2*nL) :
            r[i] = r[i-1] + 0.5 * (nLprop[i-nL-1] + nLprop[i-nL])

        if( r[nL-1]>0 or r[nL]<0) :
            print("In r_art: error in the definition of r")
            sys.exit()

        return r

    # Get Block for specific times
    def getData(self,vect,fileName) :
        cV = len(vect[0,:])
        lV = len(vect[:,0])
        #Open file of Artery
        fh = open(fileName,'r') ;

        iV = 0
        nL = 0
        for line in fh:
            if not line.startswith('#') and not line.isspace() :
                data = map(float,line.split(","))
                lenData = len(data);
                # Check length of data:
                if (lenData-1 > cV) : #Remove first column that is the number of arteries
                    print("Error in the number of columns of vect. --> Exit",lenData,cV)
                    print(data)
                    sys.exit();
                if (nL > lV) :
                    print("Error in the number of lines of vect. --> Exit",nL,lV)
                    print(data)
                    sys.exit();

                for iD in range(1,lenData) :
                    vect[iV,iD-1] = data[iD] ;
                iV += 1 ;
                nL += 1 ;

        return vect

    def __init__(self,fPath,fpathStore,logo) :

        #Logo :
        self.logo = logo
        # Pa to mmHg :
        self.PaTommHg = 0.00750061683
        self.gcms2ToPa=0.1
        # Peak Systolic velocity shape factor (Poiseuill Max Value) :
        self.factPSV = 3./2.
        # CAPILLARY PRESSURE :
        self.Pcap = 0.


        #########################
        # PATH TO FILE
        #########################
        self.path = fPath
        self.pathStore = fpathStore
        self.dataPath = self.path+'data/'

        #########################
        # DATA
        #########################
        self.output = np.genfromtxt(self.path + "parameters_"+self.logo+"/output.csv", delimiter=',')
        self.outputProfile = np.genfromtxt(self.path + "parameters_"+self.logo+"/outputProfile.csv", delimiter=',')
        self.param = np.genfromtxt(self.path + "parameters_"+self.logo+"/Parameters/systemic_network.csv", delimiter=',')

        self.DAG = np.genfromtxt(self.path + "parameters_"+self.logo+"/DAG.csv", delimiter=',') ;
        if (len(self.DAG)>2) :
            self.DAG = self.DAG[self.DAG[:,0].argsort()]

        #########################
        # NUMBER OF ARTERIES
        #########################
        if (len(self.DAG)==2) :
            self.nArt = 1 ;
        else :
            self.nArt = len(self.DAG)
            if (self.nArt == 1) :
                print("bfs_libData: Error in definition of nArt")
                sys.exit()

        ###################
        # BLOOD RHEOLOGIE :
        ###################
        if (self.nArt == 1) :
            self.rho    = self.param[4] # (g/cm^3)
            self.mu     = self.param[5] # (g/cm/s^2)
            self.nu     = self.mu / self.rho # (cm^2/s)
        else :
            self.rho    = self.param[0,4] # (g/cm^3)
            self.mu     = self.param[0,5] # (g/cm/s^2)
            self.nu     = self.mu / self.rho # (cm^2/s)

        ###################
        #LENGTH OF EACH ARTERY:
        ###################
        if (self.nArt == 1) :
            self.N = [self.param[1]]
            self.nLayer = [self.param[2]]
            self.Lart = [self.param[3]] # (cm)
        else :
            self.N = self.param[:,1]
            self.nLayer = self.param[:,2]
            self.Lart = self.param[:,3] # (cm)

        ###################
        #NUMERICS:
        ###################
        if (self.nArt == 1) :
            self.order = int(self.param[7])
        else :
            self.order = int(self.param[0,7])

        with open(self.path + "parameters_"+self.logo+"/Parameters/systemic_network.csv", 'r') as f:
            first_line = f.readline()
            line = first_line.split(',')
        self.HR = str(line[8]) ; self.HR = self.HR[:-1]
        self.solver = str(line[9]) ; self.solver = self.solver[:-1]

        ###################
        #ARTERY PROPERTIES
        ###################
        Nmax    = int(max(self.N))
        nLmax   = int(max(self.nLayer))

        self.dx = np.zeros(shape=(self.nArt,Nmax))
        self.A0 = np.zeros(shape=(self.nArt,Nmax))
        self.K = np.zeros(shape=(self.nArt,Nmax))
        self.Cv = np.zeros(shape=(self.nArt,Nmax))

        self.getData(self.dx,self.path + "parameters_"+self.logo+"/Parameters/dx.csv")
        self.getData(self.A0,self.path + "parameters_"+self.logo+"/Parameters/A0.csv")
        self.getData(self.K,self.path + "parameters_"+self.logo+"/Parameters/K.csv")
        self.getData(self.Cv,self.path + "parameters_"+self.logo+"/Parameters/Cv.csv")

        self.nLprop = np.zeros(shape=(self.nArt,nLmax))
        self.getData(self.nLprop,self.path + "parameters_"+self.logo+"/Parameters/layer.csv")


        ###################
        # BOUNDARY CONDITIONS :
        ###################

        ###################
        # TIME PARAMETERS :
        ###################
        self.time = np.genfromtxt(self.path + "parameters_"+self.logo+"/time.csv", delimiter=',')
        self.dt = self.time[2]
        self.trecStart = self.time[0]
        self.trecEnd = self.time[1]

        self.deltaRec = self.time[4]
        self.dtrec = self.dt*self.deltaRec
