#!/usr/local/bin/python3
import sys
import numpy as np
import math as mt

def plotBlock(cls,Block,pType) :
    it = 0 ; ix = 1 ; iK = 2 ; iA0 = 3; iA = 4; iQ = 5 ; iP = 6;
    igradxP=7 ; iU0=8 ; iTw=9 ; ialpha=10; iphi=11 ;
    npos = len(Block[:,0])

    # Time
    ##########
    if (pType == 't') :
        Bl = Block[:,it]
        ylabel = r'$t$ $\left[s\right]$'
    # Space
    ##########
    if (pType == 'x') :
        Bl = Block[:,ix]
        ylabel = r'$x$ $\left[cm\right]$'
    # Section at rest
    ##########
    if (pType == 'A0') :
        Bl = Block[:,iA0]
        ylabel = r'$A_0$ $\left[cm^2\right]$'
    # Radius at rest
    ##########
    if (pType == 'R0') :
        Bl = 1./np.sqrt(np.pi) * np.sqrt(Block[:,iA0])
        ylabel = r'$R_0$ $\left[cm\right]$'
    # Rigidity
    ##########
    if (pType == 'K') :
        Bl = Block[:,iK]
        ylabel = r'$K$ $\left[\frac{g}{cm^2.s^2}\right]$'
    # Flow
    ##########
    if (pType == 'Q') :
        Bl = Block[:,iQ]
        ylabel = r'$Q$ $\left[\frac{cm^3}{s}\right]$'
    # Section
    ##########
    if (pType == 'A') :
        Bl = Block[:,iA]
        ylabel = r'$A$ $\left[cm^2\right]$'
    # Radius
    ##########
    if (pType == 'R') :
        Bl = 1./np.sqrt(np.pi) * np.sqrt(Block[:,iA])
        ylabel = r'$R$ $\left[cm\right]$'
    # Pressure
    ##########
    if (pType == 'P') :
        Bl = Block[:,iP]
        ylabel = r'$P$ $\left[\frac{g}{cm.s^2}\right]$'
    # gradxP
    ##########
    if (pType == 'gradxP') :
        Bl = Block[:,igradxP];
        ylabel = r'$\frac{\partial P}{\partial x}$ $\left[\frac{g}{cm^2.s^2}\right]$'
    # Speed
    ##########
    if (pType == 'U') :
        Bl = np.ones(npos);
        for i in range(npos) :
            #Check if Q=0
            if (Block[i,iQ]==0.) :
                Bl[i] = 0.;
            #Check if A=0
            elif (Block[i,iA]==0.) :
                Bl[i] = 0.;
            else :
                Bl[i] = Block[i,iQ] / Block[i,iA];
        ylabel = r'$U$ $\left[\frac{cm}{s}\right]$'
    # R-R0
    ##########
    if (pType == 'RmR0') :
        Bl = 1. / np.sqrt(np.pi) * (np.sqrt(Block[:,iA]) - np.sqrt(Block[:,iA0]))
        ylabel = r'$R-R_0$ $\left[cm\right]$'
    # E
    ##########
    if (pType == 'E') :
        U = np.ones(npos);
        for i in range(npos) :
            #Check if Q=0
            if (Block[i,iQ]==0.) :
                U[i] = 0.;
            #Check if A=0
            elif (Block[i,iA]==0.) :
                U[i] = 0.;
            else :
                U[i] = Block[i,iQ] / Block[i,iA];
        Bl = 0.5 * cls.rho * U * U + Block[:,iP] ;
        ylabel = r'$E$ $\left[\frac{g}{cm.s^2}\right]$'
    # U0
    ##########
    if (pType == 'U0') :
        Bl = Block[:,iU0];
        ylabel = r'$U_0$ $\left[\frac{cm}{s}\right]$'
    # Tw
    ##########
    if (pType == 'Tw') :
        Bl = Block[:,iTw];
        ylabel = r'$\tau_w$ $\left[\frac{g}{cm.s^2}\right]$'
    # phi
    ##########
    if (pType == 'alpha') :
        Bl = Block[:,ialpha];
        ylabel = r'$\alpha$'
    # phi
    ##########
    if (pType == 'phi') :
        Bl = Block[:,iphi];
        ylabel = r'$\phi$'
    # Sh
    ##########
    if (pType == 'Sh') :
        Sh = np.ones(npos);
        for i in range(npos) :
            #Check if U=0
            if (Block[i,iQ]==0.) :
                Sh[i] = 0.;
            #Check if A=0
            elif (Block[i,iA]==0.) :
                Sh[i] = 0.;
            else :
                c = np.sqrt( np.abs( 0.5 * Block[i,iK] / cls.rho *  np.sqrt(Block[i,iA]) ) )
                Sh[i] = np.abs(Block[i,iQ] / Block[i,iA]) / c ;
        Bl = Sh ;
        ylabel = r'$S_h$'

    return ylabel,Bl

def get_alpha(cls,Block,Block_Profil) :

    iA = 4; iQ = 5 ;

    # Alpha
    ##########
    npos = len(Block[:,0])
    SubBlock = cls.readSubBlock_Profile(nArt=0,Block=Block_Profil)
    if (len(SubBlock) != npos) :
        print("get_alpha: Error in number of points of record points")
        sys.exit()

    lay = cls.nLprop[0]

    A = Block[:,iA] ; Q = Block[:,iQ] ;
    R = 1./np.sqrt(np.pi) * np.sqrt(A)
    alpha = np.ones(npos)

    for ip in range(npos) :

        if (Q[ip]==0.) :
            alpha[ip] = 0.;
        #Check if A=0
        elif (A[ip]==0.) :
            alpha[ip] = 0.;
        else :
            Sub = SubBlock[ip]
            nL = int( len(Sub[:,0]) / 2. ) ;
            if (len(lay) != nL) :
                print("get_alpha: Error in layer proportion")
                print(len(lay),nL)
                sys.exit()

            inte = 0. ;
            for iL in range(nL,2*nL) :
                dR = lay[int(abs(nL-iL))] * R[ip]
                inte += dR * Sub[iL,2] * Sub[iL,3] **2.
            alpha[ip] = 2. * np.pi * inte * A[ip] / (Q[ip]**2.)

    ylabel = r'$\alpha$'
    return ylabel,alpha
