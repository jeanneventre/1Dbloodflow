#!/usr/local/bin/python3
import os
import sys
from numpy import *
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

from help_Sum import *

EPSILON = 1.e-15

class artery(object):
    def __init__(self, ID):
        self.ID=ID
        self.daughterArts=[]
        self.parentArts=[]
        self.headPt=[]
        self.tailPt=[]

class point() :
    def __init__(self,ID):
        self.ID=ID
        self.bc=""

class timeSetup(): pass

class network():
    def __init__(self,ARTS,tS):
        self.arts=ARTS
        self.tS=tS

    #####################################
    #####################################
    def writeParam(self,folder="."):

        print("paramters printed in folder: \"%s/\"\n"%folder)

        fileName = folder+"/DAG.csv"
        with open(fileName,'w') as fh:
            for art in self.arts:
                fh.write("%d,%d"%(art.headPt[0].ID,art.tailPt[0].ID) + "\n")

        fileName = folder+"/inout.csv"
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#Artery","BC Type"))
            for it in range (len(self.tS.tt)) :
                fh.write(",%20.20f"%(self.tS.tt[it]))
            fh.write("\n")

            for art in self.arts:
                if (art.ID == 0) :
                    for ip in range(len(art.headPt)) :
                        fh.write("%d,%s"%(art.ID,art.headPt[ip].type))
                        for it in range (len(self.tS.tt)) :
                            fh.write(",%20.20f"%(art.headPt[ip].data[it]))
                        fh.write("\n")
                if (len(art.daughterArts)==0) :
                    for ip in range(len(art.tailPt)) :
                        fh.write("%d,%s"%(art.ID,art.tailPt[ip].type))
                        for it in range (len(self.tS.tt)) :
                            fh.write(",%20.20f"%(art.tailPt[ip].data[it]))
                        fh.write("\n")

        fileName = folder+"/Parameters/initA.csv"
        with open(fileName,'w') as fh:
            for art in self.arts:

                fh.write("%d"%(art.ID))
                for ix in range(len(art.initA)) :
                    fh.write(",%20.20f"%(art.initA[ix]))
                fh.write("\n")

        fileName = folder+"/Parameters/initQ.csv"
        with open(fileName,'w') as fh:
            for art in self.arts:

                fh.write("%d"%(art.ID))
                for ix in range(len(art.initQ)) :
                    fh.write(",%20.20f"%(art.initQ[ix]))
                fh.write("\n")

        fileName = folder +'/Parameters/systemic_network.csv'
        with open(fileName,'w') as fh:
            fh.write( "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s"%('#Artery', '<Nx>', '<Nl>', '<L> [cm]', '<rho> [g/cm^3]', '<mu> [g/cm/s]', '<Solver>', '<Order>', '<HR>', '<Profile>', '<Init_Profile>') + "\n" );
            for art in self.arts :
                fh.write("%d,%d,%d,%20.20f,%20.20f,%20.20f,%s,%d,%s,%s,%s"%(art.ID, art.N, art.nLayer, art.L, art.rho, art.mu, art.solver, art.solverOrder, art.HR, art.Profile, art.InitProfile ) + "\n" )

        fileName = folder + '/Parameters/dx.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<dx> [cm]") + "\n")
            for art in self.arts:
                if (art.N != len(art.dx)) :
                    print("In networkdef dx: Error in the number cells for artery ",art.ID)
                    sys.exit()
                if (abs(kahanSum(art.dx)-art.L) > EPSILON) :
                    print("In network_def dx: Error in the mesh size of artery ",art.ID)
                    print(kahanSum(art.dx),art.L,abs(kahanSum(art.dx)-art.L))
                fh.write("%d"%(art.ID))
                for i in range(len(art.dx)) :
                    fh.write(",%20.20f"%(art.dx[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/A0.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<A0> [cm^2]") + "\n")
            for art in self.arts:
                if (art.N != len(art.R)) :
                    print("In networkdef A0: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.R)) :
                    fh.write(",%20.20f"%(pi * art.R[i] * art.R[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/K.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<K> [g/cm^2/s^2]") + "\n")
            for art in self.arts:
                if (art.N != len(art.K)) :
                    print("In networkdef K: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.K)) :
                    fh.write(",%20.20f"%(art.K[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/Cv.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<Cv> [cm^2/s]") + "\n")
            for art in self.arts:
                if (art.N != len(art.Cv)) :
                    print("In networkdef Cv: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.Cv)) :
                    fh.write(",%20.20f"%(art.Cv[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/Knl.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<Knl> [g/cm^3/s^2]") + "\n")
            for art in self.arts:
                if (art.N != len(art.Knl)) :
                    print("In networkdef Knl: Error in the number cells for artery ",art.ID)
                    sys.exit()
                fh.write("%d"%(art.ID))
                for i in range(len(art.Knl)) :
                    fh.write(",%20.20f"%(art.Knl[i]))
                fh.write("\n")

        fileName = folder + '/Parameters/layer.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s"%("#<Artery>","<Proportion>") + "\n")
            for art in self.arts:
                if (art.nLayer != len(art.layProp)) :
                    print("In networkdef Layer: Error in the number of layers for artery ",art.ID)
                    sys.exit()
                if (abs(kahanSum(art.layProp) - 1.) > EPSILON) :
                    print("In network_def Layer: Error in the proportion of the layers of artery ",art.ID)
                fh.write("%d"%(art.ID))
                for i in range(len(art.layProp)) :
                    fh.write(",%20.15f"%(art.layProp[i]))
                fh.write("\n")

        inputFile=folder + '/output.csv'
        with open(inputFile, 'w') as fh:
            fh.write("%s,%s"%('#<numArtery>','<numMeshPoint>')+"\n")
            for art in self.arts:
                for meshPt in art.outPut:
                    fh.write("%d,%d"%( art.ID, meshPt) + "\n" )

        inputFile=folder + '/outputProfile.csv'
        with open(inputFile, 'w') as fh:
            fh.write("%s,%s"%('#<numArtery>','<numMeshPoint>')+"\n")
            for art in self.arts:
                for meshPt in art.outPutProfile:
                    fh.write("%d,%d"%( art.ID, meshPt) + "\n" )

        fileName = folder+'/time.csv'
        with open(fileName,'w') as fh:
            fh.write("%s,%s,%s,%s,%s,%s,%s,%s"%('#<tS> [s]', '<tE> [s]', '<t_step> [s]', '<Nt>', '<Nstore>', '<NstoreProfile>', '<CFL>', '<Order>') + "\n" )
            fh.write("%20.20f,%20.20f,%20.20f,%d,%d,%d,%20.20f,%d"%(self.tS.t_start, self.tS.t_end, self.tS.dt, self.tS.Nt,self.tS.storeStep,self.tS.storeStepProfile,self.tS.CFL,self.tS.timeOrder) + "\n" )
