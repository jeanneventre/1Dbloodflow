#include "arteryNum.h"

arteryNum::arteryNum(const vesselProperties& vP, const time_c& timenet) :
  artery(vP,timenet),
  // TriDiagMatrix
  Amatrix(vP.get_nx()), Bmatrix(vP.get_nx())
  {
    // Set interfaces
    faces.resize(cells.get_nx()+1) ;
    set_interface() ;
    // Set diffusion matrix for parabolic problem
    set_diffusionMatrix(timenet.get_dt()) ;
}

arteryNum::~arteryNum() {printf("\n%s\n\n", "arteryNum deleted." );}
//####################################################
// Boundary condition
//####################################################
void arteryNum::stepBC(const time_c& timenet) {
  // Inlet
  bcAQin  (timenet,bcIN) ;
  // Outlet
  bcAQout (timenet,bcOUT) ;
  // Hematocrite and structure
  bcHF    (timenet,bcVIS) ;
  // Passive scalars
  bcPS    (timenet,bcPAS) ;
}
void arteryNum::bcHF(const time_c& timenet, const vector<bc>& _bc) {
  // Set the the boundary values of structure & hematocrite

  if (_bc.size() > 0) {
    if (_bc.size() == 2 || _bc.size() == 4) {
      for (uint ibc = 0 ; ibc < _bc.size() ; ibc++) {
        // Inlet structure & hematocrite
        if      (_bc[ibc].get_type()=="inH")  { inlet.set_H   ( 0, _bc[ibc].get_data(timenet.get_n())) ;}
        else if (_bc[ibc].get_type()=="inF")  { inlet.set_F   ( 0, _bc[ibc].get_data(timenet.get_n())) ;}
        // Outlet structure & hematocrite
        else if (_bc[ibc].get_type()=="outH") { outlet.set_H  ( 0, _bc[ibc].get_data(timenet.get_n())) ;}
        else if (_bc[ibc].get_type()=="outF") { outlet.set_F  ( 0, _bc[ibc].get_data(timenet.get_n())) ;}
      }
    }
    else {Error("arteryNum:: HBC Unknown number of Hematocrite boundary conditions");}
  }
  else{
    // Provide defaults Neumann boundary conditions if not a junction
    if (bcIN.size() > 0 ) {
      inlet.set_H (0,cells.get_H()[0]) ;
      inlet.set_F (0,cells.get_F()[0]) ;
    }
    if (bcOUT.size() > 0 ) {
      outlet.set_H  (0,cells.get_H()[cells.get_nx()-1]) ;
      outlet.set_F  (0,cells.get_F()[cells.get_nx()-1]) ;
    }
  }

}
void arteryNum::bcPS(const time_c& timenet, const vector<bc>& _bc) {

  if (_bc.size() > 0) {
    if (_bc.size() == 2 || _bc.size() == 4) {
      for (uint ibc = 0 ; ibc < _bc.size() ; ibc++) {
        // Inlet concentration and oxygen
        if      (_bc[ibc].get_type()=="inC")  { inlet.set_C   ( 0, _bc[ibc].get_data(timenet.get_n())) ;}
        else if (_bc[ibc].get_type()=="inO")  { inlet.set_O   ( 0, _bc[ibc].get_data(timenet.get_n())) ;}
        // Outlet concentration and oxygen
        else if (_bc[ibc].get_type()=="outC") { outlet.set_C  ( 0, _bc[ibc].get_data(timenet.get_n())) ;}
        else if (_bc[ibc].get_type()=="outO") { outlet.set_O  ( 0, _bc[ibc].get_data(timenet.get_n())) ;}
      }
    }
    else {Error("arteryNum:: ptBC Unknown number of passive scalar boundary conditions");}
  }
  else{
    // Provide defaults Neumann boundary conditions if not a junction
    if (bcIN.size() > 0 ) {
      inlet.set_C (0,cells.get_C()[0]) ;
      inlet.set_O (0,cells.get_O()[0]) ;
    }
    if (bcOUT.size() > 0 ) {
      outlet.set_C  (0,cells.get_C()[cells.get_nx()-1]) ;
      outlet.set_O  (0,cells.get_O()[cells.get_nx()-1]) ;
    }
  }
}
void arteryNum::bcAQin(const time_c& timenet, const vector<bc>& _bc) {

  VECT AQ(2,ZERO) ;

  if (_bc.size() > 0) {
    // Subcritical Inlet
    if (_bc.size() == 1) {

      // One boundary condition
      VECT inData(1,ZERO) ;
      inData[0] = _bc[0].get_data(timenet.get_n());

      if      (_bc[0].get_type() == "inQ") {  AQ = inflow_Q(cells,inlet,inData) ;}
      else if (_bc[0].get_type() == "inU") {  AQ = inflow_U(cells,inlet,inData) ;}
      else if (_bc[0].get_type() == "inA") {  AQ = inflow_A(cells,inlet,inData) ;}
      else if (_bc[0].get_type() == "inP") {  AQ = inflow_P(cells,inlet,inData) ;}
      else if (_bc[0].get_type() == "inRt"){  AQ = inflow_Rt(cells,inlet,inData) ;}
      else {  Error("arteryNum:: inBC Unknown inlet boundary type") ;}
    }
    // Supercritical or Exact Inlet
    else if (_bc.size() == 2) {

      // Two boundary condition
      VECT inData(2,ZERO) ;

      // Supercritical
      if (_bc[0].get_type() == "inA" || _bc[0].get_type() == "inQ") {
        for (uint ibc = 0 ; ibc < _bc.size() ; ibc++) {
          if      (_bc[ibc].get_type() == "inA") { inData[0] = _bc[ibc].get_data(timenet.get_n()) ;}
          else if (_bc[ibc].get_type() == "inQ") { inData[1] = _bc[ibc].get_data(timenet.get_n()) ;}
        }
        AQ = inflow_AQ(cells,inlet,inData) ;
      }
      // Exact
      else if (_bc[0].get_type() == "inExA" || _bc[0].get_type() == "inExQ") {
        for (uint ibc = 0 ; ibc < _bc.size() ; ibc++) {
          if      (_bc[ibc].get_type() == "inExA") { inData[0] = _bc[ibc].get_data(timenet.get_n())  ;}
          else if (_bc[ibc].get_type() == "inExQ") { inData[1] = _bc[ibc].get_data(timenet.get_n())  ;}
        }
        AQ[0] = inData[0]; AQ[1] = inData[1] ;
      }
    }
    else { Error("arteryNum:: inBC Untreated number of inlet boundary conditions") ;}
    // Update
    inlet.set_A (0,AQ[0]) ;
    inlet.set_Q (0,AQ[1]) ;
  }
}
void arteryNum::bcAQout(const time_c& timenet, const vector<bc>& _bc) {

  VECT AQ(2,ZERO) ;

  if (_bc.size() > 0) {
    // Subcritical outlet
    if (_bc.size() == 1) {

      // One boundary condition
      VECT outData(1,ZERO) ;
      outData[0] = _bc[0].get_data(timenet.get_n()) ;
      // Two boundary condition
      VECT outDataR(2,ZERO) ;
      outDataR[0] = outlet.get_P() ;
      outDataR[1] = _bc[0].get_data(timenet.get_n()) ;

      if      (_bc[0].get_type() == "outQ") { AQ = outflow_Q(cells,outlet,outData) ;}
      else if (_bc[0].get_type() == "outU") { AQ = outflow_U(cells,outlet,outData) ;}
      else if (_bc[0].get_type() == "outA") { AQ = outflow_A(cells,outlet,outData) ;}
      else if (_bc[0].get_type() == "outP") { AQ = outflow_P(cells,outlet,outData) ;}
      else if (_bc[0].get_type() == "outRt"){ AQ = outflow_Rt(cells,outlet,outData);}
      else if (_bc[0].get_type() == "outR1"){ AQ = outflow_R(cells,outlet,outDataR);}
      else { Error("arteryNum:: outBC Unknown outlet boundary type") ;}
    }
    // Exact outlet
    else if (_bc.size() == 2) {

      // Two boundary condition
      VECT outData(2,ZERO) ;
      // Five boundary condition
      VECT outDataRC(4,ZERO) ;
      outDataRC[0] = outlet.get_P() ;
      outDataRC[3] = timenet.get_dt() ;

      // Exact
      if (_bc[0].get_type() == "outA" || _bc[0].get_type() == "outQ" ) {
        for (uint ibc = 0 ; ibc < _bc.size() ; ibc++) {
          if      (_bc[ibc].get_type() == "outA") { outData[0] = _bc[ibc].get_data(timenet.get_n()) ;}
          else if (_bc[ibc].get_type() == "outQ") { outData[1] = _bc[ibc].get_data(timenet.get_n()) ;}
        }
        AQ = outflow_AQ(cells,outlet,outData) ;
      }
      // Exact
      else if (_bc[0].get_type() == "outExA" || _bc[0].get_type() == "outExQ" ) {
        for (uint ibc = 0 ; ibc < _bc.size() ; ibc++) {
          if      (_bc[ibc].get_type() == "outExA") { outData[0] = _bc[ibc].get_data(timenet.get_n()) ;}
          else if (_bc[ibc].get_type() == "outExQ") { outData[1] = _bc[ibc].get_data(timenet.get_n()) ;}
        }
        AQ[0] = outData[0]; AQ[1] = outData[1] ;
      }
      // RC
      else if (_bc[0].get_type() == "outR1" || _bc[0].get_type() == "outC1") {
        for (uint ibc = 0 ; ibc < _bc.size() ; ibc++) {
          if      (_bc[ibc].get_type() == "outR1") { outDataRC[1] = _bc[ibc].get_data(timenet.get_n()) ;}
          else if (_bc[ibc].get_type() == "outC1") { outDataRC[2] = _bc[ibc].get_data(timenet.get_n()) ;}
        }
        AQ = outflow_RC(cells,outlet,outDataRC) ;
      }
    }
    // RCR
    else if (_bc.size() == 3) {

      // Seven boundary condition
      VECT outDataRCR(5,ZERO) ;

      outDataRCR[0] = outlet.get_P() ;
      outDataRCR[4] = timenet.get_dt() ;
      if (_bc[0].get_type() == "outR1" || _bc[0].get_type() == "outR2" || _bc[0].get_type() == "outC1") {
        for (uint ibc = 0 ; ibc < _bc.size() ; ibc++) {
          if      (_bc[ibc].get_type() == "outR1")  { outDataRCR[1] = _bc[ibc].get_data(timenet.get_n()) ;}
          else if (_bc[ibc].get_type() == "outR2")  { outDataRCR[2] = _bc[ibc].get_data(timenet.get_n()) ;}
          else if (_bc[ibc].get_type() == "outC1")  { outDataRCR[3] = _bc[ibc].get_data(timenet.get_n()) ;}
        }
        AQ = outflow_RCR(cells,outlet,outDataRCR) ;
      }
    }
    else { Error("arteryNum:: outBC Untreated number of outlet boundary conditions") ;}
    // Update
    outlet.set_A  (0,AQ[0]) ;
    outlet.set_Q  (0,AQ[1]) ;
  }
}
//####################################################
// Time Integration
//####################################################
void arteryNum::step(const time_c& timenet) {
  // Set values in second ghost cell
  set_ghostCell() ;
  // Store previous variables for residu
  cells.set_Am1  (cells.get_A());
  cells.set_Qm1  (cells.get_Q());
  // Advection & reaction suproblems
  if (timenet.get_nt() == 0) {
    SSPRK2(timenet) ;
  }
  else {
    AB2(timenet) ;
  }
  // Parabolic subproblem
  CrankNicolson() ;
  // Update no differential quantities
  NonDifferential() ;
  // Compute residu
  residu() ;
}
//####################################################
// Non differential quantities
//####################################################
void arteryNum::NonDifferential() {
  // Update variables who s evolution is not governed by differential equations
  // Update G & Tau
  for (int i=0; i<cells.get_nx(); i++) {
    cells.set_G(    i, shearRate(   cells.get_phi()[i],cells.get_A()[i],cells.get_Q()[i] )) ;
    cells.set_T(    i, shearStress( cells.get_mu1()[i],cells.get_G()[i],cells.get_H()[i],cells.get_Tmu()[i] )) ;
  }
}
//####################################################
// Time stepping for elliptic problem
//####################################################
void arteryNum::CrankNicolson() {
  // Second order time stepping for the eliptic viscoelastic problem.
  // If diffusion of passive scalars is included, it can be solve here.

  // If viscoelastic wall:
  if ( abs(cells.get_cv()[0]) > ZERO ){
    cells.set_Q( Amatrix.Thomas_solver( Bmatrix * cells.get_Q() ));
  }
}
//####################################################
// Time stepping for hyperbolic & reaction problems
//####################################################
void arteryNum::SSPRK2(const time_c& timenet) {
  // Strong Stability Preserving Runge Kutta scheme for linear & nonlinear hyperbolic problem
  // We use only second order as the dt imposed by the CFL is small
  // Higher-order methods would be overkill
  // Also, the CrankNicolson scheme is second order in time

  SCALAR dt = timenet.get_dt() ;
  SSPRK2Advection(dt) ;
  SSPRK2Reaction(dt) ;
}
void arteryNum::AB2(const time_c& timenet) {
  // Adam-Bashforth second order scheme
  // We use only second order as the dt imposed by the CFL is small
  // Higher-order methods would be overkill
  // Also, the CrankNicolson scheme is second order in time

  SCALAR dt = timenet.get_dt() ;
  AB2Advection(dt) ;
  AB2Reaction(dt) ;
}
void arteryNum::SSPRK2Advection(const SCALAR dt) {
  // Strong Stability Preserving Runge Kutta scheme for nonlinear hyperbolic problem
  // Intermediate boundary conditions are not computed

  // Define previous time step variables
  VECT Am1(cells.get_nx(),ZERO), Qm1(cells.get_nx(),ZERO) ;
  VECT Fm1(cells.get_nx(),ZERO) ;
  VECT Hm1(cells.get_nx(),ZERO), Cm1(cells.get_nx(),ZERO), Om1(cells.get_nx(),ZERO) ;
  // Define rhs
  VECT RHSA_1(cells.get_nx(),ZERO), RHSA_2(cells.get_nx(),ZERO) ;
  VECT RHSQ_1(cells.get_nx(),ZERO), RHSQ_2(cells.get_nx(),ZERO) ;
  VECT RHSF_1(cells.get_nx(),ZERO), RHSF_2(cells.get_nx(),ZERO) ;
  VECT RHSH_1(cells.get_nx(),ZERO), RHSH_2(cells.get_nx(),ZERO) ;
  VECT RHSC_1(cells.get_nx(),ZERO), RHSC_2(cells.get_nx(),ZERO) ;
  VECT RHSO_1(cells.get_nx(),ZERO), RHSO_2(cells.get_nx(),ZERO) ;

  // Store previous variables
  Am1 = cells.get_A();
  Qm1 = cells.get_Q();
  Fm1 = cells.get_F();
  Hm1 = cells.get_H();
  Cm1 = cells.get_C();
  Om1 = cells.get_O();

  // First step
  stepRhsAdvection(RHSA_1,RHSQ_1,RHSF_1,RHSH_1,RHSC_1,RHSO_1) ;
  for (int i=0; i<cells.get_nx(); i++) {
    // Explicitly update A & Q
    cells.set_A ( i, Am1[i] + dt * RHSA_1[i] ) ;
    cells.set_Q ( i, Qm1[i] + dt * RHSQ_1[i] ) ;
    // Explicitly update F
    cells.set_F ( i, Fm1[i] + dt * RHSF_1[i] / cells.get_A()[i] ) ;
    // Explicitly update H, C & O
    cells.set_H ( i, Hm1[i] + dt * RHSH_1[i] / cells.get_A()[i] ) ;
    cells.set_C ( i, Cm1[i] + dt * RHSC_1[i] / cells.get_A()[i] ) ;
    cells.set_O ( i, Om1[i] + dt * RHSO_1[i] / cells.get_A()[i] ) ;
  }
  // Second step
  stepRhsAdvection(RHSA_2,RHSQ_2,RHSF_2,RHSH_2,RHSC_2,RHSO_2) ;
  // Update
  for (int i=0; i<cells.get_nx(); i++) {
    // Explicitly update A & Q (Inviscid)
    cells.set_A ( i, Am1[i] + ONEsTWO * dt * (RHSA_1[i]+RHSA_2[i]) ) ;
    cells.set_Q ( i, Qm1[i] + ONEsTWO * dt * (RHSQ_1[i]+RHSQ_2[i]) ) ;
    // Explicitly update F
    cells.set_F ( i, Fm1[i] + ONEsTWO * dt * (RHSF_1[i]+RHSF_2[i]) / cells.get_A()[i] ) ;
    // Explicitly update H, C & O
    cells.set_H ( i, Hm1[i] + ONEsTWO * dt * (RHSH_1[i]+RHSH_2[i]) / cells.get_A()[i] ) ;
    cells.set_C ( i, Cm1[i] + ONEsTWO * dt * (RHSC_1[i]+RHSC_2[i]) / cells.get_A()[i] ) ;
    cells.set_O ( i, Om1[i] + ONEsTWO * dt * (RHSO_1[i]+RHSO_2[i]) / cells.get_A()[i] ) ;
  }

  // Store rhs
  for (int i=0; i<cells.get_nx(); i++) {
    cells.set_RHSA(RHSA_1) ;
    cells.set_RHSQ(RHSQ_1) ;
    cells.set_RHSF(RHSF_1) ;
    cells.set_RHSH(RHSH_1) ;
    cells.set_RHSC(RHSC_1) ;
    cells.set_RHSO(RHSO_1) ;
  }
}
void arteryNum::AB2Advection(const SCALAR dt) {
  // Adam-Bashforth second order scheme
  // No intermediate boundary condition is required

  // Define rhs
  VECT RHSA(cells.get_nx(),ZERO) ;
  VECT RHSQ(cells.get_nx(),ZERO) ;
  VECT RHSF(cells.get_nx(),ZERO) ;
  VECT RHSH(cells.get_nx(),ZERO) ;
  VECT RHSC(cells.get_nx(),ZERO) ;
  VECT RHSO(cells.get_nx(),ZERO) ;

  // First step
  stepRhsAdvection(RHSA,RHSQ,RHSF,RHSH,RHSC,RHSO) ;
  for (int i=0; i<cells.get_nx(); i++) {
    // Explicitly update A & Q
    cells.set_A ( i, cells.get_A()[i] + dt * (THREEsTWO * RHSA[i] - ONEsTWO * cells.get_RHSA()[i] )) ;
    cells.set_Q ( i, cells.get_Q()[i] + dt * (THREEsTWO * RHSQ[i] - ONEsTWO * cells.get_RHSQ()[i] )) ;
    // Explicitly update F
    cells.set_F ( i, cells.get_F()[i] + dt * (THREEsTWO * RHSF[i] - ONEsTWO * cells.get_RHSF()[i] ) / cells.get_A()[i] ) ;
    // Explicitly update H, C & O
    cells.set_H ( i, cells.get_H()[i] + dt * (THREEsTWO * RHSH[i] - ONEsTWO * cells.get_RHSH()[i] ) / cells.get_A()[i] ) ;
    cells.set_C ( i, cells.get_C()[i] + dt * (THREEsTWO * RHSC[i] - ONEsTWO * cells.get_RHSC()[i] ) / cells.get_A()[i] ) ;
    cells.set_O ( i, cells.get_O()[i] + dt * (THREEsTWO * RHSO[i] - ONEsTWO * cells.get_RHSO()[i] ) / cells.get_A()[i] ) ;
  }
  // Store rhs
  for (int i=0; i<cells.get_nx(); i++) {
    cells.set_RHSA(RHSA) ;
    cells.set_RHSQ(RHSQ) ;
    cells.set_RHSF(RHSF) ;
    cells.set_RHSH(RHSH) ;
    cells.set_RHSC(RHSC) ;
    cells.set_RHSO(RHSO) ;
  }
}
void arteryNum::SSPRK2Reaction(const SCALAR dt) {
  // Strong Stability Preserving Runge Kutta scheme for linear hyperbolic problem
  // Only cell centered value are used.
  // There is no need to step the boundary values

  // Define previous time step variables
  VECT Qm1  (cells.get_nx(),ZERO) ;
  VECT Fm1  (cells.get_nx(),ZERO) ;
  VECT Tmum1(cells.get_nx(),ZERO) ;
  // Define reac
  VECT REACQ_1    (cells.get_nx(),ZERO), REACQ_2  (cells.get_nx(),ZERO) ;
  VECT REACF_1    (cells.get_nx(),ZERO), REACF_2  (cells.get_nx(),ZERO) ;
  VECT REACTMU_1  (cells.get_nx(),ZERO), REACTMU_2(cells.get_nx(),ZERO) ;

  // Store previous variables
  Qm1   = cells.get_Q();
  Fm1   = cells.get_F();
  Tmum1 = cells.get_Tmu();

  // First step
  stepReacReaction(REACQ_1,REACF_1,REACTMU_1) ;
  for (int i=0; i<cells.get_nx(); i++) {
    // Explicitly update Q
    cells.set_Q   ( i, Qm1[i]   + dt * REACQ_1[i] ) ;
    // Explicitly update F
    cells.set_F   ( i, Fm1[i]   + dt * REACF_1[i] ) ;
    // Explicitly update Tmu
    cells.set_Tmu ( i, Tmum1[i] + dt * REACTMU_1[i] ) ;
  }
  // Second step
  stepReacReaction(REACQ_2,REACF_2,REACTMU_2) ;
  // Update
  for (int i=0; i<cells.get_nx(); i++) {
    // Explicitly update Q
    cells.set_Q   ( i, Qm1[i]   + ONEsTWO * dt * (REACQ_1[i]+REACQ_2[i]) ) ;
    // Explicitly update F
    cells.set_F   ( i, Fm1[i]   + ONEsTWO * dt * (REACF_1[i]+REACF_2[i]) ) ;
    // Explicitly update Tmu
    cells.set_Tmu ( i, Tmum1[i] + ONEsTWO * dt * (REACTMU_1[i]+REACTMU_2[i]) ) ;
  }

  // Store reac
  for (int i=0; i<cells.get_nx(); i++) {
    cells.set_REACQ   (REACQ_1) ;
    cells.set_REACF   (REACF_1) ;
    cells.set_REACTMU (REACTMU_1) ;
  }
}
void arteryNum::AB2Reaction(const SCALAR dt) {
  // Adam-Bashforth second order scheme
  // No intermediate boundary condition is required

  // Define reac
  VECT REACQ    (cells.get_nx(),ZERO) ;
  VECT REACF    (cells.get_nx(),ZERO) ;
  VECT REACTMU  (cells.get_nx(),ZERO) ;

  // First step
  stepReacReaction(REACQ,REACF,REACTMU) ;
  for (int i=0; i<cells.get_nx(); i++) {
    // Explicitly update Q
    cells.set_Q   ( i, cells.get_Q()[i]   + dt * (THREEsTWO * REACQ[i]  - ONEsTWO * cells.get_REACQ()[i] )) ;
    // Explicitly update F
    cells.set_F   ( i, cells.get_F()[i]   + dt * (THREEsTWO * REACF[i]  - ONEsTWO * cells.get_REACF()[i] )) ;
    // Explicitly update Tmu
    cells.set_Tmu ( i, cells.get_Tmu()[i] + dt * (THREEsTWO * REACTMU[i]- ONEsTWO * cells.get_REACTMU()[i] )) ;
  }
  // Store reac
  for (int i=0; i<cells.get_nx(); i++) {
    cells.set_REACQ   (REACQ) ;
    cells.set_REACF   (REACF) ;
    cells.set_REACTMU (REACTMU) ;
  }
}
//####################################################
// Right hand side
//####################################################
// The rhs vectors contain the flux terms.
// They are used to solve the homogeneous hyperbolic equations
void arteryNum::stepRhsAdvection(VECT& RHSA, VECT& RHSQ, VECT& RHSF, VECT& RHSH, VECT& RHSC, VECT& RHSO){
  // Elementary time stepping method for the homogeneous hyperbolic equations
  // The hyperbolic equations are:
  //    - Mass and momentum equations
  //    - Passive scalar equations (H, C, O)
  //    - Structure function equation
  // !!! The strucutre stress does not have an advection term, therefore is not updated in this part

  // Reconstruct variables
  stepReconstruct() ;
  // Compute the fluxes
  stepFlux() ;
  // Compute the rhs
  rhsAQ(RHSA,RHSQ) ;
  rhsF(RHSF) ;
  rhsPS(RHSH,RHSC,RHSO) ;
}
void arteryNum::rhsAQ(VECT& rhsA, VECT& rhsQ) {
  // Solve hyperbolic problem with topography source term
  for (int i=0; i<cells.get_nx(); i++) {
    // Homogeneous hyperbolic problem with topography source term
    rhsA[i]   = - ( faces[i+1].get_FA() - faces[i].get_FA() ) / cells.get_dx()[i] ;
    rhsQ[i]   = - ( faces[i+1].get_FQ() + faces[i+1].get_FQhr()[0] - faces[i].get_FQ() - faces[i].get_FQhr()[1] ) / cells.get_dx()[i] ;
  }
}
void arteryNum::rhsF(VECT& rhsF) {
  // Solve passive transport of F only (no production or destruction)
  for (int i=0; i<cells.get_nx(); i++) {
    rhsF[i]   = - ( faces[i+1].get_FF() - faces[i].get_FF() ) / cells.get_dx()[i] ;
  }
}
void arteryNum::rhsPS(VECT& rhsH, VECT& rhsC, VECT& rhsO) {
  // Solve passive transport
  for (int i=0; i<cells.get_nx(); i++) {
    rhsH[i]   = - ( faces[i+1].get_FH() - faces[i].get_FH() ) / cells.get_dx()[i] ;
    rhsC[i]   = - ( faces[i+1].get_FC() - faces[i].get_FC() ) / cells.get_dx()[i] ;
    rhsO[i]   = - ( faces[i+1].get_FO() - faces[i].get_FO() ) / cells.get_dx()[i] ;
  }
}
//####################################################
// Reaction
//####################################################
// The reac vectors contain the reaction terms.
// They include viscous effects, structure production and destruction and shear stress production
void arteryNum::stepReacReaction(VECT& REACQ, VECT& REACF, VECT& REACTMU){
  // Elementary time stepping method for the reaction equations
  // Reaction terms appear in:
  //    - the momentum balance equations and in
  //    - the structure function equations
  //    - the structure shear stress equation
  // !!! No variable reconstruction is required. Only cell centered value are used

  NonDifferential() ;
  // Compute the reac
  reacQ(REACQ) ;
  reacF(REACF) ;
  reacTmu(REACTMU) ;
}
void arteryNum::reacQ(VECT& reacQ) {
  // Solve viscous effects
  for (int i=0; i<cells.get_nx(); i++) {
    reacQ[i] = shearLaplacian(cells.get_rho(),cells.get_A()[i],cells.get_T()[i]) ;
  }
}
void arteryNum::reacF(VECT& reacF) {
  // Solve structure production and destruction
  for (int i=0; i<cells.get_nx(); i++) {
    reacF[i] = prodesF( cells.get_kmu()[i], cells.get_amu()[i],
                        cells.get_G()[i],   cells.get_H()[i],   cells.get_F()[i]
                      ) ;
  }
}
void arteryNum::reacTmu(VECT& reacTmu) {
  // Solve shear stress production
  for (int i=0; i<cells.get_nx(); i++) {
    reacTmu[i] = prodTmu( cells.get_mu0()[i], cells.get_mu1()[i],
                          cells.get_kmu()[i],
                          cells.get_G()[i],   cells.get_H()[i],
                          cells.get_F()[i],   cells.get_Tmu()[i]
                        ) ;
  }
}
//####################################################
// Evaluate flux
//####################################################
void arteryNum::stepFlux() {
  // Evaluate fluxes
  fluxAQ();
  fluxQhr();
  fluxPS();
}
//####################################################
// Flux for conservative variables
//####################################################
void arteryNum::fluxAQ() {
    VECT F(4,ZERO) ;
    for (int i=0; i<cells.get_nx()+1; i++ ) {
      F = flux_hat( cells.get_rho(),
                    faces[i].get_khr()   ,
                    faces[i].get_Ahr()[0],
                    faces[i].get_Ahr()[1],
                    faces[i].get_Q()[0],
                    faces[i].get_Q()[1]
                  ) ;
      faces[i].set_FA( F[0] + F[1] );
      faces[i].set_FQ( F[2] + F[3] );
    }
}
//####################################################
// Momentum flux correction for hydrostatic reconstruction
//####################################################
void arteryNum::fluxQhr() {
  // Correction due to high order reconstruction
  SCALAR kcl=ZERO, kcr=ZERO ;
  for (int i=0; i<cells.get_nx()+1; i++ ) {

    // Centered rigidity on both sides of the interface
    if (i==0) {
      kcl = inlet.get_k()[0] ;
      kcr = recKc(faces[i].get_k()[1]   , faces[i+1].get_k()[0]) ;
    }
    else if (i==cells.get_nx()) {
      kcl = recKc(faces[i-1].get_k()[1] , faces[i].get_k()[0]) ;
      kcr = outlet.get_k()[0] ;
    }
    else {
      kcl = recKc(faces[i-1].get_k()[1] , faces[i].get_k()[0]) ;
      kcr = recKc(faces[i].get_k()[1]   , faces[i+1].get_k()[0]) ;
    }
    // Momentum flux correction on the left side of the interface
    faces[i].set_FQhr(  0,    fluxP(cells.get_rho(),kcl,faces[i].get_Ac()[0])
                            - fluxP(cells.get_rho(),faces[i].get_khr(),faces[i].get_Ahr()[0])
                      ) ;
    // Momentum flux correction on the right side of the interface
    faces[i].set_FQhr(  1,    fluxP(cells.get_rho(),kcr,faces[i].get_Ac()[1])
                            - fluxP(cells.get_rho(),faces[i].get_khr(),faces[i].get_Ahr()[1])
                      ) ;
  }
}
//####################################################
// Flux for transported variables
//####################################################
void arteryNum::fluxPS() {
    for (int i=0; i<cells.get_nx()+1; i++ ) {
      faces[i].set_FH( flux_transport( faces[i].get_FA(), faces[i].get_H()[0], faces[i].get_H()[1] ));
      faces[i].set_FC( flux_transport( faces[i].get_FA(), faces[i].get_C()[0], faces[i].get_C()[1] ));
      faces[i].set_FO( flux_transport( faces[i].get_FA(), faces[i].get_O()[0], faces[i].get_O()[1] ));
      faces[i].set_FF( flux_transport( faces[i].get_FA(), faces[i].get_F()[0], faces[i].get_F()[1] ));
    }
}
//####################################################
// Reconstruction
//####################################################
void arteryNum::stepReconstruct() {
  // High order reconstruction
  reconstructOrder();
  // Hydrostatic reconstruction
  reconstructHR();
}
//####################################################
// First and Second Order Reconstruction
//####################################################
void arteryNum::reconstructOrder() {
  // The indice l refers to the left side of the interface
  // The indice r refers to the right side of the interface

  // As the boundary conditions are of order 1, we use a first order reconstruction for the first and last interface.

  // Update auxillary variables (Ho, HmZo)
  cells.set_Auxillary() ;
  inlet.set_Auxillary() ;
  outlet.set_Auxillary() ;

  VECT Kl(    cells.get_nx()+1,ZERO), Kr(     cells.get_nx()+1,ZERO);
  VECT Hol(   cells.get_nx()+1,ZERO), Hor(    cells.get_nx()+1,ZERO);
  VECT HmZol( cells.get_nx()+1,ZERO), HmZor(  cells.get_nx()+1,ZERO);
  VECT Ql(    cells.get_nx()+1,ZERO), Qr(     cells.get_nx()+1,ZERO);

  VECT Hl(    cells.get_nx()+1,ZERO), Hr(     cells.get_nx()+1,ZERO);
  VECT Cl(    cells.get_nx()+1,ZERO), Cr(     cells.get_nx()+1,ZERO);
  VECT Ol(    cells.get_nx()+1,ZERO), Or(     cells.get_nx()+1,ZERO);
  VECT Fl(    cells.get_nx()+1,ZERO), Fr(     cells.get_nx()+1,ZERO);

  // K
  recOrder(xorder,  cells.get_k(),    cells.get_dx(), inlet.get_k(),    inlet.get_dx(), outlet.get_k(),     outlet.get_dx(),  Kl,Kr) ;
  //Ho
  recOrder(xorder,  cells.get_Ho(),   cells.get_dx(), inlet.get_Ho(),   inlet.get_dx(), outlet.get_Ho(),    outlet.get_dx(),  Hol,Hor) ;
  //HmZo
  recOrder(xorder,  cells.get_HmZo(), cells.get_dx(), inlet.get_HmZo(), inlet.get_dx(), outlet.get_HmZo(),  outlet.get_dx(),  HmZol,HmZor) ;
  //Q
  recOrder(xorder,  cells.get_Q(),    cells.get_dx(), inlet.get_Q(),    inlet.get_dx(), outlet.get_Q(),     outlet.get_dx(),  Ql,Qr) ;
  //H
  recOrder(xorder,  cells.get_H(),    cells.get_dx(), inlet.get_H(),    inlet.get_dx(), outlet.get_H(),     outlet.get_dx(),  Hl,Hr) ;
  //C
  recOrder(xorder,  cells.get_C(),    cells.get_dx(), inlet.get_C(),    inlet.get_dx(), outlet.get_C(),     outlet.get_dx(),  Cl,Cr) ;
  //O
  recOrder(xorder,  cells.get_O(),    cells.get_dx(), inlet.get_O(),    inlet.get_dx(), outlet.get_O(),     outlet.get_dx(),  Ol,Or) ;
  //f
  recOrder(xorder,  cells.get_F(),    cells.get_dx(), inlet.get_F(),    inlet.get_dx(), outlet.get_F(),     outlet.get_dx(),  Fl,Fr) ;

  // Update all interface variables
  VECT inter(2,ZERO) ;

  for (int i=0; i<cells.get_nx()+1; i++) {

    inter[0] = pow( (Hol[i]-HmZol[i])/Kl[i] , TWO); inter[1] = pow( (Hor[i]-HmZor[i])/Kr[i] , TWO); faces[i].set_a0( inter ) ;
    inter[0] = Kl[i];                               inter[1] = Kr[i];                               faces[i].set_k( inter ) ;

    inter[0] = pow( Hol[i]/Kl[i] , TWO);  inter[1] = pow( Hor[i]/Kr[i] , TWO);  faces[i].set_A( inter ) ;
    inter[0] = Ql[i];                     inter[1] = Qr[i];                     faces[i].set_Q( inter ) ;

    inter[0] = Hl[i]; inter[1] = Hr[i]; faces[i].set_H( inter ) ;
    inter[0] = Cl[i]; inter[1] = Cr[i]; faces[i].set_C( inter ) ;
    inter[0] = Ol[i]; inter[1] = Or[i]; faces[i].set_O( inter ) ;
    inter[0] = Fl[i]; inter[1] = Fr[i]; faces[i].set_F( inter ) ;

  }
}
//####################################################
// Hydrostatic Reconstruction:
//####################################################
void arteryNum::reconstructHR() {
  for (int i=0; i<cells.get_nx()+1; i++) {
    set_HR(i) ;
  }
}
void arteryNum::set_HR(const int i) {

  SCALAR  kc=ZERO, a0c=ZERO ;
  VECT    inter(2,ZERO) ;

  // Interface values
  faces[i].set_khr(   recK( faces[i].get_k()[0]  , faces[i].get_k()[1]  ));
  faces[i].set_a0hr(  pow( recZ( faces[i].get_k()[0]*sqrt(faces[i].get_a0()[0]) , faces[i].get_k()[1]*sqrt(faces[i].get_a0()[1]) ) / faces[i].get_khr() , TWO ) );

  inter[0] = recA( faces[i].get_khr() , faces[i].get_a0hr() , faces[i].get_k()[0]*( sqrt(faces[i].get_A()[0]) - sqrt(faces[i].get_a0()[0]) )) ;
  inter[1] = recA( faces[i].get_khr() , faces[i].get_a0hr() , faces[i].get_k()[1]*( sqrt(faces[i].get_A()[1]) - sqrt(faces[i].get_a0()[1]) )) ;
  faces[i].set_Ahr( inter ) ;

  // Cell centered values
  if (i==0) {
    // Estimation of the centered value
    inter[0] = inlet.get_A()[0] ;
    //Computation of the centered value
    kc  = recKc(faces[i].get_k()[1]  , faces[i+1].get_k()[0] ) ;
    a0c = pow( recZc( faces[i].get_k()[1]*sqrt(faces[i].get_a0()[1]) , faces[i+1].get_k()[0]*sqrt(faces[i+1].get_a0()[0]) ) / kc , TWO ) ;
    inter[1] = recA(  kc , a0c , faces[i].get_k()[1]*( sqrt(faces[i].get_A()[1]) - sqrt(faces[i].get_a0()[1]) )) ;

    faces[i].set_Ac( inter ) ;
  }
  else if (i==cells.get_nx()) {
    // Computation of the centered value
    kc  = recKc(faces[i-1].get_k()[1]  , faces[i].get_k()[0] ) ;
    a0c = pow( recZc( faces[i-1].get_k()[1]*sqrt(faces[i-1].get_a0()[1]) , faces[i].get_k()[0]*sqrt(faces[i].get_a0()[0]) ) / kc , TWO ) ;
    inter[0] = recA(  kc , a0c , faces[i].get_k()[0]*( sqrt(faces[i].get_A()[0]) - sqrt(faces[i].get_a0()[0]) )) ;
    // Estimation of the centered value
    inter[1] = outlet.get_A()[0] ;

    faces[i].set_Ac( inter ) ;

  }
  else {

    kc  = recKc(faces[i-1].get_k()[1]  , faces[i].get_k()[0] ) ;
    a0c = pow( recZc( faces[i-1].get_k()[1]*sqrt(faces[i-1].get_a0()[1]) , faces[i].get_k()[0]*sqrt(faces[i].get_a0()[0]) ) / kc , TWO ) ;
    inter[0] = recA(  kc , a0c , faces[i].get_k()[0]*( sqrt(faces[i].get_A()[0]) - sqrt(faces[i].get_a0()[0]) )) ;

    kc  = recKc(faces[i].get_k()[1]  , faces[i+1].get_k()[0] ) ;
    a0c = pow( recZc( faces[i].get_k()[1]*sqrt(faces[i].get_a0()[1]) , faces[i+1].get_k()[0]*sqrt(faces[i+1].get_a0()[0]) ) / kc , TWO ) ;
    inter[1] = recA(  kc , a0c , faces[i].get_k()[1]*( sqrt(faces[i].get_A()[1]) - sqrt(faces[i].get_a0()[1]) )) ;

    faces[i].set_Ac( inter ) ;

  }
}
//####################################################
// Set properties
//####################################################
void arteryNum::set_interface() {

  // We define the interface variables,
  // given by high order reconstruction and hydrostatic reconstruction
  VECT inter(2,ZERO) ;

  for (int i=0; i<cells.get_nx()+1; i++) {

    // First interface
    if ( i==0 ) {

      inter[0] = inlet.get_a0()[0]; inter[1] = cells.get_a0()[i]; faces[i].set_a0(  inter );
      inter[0] = inlet.get_k()[0];  inter[1] = cells.get_k()[i];  faces[i].set_k(   inter );

      inter[0] = inlet.get_A()[0];  inter[1] = cells.get_A()[i];  faces[i].set_A(   inter );
                                                                  faces[i].set_Ahr( inter );
                                                                  faces[i].set_Ac(  inter );

      inter[0] = inlet.get_Q()[0];  inter[1] = cells.get_Q()[i];  faces[i].set_Q(   inter );

      inter[0] = inlet.get_H()[0];  inter[1] = cells.get_H()[i];  faces[i].set_H(   inter );
      inter[0] = inlet.get_C()[0];  inter[1] = cells.get_C()[i];  faces[i].set_C(   inter );
      inter[0] = inlet.get_O()[0];  inter[1] = cells.get_O()[i];  faces[i].set_O(   inter );

      inter[0] = inlet.get_F()[0];  inter[1] = cells.get_F()[i];  faces[i].set_F(   inter );

    }
    // Last interface
    else if( i==cells.get_nx() ) {

      inter[0] = cells.get_a0()[i-1]; inter[1] = outlet.get_a0()[0]; faces[i].set_a0( inter );
      inter[0] = cells.get_k()[i-1];  inter[1] = outlet.get_k()[0];  faces[i].set_k(  inter );

      inter[0] = cells.get_A()[i-1];  inter[1] = outlet.get_A()[0];  faces[i].set_A(  inter );
                                                                     faces[i].set_Ahr( inter );
                                                                     faces[i].set_Ac(  inter );

      inter[0] = cells.get_Q()[i-1];  inter[1] = outlet.get_Q()[0];  faces[i].set_Q(  inter );

      inter[0] = cells.get_H()[i-1];  inter[1] = outlet.get_H()[0];  faces[i].set_H(  inter );
      inter[0] = cells.get_C()[i-1];  inter[1] = outlet.get_C()[0];  faces[i].set_C(  inter );
      inter[0] = cells.get_O()[i-1];  inter[1] = outlet.get_O()[0];  faces[i].set_O(  inter );

      inter[0] = cells.get_F()[i-1];  inter[1] = outlet.get_F()[0];  faces[i].set_F(  inter );

    }
    else {

      inter[0] = cells.get_a0()[i-1]; inter[1] = cells.get_a0()[i]; faces[i].set_a0(  inter );
      inter[0] = cells.get_k()[i-1];  inter[1] = cells.get_k()[i];  faces[i].set_k(   inter );

      inter[0] = cells.get_A()[i-1];  inter[1] = cells.get_A()[i];  faces[i].set_A(   inter );
                                                                    faces[i].set_Ahr( inter );
                                                                    faces[i].set_Ac(  inter );

      inter[0] = cells.get_Q()[i-1];  inter[1] = cells.get_Q()[i];  faces[i].set_Q(   inter );

      inter[0] = cells.get_H()[i-1];  inter[1] = cells.get_H()[i];  faces[i].set_H(   inter );
      inter[0] = cells.get_C()[i-1];  inter[1] = cells.get_C()[i];  faces[i].set_C(   inter );
      inter[0] = cells.get_O()[i-1];  inter[1] = cells.get_O()[i];  faces[i].set_O(   inter );

      inter[0] = cells.get_F()[i-1];  inter[1] = cells.get_F()[i];  faces[i].set_F(   inter );

    }

    faces[i].set_FA( ZERO ) ;
    faces[i].set_FQ( ZERO ) ;
    faces[i].set_FH( ZERO ) ;
    faces[i].set_FC( ZERO ) ;
    faces[i].set_FO( ZERO ) ;
    faces[i].set_FF( ZERO ) ;

    faces[i].set_khr(ZERO ) ;
    faces[i].set_a0hr(ZERO) ;

    inter[0] = ZERO; inter[1] = ZERO; faces[i].set_FQhr( inter ) ;

  }

  // Update hydrostatic reconstruction variables
  for (int i=0; i<cells.get_nx()+1; i++) {
    set_HR(i) ;
  }
}
//####################################################
// Viscoelastic and Inertial Subproblem
//####################################################
void arteryNum::set_diffusionMatrix(const SCALAR dt) {
  SCALAR dxm=ZERO, dxp=ZERO ;
  SCALAR r=ZERO;

  // Compute the Center (b) diagonal coefficients
  for(int i=0; i<cells.get_nx(); i++) {

    if (i==0) {
      dxm = ONEsTWO * ( inlet.get_dx()[0] + cells.get_dx()[i] ) ;
      dxp = ONEsTWO * ( cells.get_dx()[i] + cells.get_dx()[i+1] ) ;
    }
    else if (i==cells.get_nx()-1) {
      dxm = ONEsTWO * ( cells.get_dx()[i-1] + cells.get_dx()[i] ) ;
      dxp = ONEsTWO * ( cells.get_dx()[i]   + outlet.get_dx()[0] ) ;
    }
    else {
      dxm = ONEsTWO * ( cells.get_dx()[i-1] + cells.get_dx()[i] ) ;
      dxp = ONEsTWO * ( cells.get_dx()[i]   + cells.get_dx()[i+1] ) ;
    }

    r  = ONEsTWO * dt * cells.get_cv()[i] * TWO / (dxp*dxm*dxm + dxm*dxp*dxp) ;
    Amatrix.set_b_at(i,ONE + (dxm+dxp) * r);
    Bmatrix.set_b_at(i,ONE - (dxm+dxp) * r);
  }

  // Compute Lower (a) and Upper (c) diagonal coefficients
  for(int i=1; i<cells.get_nx()-1; i++) {

    dxm = ONEsTWO * ( cells.get_dx()[i-1] + cells.get_dx()[i] ) ;
    dxp = ONEsTWO * ( cells.get_dx()[i]   + cells.get_dx()[i+1] ) ;

    r  = ONEsTWO * dt * cells.get_cv()[i] * TWO / (dxp*dxm*dxm + dxm*dxp*dxp) ;
    Amatrix.set_a_at( i-1,-dxp*r);
    Amatrix.set_c_at( i,  -dxm*r);
    Bmatrix.set_a_at( i-1, dxp*r);
    Bmatrix.set_c_at( i,   dxm*r);
  }

  // Homogeneous Neumann B.C.

  // First cell
  dxm = ONEsTWO * ( inlet.get_dx()[0] + cells.get_dx()[0] ) ;
  dxp = ONEsTWO * ( cells.get_dx()[0] + cells.get_dx()[1] ) ;

  r  = ONEsTWO * dt * cells.get_cv()[0] * TWO / (dxp*dxm*dxm + dxm*dxp*dxp) ;
  Amatrix.set_c_at( 0, - (dxm+dxp) * r);
  Bmatrix.set_c_at( 0,   (dxm+dxp) * r);

  // Last cell
  dxm = ONEsTWO * ( cells.get_dx()[cells.get_nx()-2] + cells.get_dx()[cells.get_nx()-1] ) ;
  dxp = ONEsTWO * ( cells.get_dx()[cells.get_nx()-1] + outlet.get_dx()[0] ) ;

  r   = ONEsTWO * dt * cells.get_cv()[cells.get_nx()-1] * TWO / (dxp*dxm*dxm + dxm*dxp*dxp) ;
  Amatrix.set_a_at( cells.get_nx() - 2, - (dxm+dxp) * r);
  Bmatrix.set_a_at( cells.get_nx() - 2 ,  (dxm+dxp) * r);
}
//####################################################
// Residu
//####################################################
void arteryNum::residu() {
  // Compute residu

  VECT vresA(cells.get_nx(),ZERO), vresQ(cells.get_nx(),ZERO) ;
  VECT meanA(cells.get_nx(),ZERO), meanQ(cells.get_nx(),ZERO) ;
  resA = ZERO ;
  resQ = ZERO ;

  for (int i=0; i<cells.get_nx(); i++) {
    vresA[i] = abs(cells.get_A()[i] - cells.get_Am1()[i]) ;
    vresQ[i] = abs(cells.get_Q()[i] - cells.get_Qm1()[i]) ;
    meanA[i] = abs(cells.get_A()[i]) ;
    meanQ[i] = abs(cells.get_Q()[i]) ;
  }

  if (kahanSum(meanA) > EPSILON) {
    resA = kahanSum(vresA) / kahanSum(meanA) ;
  }
  if (kahanSum(meanQ) > EPSILON) {
    resQ = kahanSum(vresQ) / kahanSum(meanQ) ;
  }
}
