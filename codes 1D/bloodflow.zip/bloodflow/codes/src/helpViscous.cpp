 #include "helpViscous.h"

// Rheology & Aggregation

// Constants
SCALAR mu0(const SCALAR m0, const SCALAR H) {
  SCALAR Href = 0.45L ;
  // return mu0 * H / Href ;
  return m0 ;
}
SCALAR mu1(const SCALAR m1, const SCALAR H) {
  SCALAR Href = 0.45L ;
  // return mu1 * H / Href ;
  return m1 ;
}
SCALAR kmu(const SCALAR kmu, const SCALAR H) {
  SCALAR Href = 0.45L ;
  // return kmu * H / Href ;
  return kmu ;
}
SCALAR amu(const SCALAR amu, const SCALAR H) {
  SCALAR Href = 0.45L ;
  // return amu * H / Href ;
  return amu ;
}

SCALAR lst(const SCALAR k, const SCALAR F) {
  return F / k ;
}
SCALAR oneSlst(const SCALAR k, const SCALAR F) {
  return k / F ;
}
SCALAR must(const SCALAR m0, const SCALAR m1, const SCALAR F) {
  return (m0-m1) * F ;
}


SCALAR prodesF(const SCALAR k, const SCALAR a, const SCALAR G, const SCALAR H, const SCALAR F) {
  return kmu(k,H) * (ONE-F) - amu(a,H) * abs(G) * F ;
}
SCALAR prodTmu(const SCALAR m0, const SCALAR m1, const SCALAR k, const SCALAR G, const SCALAR H, const SCALAR F, const SCALAR Tmu  ) {
  // If there is no structure
  if ( abs(F) <= EPSILON) {
    return ZERO ;
  }
  else {
    return oneSlst(kmu(k,H),F) * ( - Tmu + must(mu0(m0,H),mu1(m1,H),F) * G ) ;
  }
}

SCALAR shearRate(const SCALAR phi, const SCALAR A, const SCALAR Q) {
  SCALAR G=ZERO ;
  if (A <= EPSILON) {
    G = ZERO ;
  }
  else {
    G = sqrt(PI) * phi * Q / pow( A, THREEsTWO ) ;
  }
  return G ;
}
SCALAR shearStress(const SCALAR m1, const SCALAR G, const SCALAR H, const SCALAR Tmu ) {
  return  Tmu + mu1(m1,H) * G ;
}

// Steady strucutre shear stress
SCALAR shearStressMu(const SCALAR m0, const SCALAR m1, const SCALAR G, const SCALAR H, const SCALAR F ) {
  return must(mu0(m0,H),mu1(m1,H),F) * G ;
}

// Viscous effects in momentum equation
SCALAR shearLaplacian (const SCALAR RHO, const SCALAR A, const SCALAR T) {
  // For Newtonian and non-Newtonian fluids
  return TWO*PI / RHO * sqrt(A/PI) * T ;
  
  // For Delestre and Thacker solutions
  // return TWO*PI / RHO * sqrt(A/PI) * T * A ;

}
