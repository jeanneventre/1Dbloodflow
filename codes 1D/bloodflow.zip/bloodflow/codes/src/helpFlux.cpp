 #include "helpFlux.h"

// Subscript r refers to the left side of the interface
// Subscript l refers to the right side of the interface

// Kinetic flux with Hat function
VECT flux_hat(const SCALAR RHO, const SCALAR K, const SCALAR A_r, const SCALAR A_l, const SCALAR Q_r, const SCALAR Q_l) {

  VECT F(4) ;
  SCALAR SQRTthree = sqrt(THREE) , oneStwoSQRTthree = ONEsTWO / SQRTthree ;
  SCALAR U_r=ZERO, U_l=ZERO ;
  SCALAR ci=ZERO, cg=ZERO, Mp=ZERO, Mm=ZERO ;
  SCALAR FAp=ZERO , FAm=ZERO , FQp=ZERO , FQm=ZERO ;

  // U
  //#############
  if (A_r<EPSILON) {U_r=ZERO;}
  else {U_r=Q_r/A_r;}
  if (A_l<EPSILON) {U_l=ZERO;}
  else {U_l=Q_l/A_l;}
  // F+(U_rr[i])
  //#############
  ci  = sqrt( ONEsTHREE * K / RHO * sqrt(A_r) ) ;
  cg  = oneStwoSQRTthree * A_r / ci ;
  Mp  = MAX(ZERO, U_r + SQRTthree * ci) ;
  Mm  = MAX(ZERO, U_r - SQRTthree * ci) ;
  FAp = ONEsTWO   * cg * ( pow(Mp,TWO)    - pow(Mm,TWO) ) ;
  FQp = ONEsTHREE * cg * ( pow(Mp,THREE)  - pow(Mm,THREE) ) ;
  // F-(U_ll[i+1])
  //#############
  ci  = sqrt( ONEsTHREE * K / RHO * sqrt(A_l) ) ;
  cg  = oneStwoSQRTthree * A_l / ci ;
  Mp  = MIN(ZERO,U_l + SQRTthree * ci) ;
  Mm  = MIN(ZERO,U_l - SQRTthree * ci) ;
  FAm = ONEsTWO   * cg * ( pow(Mp,TWO)    - pow(Mm,TWO) ) ;
  FQm = ONEsTHREE * cg * ( pow(Mp,THREE)  - pow(Mm,THREE) ) ;
  // F
  //#############
  F[0] = FAp ; F[1] = FAm ; F[2] = FQp ; F[3] = FQm ;
  return F;
}
// HLL flux
// HLL flux
VECT flux_hll(const SCALAR RHO, const SCALAR K, const SCALAR A_r, const SCALAR A_l, const SCALAR Q_r, const SCALAR Q_l) {

    VECT F(2) ;
    SCALAR l2_r=ZERO,l2_l=ZERO,l1_r=ZERO,l1_l=ZERO ;
    SCALAR c1=ZERO,c2=ZERO ;

    l2_r = l1(RHO,K,A_r,Q_r);
    l2_l = l1(RHO,K,A_l,Q_l);
    l1_r = l2(RHO,K,A_r,Q_r);
    l1_l = l2(RHO,K,A_l,Q_l);
    c2 = MAX(l2_r,l2_l);
    c1 = MIN(l1_r,l1_l);

    // For A
    if (c1 >=0.) {
          F[0] = Q_r ;
          F[1] = fluxQ(RHO,K,A_r,Q_r);
    }
    else if (c1 < 0. && c2 > 0.) {
          F[0] = ( c2*Q_r - c1*Q_l) / (c2-c1) + c1*c2* (A_l-A_r) / (c2-c1);
          F[1] = ( c2*fluxQ(RHO,K,A_r,Q_r) - c1*fluxQ(RHO,K,A_l,Q_l)) / (c2-c1) + c1*c2*(Q_l-Q_r) / (c2-c1);
    }
    else {
          F[0] = Q_l;
          F[1] = fluxQ(RHO,K,A_l,Q_l);
    }

    return F;
}
// Flux for passive transport
SCALAR flux_transport(const SCALAR Q, const SCALAR Xl, const SCALAR Xr) {
  return  max(ZERO,Q) * Xl + min(ZERO,Q) * Xr ;
}
