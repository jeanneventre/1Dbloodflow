#include "helpOrder.h"


void recOrder( const SCALAR order, const VECT& artX, const VECT& artdx, const VECT& inX, const VECT& indx, const VECT& outX, const VECT& outdx, VECT& Xl, VECT& Xr ) {

  // The indice l refers to the left side of the interface
  // The indice r refers to the right side of the interface

  if ( artX.get_dim() < 3 ) {
    Error("helpOrder::recOrder Insufficient number of cells") ;
  }
  if ( inX.get_dim() != 2 || outX.get_dim() != 2 ) {
    Error("helpOrder::recOrder Insufficient number of boundary cells") ;
  }

  int   n = artX.get_dim() ;
  VECT  rec(2,    ZERO) ;

  if ( Xl.get_dim() != n+1 || Xr.get_dim() != n+1 ) {
    Error("helpOrder::recOrder Error in dimension of Xl or Xr") ;
  }

  // Order 1
  if (order==1. || order==1.5 || order== 2.) {
    tvdOrder(order,artX,artdx,inX,indx,outX,outdx,Xl,Xr) ;
  }
  // Order 1.5
  else if (order == 1.75) {
    bvdOrder(artX,artdx,inX,indx,outX,outdx,Xl,Xr) ;
  }
  else {
    Error("helpOrder::recOrder order choosen not exist");
  }
}

// Boundary value diminishing
void bvdOrder( const VECT& artX, const VECT& artdx, const VECT& inX, const VECT& indx, const VECT& outX, const VECT& outdx, VECT& Xl, VECT& Xr ) {

  int n = artX.get_dim() ;
  VECT Xl1(n+1,ZERO), Xr1(n+1,ZERO) ;
  VECT Xl2(n+1,ZERO), Xr2(n+1,ZERO) ;
  VECT Il (n+1,ZERO), Ir(n+1,ZERO) ;
  SCALAR BV11=ZERO, BV12=ZERO, BV21=ZERO, BV22=ZERO, BV=ZERO ;

  // High order function
  tvdOrder(2.,artX,artdx,inX,indx,outX,outdx,Xl1,Xr1) ;
  // Sigmoid function
  tvdOrder(1.5,artX,artdx,inX,indx,outX,outdx,Xl2,Xr2) ;

  // Boundaries always at order 1:
  Xl[0]   = inX[0]    ; Xr[0] = artX[0]   ; Xl[1] = artX[0] ;
  Xr[n-1] = artX[n-1] ; Xl[n] = artX[n-1] ; Xr[n] = outX[0] ;

  // BVD algorithm for interior faces
  for (int i=1; i<n; i++) {
    BV11  = abs(Xl1[i]-Xr1[i]) ;
    BV12  = abs(Xl1[i]-Xr2[i]) ;
    BV21  = abs(Xl2[i]-Xr1[i]) ;
    BV22  = abs(Xl2[i]-Xr2[i]) ;
    BV    = MIN(BV11, MIN(BV12, MIN(BV21,BV22))) ;
    if      (BV11 == BV) { Il[i] = ONE ; Ir[i] = ONE ;}
    else if (BV12 == BV) { Il[i] = ONE ; Ir[i] = TWO ;}
    else if (BV21 == BV) { Il[i] = TWO ; Ir[i] = ONE ;}
    else if (BV22 == BV) { Il[i] = TWO ; Ir[i] = TWO ;}
    else {
      printf("%Lf,\t %Lf,\t %Lf,\t %Lf,\t %Lf \n",BV,BV11,BV12,BV21,BV22);
      Error("helpOrder::bvdOrder Unknown min") ;
    }
  }

  // Reconstruction for interior cells
  SCALAR s=ZERO ;
  for (int i=1; i<n-1; i++) {
    if      (Ir[i] == ONE && Il[i+1] == ONE) { Xr[i] = Xr1[i] ; Xl[i+1] = Xl1[i+1] ;}
    else if (Ir[i] == TWO && Il[i+1] == TWO) { Xr[i] = Xr2[i] ; Xl[i+1] = Xl2[i+1] ;}
    else if (Ir[i] == ONE && Il[i+1] == TWO) {

      if      (Il[i] == ONE && Ir[i+1] == ONE) { s = (Xl1[i]-Xr1[i])*(Xl2[i+1]-Xr1[i+1]) ;}
      else if (Il[i] == ONE && Ir[i+1] == TWO) { s = (Xl1[i]-Xr1[i])*(Xl2[i+1]-Xr2[i+1]) ;}
      else if (Il[i] == TWO && Ir[i+1] == ONE) { s = (Xl2[i]-Xr1[i])*(Xl2[i+1]-Xr1[i+1]) ;}
      else if (Il[i] == TWO && Ir[i+1] == TWO) { s = (Xl2[i]-Xr1[i])*(Xl2[i+1]-Xr2[i+1]) ;}

      if ( s < ZERO)  { Xr[i] = Xr1[i] ; Xl[i+1] = Xl1[i+1] ;}
      else            { Xr[i] = Xr2[i] ; Xl[i+1] = Xl2[i+1] ;}

    }
    else if (Ir[i] == TWO && Il[i+1] == ONE) {

      if      (Il[i] == ONE && Ir[i+1] == ONE) { s = (Xl1[i]-Xr2[i])*(Xl1[i+1]-Xr1[i+1]) ;}
      else if (Il[i] == ONE && Ir[i+1] == TWO) { s = (Xl1[i]-Xr2[i])*(Xl1[i+1]-Xr2[i+1]) ;}
      else if (Il[i] == TWO && Ir[i+1] == ONE) { s = (Xl2[i]-Xr2[i])*(Xl1[i+1]-Xr1[i+1]) ;}
      else if (Il[i] == TWO && Ir[i+1] == TWO) { s = (Xl2[i]-Xr2[i])*(Xl1[i+1]-Xr2[i+1]) ;}

      if ( s < ZERO)  { Xr[i] = Xr1[i] ; Xl[i+1] = Xl1[i+1] ;}
      else            { Xr[i] = Xr2[i] ; Xl[i+1] = Xl2[i+1] ;}
    }
  }
}

// Total variation diminishing
void tvdOrder( const SCALAR order, const VECT& artX, const VECT& artdx, const VECT& inX, const VECT& indx, const VECT& outX, const VECT& outdx, VECT& Xl, VECT& Xr ) {

  // The indice l refers to the left side of the interface
  // The indice r refers to the right side of the interface

  // As the boundary conditions are of order 1, we use a first order reconstruction for the first and last interface.

  int   n = artX.get_dim() ;
  VECT  rec(2,    ZERO) ;

  // Order 1
  if (order == 1.) {
    // Inlet
    Xl[0] = inX[0] ;
    Xr[0] = artX[0] ;
    // Artery
    for (int i=1; i<n; i++) {
      Xl[i] = artX[i-1] ;
      Xr[i] = artX[i] ;
    }
    // Outlet
    Xl[n] = artX[n-1] ;
    Xr[n] = outX[0] ;
  }
  // Order 1.5
  else if (order == 1.5) {
    // Inlet
    Xl[0] = inX[0] ;
    // Cell 0
    rec   = thinc(inX[0], artX[0], artX[1]) ;
    Xr[0] = artX[0] ;//rec[0] ;
    Xl[1] = rec[1] ;
    // Artery
    for (int i=1; i<n-1; i++) {
      rec     = thinc(artX[i-1],  artX[i], artX[i+1]) ;
      Xr[i]   = rec[0] ;
      Xl[i+1] = rec[1] ;
    }
    // Cell n-1
    rec       = thinc(artX[n-2], artX[n-1], outX[0]) ;
    Xr[n-1]   = rec[0] ;
    Xl[n]     = artX[n-1] ; //rec[1] ;
    // Outlet
    Xr[n] = outX[0] ;
  }
  // Order 2
  else if (order == 2.) {
    // Inlet
    Xl[0] = inX[0] ;
    // Cell 0
    rec   = muscl (inX[0], indx[0], artX[0], artdx[0], artX[1], artdx[1]) ;
    Xr[0] = artX[0] ;
    Xl[1] = rec[1] ;
    // Artery
    for (int i=1; i<n-1; i++) {
      rec     = muscl(artX[i-1], artdx[i-1],  artX[i], artdx[i], artX[i+1], artdx[i+1]) ;
      Xr[i]   = rec[0] ;
      Xl[i+1] = rec[1] ;
    }
    // Cell n-1
    rec       = muscl( artX[n-2], artdx[n-2], artX[n-1], artdx[n-1], outX[0], outdx[0]) ;
    Xr[n-1]   = rec[0] ;
    Xl[n]     = artX[n-1] ;
    // Outlet
    Xr[n] = outX[0] ;
  }
  else {
    Error("helpOrder::tvdOrder order choosen not exist");
  }
}

// Muscl
VECT muscl(const SCALAR ul, const SCALAR dxl, const SCALAR u, const SCALAR dx, const SCALAR ur, const SCALAR dxr) {
  VECT  uo(2,ZERO) ;
  uo[0] = u - ONEsTWO * dx * minmod(  (u-ul)*TWO/(dxl+dx)   , (ur-u)*TWO/(dx+dxr) ) ; // u_ro
  uo[1] = u + ONEsTWO * dx * minmod(  (u-ul)*TWO/(dxl+dx)   , (ur-u)*TWO/(dx+dxr) ) ; // u_lo
  return uo ;
}
SCALAR minmod(const SCALAR a, const SCALAR b) {
  if (a > 0 && b > 0)
      return min(a,b);
  else if (a < 0 && b < 0 )
      return max(a,b);
  else
      return 0;
}
// Thinc
VECT thinc(const SCALAR ul, const SCALAR u, const SCALAR ur) {
  VECT    uo(2,ZERO) ;
  SCALAR  umin  = MIN(ul,ur) ;
  SCALAR  umax  = MAX(ul,ur) - umin ;
  SCALAR  g     = sign(ur-ul);
  SCALAR  b     = 3.L ; // Controles the thickness of the tanh
  SCALAR  thb   = tanh(b) ;
  SCALAR  eps   = 1.e-8L ;

  SCALAR  B     = exp( g*b * (TWO * (u - umin + eps)/(umax + eps) - ONE)) ;
  SCALAR  A     = (B / cosh(b) - ONE) / thb ;

  if ( (u - ul) * (ur - u) <= ZERO ) {
    uo[0] = u ;
    uo[1] = u ;
  }
  else if (abs(umax) < eps) {
    cerr << umax << endl;
    uo[0] = u ;
    uo[1] = u ;
  }
  else {
    uo[0] = umin + umax / TWO * (ONE + g * A) ;
    uo[1] = umin + umax / TWO * (ONE + g * (thb + A)/(ONE + A*thb)) ;
  }
  return uo ;
}
