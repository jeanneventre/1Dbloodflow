#include "conjunction.h"

conjunction::conjunction () {

  // Junction type
  //##############
  typeJ = "" ;

  // Geometry
  //#########
  l     = ZERO  ;
  V0    = ZERO  ;
  a0    = ZERO  ;

  // Physics
  //#########
  rho = ZERO ;
  k   = ZERO ;

  // Rheology
  //#########
  phi   = ZERO ;
  mu0   = ZERO ;
  mu1   = ZERO ;
  kmu   = ZERO ;
  amu   = ZERO ;

  // Variables
  //##########
  V   = ZERO ;
  A   = ZERO ;
  VQ  = ZERO ;
  Q   = ZERO ;
  VE  = ZERO ;
  E   = ZERO ;

  // Passive scalars
  //################
  VH  = ZERO ;
  H   = ZERO ;
  VC  = ZERO ;
  C   = ZERO ;
  VO  = ZERO ;
  O   = ZERO ;

  // Aggregation
  //############
  VF  = ZERO ;
  F   = ZERO ;
  G   = ZERO ;
  Tmu = ZERO ;
  T   = ZERO ;

  set_properties() ;

}

conjunction::~conjunction () {cout << "conjunction deleted" << endl;}
//####################################################
// Setters
//####################################################
void conjunction::set_properties() {
  // Set properties of junction as mean of the properties of parent and daughter arteries

  int nparts = get_nparts() , ndarts = get_ndarts() ;
  // Loop on parents & daughter arteries

  if (nparts > 0 && ndarts > 0) {

    // Junction type
    typeJ = parts[0]->get_bcJ()[0].get_type() ;
    // Verify that all junction have the same type
    for (int i=0; i < nparts ; i++) {
      if (typeJ != parts[i]->get_bcJ()[0].get_type() ) { Error("conjunction:set_properties Error in the junction type of parent arteries") ;}
    }
    for (int i=0; i < ndarts ; i++) {
      if (typeJ != darts[i]->get_bcJ()[0].get_type() ) { Error("conjunction:set_properties Error in the junction type of daughter arteries") ;}
    }

    if ( typeJ.compare("jA") == 0 || typeJ.compare("jAQ") == 0 ) {

      // Define cross-sectional area of junction
      a0 = ZERO ; A = ZERO ;
      SCALAR a0p = TWENTY , a0pm = ZERO , a0d = ZERO , a0dm = ZERO ;
      // Daughter arteries
      for ( int i=0; i < ndarts ; i++) {
        a0d   = MAX( a0d, darts[i]->get_inlet().get_a0()[0] ) ;
        a0dm += darts[i]->get_inlet().get_a0()[0] / double(ndarts) ;
        A     = MAX( A,   darts[i]->get_inlet().get_A ()[0] ) ;
      }
      for ( int i=0; i < nparts ; i++) {
        a0p   = MIN( a0p, parts[i]->get_outlet().get_a0()[0] ) ;
        a0pm += parts[i]->get_outlet().get_a0()[0] / double(nparts) ;
      }
      // Verify that a0 < a0_parent
      if (a0p >= a0d ) {
        a0 = a0d ;
      }
      else {
        a0 = ONEsTWO * (a0pm+a0dm) ;
      }

      // Define equivalent length of junction
      l = ZERO ;
      // Parent arteries
      for ( int i=0; i < nparts ; i++) {
        l     += parts[i]->get_outlet().get_dx()[0] ;
      }
      // Daughter arteries
      for ( int i=0; i < ndarts ; i++) {
        l     += darts[i]->get_inlet().get_dx()[0] ;
      }

      // Define geometrical properties of junction
      // Parent arteries
      for ( int i=0; i < nparts ; i++) {
        rho   += parts[i]->get_cells  ().get_rho()    / double(nparts) / TWO ;
        k     += parts[i]->get_outlet ().get_k  ()[0] / double(nparts) / TWO ;
        phi   += parts[i]->get_cells  ().get_phi()[parts[i]->get_cells().get_nx()-1] / double(nparts) / TWO ;
        mu0   += parts[i]->get_cells  ().get_mu0()[parts[i]->get_cells().get_nx()-1] / double(nparts) / TWO ;
        mu1   += parts[i]->get_cells  ().get_mu1()[parts[i]->get_cells().get_nx()-1] / double(nparts) / TWO ;
        kmu   += parts[i]->get_cells  ().get_kmu()[parts[i]->get_cells().get_nx()-1] / double(nparts) / TWO ;
        amu   += parts[i]->get_cells  ().get_amu()[parts[i]->get_cells().get_nx()-1] / double(nparts) / TWO ;
      }
      // Daughter arteries
      for ( int i=0; i < ndarts ; i++) {
        rho   += darts[i]->get_cells().get_rho()    / double(ndarts) / TWO ;
        k     += darts[i]->get_inlet().get_k  ()[0] / double(ndarts) / TWO ;
        phi   += darts[i]->get_cells().get_phi()[0] / double(ndarts) / TWO ;
        mu0   += darts[i]->get_cells().get_mu0()[0] / double(ndarts) / TWO ;
        mu1   += darts[i]->get_cells().get_mu1()[0] / double(ndarts) / TWO ;
        kmu   += darts[i]->get_cells().get_kmu()[0] / double(ndarts) / TWO ;
        amu   += darts[i]->get_cells().get_amu()[0] / double(ndarts) / TWO ;
      }

      // Check
      printf("Junctio: %Lf,%Lf\n", a0,k);
      for ( int i=0; i < nparts ; i++) {
        printf("Parent: %Lf,%Lf\n", parts[i]->get_outlet().get_a0()[0],parts[i]->get_outlet ().get_k  ()[0] );
      }
      // Daughter arteries
      for ( int i=0; i < ndarts ; i++) {
        printf("Daughter: %Lf,%Lf\n", darts[i]->get_inlet().get_a0()[0],darts[i]->get_inlet().get_k  ()[0] );
      }

      // Define physical variables of junction
      // Parent arteries
      for ( int i=0; i < nparts ; i++) {
        Q     += parts[i]->get_outlet ().get_Q  ()[0]           / double(nparts) / TWO ;
        E     += Energy ( parts[i]->get_cells ().get_rho(),
                          parts[i]->get_outlet().get_k  ()[0],
                          parts[i]->get_outlet().get_a0 ()[0],
                          parts[i]->get_outlet().get_A  ()[0],
                          parts[i]->get_outlet().get_Q  ()[0] ) / double(nparts) / TWO ;

        H     += parts[i]->get_outlet ().get_H()[0] / double(nparts) / TWO ;
        C     += parts[i]->get_outlet ().get_C()[0] / double(nparts) / TWO ;
        O     += parts[i]->get_outlet ().get_O()[0] / double(nparts) / TWO ;
        F     += parts[i]->get_outlet ().get_F()[0] / double(nparts) / TWO ;
      }
      // Daughter arteries
      for ( int i=0; i < ndarts ; i++) {
        Q     += darts[i]->get_inlet().get_Q  ()[0]             / double(ndarts / TWO) ;
        E     += Energy ( darts[i]->get_cells().get_rho (),
                          darts[i]->get_inlet().get_k   ()[0],
                          darts[i]->get_inlet().get_a0  ()[0],
                          darts[i]->get_inlet().get_A   ()[0],
                          darts[i]->get_inlet().get_Q   ()[0] ) / double(ndarts) / TWO ;

        H     += darts[i]->get_inlet().get_H()[0] / double(ndarts) / TWO ;
        C     += darts[i]->get_inlet().get_C()[0] / double(ndarts) / TWO ;
        O     += darts[i]->get_inlet().get_O()[0] / double(ndarts) / TWO ;
        F     += darts[i]->get_inlet().get_F()[0] / double(ndarts) / TWO ;
      }

      // Define volume quantities
      V0  = a0  * l ;
      V   = A   * l ;
      VQ  = Q   * l ;
      VE  = E   * l ;
      VH  = H   * V ;
      VC  = C   * V ;
      VO  = O   * V ;
      VF  = F   * V ;

      // Define auxillary variables
      G     = shearRate     (phi,A,Q) ;
      Tmu   = shearStressMu (mu0,mu1,G,H,F);
      T     = shearStress   (mu1,G,H,Tmu) ;

      // Unify properties of parent and daughter arteries to insure steady state at rest
      for ( int i=0; i < nparts ; i++) {
        parts[i]->get_outlet().set_k  (0,k)   ; parts[i]->get_outlet().set_k  (1,k) ;
        parts[i]->get_outlet().set_a0 (0,a0)  ; parts[i]->get_outlet().set_a0 (1,a0) ;

        parts[i]->get_outlet().set_A  (0,A)   ; parts[i]->get_outlet().set_A  (1,A) ;
        parts[i]->get_outlet().set_Q  (0,Q)   ; parts[i]->get_outlet().set_Q  (1,Q) ;

        parts[i]->get_outlet().set_H  (0,H)   ; parts[i]->get_outlet().set_H  (1,H) ;
        parts[i]->get_outlet().set_C  (0,C)   ; parts[i]->get_outlet().set_C  (1,C) ;
        parts[i]->get_outlet().set_O  (0,O)   ; parts[i]->get_outlet().set_O  (1,O) ;

        parts[i]->get_outlet().set_F  (0,F)   ; parts[i]->get_outlet().set_F  (1,F) ;

        parts[i]->get_outlet().set_G  (0,G)   ; parts[i]->get_outlet().set_G  (1,G) ;
        parts[i]->get_outlet().set_Tmu(0,Tmu) ; parts[i]->get_outlet().set_Tmu(1,Tmu) ;
        parts[i]->get_outlet().set_T  (0,T)   ; parts[i]->get_outlet().set_T  (1,T) ;
      }
      for ( int i=0; i < ndarts ; i++) {
        darts[i]->get_inlet().set_k   (0,k)   ; darts[i]->get_inlet().set_k   (1,k) ;
        darts[i]->get_inlet().set_a0  (0,a0)  ; darts[i]->get_inlet().set_a0  (1,a0) ;

        darts[i]->get_inlet().set_A   (0,A)   ; darts[i]->get_inlet().set_A   (1,A) ;
        darts[i]->get_inlet().set_Q   (0,Q)   ; darts[i]->get_inlet().set_Q   (1,Q) ;

        darts[i]->get_inlet().set_H   (0,H)   ; darts[i]->get_inlet().set_H   (1,H) ;
        darts[i]->get_inlet().set_C   (0,C)   ; darts[i]->get_inlet().set_C   (1,C) ;
        darts[i]->get_inlet().set_O   (0,O)   ; darts[i]->get_inlet().set_O   (1,O) ;

        darts[i]->get_inlet().set_F   (0,F)   ; darts[i]->get_inlet().set_F   (1,F) ;

        darts[i]->get_inlet().set_G   (0,G)   ; darts[i]->get_inlet().set_G   (1,G) ;
        darts[i]->get_inlet().set_Tmu (0,Tmu) ; darts[i]->get_inlet().set_Tmu (1,Tmu) ;
        darts[i]->get_inlet().set_T   (0,T)   ; darts[i]->get_inlet().set_T   (1,T) ;
      }
    }
  }
}
