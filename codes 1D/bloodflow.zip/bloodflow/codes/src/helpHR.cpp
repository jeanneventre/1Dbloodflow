 #include "helpHR.h"

// The indice l refers to the left side of the interface
// The indice r refers to the right side of the interface
SCALAR recK(  const SCALAR kl,  const SCALAR kr) {
  return max( kl  , kr  ) ;
}
SCALAR recZ( const SCALAR Zl, const SCALAR Zr) {
  return min( Zl , Zr ) ;
}
SCALAR recA(  const SCALAR khr, const SCALAR a0hr, const SCALAR HmZo) {
  return pow( max( ZERO, ONE / khr * ( khr*sqrt(a0hr) + HmZo ) ) , TWO ) ;
}

// The indice l refers to the left side of the cell
// The indice r refers to the right side of the cell
SCALAR recKc(const SCALAR kl, const SCALAR kr) {
  return sqrt(kl*kr) ;
}
SCALAR recZc(const SCALAR Zl, const SCALAR Zr) {
  return ONEsTWO * ( Zl + Zr ) ;
}
