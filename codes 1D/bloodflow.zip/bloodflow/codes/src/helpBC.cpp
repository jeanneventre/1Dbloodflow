#include "helpBC.h"

// The boundary conditions are implemented at first order
// Only a first order reconstruction is used at the boundary faces

//####################################################
// INLET
//####################################################
// Cross-sectional area
VECT inflow_A(const meshCell& cells, const meshBC& inlet, const VECT& inData){
  VECT AQ(2,ZERO) ;
  // Boundary centered values
  SCALAR  k   = inlet.get_k  ()[0] ;
  SCALAR  a0  = inlet.get_a0 ()[0] ;
  SCALAR  A   = inData[0] ;
  // Cell centered values
  SCALAR  rho = cells.get_rho () ;
  SCALAR  kc  = cells.get_k   ()[0] ;
  SCALAR  a0c = cells.get_a0  ()[0] ;
  SCALAR  Ac  = cells.get_A   ()[0] ;
  SCALAR  Qc  = cells.get_Q   ()[0] ;

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  SCALAR  khr = recK(k,kc) ;
  SCALAR  a0hr= pow( recZ(k*sqrt(a0),kc*sqrt(a0c)) / khr , TWO ) ;
  SCALAR  Ar  = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  SCALAR  Qr  = Qc ;
  SCALAR  Al  = recA(khr,a0hr,k*(sqrt(A)-sqrt(a0))) ;

  // Matching of the outgoing characteristic
  // It is important to use the HR reconstructed variables here
  SCALAR W2n  = W2(rho,khr,Ar,Qr) ;
  SCALAR W1n  = W2n + EIGHT * cmk(rho,khr,Al);

  AQ[0]       = A ;
  AQ[1]       = QfromW(AQ[0],W1n,W2n);
  return AQ;
}
// Pressure
VECT inflow_P(const meshCell& cells, const meshBC& inlet, const VECT& inData){
  VECT modData(1,ZERO) ;
  SCALAR inP  = inData[0] ;
  modData[0]  = pow( inP / inlet.get_k()[0] + sqrt(inlet.get_a0()[0]) , TWO );
  VECT AQ     = inflow_A(cells,inlet,modData) ;
  return AQ;
}
// Flow rate
VECT inflow_Q(const meshCell& cells, const meshBC& inlet, const VECT& inData){
  VECT AQ(2,ZERO);
  VECT guess(2,ZERO), par(8,ZERO);
  // Guess for boundary side
  guess[0] = inlet.get_A()[0] ; // A
  guess[1] = inData[0] ;        // Q
  // Parameters
  // Cell centered values
  par[0] = cells.get_A  ()[0] ;
  par[1] = cells.get_Q  ()[0] ;
  // Cell centered geoemtrical and mechanical properties
  par[2] = cells.get_rho() ;
  par[3] = inlet.get_k  ()[0] ;
  par[4] = cells.get_k  ()[0] ;
  par[5] = inlet.get_a0 ()[0] ;
  par[6] = cells.get_a0 ()[0] ;
  // Desired flow rate at the cell interface
  par[7] = inData[0] ;

  AQ = newtonRahpson(fun_inflow_Q, guess, par, int(maxIt), EPSILON);
  return AQ;
}
// Speed
VECT inflow_U(const meshCell& cells, const meshBC& inlet, const VECT& inData) {
  VECT modData(1,ZERO) ;
  SCALAR inU  = inData[0] ;
  modData[0]  = inU * cells.get_A()[0] ;
  VECT AQ     = inflow_Q( cells, inlet, modData );
  return AQ;
}
// Cross-sectional area and flow rate
VECT inflow_AQ(const meshCell& cells, const meshBC& inlet, const VECT& inData) {
  VECT AQ(2,ZERO);
  VECT guess(2,ZERO), par(9,ZERO);
  // Guess for boundary side
  guess[0] = inData[0] ; // A
  guess[1] = inData[1] ; // Q
  // Parameters
  // Cell centered values
  par[0] = cells.get_A  ()[0] ;
  par[1] = cells.get_Q  ()[0] ;
  // Cell centered geoemtrical and mechanical properties
  par[2] = cells.get_rho() ;
  par[3] = inlet.get_k  ()[0] ;
  par[4] = cells.get_k  ()[0] ;
  par[5] = inlet.get_a0 ()[0] ;
  par[6] = cells.get_a0 ()[0] ;
  // Desired cross-section area and flow rate at the cell interface
  par[7] = inData[0] ; // A
  par[8] = inData[1] ; // Q

  AQ = newtonRahpson(fun_inflow_AQ, guess, par, int(maxIt), EPSILON);
  return AQ;
}
// Cross-sectional area and speed
VECT inflow_AU(const meshCell& cells, const meshBC& inlet, const VECT& inData){
  VECT modData(2,ZERO) ;
  SCALAR inA  = inData[0], inU = inData[1] ;
  modData[0]  = inA ;
  modData[1]  = inU * cells.get_A()[0] ;
  VECT AQ     = inflow_AQ( cells, inlet, modData );
  return AQ;
}
// Reflection coefficient
VECT inflow_Rt(const meshCell& cells, const meshBC& inlet, const VECT& inData){
  VECT AQ(2,ZERO);
  // Boundary centered values
  SCALAR  k   = inlet.get_k  ()[0] ;
  SCALAR  a0  = inlet.get_a0 ()[0] ;
  // Cell centered values
  SCALAR  rho = cells.get_rho () ;
  SCALAR  kc  = cells.get_k   ()[0] ;
  SCALAR  a0c = cells.get_a0  ()[0] ;
  SCALAR  Ac  = cells.get_A   ()[0] ;
  SCALAR  Qc  = cells.get_Q   ()[0] ;

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  SCALAR  khr = recK(k,kc) ;
  SCALAR  a0hr= pow( recZ(k*sqrt(a0),kc*sqrt(a0c)) / khr , TWO ) ;
  SCALAR  Ar  = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  SCALAR  Qr  = Qc ;

  // Matching of the outgoing characteristic
  // It is important to use the HR reconstructed variables here
  SCALAR W2n  = W2(rho,khr,Ar,Qr) ;
  SCALAR W1n  = inlet.get_W10() - inData[0] * (W2n - inlet.get_W20()) ;

  AQ[0]       = AfromW(rho,khr,W1n,W2n) ;
  AQ[1]       = QfromW(AQ[0],W1n,W2n) ;
  return AQ;
}
//####################################################
// OUTLET
//####################################################
// Cross-sectional area
VECT outflow_A(const meshCell& cells, const meshBC& outlet, const VECT& outData){
  VECT    AQ(2,ZERO);

  // Boundary centered values
  SCALAR  k   = outlet.get_k  ()[0] ;
  SCALAR  a0  = outlet.get_a0 ()[0] ;
  SCALAR  A   = outData[0] ;
  // Cell centered values
  SCALAR  rho = cells.get_rho () ;
  SCALAR  kc  = cells.get_k   ()[cells.get_nx()-1] ;
  SCALAR  a0c = cells.get_a0  ()[cells.get_nx()-1] ;
  SCALAR  Ac  = cells.get_A   ()[cells.get_nx()-1] ;
  SCALAR  Qc  = cells.get_Q   ()[cells.get_nx()-1] ;

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  SCALAR  khr = recK(kc,k) ;
  SCALAR  a0hr= pow( recZ(kc*sqrt(a0c),k*sqrt(a0)) / khr , TWO ) ;
  SCALAR  Al  = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  SCALAR  Ql  = Qc ;
  SCALAR  Ar  = recA(khr,a0hr,k*(sqrt(A)-sqrt(a0))) ;

  // Matching of the outgoing characteristic
  // It is important to use the HR reconstructed variables here
  SCALAR W1n  = W1(rho,khr,Al,Ql) ;
  SCALAR W2n  = W1n - EIGHT * cmk(rho,khr,Ar) ;

  AQ[0]       = A ;
  AQ[1]       = QfromW(AQ[0],W1n,W2n) ;
  return AQ;
}
// Pressure
VECT outflow_P(const meshCell& cells, const meshBC& outlet, const VECT& outData){
  VECT modData(1,ZERO) ;
  SCALAR outP = outData[0] ;
  modData[0]  = pow( outP / outlet.get_k()[0] + sqrt(outlet.get_a0()[0]) , TWO );
  VECT AQ     = outflow_A(cells,outlet,modData) ;
  return AQ;
}
// Flow rate
VECT outflow_Q(const meshCell& cells, const meshBC& outlet, const VECT& outData){
  VECT AQ(2,ZERO);
  VECT guess(2,ZERO), par(8,ZERO);
  // Guess for boundary side
  guess[0] = outlet.get_A()[0] ;  // A
  guess[1] = outData[0] ;         // Q
  // Parameters
  // Cell centered values
  par[0] = cells.get_A    ()[cells.get_nx()-1] ;
  par[1] = cells.get_Q    ()[cells.get_nx()-1] ;
  // Cell centered geoemtrical and mechanical properties
  par[2] = cells.get_rho  () ;
  par[3] = outlet.get_k   ()[0] ;
  par[4] = cells.get_k    ()[cells.get_nx()-1] ;
  par[5] = outlet.get_a0  ()[0] ;
  par[6] = cells.get_a0   ()[cells.get_nx()-1] ;
  // Desired flow rate at the cell interface
  par[7] = outData[0] ;

  AQ = newtonRahpson(fun_outflow_Q, guess, par, int(maxIt), EPSILON);
  return AQ;
}
// Speed
VECT outflow_U(const meshCell& cells, const meshBC& outlet, const VECT& outData) {
  VECT modData(1,ZERO) ;
  SCALAR outU = outData[0] ;
  modData[0]  = outU * cells.get_A()[cells.get_nx()-1] ;
  VECT AQ     = outflow_Q( cells, outlet, modData );
  return AQ;
}
// Cross-sectional area and flow rate
VECT outflow_AQ(const meshCell& cells, const meshBC& outlet, const VECT& outData){
  VECT AQ(2,ZERO);
  VECT guess(2,ZERO), par(9,ZERO);
  // Guess for boundary side
  guess[0] = outData[0] ; // A
  guess[1] = outData[1] ; // Q
  // Parameters
  // Cell centered values
  par[0] = cells.get_A    ()[cells.get_nx()-1] ;
  par[1] = cells.get_Q    ()[cells.get_nx()-1] ;
  // Cell centered geoemtrical and mechanical properties
  par[2] = cells.get_rho  () ;
  par[3] = outlet.get_k   ()[0] ;
  par[4] = cells.get_k    ()[cells.get_nx()-1] ;
  par[5] = outlet.get_a0  ()[0] ;
  par[6] = cells.get_a0   ()[cells.get_nx()-1] ;
  // Desired flow rate at the cell interface
  par[7] = outData[0] ; // A
  par[8] = outData[1] ; // Q

  AQ = newtonRahpson(fun_outflow_AQ, guess, par, int(maxIt), EPSILON);
  return AQ;
}
// Reflection coefficient
VECT outflow_Rt(const meshCell& cells, const meshBC& outlet, const VECT& outData){
  VECT AQ(2,ZERO);

  // Boundary centered values
  SCALAR  k   = outlet.get_k  ()[0] ;
  SCALAR  a0  = outlet.get_a0 ()[0] ;
  // Cell centered values
  SCALAR  rho = cells.get_rho () ;
  SCALAR  kc  = cells.get_k   ()[cells.get_nx()-1] ;
  SCALAR  a0c = cells.get_a0  ()[cells.get_nx()-1] ;
  SCALAR  Ac  = cells.get_A   ()[cells.get_nx()-1] ;
  SCALAR  Qc  = cells.get_Q   ()[cells.get_nx()-1] ;

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  SCALAR  khr = recK(kc,k) ;
  SCALAR  a0hr= pow( recZ(kc*sqrt(a0c),k*sqrt(a0)) / khr , TWO ) ;
  SCALAR  Al  = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  SCALAR  Ql  = Qc ;

  // Matching of the outgoing characteristic
  // It is important to use the HR reconstructed variables here
  SCALAR W1n  = W1(rho,khr,Al,Ql) ;
  SCALAR W2n  = outlet.get_W20() - outData[0] * (W1n - outlet.get_W10()) ;

  AQ[0]       = AfromW(rho,khr,W1n,W2n) ;
  AQ[1]       = QfromW(AQ[0],W1n,W2n) ;
  return AQ;
}
// Resistance
VECT outflow_R(const meshCell& cells, const meshBC& outlet, const VECT& outData){
  VECT AQ(2,ZERO);
  VECT guess(2,ZERO), par(9,ZERO);
  // Guess for boundary side
  guess[0] = outlet.get_A()[0] ;
  guess[1] = outlet.get_Q()[0] ;
  // Parameters
  // Cell centered values
  par[0] = cells.get_A    ()[cells.get_nx()-1] ;
  par[1] = cells.get_Q    ()[cells.get_nx()-1] ;
  // Cell centered geoemtrical and mechanical properties
  par[2] = cells.get_rho  () ;
  par[3] = outlet.get_k   ()[0] ;
  par[4] = cells.get_k    ()[cells.get_nx()-1] ;
  par[5] = outlet.get_a0  ()[0] ;
  par[6] = cells.get_a0   ()[cells.get_nx()-1] ;
  // Desired flow rate at the cell interface
  par[7] = outData[0] ; // Pcap
  par[8] = outData[1] ; // R

  AQ = newtonRahpson(fun_outflow_R, guess, par, int(maxIt), EPSILON);
  return AQ;
}
// Resistance and compliance
VECT outflow_RC(const meshCell& cells, const meshBC& outlet, const VECT& outData){
  VECT AQ(2,ZERO);
  VECT guess(2,ZERO), par(12,ZERO);
  // Guess for boundary side
  guess[0] = outlet.get_A()[0] ;
  guess[1] = outlet.get_Q()[0] ;
  // Parameters
  // Cell centered values
  par[0] = cells.get_A    ()[cells.get_nx()-1] ;
  par[1] = cells.get_Q    ()[cells.get_nx()-1] ;
  // Cell centered geoemtrical and mechanical properties
  par[2] = cells.get_rho  () ;
  par[3] = outlet.get_k   ()[0] ;
  par[4] = cells.get_k    ()[cells.get_nx()-1] ;
  par[5] = outlet.get_a0  ()[0] ;
  par[6] = cells.get_a0   ()[cells.get_nx()-1] ;
  // Desired flow rate at the cell interface
  par[7]  = outData[0] ; // Pcap
  par[8]  = outData[1] ; // R
  par[9]  = outData[2] ; // C
  par[10] = outlet.get_A()[0] ; // Am1
  par[11] = outData[3] ; // dt

  AQ = newtonRahpson(fun_outflow_RC, guess, par, int(maxIt), EPSILON);
  return AQ;
}
// 2 resistances and 1 compliance
VECT outflow_RCR(const meshCell& cells, const meshBC& outlet, const VECT& outData){
  VECT AQ(2,ZERO);
  VECT guess(2,ZERO), par(14,ZERO);
  // Guess for boundary side
  guess[0] = outlet.get_A()[0] ;
  guess[1] = outlet.get_Q()[0] ;
  // Parameters
  // Cell centered values
  par[0] = cells.get_A    ()[cells.get_nx()-1] ;
  par[1] = cells.get_Q    ()[cells.get_nx()-1] ;
  // Cell centered geoemtrical and mechanical properties
  par[2] = cells.get_rho  () ;
  par[3] = outlet.get_k   ()[0] ;
  par[4] = cells.get_k    ()[cells.get_nx()-1] ;
  par[5] = outlet.get_a0  ()[0] ;
  par[6] = cells.get_a0   ()[cells.get_nx()-1] ;
  // Desired flow rate at the cell interface
  par[7]  = outData[0] ; // Pcap
  par[8]  = outData[1] ; // R1
  par[9]  = outData[2] ; // R2
  par[10] = outData[3] ; // C
  par[11] = outlet.get_A()[0] ; // Am1
  par[12] = outlet.get_Q()[0] ; // Qm1
  par[13] = outData[4] ; // dt

  AQ = newtonRahpson(fun_outflow_RCR, guess, par, int(maxIt), EPSILON);
  return AQ;
}
//####################################################
// HELP FUNCTIONS
//####################################################
VECT fun_inflow_Q(const VECT& AQ, const VECT& par){
  // The subscript c refers to the cell centered inside the physical domain
  // The subscripts l and r refer respectively to the values at the left and right of interface

  VECT    F(4,ZERO) , res(2,ZERO) ;
  SCALAR  khr=ZERO, a0hr=ZERO ;
  SCALAR  Al=ZERO,  Ar=ZERO,  Ql=ZERO, Qr=ZERO ;
  SCALAR  FA=ZERO,  FAc=ZERO, FQ=ZERO ;

  // Boundary centered values
  SCALAR  A = AQ[0], Q = AQ[1] ;
  // Cell centered values
  SCALAR  Ac  = par[0] , Qc   = par[1] ;
  SCALAR  rho = par[2] ;
  SCALAR  k   = par[3] , kc   = par[4] ;
  SCALAR  a0  = par[5] , a0c  = par[6] ;
  SCALAR  inQ = par[7] ;

  // We do not reconstruct at a higher order

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  khr   = recK(k,kc) ;
  a0hr  = pow( recZ(k*sqrt(a0),kc*sqrt(a0c)) / khr , TWO ) ;
  Al    = recA(khr,a0hr,k*(sqrt(A)-sqrt(a0))) ;
  Ar    = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  Ql    = Q ;
  Qr    = Qc ;

  // Compute the flux
  F = flux_hat(rho,khr,Al,Ar,Ql,Qr) ;
  FA = F[0] ; FAc = F[1] ; FQ = F[2] ;

  // Upwind decentering of the boundary condition:
  if (inQ - FAc <= ZERO) {
    res[0] = FA ; res[1] = FQ ;
  }
  else {
    // FAp + Fam = Q at the interface
    res[0] = FA + FAc - inQ;
    // Matching of the outgoing characteristic
    // It is important to use the HR reconstructed variables here
    res[1] = W2(rho,khr,Al,Ql) - W2(rho,khr,Ar,Qr) ;
  }
  return res;
}
VECT fun_inflow_AQ(const VECT& AQ, const VECT& par){
  // The subscript c refers to the cell centered inside the physical domain
  // The subscripts l and r refer respectively to the values at the left and right of interface

  VECT    F(4,ZERO) , res(2,ZERO) ;
  SCALAR  khr=ZERO, a0hr=ZERO ;
  SCALAR  Al=ZERO,  Ar=ZERO,  Ql=ZERO, Qr=ZERO ;
  SCALAR  FA=ZERO,  FAc=ZERO, FQ=ZERO ;

  // Boundary centered values
  SCALAR  A = AQ[0], Q = AQ[1] ;
  // Cell centered values
  SCALAR  Ac  = par[0] , Qc   = par[1] ;
  SCALAR  rho = par[2] ;
  SCALAR  k   = par[3] , kc   = par[4] ;
  SCALAR  a0  = par[5] , a0c  = par[6] ;
  SCALAR  inA = par[7] , inQ  = par[8] ;

  // We do not reconstruct at a higher order

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  khr   = recK(k,kc) ;
  a0hr  = pow( recZ(k*sqrt(a0),kc*sqrt(a0c)) / khr , TWO ) ;
  Al    = recA(khr,a0hr,k*(sqrt(A)-sqrt(a0))) ;
  Ar    = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  Ql    = Q ;
  Qr    = Qc ;

  // Compute the flux
  F = flux_hat(rho,khr,Al,Ar,Ql,Qr) ;
  FA = F[0] ; FAc = F[1] ; FQ = F[2] ;

  // Upwind decentering of the boundary condition:
  if (inQ - FAc <= ZERO) {
    res[0] = FA ; res[1] = FQ ;
  }
  else {
    // FAp + Fam = Q at the interface
    res[0] = FA + FAc - inQ;
    // Matching of the outgoing characteristic
    res[1] = A - inA ;
  }
  return res;
}
VECT fun_outflow_Q(const VECT& AQ, const VECT& par){
  // The subscript c refers to the cell centered inside the physical domain
  // The subscripts l and r refer respectively to the values at the left and right of interface

  VECT    F(4,ZERO) , res(2,ZERO) ;
  SCALAR  khr=ZERO, a0hr=ZERO ;
  SCALAR  Al=ZERO,  Ar=ZERO,  Ql=ZERO, Qr=ZERO ;
  SCALAR  FA=ZERO,  FAc=ZERO, FQ=ZERO ;

  // Boundary centered values
  SCALAR  A = AQ[0], Q = AQ[1] ;
  // Cell centered values
  SCALAR  Ac  = par[0] , Qc   = par[1] ;
  SCALAR  rho = par[2] ;
  SCALAR  k   = par[3] , kc   = par[4] ;
  SCALAR  a0  = par[5] , a0c  = par[6] ;
  SCALAR  outQ= par[7] ;

  // We do not reconstruct at a higher order

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  khr   = recK(kc,k) ;
  a0hr  = pow( recZ(kc*sqrt(a0c),k*sqrt(a0)) / khr , TWO ) ;
  Al    = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  Ar    = recA(khr,a0hr,k*(sqrt(A)-sqrt(a0))) ;
  Ql    = Qc ;
  Qr    = Q ;

  // Compute the flux
  F = flux_hat(rho,khr,Al,Ar,Ql,Qr) ;
  FAc = F[0] ; FA = F[1] ; FQ = F[3] ;

  // Upwind decentering of the boundary condition:
  if (outQ - FAc >= ZERO) {
    res[0] = FA ; res[1] = FQ ;
  }
  else {
    // FAp + Fam = Q at the interface
    res[0] = FA + FAc - outQ;
    // Matching of the outgoing characteristic
    // It is important to use the HR reconstructed variables here
    res[1] = W1(rho,khr,Ar,Qr) - W1(rho,khr,Al,Ql) ;
  }
  return res;
}
VECT fun_outflow_AQ(const VECT& AQ, const VECT& par){
  // The subscript c refers to the cell centered inside the physical domain
  // The subscripts l and r refer respectively to the values at the left and right of interface

  VECT    F(4,ZERO) , res(2,ZERO) ;
  SCALAR  khr=ZERO, a0hr=ZERO ;
  SCALAR  Al=ZERO,  Ar=ZERO,  Ql=ZERO, Qr=ZERO ;
  SCALAR  FA=ZERO,  FAc=ZERO, FQ=ZERO ;

  // Boundary centered values
  SCALAR  A = AQ[0], Q = AQ[1] ;
  // Cell centered values
  SCALAR  Ac  = par[0] , Qc   = par[1] ;
  SCALAR  rho = par[2] ;
  SCALAR  k   = par[3] , kc   = par[4] ;
  SCALAR  a0  = par[5] , a0c  = par[6] ;
  SCALAR  outA= par[7] , outQ = par[8] ;

  // We do not reconstruct at a higher order

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  khr   = recK(kc,k) ;
  a0hr  = pow( recZ(kc*sqrt(a0c),k*sqrt(a0)) / khr , TWO ) ;
  Al    = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  Ar    = recA(khr,a0hr,k*(sqrt(A)-sqrt(a0))) ;
  Ql    = Qc ;
  Qr    = Q ;

  // Compute the flux
  F = flux_hat(rho,khr,Al,Ar,Ql,Qr) ;
  FAc = F[0] ; FA = F[1] ; FQ = F[3] ;

  // Upwind decentering of the boundary condition:
  if (outQ - FAc >= ZERO) {
    res[0] = FA ; res[1] = FQ ;
  }
  else {
    // FAp + Fam = Q at the interface
    res[0] = FA + FAc - outQ;
    // Matching of the outgoing characteristic
    res[1] = A - outA ;
  }
  return res;
}
VECT fun_outflow_R(const VECT& AQ, const VECT& par){
  // The subscript c refers to the cell centered inside the physical domain
  // The subscripts l and r refer respectively to the values at the left and right of interface

  VECT    F(4,ZERO) , res(2,ZERO) ;
  SCALAR  khr=ZERO, a0hr=ZERO ;
  SCALAR  Al=ZERO,  Ar=ZERO,  Ql=ZERO, Qr=ZERO ;

  // Boundary centered values
  SCALAR  A = AQ[0], Q = AQ[1] ;
  // Cell centered values
  SCALAR  Ac  = par[0] , Qc   = par[1] ;
  SCALAR  rho = par[2] ;
  SCALAR  k   = par[3] , kc   = par[4] ;
  SCALAR  a0  = par[5] , a0c  = par[6] ;
  SCALAR  outP= par[7] , outR = par[8];

  // We do not reconstruct at a higher order

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  khr   = recK(kc,k) ;
  a0hr  = pow( recZ(kc*sqrt(a0c),k*sqrt(a0)) / khr , TWO ) ;
  Al    = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  Ar    = recA(khr,a0hr,k*(sqrt(A)-sqrt(a0))) ;
  Ql    = Qc ;
  Qr    = Q ;

  // P-Pcap = R * Q
  res[0] = Q - (Pel(k,a0,A) - outP) / outR ;
  // Matching of the outgoing characteristic
  // It is important to use the HR reconstructed variables here
  res[1] = W1(rho,khr,Ar,Qr) - W1(rho,khr,Al,Ql) ;

  return res;

}
VECT fun_outflow_RC(const VECT& AQ, const VECT& par){
  // The subscript c refers to the cell centered inside the physical domain
  // The subscripts l and r refer respectively to the values at the left and right of interface

  VECT    F(4,ZERO) , res(2,ZERO) ;
  SCALAR  khr=ZERO, a0hr=ZERO ;
  SCALAR  Al=ZERO,  Ar=ZERO,  Ql=ZERO, Qr=ZERO ;

  // Boundary centered values
  SCALAR  A = AQ[0], Q = AQ[1] ;
  // Cell centered values
  SCALAR  Ac  = par[0] , Qc   = par[1] ;
  SCALAR  rho = par[2] ;
  SCALAR  k   = par[3] , kc   = par[4] ;
  SCALAR  a0  = par[5] , a0c  = par[6] ;
  SCALAR  outP= par[7] , outR = par[8] , outC = par[9] ;
  SCALAR  Am1 = par[10], dt   = par[11];

  // We do not reconstruct at a higher order

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  khr   = recK(kc,k) ;
  a0hr  = pow( recZ(kc*sqrt(a0c),k*sqrt(a0)) / khr , TWO ) ;
  Al    = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  Ar    = recA(khr,a0hr,k*(sqrt(A)-sqrt(a0))) ;
  Ql    = Qc ;
  Qr    = Q ;

  // P-Pcap = R * Q
  res[0] = - outC * (Pel(k,a0,A) - Pel(k,a0,Am1)) + dt * ( Q - (Pel(k,a0,A) - outP) / outR );
  // Matching of the outgoing characteristic
  // It is important to use the HR reconstructed variables here
  res[1] = W1(rho,khr,Ar,Qr) - W1(rho,khr,Al,Ql) ;

  return res;
}
VECT fun_outflow_RCR(const VECT& AQ, const VECT& par){
  // The subscript c refers to the cell centered inside the physical domain
  // The subscripts l and r refer respectively to the values at the left and right of interface

  VECT    F(4,ZERO) , res(2,ZERO) ;
  SCALAR  khr=ZERO, a0hr=ZERO ;
  SCALAR  Al=ZERO,  Ar=ZERO,  Ql=ZERO, Qr=ZERO ;

  // Boundary centered values
  SCALAR  A = AQ[0], Q = AQ[1] ;
  // Cell centered values
  SCALAR  Ac  = par[0] , Qc   = par[1] ;
  SCALAR  rho = par[2] ;
  SCALAR  k   = par[3] , kc   = par[4] ;
  SCALAR  a0  = par[5] , a0c  = par[6] ;
  SCALAR  outP= par[7] , outR1= par[8] , outR2= par[9] , outC = par[10] ;
  SCALAR  Am1 = par[11], Qm1  = par[12], dt   = par[13];

  // We do not reconstruct at a higher order

  // Hydrostatic reconstruction (only k, a0 and A)
  // We do not need cell centered values as we do not use the momentum flux FQ
  khr   = recK(kc,k) ;
  a0hr  = pow( recZ(kc*sqrt(a0c),k*sqrt(a0)) / khr , TWO ) ;
  Al    = recA(khr,a0hr,kc*(sqrt(Ac)-sqrt(a0c))) ;
  Ar    = recA(khr,a0hr,k*(sqrt(A)-sqrt(a0))) ;
  Ql    = Qc ;
  Qr    = Q ;

  // P-Pcap = R * Q
  res[0] = outC * (Q - Qm1) - outC/outR1 * (Pel(k,a0,A) - Pel(k,a0,Am1)) + dt * ( (ONE/outR1 + ONE/outR2) * Q - (Pel(k,a0,A) - outP) / outR1 / outR2 );
  // Matching of the outgoing characteristic
  // It is important to use the HR reconstructed variables here
  res[1] = W1(rho,khr,Ar,Qr) - W1(rho,khr,Al,Ql) ;

  return res;
}
