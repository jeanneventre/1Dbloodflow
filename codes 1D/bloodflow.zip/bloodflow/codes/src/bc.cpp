#include "bc.h"

bc::bc () {}

bc::bc (const string& _type, const VECT& _data) {
    type = _type;
    data = _data;
}

bc::~bc () {}
