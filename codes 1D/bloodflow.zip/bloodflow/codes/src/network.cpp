#include "network.h"

network::network(const string& paraFolder) {

    // Create class to store all file names
    file dataFile ; // Use default constructor

    dataFile.set_dagFile          (paraFolder + "DAG.csv");
    dataFile.set_bcFile           (paraFolder + "/inout.csv");
    dataFile.set_bcpropertiesFile (paraFolder + "Parameters/inoutParam.csv");
    dataFile.set_propertiesFile   (paraFolder + "Parameters/systemic_network.csv");
    dataFile.set_dxFile           (paraFolder + "Parameters/dx.csv");
    dataFile.set_a0File           (paraFolder + "Parameters/A0.csv");
    dataFile.set_kFile            (paraFolder + "Parameters/K.csv");
    dataFile.set_cvFile           (paraFolder + "Parameters/Cv.csv");
    dataFile.set_knlFile          (paraFolder + "Parameters/Knl.csv");

    dataFile.set_phiFile          (paraFolder + "Parameters/phi.csv");
    dataFile.set_mu0File          (paraFolder + "Parameters/mu0.csv");
    dataFile.set_mu1File          (paraFolder + "Parameters/mu1.csv");
    dataFile.set_kmuFile          (paraFolder + "Parameters/kmu.csv");
    dataFile.set_amuFile          (paraFolder + "Parameters/amu.csv");

    dataFile.set_initAFile        (paraFolder + "Parameters/initA.csv");
    dataFile.set_initQFile        (paraFolder + "Parameters/initQ.csv");
    dataFile.set_initFFile        (paraFolder + "Parameters/initF.csv");
    dataFile.set_initHFile        (paraFolder + "Parameters/initH.csv");
    dataFile.set_initCFile        (paraFolder + "Parameters/initC.csv");
    dataFile.set_initOFile        (paraFolder + "Parameters/initO.csv");

    dataFile.set_outputFile       (paraFolder + "/output.csv");
    dataFile.set_timeFile         (paraFolder + "/time.csv");

    // Parse all input files
    parser fileParser(dataFile);

    // Get the number of arteries and resize vP
    nart  = fileParser.nSet(			(dataFile.get_propertiesFile()).c_str());
    // Get the number of boundary conditions
  	nbc  = fileParser.nSet(				(dataFile.get_bcFile()).c_str());

    vP.resize(nart) ;

    // Set vessel properties
    fileParser.propertiesSet(vP,nart) ;
    // Set boundary properties
    fileParser.bcSet(vP,nbc) ;
    // Set boundary parameters
    fileParser.bcpropertiesSet(vP,nart) ;

    // Set time properties
    timenet.set_n(0) ;
    fileParser.tSet(timenet);
    if ( (int( timenet.get_te()/timenet.get_dt()) != timenet.get_nt()) && (floor( timenet.get_te()/timenet.get_dt()) != timenet.get_nt()) && (ceil( timenet.get_te()/timenet.get_dt()) != timenet.get_nt()) ) {
      if ( (int( timenet.get_te()/timenet.get_dt()) - 1 != timenet.get_nt()) && (int( timenet.get_te()/timenet.get_dt()) + 1 != timenet.get_nt()) ) {
        printf("\nint(te/dt)=%d, ,nt=%d\n", int( timenet.get_te()/timenet.get_dt()), timenet.get_nt() );
        Error("network: int( te/dt) != nt");
      }
    }

    // Set output
    fileParser.outputSet(outnet);

    // Create arteries
    arts.resize(nart,0);     // contains pointers to artery
    for (int i=0; i< nart; i++) {
      appointSolver(arts[i],vP[i],timenet);
    }

    // Create conjunctionNums
    nconj = fileParser.dagSet(arts,conjs) ;
    if ( nconj != int(conjs.size())  ) {
      printf("\nnconjs=%d, ,conjs.size()=%d\n", nconj, int(conjs.size()) );
      Error("network: nconjs != conjs.size()");
    }
    // Set conjunction properties
    for (int i=0; i < nconj ; i++) {
      conjs[i]->set_properties() ;
    }

    // Initialize residu
    resnet.set_resA   ( ZERO ) ;
    resnet.set_resQ   ( ZERO ) ;

    printf("\nNetwork definition\n") ;
    printf("#########################################\n") ;
		printf("Number of arteries        : %d\n" , nart );
		printf("Number of conjunctions    : %d\n" , nconj );
    printf("Number of imposed BC      : %d\n" , nbc );

    printf("Time definition\n") ;
    printf("#########################################\n") ;
		printf("Number of time steps      : %d\n"       , timenet.get_nt() );
    printf("CFL condition             : %.14Lf\n"   , timenet.get_cfl() );
    printf("Time order                : %d\n"       , timenet.get_order() );
		printf("Time step                 : %.14Lf\n"   , timenet.get_dt() );
    printf("Final time                : %.14Lf\n"   , timenet.get_te() );

    printf("Output definition\n") ;
    printf("#########################################\n") ;
		printf("Number of output arteries : %d\n"       , outnet.size_storeArt() );
		printf("Number of output positions: %d\n\n"     , outnet.size_posRecord() );

}

network::~network()  {printf("\n%s\n\n", "network deleted." );}
//####################################################
// Run Sequential
//####################################################
void network::run(){

  // Open data files
  openFile() ;

  int prin = 1;

  // Store initial data
  writeToFile(ZERO);

  // Verbose for arteries
  arts[0]->verbose(timenet);

  // Temporal loop
  //###################
  for (int it = 1; it < timenet.get_nt() ; it++){

    // Check NaN
    if ( it%100==0 ) {
      for ( uint iArt=0; iArt<arts.size(); iArt++) {
        check_nan(iArt) ;
      }
    }

    if (it != timenet.get_n()+1) {
      printf("\nit=%d, \t n=%d\n", it, timenet.get_n()+1 );
      Error("network::run it != timenet.get_n()+1");
    }

    if ( abs(timenet.get_t(it) - double(it*timenet.get_dt())) > EPSILON_T ) {
      printf("\nt=%.14f, \t it*dt=%.14f\n", double(timenet.get_t(it)), double(it*timenet.get_dt()) );
      Error("network::run timenet.get_t(it) != double(it*timenet.get_nt())");
    }

    if ( int(0.01 * prin * timenet.get_nt()) == it){

      // Check if time step verifies CFL condition
      check_dt() ;
      // Compute residu
      get_residu(resnet);

      printf("Completion      : %5.2f %% \n" , 100.*double(it) / double(timenet.get_nt()) );
      printf("      Iteration : %d\n"         , it );
      printf("      Time      : %5.10f\n"        , double( it * timenet.get_dt())  );
      printf("      Time step : dt=%1.8f, dtCFL=%1.8f\n" ,  double(timenet.get_dt()), double(timenet.get_dtcfl()));
      printf("Residu          :\n");
      printf("              A : %1.14f\n" ,  double(resnet.get_resA()));
      printf("              Q : %1.14f\n" ,  double(resnet.get_resQ()));

      fflush(stdout);
      prin++;
    }

    // Unsteady loop

    // Set conjunction properties
    for(int i=0; i < nconj; i++) {
      conjs[i]->stepConj(timenet);
    }
    // Set boundary conditions
    for(int i=0; i < nart; i++) {
      arts[i]->stepBC(timenet);
    }
    // Time advance
    for(int i=0; i < nart; i++) {
      arts[i]->step(timenet);
    }

    // Update n
    timenet.set_n(it);

    if( it%timenet.get_nstore()==0 && timenet.get_t(it) >= timenet.get_ts() ){
      writeToFile(timenet.get_t(it));
    }

  } // END TEMPORAL LOOP

  // Store Final Time
  writeToFile(timenet.get_t( timenet.get_nt()-1 ));
  closeFile();

  cout<<"End of computation."<<endl;

}
//####################################################
// Run in parallel
//####################################################
void network::run_omp(){

  // Open data files
  openFile() ;

  int prin = 1;

  // Store initial data
  writeToFile(ZERO);

  // Verbose for arteries
  arts[0]->verbose(timenet);

  // Define number of threads
  int nthreads ;
  char* p_OMP_NUM = NULL;
  p_OMP_NUM = getenv ("OMP_NUM_THREADS");
  if (p_OMP_NUM!=NULL){
      int omp_num = atoi(p_OMP_NUM);
      if( omp_num > int(arts.size()) ){
        omp_set_num_threads(arts.size());
      }
      else {
        omp_set_num_threads(omp_num);
      }
  }
  else {
    Error("network::rum_omp OMP_NUM_THREADS is undefined") ;
  }

  // Temporal loop
  //###################
  for (int it = 1; it < timenet.get_nt() ; it++){

    // Check NaN
    if ( it%100==0 ) {
      for ( uint iArt=0; iArt<arts.size(); iArt++) {
        check_nan(iArt) ;
      }
    }

    if (it != timenet.get_n()+1) {
      printf("\nit=%d, \t n=%d\n", it, timenet.get_n()+1 );
      Error("network::run it != timenet.get_n()+1");
    }

    if ( abs(timenet.get_t(it) - double(it*timenet.get_dt())) > EPSILON_T ) {
      printf("\nt=%.14f, \t it*dt=%.14f\n", double(timenet.get_t(it)), double(it*timenet.get_dt()) );
      Error("network::run timenet.get_t(it) != double(it*timenet.get_nt())");
    }

    if ( int(0.01 * prin * timenet.get_nt()) == it){

      // Check if time step verifies CFL condition
      check_dt() ;
      // Compute residu
      get_residu(resnet);

      printf("Completion      : %5.2f %% \n" , 100.*double(it) / double(timenet.get_nt()) );
      printf("      Iteration : %d\n"         , it );
      printf("      Time      : %5.10f\n"        , double( it * timenet.get_dt())  );
      printf("      Time step : dt=%1.8f, dtCFL=%1.8f\n" ,  double(timenet.get_dt()), double(timenet.get_dtcfl()));
      printf("Residu          :\n");
      printf("              A : %1.14f\n" ,  double(resnet.get_resA()));
      printf("              Q : %1.14f\n" ,  double(resnet.get_resQ()));

      fflush(stdout);
      prin++;
    }

    // Begin openmp
    #pragma omp parallel
    {

    // Get number of threads
    nthreads = omp_get_num_threads() ;
    // Get index of thread
    int ithread = omp_get_thread_num();
    // Define number of junctions treated by the thread
    int cthreads =ceil( nconj / float(nthreads) );
    // Define loop index for junction
    int ics = ithread * cthreads;
    int ice ;
    if( (ithread+1) * cthreads - 1 < nconj - 1 ) {
        ice= (ithread+1) * cthreads-1;
    }
    else {
        ice = nconj - 1;
    }
    // Define number of arteries treated by the thread
    int athreads=ceil( nart / float(nthreads) );
    // Define loop index for artery
    int ias = ithread * athreads;
    int iae ;
    if( (ithread+1) * athreads - 1 < nart - 1 ) {
        iae = (ithread+1) * athreads-1;
    }
    else {
        iae = nart - 1;
    }

    // Unsteady loop

    // Set conjunction properties
    for(int i=ics; i <= ice; i++) {
      conjs[i]->stepConj(timenet);
    }
    // Set boundary conditions
    for(int i=ias; i <= iae; i++) {
      arts[i]->stepBC(timenet);
    }

    #pragma omp barrier

    // Time advance
    for(int i=ias; i <= iae; i++) {
      arts[i]->step(timenet);
    }

    } // End parallel loop

    // Update n
    timenet.set_n(it);

    if( it%timenet.get_nstore()==0 && timenet.get_t(it) >= timenet.get_ts() ){
      writeToFile(timenet.get_t(it));
    }

  } // END TEMPORAL LOOP

  // Store Final Time
  writeToFile(timenet.get_t( timenet.get_nt()-1 ));
  closeFile();

  cout<<"End of computation."<<endl;

}
//####################################################
// Appoint Solver
//####################################################
void network::appointSolver(artery*& art, vesselProperties& vP, time_c& timenet ){

  string solver=vP.get_solver();
  if(solver=="RUS" || solver=="HLL" || solver=="KIN_HAT" || solver=="KIN_SQRT")
      art = new arteryNum(vP,timenet);
  else
      cerr<<" solver <"<< solver<<"> not defined"<<endl;

}
//####################################################
// Writters
//####################################################
void network::openFile(){

  string Artdatafile;
  string Conjdatafile;
  string Residudatafile;

  //Open artery files:
  file_record = (FILE **) malloc( (outnet.size_storeArt()) * sizeof(FILE*));
  for(int i = 0; i < outnet.size_storeArt() ; ++i) {
    char buf[32];
    // now we build the file name
    snprintf(buf, sizeof(char) * 32, "Artery_%i.csv", outnet.get_storeArt(i));
    Artdatafile = dataFolder + "/" + suffix;
    Artdatafile += buf;

    // Check if file exists:
    if ( i == 0 ) {
      if (fileExist(Artdatafile) == 1) {

        printf("\n#########################################\n") ;
        printf("%s\n","Write over artery files: y/n" );

        string choice;

        getline(cin,choice);
        if (choice == "n" || choice == "N") {
          exit(1);
        }
      }
    }

    file_record[i] = fopen(Artdatafile.c_str(), "w");
    fprintf(file_record[i],
           "%s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s \n ",
           "#t [s]","x [cm]","K [g/cm^2/s^2]","A0 [cm^2]",
           "A [cm^2]","Q [cm^3/s]","P [g/cm/s^2]",
           "gamma [s^-1]", "H [cm^{-3}]", "f", "taust [g/cm/s^2]", "tau [g/cm/s^2]",
           "C [cm^{-3}]", "O [cm^{-3}]"
            );
    fflush(file_record[i]);
  }

  //Open conjunction files:
  file_record_junction = (FILE **) malloc( (nconj) * sizeof(FILE*));
  for(int i = 0; i < nconj ; ++i) {
    char buf[32];
    // now we build the file name
    snprintf(buf, sizeof(char) * 32, "Junction_%i.csv", i);
    Conjdatafile = dataFolder + "/" + suffix;
    Conjdatafile += buf;

    // Check if file exists:
    if ( i == 0 ) {
      if (fileExist(Conjdatafile) == 1) {

        printf("%s\n","Write over junction files: y/n" );

        string choice;

        getline(cin,choice);
        if (choice == "n" || choice == "N") {
          exit(1);
        }
      }
    }

    file_record_junction[i] = fopen(Conjdatafile.c_str(), "w");
    fprintf(file_record_junction[i],
           "%s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s,\t %s \n ",
           "#t [s]","l [cm]","K [g/cm^2/s^2]","A0 [cm^2]",
           "A [cm^2]","Q [cm^3/s]","P [g/cm/s^2]",
           "gamma [s^-1]", "H [cm^{-3}]", "f", "taust [g/cm/s^2]", "tau [g/cm/s^2]",
           "C [cm^{-3}]", "O [cm^{-3}]"
            );
    fflush(file_record_junction[i]);
  }

  //Open residu file
  Residudatafile = dataFolder + "/Residu_AQ.csv";
  file_residu = fopen(Residudatafile.c_str(), "w");
  fprintf(file_residu,
         "%s,\t %s,\t %s \n ",
         "#t [s]","res[A]","res[Q]"
          );
  fflush(file_residu);

}
void network::closeFile(){
  //Close artery files:
  for(int i = 0; i < outnet.size_storeArt() ; ++i) {
    fflush(file_record[i]);
    fclose(file_record[i]);
  }
  free(file_record) ;
  //Close junction files:
  for(int i = 0; i < nconj ; ++i) {
    fflush(file_record_junction[i]);
    fclose(file_record_junction[i]);
  }
  free(file_record_junction) ;
  //Close residu file:
  fflush(file_residu);
  fclose(file_residu);
}

void network::writeToFile(const SCALAR _t) const{

    int iArt=0;
    // Loop on all record points
    //#####################
    for(int i=0; i<outnet.size_arteryRecord(); i++) {
      if (outnet.get_arteryRecord(i) != outnet.get_storeArt(iArt) ) {
        fprintf(file_record[iArt], "\n");
        fprintf(file_record[iArt], "\n");
        iArt ++;
      }
      fprintf(file_record[iArt],
          "%20.20Lf ,\t %20.20Lf,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf \n",
          _t,
          arts[outnet.get_arteryRecord(i)]->read_x    (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_k    (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_a0   (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_A    (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_Q    (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_P    (outnet.get_posRecord(i), timenet.get_dt()),
          arts[outnet.get_arteryRecord(i)]->read_G    (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_H    (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_F    (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_Tmu  (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_T    (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_C    (outnet.get_posRecord(i)),
          arts[outnet.get_arteryRecord(i)]->read_O    (outnet.get_posRecord(i))
      );
      fflush(file_record[iArt]);
    }

    fprintf(file_record[iArt], "\n");
    fprintf(file_record[iArt], "\n");
    fflush(file_record[iArt]);

    // Loop on all junction points
    //#####################
    for(int i=0; i<nconj; i++) {
      fprintf(file_record_junction[i],
          "%20.20Lf ,\t %20.20Lf,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf ,\t %20.20Lf \n",
          _t,
          conjs[i]->read_l    (),
          conjs[i]->read_k    (),
          conjs[i]->read_a0   (),
          conjs[i]->read_A    (),
          conjs[i]->read_Q    (),
          conjs[i]->read_P    (),
          conjs[i]->read_G    (),
          conjs[i]->read_H    (),
          conjs[i]->read_F    (),
          conjs[i]->read_Tmu  (),
          conjs[i]->read_T    (),
          conjs[i]->read_C    (),
          conjs[i]->read_O    ()
      );
      fflush(file_record_junction[i]);
    }

    //Write residu
    fprintf(file_residu,
        "%20.20Lf ,\t %20.20Lf ,\t %20.20Lf \n",
        _t,
        resnet.get_resA(),
        resnet.get_resQ()
    );
    fflush(file_residu);
}
//####################################################
// Time Step
//####################################################
void network::check_dt() {
  SCALAR dtcfl = TEN ;
  for (uint n = 0; n < arts.size(); n++) {
    dtcfl = MIN( arts[n]->check_dt(timenet.get_dt(),timenet.get_cfl()) , dtcfl ) ;
  }
  timenet.set_dtcfl(dtcfl) ;
}
void network::check_nan(const int n) {
  for (int i = 0; i < arts[n]->get_cells().get_nx(); i++) {
    if ( isnan(arts[n]->read_A(i)) ) {
      printf("\nArtery %d, A[%d] is NaN\n",n,i);
      Error("NAN") ;
    }
    if ( isnan(arts[n]->read_Q(i)) ) {
      printf("\nArtery %d, Q[%d] is NaN\n",n,i);
      Error("NAN") ;
    }
  }
}
//####################################################
// Residu
//####################################################
void network::get_residu(residu& resnet) {
  SCALAR resA = ZERO, resQ = ZERO ;
  for (uint n = 0; n < arts.size(); n++) {
    resA += arts[n]->get_resA();
    resQ += arts[n]->get_resQ();
  }
  resnet.set_resA(resA/double(arts.size()));
  resnet.set_resQ(resQ/double(arts.size()));
}
//####################################################
// Other
//####################################################
bool network::fileExist (const string& name) {
  return ( access( name.c_str(), F_OK ) != -1 );
}
