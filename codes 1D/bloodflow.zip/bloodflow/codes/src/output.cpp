#include "output.h"

output::output () {}
output::~output ()  {printf("\n%s\n\n", "output deleted." );}
