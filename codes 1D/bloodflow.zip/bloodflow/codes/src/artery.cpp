#include "artery.h"

artery::artery(const vesselProperties& vP, const time_c& timenet) :

  // Numerics
  solver(vP.get_solver()),
  hr(vP.get_hr()),
  xorder(vP.get_order()),
  // Boundary conditions
  bcART(vP.get_artbc())

  {
    // Set cells properties
    set_mesh(vP) ;
    // Set boundaries properties
    set_boundary(vP) ;
    // Set boundary conditions
    set_boundaryConditions() ;

    // Define residu
    resA = ZERO ;
    resQ = ZERO ;
}

artery::~artery() {printf("\n%s\n\n", "artery deleted." );}
//####################################################
// Verbose
//####################################################
void artery::verbose(const time_c& timenet) {

  if (timenet.get_n() == 0) {
    printf("\n%s\n", "Artery definition" );
    printf("#########################################\n") ;
    if (cells.get_mu0()[0] != ZERO || cells.get_mu1()[0] != ZERO) {
      printf("Viscosity        : ON \n");
      printf("    phi   : %Lf \n", cells.get_phi()[0]);
      printf("    mu0   : %Lf \n", cells.get_mu0()[0]);
      printf("    mu1   : %Lf \n", cells.get_mu1()[0]);
      printf("    kmu   : %Lf \n", cells.get_kmu()[0]);
      printf("    amu   : %Lf \n", cells.get_amu()[0]);
      printf("    H     : %Lf \n", cells.get_H()[0]);
      printf("    F     : %Lf \n", cells.get_F()[0]);
    }
    else {printf("Viscosity        : OFF \n");}

    if  (cells.get_cv()[0] != ZERO)     {
      printf("Viscoelasticity  : ON \n");
      printf("    cv    : %Lf \n", cells.get_cv()[0]);
    }
    else                                {printf("Viscoelasticity  : OFF \n");}

    if  (solver.compare("KIN_HAT")==0)  {printf("Numerical Flux   : Kinetic Hat \n");}

    printf("Space Order      : %Lf \n", xorder);

    if  (hr.compare("HRQ")==0)          {printf("HR               : HRQ \n \n");}
  }
}
//####################################################
// Set properties
//####################################################
void artery::set_mesh(const vesselProperties& vP) {
  // Define the cell averaged variables

  // Geoemtrical and mechanical quantities
  cells.set_rho (vP.get_rho());
  cells.set_l   (vP.get_l());
  cells.set_a0  (vP.get_a0());
  cells.set_k   (vP.get_k());
  cells.set_cv  (vP.get_cv());
  cells.set_phi (vP.get_phi());
  cells.set_mu0 (vP.get_mu0());
  cells.set_mu1 (vP.get_mu1());
  cells.set_kmu (vP.get_kmu());
  cells.set_amu (vP.get_amu());

  // Mesh
  cells.set_nx  (vP.get_nx());
  cells.set_dx  (vP.get_dx());
  cells.set_x   (set_x(cells.get_dx(),cells.get_l()));

  // Conservative quantities
  cells.set_A   (vP.get_initA());
  cells.set_Q   (vP.get_initQ());

  // Passive scalars
  cells.set_H   (vP.get_initH());
  cells.set_C   (vP.get_initC());
  cells.set_O   (vP.get_initO());

  // NULL vector
  VECT NUL(cells.get_nx(),ZERO) ;

  // Viscous quantities
  cells.set_F   (vP.get_initF());
  cells.set_G   (NUL);
  cells.set_Tmu (NUL);
  cells.set_T   (NUL);
  for (int i=0; i<cells.get_nx(); i++) {
    cells.set_G   ( i, shearRate      (cells.get_phi()[i], cells.get_A()[i],  cells.get_Q()[i] ));
    cells.set_Tmu ( i, shearStressMu  (cells.get_mu0()[i], cells.get_mu1()[i],cells.get_G()[i], cells.get_H()[i], cells.get_F()[i] )),
    cells.set_T   ( i, shearStress    (cells.get_mu1()[i], cells.get_G()[i],  cells.get_H()[i], cells.get_Tmu()[i] ));
  }

  // Auxillary quantities
  cells.set_Ho( NUL);
  cells.set_HmZo(NUL);

  // rhs and reac variables
  cells.set_RHSA(NUL);
  cells.set_RHSQ(NUL);
  cells.set_RHSF(NUL);
  cells.set_RHSH(NUL);
  cells.set_RHSC(NUL);
  cells.set_RHSO(NUL);

  cells.set_REACQ(NUL);
  cells.set_REACF(NUL);
  cells.set_REACTMU(NUL);

  // Previous time variables
  cells.set_Am1  (vP.get_initA());
  cells.set_Qm1  (vP.get_initQ());
}
void artery::set_boundary(const vesselProperties& vP) {

  // We define two boundary cells for second order reconstruction at BC
  VECT in(2,ZERO) ;
  VECT out(2,ZERO) ;

  // Inlet
  inlet.set_a0    (vP.get_ina0()) ;
  inlet.set_k     (vP.get_ink()) ;

  inlet.set_dx    (vP.get_indx()) ;
  inlet.set_angle (vP.get_inang()) ;
  inlet.set_P     (ZERO) ;

  inlet.set_A   (in) ; inlet.set_A  (0,cells.get_A()[0]) ;    inlet.set_A   (1,cells.get_A()[0]);
  inlet.set_Q   (in) ; inlet.set_Q  (0,cells.get_Q()[0]) ;    inlet.set_Q   (1,cells.get_Q()[0]);

  inlet.set_H   (in) ; inlet.set_H  (0,cells.get_H()[0]) ;    inlet.set_H   (1,cells.get_H()[0]);
  inlet.set_C   (in) ; inlet.set_C  (0,cells.get_C()[0]) ;    inlet.set_C   (1,cells.get_C()[0]);
  inlet.set_O   (in) ; inlet.set_O  (0,cells.get_O()[0]) ;    inlet.set_O   (1,cells.get_O()[0]);

  inlet.set_F   (in) ; inlet.set_F  (0,cells.get_F()[0]) ;    inlet.set_F   (1,cells.get_F()[0]);
  inlet.set_G   (in) ; inlet.set_G  (0,cells.get_G()[0]) ;    inlet.set_G   (1,cells.get_G()[0]);
  inlet.set_Tmu (in) ; inlet.set_Tmu(0,cells.get_Tmu()[0]) ;  inlet.set_Tmu (1,cells.get_Tmu()[0]);
  inlet.set_T   (in) ; inlet.set_T  (0,cells.get_T()[0]) ;    inlet.set_T   (1,cells.get_T()[0]);

  inlet.set_W10( W1(cells.get_rho(),inlet.get_k()[0],inlet.get_A()[0],inlet.get_Q()[0])) ;
  inlet.set_W20( W2(cells.get_rho(),inlet.get_k()[0],inlet.get_A()[0],inlet.get_Q()[0])) ;

  inlet.set_Ho  (in) ;
  inlet.set_HmZo(in) ;

  // Outlet
  outlet.set_k    (vP.get_outk()) ;
  outlet.set_a0   (vP.get_outa0()) ;

  outlet.set_dx   (vP.get_outdx()) ;
  outlet.set_angle(vP.get_outang()) ;
  outlet.set_P    (vP.get_outP()) ;

  outlet.set_A    (out) ; outlet.set_A    (0,cells.get_A()[cells.get_nx()-1]) ;   outlet.set_A  (1,cells.get_A()[cells.get_nx()-1]) ;
  outlet.set_Q    (out) ; outlet.set_Q    (0,cells.get_Q()[cells.get_nx()-1]) ;   outlet.set_Q  (1,cells.get_Q()[cells.get_nx()-1]) ;

  outlet.set_H    (out) ; outlet.set_H    (0,cells.get_H()[cells.get_nx()-1]) ;   outlet.set_H  (1,cells.get_H()[cells.get_nx()-1]) ;
  outlet.set_C    (out) ; outlet.set_C    (0,cells.get_C()[cells.get_nx()-1]) ;   outlet.set_C  (1,cells.get_C()[cells.get_nx()-1]) ;
  outlet.set_O    (out) ; outlet.set_O    (0,cells.get_O()[cells.get_nx()-1]) ;   outlet.set_O  (1,cells.get_O()[cells.get_nx()-1]) ;

  outlet.set_F    (out) ; outlet.set_F    (0,cells.get_F()[cells.get_nx()-1]) ;   outlet.set_F  (1,cells.get_F()[cells.get_nx()-1]) ;
  outlet.set_G    (out) ; outlet.set_G    (0,cells.get_G()[cells.get_nx()-1]) ;   outlet.set_G  (1,cells.get_G()[cells.get_nx()-1]) ;
  outlet.set_Tmu  (out) ; outlet.set_Tmu  (0,cells.get_Tmu()[cells.get_nx()-1]) ; outlet.set_Tmu(1,cells.get_Tmu()[cells.get_nx()-1]) ;
  outlet.set_T    (out) ; outlet.set_T    (0,cells.get_T()[cells.get_nx()-1]) ;   outlet.set_T  (1,cells.get_T()[cells.get_nx()-1]) ;

  outlet.set_W10( W1(cells.get_rho(),outlet.get_k()[0],outlet.get_A()[0],outlet.get_Q()[0])) ;
  outlet.set_W20( W2(cells.get_rho(),outlet.get_k()[0],outlet.get_A()[0],outlet .get_Q()[0])) ;

  outlet.set_Ho   (out) ;
  outlet.set_HmZo (out) ;

  // Properly set second ghost cell
  set_ghostCell() ;

}
void artery::set_ghostCell() {
  // Reconstruct second ghost cell, used only for high order reconstruction
  // We therefore reconstruct only the variables used in arteryNum::reconstructOrder()
  // We use polynomial reconstructions.

  // By default, we use a first order reconstruction as are boundary conditions are of order 1.
  // If a high order is used, then proper implementation of high order boundary conditions must be done

  int order = 1 ;

  if (order != 1) {
    Error("artery::set_ghostCell For high order reconstruction, high order boundary conditions must be implemented") ;
  }

  SCALAR x1=ZERO,x2=ZERO,x3=ZERO ;
  SCALAR y1=ZERO,y2=ZERO,y3=ZERO ;

  // Inlet
  x1  = (inlet.get_dx()[1] + inlet.get_dx()[0]) / TWO ;
  x2  = x1 + (inlet.get_dx()[0] + cells.get_dx()[0]) / TWO ;
  x3  = x1 + x2 + (cells.get_dx()[0] + cells.get_dx()[1]) / TWO ;

  y1  = inlet.get_k()[0]  ; y2 = cells.get_k()[0]  ; y3 = cells.get_k()[1]  ; inlet.set_k (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = inlet.get_a0()[0] ; y2 = cells.get_a0()[0] ; y3 = cells.get_a0()[1] ; inlet.set_a0(1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = inlet.get_A()[0]  ; y2 = cells.get_A()[0]  ; y3 = cells.get_A()[1]  ; inlet.set_A (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = inlet.get_Q()[0]  ; y2 = cells.get_Q()[0]  ; y3 = cells.get_Q()[1]  ; inlet.set_Q (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = inlet.get_H()[0]  ; y2 = cells.get_H()[0]  ; y3 = cells.get_H()[1]  ; inlet.set_H (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = inlet.get_C()[0]  ; y2 = cells.get_C()[0]  ; y3 = cells.get_C()[1]  ; inlet.set_C (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = inlet.get_O()[0]  ; y2 = cells.get_O()[0]  ; y3 = cells.get_O()[1]  ; inlet.set_O (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = inlet.get_F()[0]  ; y2 = cells.get_F()[0]  ; y3 = cells.get_F()[1]  ; inlet.set_F (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;

  // Inlet
  x1  = -(outlet.get_dx()[1] + outlet.get_dx()[0]) / TWO ;
  x2  = x1 - (outlet.get_dx()[0] + cells.get_dx()[cells.get_nx()-1]) / TWO ;
  x3  = x1 + x2 - (cells.get_dx()[cells.get_nx()-1] + cells.get_dx()[cells.get_nx()-2]) / TWO ;

  y1  = outlet.get_k()[0]  ; y2 = cells.get_k()[cells.get_nx()-1]  ; y3 = cells.get_k()[cells.get_nx()-2]  ; outlet.set_k (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = outlet.get_a0()[0] ; y2 = cells.get_a0()[cells.get_nx()-1] ; y3 = cells.get_a0()[cells.get_nx()-2] ; outlet.set_a0(1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = outlet.get_A()[0]  ; y2 = cells.get_A()[cells.get_nx()-1]  ; y3 = cells.get_A()[cells.get_nx()-2]  ; outlet.set_A (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = outlet.get_Q()[0]  ; y2 = cells.get_Q()[cells.get_nx()-1]  ; y3 = cells.get_Q()[cells.get_nx()-2]  ; outlet.set_Q (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = outlet.get_H()[0]  ; y2 = cells.get_H()[cells.get_nx()-1]  ; y3 = cells.get_H()[cells.get_nx()-2]  ; outlet.set_H (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = outlet.get_C()[0]  ; y2 = cells.get_C()[cells.get_nx()-1]  ; y3 = cells.get_C()[cells.get_nx()-2]  ; outlet.set_C (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = outlet.get_O()[0]  ; y2 = cells.get_O()[cells.get_nx()-1]  ; y3 = cells.get_O()[cells.get_nx()-2]  ; outlet.set_O (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;
  y1  = outlet.get_F()[0]  ; y2 = cells.get_F()[cells.get_nx()-1]  ; y3 = cells.get_F()[cells.get_nx()-2]  ; outlet.set_F (1, interpOrder(order,ZERO,x1,y1,x2,y2,x3,y3) ) ;

}
void artery::set_boundaryConditions() {
  for (uint i = 0 ; i < bcART.size() ; i++) {
    // Inlet
    if      ( bcART[i].get_type()=="inA"   || bcART[i].get_type()=="inQ" )  { bcIN.push_back(bcART[i]) ;}
    else if ( bcART[i].get_type()=="inP"   || bcART[i].get_type()=="inU" )  { bcIN.push_back(bcART[i]) ;}
    else if ( bcART[i].get_type()=="inRt"  )                                { bcIN.push_back(bcART[i]) ;}
    else if ( bcART[i].get_type()=="inExA" || bcART[i].get_type()=="inExQ") { bcIN.push_back(bcART[i]) ;}
    // Outlet
    else if ( bcART[i].get_type()=="outA" || bcART[i].get_type()=="outQ" )                                { bcOUT.push_back(bcART[i]) ;}
    else if ( bcART[i].get_type()=="outP" || bcART[i].get_type()=="outU" )                                { bcOUT.push_back(bcART[i]) ;}
    else if ( bcART[i].get_type()=="outRt" )                                                              { bcOUT.push_back(bcART[i]) ;}
    else if ( bcART[i].get_type()=="outR1" || bcART[i].get_type()=="outC1" || bcART[i].get_type()=="outR2") { bcOUT.push_back(bcART[i]) ;}
    else if ( bcART[i].get_type()=="outExA" || bcART[i].get_type()=="outExQ")                             { bcOUT.push_back(bcART[i]) ;}
    // Viscous quantities (Hematocrite & strucutre)
    else if ( bcART[i].get_type()=="inH" || bcART[i].get_type()=="inF")   { bcVIS.push_back(bcART[i]) ;}
    else if ( bcART[i].get_type()=="outH"|| bcART[i].get_type()=="outF")  { bcVIS.push_back(bcART[i]) ;}
    // Passive scalars (Concentration & Oxygen)
    else if ( bcART[i].get_type()=="inC" || bcART[i].get_type()=="inO")   { bcPAS.push_back(bcART[i]) ;}
    else if ( bcART[i].get_type()=="outC" || bcART[i].get_type()=="outO") { bcPAS.push_back(bcART[i]) ;}
    // Junction
    else if (bcART[i].get_type() == "jS" || bcART[i].get_type() == "jA" || bcART[i].get_type() == "jAQ") { bcJUN.push_back(bcART[i]) ;}
    else { Error("artery::set_bc Unknown inlet or outlet boundary type") ;}
  }
}
VECT artery::set_x(const VECT& dx, const SCALAR l) {
  int   n=dx.get_dim();
  VECT  x(n,ZERO);
  x[0] = ONEsTWO * dx[0];
  for (int i=1; i<n; i++) {
      x[i] = x[i-1] +  ONEsTWO * (dx[i-1]+dx[i]) ;
  }
  if (abs(kahanSum(dx) - l) > EPSILON_X) {
    printf("sum=%20.20Lf,L=%20.20Lf,sum-L=%20.20Lf,eps=%20.20Lf\n",kahanSum(dx),l,abs(kahanSum(dx)-l),EPSILON_X );
    Error("set_dx: Error in sum(dx)") ;
  }
  return x ;
}
//####################################################
// Readers
//####################################################
SCALAR artery::read_P(int pos, const SCALAR dt) {
  return    Pel(  cells.get_k()[pos],cells.get_a0()[pos],cells.get_A()[pos])
          + Pvis( dt,cells.get_rho(),cells.get_cv()[pos],cells.get_A()[pos],cells.get_Am1()[pos]) ;

}
//####################################################
// Checkers
//####################################################
SCALAR artery::check_dt(const SCALAR dt, const SCALAR cfl) {
  SCALAR dtmp   = ZERO ;
  SCALAR dtcfl  = ZERO ;
  // Check if time step verifies CFL condition
  for (int i=0; i<cells.get_nx(); i++) {
    dtcfl = cfl * cells.get_dx()[i] / (  abs(cells.get_Q()[i]/cells.get_A()[i])
                                                          + cmk(cells.get_rho(),cells.get_k()[i],cells.get_A()[i])
                                                        ) ;
    dtmp  = MIN(dt,dtcfl) ;
  }

  if ( dtmp != dt ) {
    printf("\ndt=%.14Lf,\t CFL*dx/(u+lambda)=%.14Lf\n", dt, dtmp );
    Error("artery::check_dt Time step is too large.");
    return ZERO ;
  }
  return dtcfl ;
}
