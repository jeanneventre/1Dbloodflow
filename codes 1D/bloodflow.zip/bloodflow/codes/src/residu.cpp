#include "residu.h"

residu::residu () {
  resA    = ZERO ;
  resQ    = ZERO ;
}

residu::~residu () {printf("\n%s\n\n", "residu deleted." );}
