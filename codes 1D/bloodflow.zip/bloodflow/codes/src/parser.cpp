#include "parser.h"

parser::parser(const file& dataFile) {

	readtoString( (dataFile.get_propertiesFile()).c_str()	, propertiesData	);
	readtoMatrix( (dataFile.get_dxFile()).c_str()					,	dxData					);
	readtoMatrix( (dataFile.get_a0File()).c_str()					,	a0Data					);
	readtoMatrix( (dataFile.get_kFile()).c_str()					,	kData						);
	readtoMatrix( (dataFile.get_cvFile()).c_str()					, cvData					);
	readtoMatrix( (dataFile.get_knlFile()).c_str()				, knlData					);

	readtoMatrix( (dataFile.get_phiFile()).c_str()				, phiData					);
	readtoMatrix( (dataFile.get_mu0File()).c_str()				, mu0Data					);
	readtoMatrix( (dataFile.get_mu1File()).c_str()			, mu1Data				);
	readtoMatrix( (dataFile.get_kmuFile()).c_str()				, kmuData					);
	readtoMatrix( (dataFile.get_amuFile()).c_str()				, amuData					);

	readtoMatrix( (dataFile.get_initAFile()).c_str()			, initAData	);
	readtoMatrix( (dataFile.get_initQFile()).c_str()			, initQData	);
	readtoMatrix( (dataFile.get_initFFile()).c_str()			, initFData	);
	readtoMatrix( (dataFile.get_initHFile()).c_str()		, initHData	);

	readtoMatrix( (dataFile.get_initCFile()).c_str()		, initCData	);
	readtoMatrix( (dataFile.get_initOFile()).c_str()		, initOData	);

	readtoMatrix( (dataFile.get_dagFile()).c_str()				, dagData					);
	readtoMatrix( (dataFile.get_outputFile()).c_str()			, outputData			);

	readtoString( (dataFile.get_bcFile()).c_str()						, bcData				);
	readtoString( (dataFile.get_bcpropertiesFile()).c_str()	, bcpropertiesData	);

	readtoString( (dataFile.get_timeFile()).c_str()					, timeData				);

}

parser::~parser() {printf("\n%s\n\n", "parser deleted." );}

//####################################################
// Set
//####################################################
int parser::nSet( const char* file ) {

	int nbl=0;
	int j=0;
	string ch;   // store temporarily read strings
	size_t found;

	// Open file
  ifstream entries(file,ios::in);
	if (!entries) {
		cerr << "parser::readtoString: Impossible to open the " << file << " file\n" << endl;
		exit(1);
	}

	// Get nbl
	while (!entries.eof()) {
		getline (entries, ch);

		found = ch.find("#") ;
		j = int(found) ;
		if (j>=0) {
			continue ;
		}

		if (ch=="") {
			continue ;
		}

		nbl ++;
	}

	entries.close();

	return nbl ;
}

void parser::propertiesSet( vector<vesselProperties>& _vP, const int n){

	vector<string> tableColumn = split(propertiesData[0],",");

	int nx_pos 			= findPosition_inTable(tableColumn,"<Nx>");
	int l_pos				= findPosition_inTable(tableColumn,"<L>");
	int rho_pos			= findPosition_inTable(tableColumn,"<rho>");

	int solver_pos	= findPosition_inTable(tableColumn,"<Solver>");
	int order_pos		= findPosition_inTable(tableColumn,"<Order>");
	int hr_pos			= findPosition_inTable(tableColumn,"<HR>");

	vector<string> value;

	// Loop on arteries
	for ( int i=0;i<n; i++) {

		// Scalar properties of artery
  	value=split(propertiesData[i+1],",");

		_vP[i].set_nx( 			atoi((value[nx_pos].c_str())) 					);
		_vP[i].set_l( 			strtold( value[l_pos].c_str(),	NULL)	);
		_vP[i].set_rho( 		strtold( value[rho_pos].c_str(),NULL) );

  	_vP[i].set_solver( 	value[solver_pos] );
  	_vP[i].set_order( 	strtold( value[order_pos].c_str(),	NULL)	);
		_vP[i].set_hr( 			value[hr_pos] );

		// Vector properties of artery
		int nx = _vP[i].get_nx() ;
		VECT tmp(nx,0) ;

		// dx
		if (dxData.get_numOfCols() < uint(nx + 1)) {
			printf("i=%d,\t numCols=%d,\t nx+1=%d\n", i, dxData.get_numOfCols(),uint(nx + 1) );
			Error("setProperties: numOfCols dx != nx + 1");
		}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(dxData(i,j+1));
		}
		_vP[i].set_dx(tmp) ;

		// a0
		if (a0Data.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols a0 != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(a0Data(i,j+1));
		}
		_vP[i].set_a0(tmp) ;

		// k
		if (kData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols k != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(kData(i,j+1));
		}
		_vP[i].set_k(tmp) ;

		// cv
		if (cvData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols cv != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(cvData(i,j+1));
		}
		_vP[i].set_cv(tmp) ;

		// knl
		if (knlData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols knl != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(knlData(i,j+1));
		}
		_vP[i].set_knl(tmp) ;

		// phi
		if (phiData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols phi != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(phiData(i,j+1));
		}
		_vP[i].set_phi(tmp) ;

		// mu0
		if (mu0Data.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols mu0 != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(mu0Data(i,j+1));
		}
		_vP[i].set_mu0(tmp) ;

		// mu1
		if (mu1Data.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols mu1 != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(mu1Data(i,j+1));
		}
		_vP[i].set_mu1(tmp) ;

		// kmu
		if (kmuData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols kmu != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(kmuData(i,j+1));
		}
		_vP[i].set_kmu(tmp) ;

		// amu
		if (amuData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols amu != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(amuData(i,j+1));
		}
		_vP[i].set_amu(tmp) ;

		// initA
		if (initAData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols initAData != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(initAData(i,j+1));
		}
		_vP[i].set_initA(tmp) ;

		// initQ
		if (initQData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols initQData != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(initQData(i,j+1));
		}
		_vP[i].set_initQ(tmp) ;

		// initF
		if (initFData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols initFData != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(initFData(i,j+1));
		}
		_vP[i].set_initF(tmp) ;

		// initH
		if (initHData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols initHData != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(initHData(i,j+1));
		}
		_vP[i].set_initH(tmp) ;

		// initC
		if (initCData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols initCData != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(initCData(i,j+1));
		}
		_vP[i].set_initC(tmp) ;

		// initO
		if (initOData.get_numOfCols() < uint(nx + 1)) { Error("setProperties: numOfCols initOData != nx + 1");}
		for ( int j=0; j < nx; j++) {
			tmp[j] = double(initOData(i,j+1));
		}
		_vP[i].set_initO(tmp) ;
	}
}

void parser::bcpropertiesSet( vector<vesselProperties>& _vP, const int n){

	vector<string> tableColumn = split(bcpropertiesData[0],",");

	int ina0_pos 		= findPosition_inTable(tableColumn,"<A0_in>");
	int outa0_pos		= findPosition_inTable(tableColumn,"<A0_out>");
	int ink_pos			= findPosition_inTable(tableColumn,"<K_in>");
	int outk_pos		= findPosition_inTable(tableColumn,"<K_out>");
	int indx_pos		= findPosition_inTable(tableColumn,"<dx_in>");
	int outdx_pos		= findPosition_inTable(tableColumn,"<dx_out>");
	int inang_pos		= findPosition_inTable(tableColumn,"<angle_in>");
	int outang_pos	= findPosition_inTable(tableColumn,"<angle_out>");
	int outP_pos		= findPosition_inTable(tableColumn,"<P_out>");

	vector<string> value;
	VECT tmp(2,0) ;

	// Loop on arteries
	for ( int i=0;i<n; i++) {

		// Scalar properties of artery
  	value=split(bcpropertiesData[i+1],",");

		tmp[0] = strtold( 	value[ina0_pos].c_str(),	NULL) ;
		_vP[i].set_ina0( 		tmp	);
		tmp[0] = strtold( 	value[outa0_pos].c_str(),	NULL) ;
		_vP[i].set_outa0( 	tmp	);
		tmp[0] = strtold( 	value[ink_pos].c_str(),	NULL) ;
		_vP[i].set_ink( 		tmp );
		tmp[0] = strtold( 	value[outk_pos].c_str(),	NULL) ;
		_vP[i].set_outk( 		tmp );
		tmp[0] = strtold( 	value[indx_pos].c_str(),	NULL) ;
		_vP[i].set_indx( 		tmp );
		tmp[0] = strtold( 	value[outdx_pos].c_str(),	NULL) ;
		_vP[i].set_outdx( 	tmp );
		tmp[0] = strtold( 	value[inang_pos].c_str(),	NULL) ;
		_vP[i].set_inang( 	tmp[0] );
		tmp[0] = strtold( 	value[outang_pos].c_str(),	NULL) ;
		_vP[i].set_outang( tmp[0] );
		tmp[0] = strtold( 	value[outP_pos].c_str(),	NULL) ;
		_vP[i].set_outP( 		tmp[0] );
	}
}

void parser::bcSet( vector<vesselProperties>& _vP, const int n){

	vector<string> value ;
	string type ;
	int iart = 0, nt = 0;
	bc tmpbc ;

	value = split(bcData[0],",");
	nt = value.size() -2 ;

	// Define size of data
	VECT conjdata(nt,ZERO) ;
	VECT data(nt,ZERO) ;

	// Loop on boundary conditions
	for ( int i=0;i<n; i++) {

		value = split(bcData[i+1],",");

		iart = atoi(value[0].c_str());
		type = value[1] ;

		// No data for junction
		if (value.size() -2 == 0) {

			tmpbc = bc(type,conjdata) ;
			_vP[iart].add_bc(tmpbc);

		}

		// Only one value
		else if (value.size() -2 == 1) {
			for ( int j=0; j<nt; j++){
				data[j] = strtold( value[2].c_str(),NULL) ;
			}
			tmpbc = bc(type,data) ;
			_vP[iart].add_bc(tmpbc);
		}

		else if (value.size() -2 == uint(nt)) {
			for ( int j=0; j<nt; j++){
				data[j] = strtold( value[j+2].c_str(),NULL) ;
			}
			tmpbc = bc(type,data) ;
			_vP[iart].add_bc(tmpbc);
		}

		else { Error("parser::bcSet value.size() -2 != nt and != 3");}

	}
}
void parser::tSet(time_c& timenet){

	vector<string> tableColumn = split(timeData[0],",");

	int ts_pos 			= findPosition_inTable(tableColumn,"<tS>");
	int te_pos			= findPosition_inTable(tableColumn,"<tE>");
	int dt_pos			= findPosition_inTable(tableColumn,"<t_step>");
	int nt_pos			= findPosition_inTable(tableColumn,"<Nt>");
	int nstore_pos	= findPosition_inTable(tableColumn,"<Nstore>");
	int cfl_pos			= findPosition_inTable(tableColumn,"<CFL>");
	int order_pos		= findPosition_inTable(tableColumn,"<Order>");

	vector<string> value=split(timeData[1],",");

	timenet.set_ts( 		strtold( value[ts_pos].c_str(),	NULL) 		);
	timenet.set_te( 		strtold( value[te_pos].c_str(),	NULL) 		);
	timenet.set_dt( 		strtold( value[dt_pos].c_str(),	NULL) 		);
	timenet.set_nt( 		strtold( value[nt_pos].c_str(),	NULL) 		);
	timenet.set_nstore( strtold( value[nstore_pos].c_str(),	NULL) );
	timenet.set_cfl( 		strtold( value[cfl_pos].c_str(),	NULL) 	);
	timenet.set_dtcfl( 	strtold( value[dt_pos].c_str(),	NULL) 		);
	timenet.set_order( 	atoi((value[order_pos].c_str())) 					);

	// Verification
	vector<string> tstmp ;

	tstmp = split(bcData[0],",");
	if( int(tstmp.size()-2) != timenet.get_nt() ) { Error("parser::tSet nt(tstmp.size()-2) != nt") ;}

	VECT tmp(timenet.get_nt(),0) ;
	for ( int j=0; j<timenet.get_nt(); j++){
		tmp[j] = strtold( tstmp[j+2].c_str(),NULL) ;
	}
	timenet.set_t(tmp) ;

}
void parser::outputSet(output& outnet){

	int nArt = -1;
	int nArttmp = 0 ;

  for (uint i=0; i < outputData.get_numOfRows() ; i++) {

    outnet.add_arteryRecord( int(outputData(i,0)) );
    outnet.add_posRecord( int(outputData(i,1)) );

    // Store record Artery to open file
		nArttmp = int(outputData(i,0)) ;

    if (nArt != nArttmp) {
    	nArt = nArttmp;
      outnet.add_storeArt( nArt ) ;
    }
	}

}
int parser::dagSet(vector<artery*>& _arts, vector<conjunction*>& _conjs){

	vector<int> vConj ;
	vector<int>::iterator it ;

	int hConj, tConj ;

	// Check number of arteries
	if (int(_arts.size()) != int(dagData.get_numOfRows())){
		Error("parser::dagSet arts.size() != dagData.get_numOfRows()" ) ;
	}

	for (uint i=0; i < dagData.get_numOfRows() ; i++) {
		hConj = int(dagData(i,0)) ;
		tConj = int(dagData(i,1)) ;

		it = find( vConj.begin(), vConj.end(), hConj ) ;
		if (it == vConj.end()) {
			// cout << "Element not found in myvector: " << int(dagData(i,0)) << '\n' ;
			vConj.push_back(hConj);
		}
		it = find( vConj.begin(), vConj.end(), tConj ) ;
		if (it == vConj.end()) {
			// cout << "Element not found in myvector: " << int(dagData(i,1)) << '\n' ;
			vConj.push_back(tConj);
		}
	}

	// Resize and create conjunctionNum
	_conjs.resize(vConj.size());
	for (uint i=0; i < _conjs.size() ; i++ ) {
		_conjs[i] = new conjunctionNum() ;
	}

	// Add parent and daughter arteries to conjunction
	for (uint i=0; i < dagData.get_numOfRows() ; i++) {
		hConj = int(dagData(i,0)) ;
		tConj = int(dagData(i,1)) ;

		// _conjs[hConj]->add_dart(_arts[i]) ;
		// _conjs[tConj]->add_part(_arts[i]) ;
		_conjs[find( vConj.begin(), vConj.end(), hConj )-vConj.begin()]->add_dart(_arts[i]) ;
		_conjs[find( vConj.begin(), vConj.end(), tConj )-vConj.begin()]->add_part(_arts[i]) ;

	}

	return vConj.size() ;

}
//####################################################
// Read
//####################################################
void parser::readtoMatrix(const char* file, MATR& data) {

  string ch;   // store temporarily read strings
	vector<string> str_;
	int j=0, nbl=0;
	uint num_Max=0;
	size_t found;

	// Open file
  ifstream entries(file,ios::in);
	if (!entries) {
		cerr << "parser::readtoMatrix: Impossible to open the " << file << " file\n" << endl;
		exit(1);
	}

	while (!entries.eof()) {
		getline (entries, ch);		// read a line

		found = ch.find("#") ;
		j = int(found) ;
		if (j>=0) {
			continue ;
		}

		if (ch=="") {
			continue ;
		}

		str_.push_back(ch);
    vector<string> chtemp=split(ch,",");
    if (num_Max < chtemp.size()) {
      num_Max = chtemp.size() ;
    }
		nbl ++ ;
	}
	entries.close();

  data = MATR (nbl,num_Max);
  for(int i=0; i< nbl; i++){
    vector<string> temp=split(str_[i],",");
    for (uint j=0; j< temp.size() ; j++) {
      data(i,j) = strtold(temp[j].c_str(),NULL);
    }
  }
}

void parser::readtoString(const char* file, string*& data) {

	int i=0, j=0, nbl=0;
	size_t found;
	string ch;

	// Open file
  ifstream entries(file,ios::in);
	if (!entries) {
		cerr << "parser::readtoString: Impossible to open the " << file << " file\n" << endl;
		exit(1);
	}

	// Get nbl
	while (!entries.eof()) {
		getline (entries, ch);
		if (ch=="") {
			continue ;
		}
		nbl ++;
	}

	// Clear and read again
	entries.clear();
	entries.seekg(0,ios::beg);

	// Create vector to store data
  data = new string[nbl];

	// Loop on lines of file
	while (!entries.eof()){
		getline (entries, ch);

		found = ch.find("#");
		j = int(found);
		if ( j>0){
				ch.erase (ch.begin()+j, ch.end());
		}

		if (ch=="") {
			continue ;
		}

		data[i] = ch;

		i++;
	}

	entries.close();
}
