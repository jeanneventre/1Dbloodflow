#include "conjunctionNum.h"

conjunctionNum::conjunctionNum() :

  conjunction()

{}

conjunctionNum::~conjunctionNum() {printf("\n%s\n\n", "conjunctionNum deleted." );}
//####################################################
// Time advance
//####################################################
void conjunctionNum::stepConj(const time_c& timenet) {

  int nparts = get_nparts() , ndarts = get_ndarts() ;

  if (nparts > 0 && ndarts > 0) {
    if      ( typeJ.compare("jS") == 0 )   { jS(timenet) ;}
    else if ( typeJ.compare("jA") == 0 )   { jA(timenet)      ;}
    else if ( typeJ.compare("jAQ") == 0 )  { jAQ(timenet)     ;}
    else { Error("conjunction::stepConj Unknown junction type") ;}
  }
}
//####################################################
// Time advance: Steady state conservation
//####################################################
void conjunctionNum::jS(const time_c& timenet) {

  int nparts = get_nparts() , ndarts = get_ndarts() ;

  VECT AQ( 2 * ( nparts + ndarts) , ZERO);
  VECT guess(2*nparts + 2*ndarts , ZERO) , par( 3*nparts + 3*ndarts + 1 , ZERO) ;

  if (nparts > 0 && ndarts > 0) {

    // Initial guess
    int iguess = 0 ;
    for ( int i=0; i < nparts ; i++) {
      guess[iguess]   = parts[i]->get_cells().get_A()[parts[i]->get_cells().get_nx()-1] ;
      guess[iguess+1] = parts[i]->get_cells().get_Q()[parts[i]->get_cells().get_nx()-1] ;
      iguess += 2 ;
    }
    for ( int i=0; i < ndarts ; i++) {
      guess[iguess]   = darts[i]->get_cells().get_A()[0] ;
      guess[iguess+1] = darts[i]->get_cells().get_Q()[0] ;
      iguess += 2 ;
    }

    //####################################
    // Get parameters
    //####################################
    int ipar = 0 ;
    // Outgoing characteristic
    for ( int i=0; i < nparts ; i++) {
      par[ipar] = W1( parts[i]->get_cells().get_rho(),
                      parts[i]->get_cells().get_k()[parts[i]->get_cells().get_nx()-1],
                      parts[i]->get_cells().get_A()[parts[i]->get_cells().get_nx()-1],
                      parts[i]->get_cells().get_Q()[parts[i]->get_cells().get_nx()-1] ) ;
      ipar += 1 ;
    }
    // Incoming characteristic
    for ( int i=0; i < ndarts ; i++) {
      par[ipar] = W2( darts[i]->get_cells().get_rho(),
                      darts[i]->get_cells().get_k()[0],
                      darts[i]->get_cells().get_A()[0],
                      darts[i]->get_cells().get_Q()[0] ) ;
      ipar += 1 ;
    }
    // rho
    par[ipar] = parts[0]->get_cells().get_rho() ;
    ipar += 1 ;
    // k
    for ( int i=0; i < nparts ; i++) {
      par[ipar] = parts[i]->get_outlet().get_k()[0] ;
      ipar += 1 ;
    }
    for ( int i=0; i < ndarts ; i++) {
      par[ipar] = darts[i]->get_inlet().get_k()[0] ;
      ipar += 1 ;
    }
    // a0
    for ( int i=0; i < nparts ; i++) {
      par[ipar] = parts[i]->get_outlet().get_a0()[0] ;
      ipar += 1 ;
    }
    for ( int i=0; i < ndarts ; i++) {
      par[ipar] = darts[i]->get_inlet().get_a0()[0] ;
      ipar += 1 ;
    }

    // Solve problem
    if      (nparts == 1 && ndarts == 1 ) { AQ = newtonRahpson(fun_conj_PD    , guess, par, int(maxIt), EPSILON_JUNC) ;}
    else if (nparts == 1 && ndarts == 2 ) { AQ = newtonRahpson(fun_conj_PDD   , guess, par, int(maxIt), EPSILON_JUNC) ;}
    else if (nparts == 1 && ndarts == 3 ) { AQ = newtonRahpson(fun_conj_PDDD  , guess, par, int(maxIt), EPSILON_JUNC) ;}
    else if (nparts == 1 && ndarts == 4 ) { AQ = newtonRahpson(fun_conj_PDDDD , guess, par, int(maxIt), EPSILON_JUNC) ;}
    else if (nparts == 2 && ndarts == 1 ) { AQ = newtonRahpson(fun_conj_PPD   , guess, par, int(maxIt), EPSILON_JUNC) ;}
    else if (nparts == 2 && ndarts == 2 ) { AQ = newtonRahpson(fun_conj_PPDD  , guess, par, int(maxIt), EPSILON_JUNC) ;}
    else if (nparts == 2 && ndarts == 3 ) { AQ = newtonRahpson(fun_conj_PPDDD , guess, par, int(maxIt), EPSILON_JUNC) ;}
    else { Error("Untreated number of parent and daughter arteries") ;}

    // Update inlet and outlet ghost cells
    int iAQ = 0 ;
    for ( int i=0; i < nparts ; i++) {
      parts[i]->get_outlet().set_A(0,AQ[iAQ])  ;
      parts[i]->get_outlet().set_Q(0,AQ[iAQ+1] );
      iAQ += 2 ;
    }
    for ( int i=0; i < ndarts ; i++) {
      darts[i]->get_inlet().set_A(0,AQ[iAQ])   ;
      darts[i]->get_inlet().set_Q(0,AQ[iAQ+1] ) ;
      iAQ += 2 ;
    }

    // Solve passive transport problem and transport strucutre
    // Based on the paper of Murillo (2015)
    // Upwind method that conserves flux
    SCALAR sumQ=ZERO, sumQH=ZERO, sumQC=ZERO, sumQO=ZERO, sumQF=ZERO ;
    VECT vQp( nparts, ZERO) , vQd( ndarts, ZERO) ;
    VECT vQHp(nparts, ZERO) , vQHd(ndarts, ZERO) ;
    VECT vQCp(nparts, ZERO) , vQCd(ndarts, ZERO) ;
    VECT vQOp(nparts, ZERO) , vQOd(ndarts, ZERO) ;
    VECT vQFp(nparts, ZERO) , vQFd(ndarts, ZERO) ;

    // Compute usefull quantities
    for ( int i=0; i < nparts ; i++) {
      sumQ   += max( ZERO, parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ) ;
      sumQH  += max( ZERO, parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ) * parts[i]->get_cells().get_H()[parts[i]->get_cells().get_nx()-1] ;
      sumQC  += max( ZERO, parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ) * parts[i]->get_cells().get_C()[parts[i]->get_cells().get_nx()-1] ;
      sumQO  += max( ZERO, parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ) * parts[i]->get_cells().get_O()[parts[i]->get_cells().get_nx()-1] ;
      sumQF  += max( ZERO, parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ) * parts[i]->get_cells().get_F()[parts[i]->get_cells().get_nx()-1] ;
    }
    for ( int i=0; i < ndarts ; i++) {
      sumQ   -= min( ZERO, darts[i]->get_faces(0).get_FA() ) ;
      sumQH  -= min( ZERO, darts[i]->get_faces(0).get_FA() ) * darts[i]->get_cells().get_H()[0] ;
      sumQC  -= min( ZERO, darts[i]->get_faces(0).get_FA() ) * darts[i]->get_cells().get_C()[0] ;
      sumQO  -= min( ZERO, darts[i]->get_faces(0).get_FA() ) * darts[i]->get_cells().get_O()[0] ;
      sumQF  -= min( ZERO, darts[i]->get_faces(0).get_FA() ) * darts[i]->get_cells().get_F()[0] ;
    }
    // Compute usefull quantities
    for ( int i=0; i < nparts ; i++) {
      vQp[i]   = -sumQ   + max( ZERO, parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ) ;
      vQHp[i]  = -sumQH  + max( ZERO, parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ) * parts[i]->get_cells().get_H()[parts[i]->get_cells().get_nx()-1] ;
      vQCp[i]  = -sumQC  + max( ZERO, parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ) * parts[i]->get_cells().get_C()[parts[i]->get_cells().get_nx()-1] ;
      vQOp[i]  = -sumQO  + max( ZERO, parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ) * parts[i]->get_cells().get_O()[parts[i]->get_cells().get_nx()-1] ;
      vQFp[i]  = -sumQF  + max( ZERO, parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ) * parts[i]->get_cells().get_F()[parts[i]->get_cells().get_nx()-1] ;
    }
    for ( int i=0; i < ndarts ; i++) {
      vQd[i]   = sumQ   + min( ZERO, darts[i]->get_faces(0).get_FA() ) ;
      vQHd[i]  = sumQH  + min( ZERO, darts[i]->get_faces(0).get_FA() ) * darts[i]->get_cells().get_H()[0] ;
      vQCd[i]  = sumQC  + min( ZERO, darts[i]->get_faces(0).get_FA() ) * darts[i]->get_cells().get_C()[0] ;
      vQOd[i]  = sumQO  + min( ZERO, darts[i]->get_faces(0).get_FA() ) * darts[i]->get_cells().get_O()[0] ;
      vQFd[i]  = sumQF  + min( ZERO, darts[i]->get_faces(0).get_FA() ) * darts[i]->get_cells().get_F()[0] ;
    }

    // Upwinding
    for ( int i=0; i < nparts ; i++) {
      if ( parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() >= ZERO ) {
        parts[i]->get_outlet().set_H(0,parts[i]->get_cells().get_H()[parts[i]->get_cells().get_nx() -1]);
        parts[i]->get_outlet().set_C(0,parts[i]->get_cells().get_C()[parts[i]->get_cells().get_nx() -1]);
        parts[i]->get_outlet().set_O(0,parts[i]->get_cells().get_O()[parts[i]->get_cells().get_nx() -1]);
        parts[i]->get_outlet().set_F(0,parts[i]->get_cells().get_F()[parts[i]->get_cells().get_nx() -1]);
      }
      else {
        parts[i]->get_outlet().set_H(0,vQHp[i] / (vQp[i]+EPSILON) ); // We add epsilon in case of vQp[i] = ZERO
        parts[i]->get_outlet().set_C(0,vQCp[i] / (vQp[i]+EPSILON) );
        parts[i]->get_outlet().set_O(0,vQOp[i] / (vQp[i]+EPSILON) );
        parts[i]->get_outlet().set_F(0,vQFp[i] / (vQp[i]+EPSILON) );
      }
    }
    for ( int i=0; i < ndarts ; i++) {
      if ( darts[i]->get_faces(0).get_FA() <= ZERO ) {
        darts[i]->get_inlet().set_H(0,darts[i]->get_cells().get_H()[0]);
        darts[i]->get_inlet().set_C(0,darts[i]->get_cells().get_C()[0]);
        darts[i]->get_inlet().set_O(0,darts[i]->get_cells().get_O()[0]);
        darts[i]->get_inlet().set_F(0,darts[i]->get_cells().get_F()[0]);
      }
      else {
        darts[i]->get_inlet().set_H(0,vQHd[i] / (vQd[i]+EPSILON) ); // We add epsilon in case of vQd[i] = ZERO
        darts[i]->get_inlet().set_C(0,vQCd[i] / (vQd[i]+EPSILON) );
        darts[i]->get_inlet().set_O(0,vQOd[i] / (vQd[i]+EPSILON) );
        darts[i]->get_inlet().set_F(0,vQFd[i] / (vQd[i]+EPSILON) );
      }
    }
  }

}
//####################################################
// Time advance: Mass equation + Neuwman boundary condition
//####################################################
void conjunctionNum::jA(const time_c& timenet) {

  // Q is not a variable of this junction model
  // Flow is imposed through homogeneous Neumann boundary conditions at the interface of the junction
  // This approximation is valid as long as the long wave hypothesis holds

  int nparts = get_nparts() ;
  int ndarts = get_ndarts() ;

  SCALAR sumQ = ZERO , sumQF = ZERO , sumQH = ZERO , sumQC = ZERO , sumQO = ZERO ;

  if (nparts > 0 && ndarts > 0) {

    // Store previous volume
    Vm1 = V ;

    // Advection

    for ( int i=0; i < nparts ; i++) {
      sumQ  -= parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() ;
      sumQF -= parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FF() ;
      sumQH -= parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FH() ;
      sumQC -= parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FC() ;
      sumQO -= parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FO() ;
    }
    for ( int i=0; i < ndarts ; i++) {
      sumQ  += darts[i]->get_faces(0).get_FA();
      sumQF += darts[i]->get_faces(0).get_FF();
      sumQH += darts[i]->get_faces(0).get_FH();
      sumQC += darts[i]->get_faces(0).get_FC();
      sumQO += darts[i]->get_faces(0).get_FO();
    }
    // Update
    V   = V   - timenet.get_dt() * sumQ ;
    VF  = VF  - timenet.get_dt() * sumQF ;
    VH  = VH  - timenet.get_dt() * sumQH ;
    VC  = VC  - timenet.get_dt() * sumQC ;
    VO  = VO  - timenet.get_dt() * sumQO ;
    // Check positivity
    if (V  < ZERO) { printf("%.20Lf\n", V );  Error("jA V is negative") ;}
    if (VF < ZERO) { printf("%.20Lf\n", VF ); Error("jA VF is negative") ;}
    if (VH < ZERO) { printf("%.20Lf\n", VH ); Error("jA VH is negative") ;}
    if (VC < ZERO) { printf("%.20Lf\n", VC ); Error("jA VC is negative") ;}
    if (VO < ZERO) { printf("%.20Lf\n", VO ); Error("jA VO is negative") ;}
    // Update
    A = V / l ;
    F = VF / V ;
    H = VH / V ;
    C = VC / V ;
    O = VO / V ;

    // Reaction

    // Update non differential quantities (G, T)
    // Tmu is not updated here as it is not advected

    // G is updated by mean value as Q is not defined in this model
    G = ZERO ;
    for ( int i=0; i < nparts ; i++) { G += shearRate(phi,parts[i]->get_outlet().get_A()[0],parts[i]->get_outlet().get_Q()[0])  / double(nparts) / TWO ;}
    for ( int i=0; i < ndarts ; i++) { G += shearRate(phi,darts[i]->get_inlet().get_A()[0] ,darts[i]->get_inlet().get_Q()[0])   / double(ndarts) / TWO ;}

    T = shearStress (mu1,G,H,Tmu) ;

    F   = F   + timenet.get_dt() * prodesF        (kmu,amu,G,H,F) ;
    if (F < ZERO) { printf("%.20Lf\n", F ); Error("jA F is negative") ;}

    Tmu = Tmu + timenet.get_dt() * prodTmu        (mu0,mu1,kmu,G,H,F,Tmu) ;

    // Update inlet and outlet ghost cells
    // Characteristic matching for the flow rate, with added viscous dissipation
    for ( int i=0; i < nparts ; i++) {
      parts[i]->get_outlet().set_A(0,A) ;
      parts[i]->get_outlet().set_Q(0,parts[i]->get_faces(parts[i]->get_cells().get_nx()).get_FA() + timenet.get_dt() * shearLaplacian (rho,A,T) );
      parts[i]->get_outlet().set_F(0,F) ;
      parts[i]->get_outlet().set_H(0,H) ;
      parts[i]->get_outlet().set_C(0,C) ;
      parts[i]->get_outlet().set_O(0,O) ;
    }
    for ( int i=0; i < ndarts ; i++) {
      darts[i]->get_inlet().set_A(0,A) ;
      darts[i]->get_inlet().set_Q(0,darts[i]->get_faces(0).get_FA() + timenet.get_dt() * shearLaplacian (rho,A,T) );
      darts[i]->get_inlet().set_F(0,F) ;
      darts[i]->get_inlet().set_H(0,H) ;
      darts[i]->get_inlet().set_C(0,C) ;
      darts[i]->get_inlet().set_O(0,O) ;
    }
  }
}
//####################################################
// Time advance: Mass equation + Momentum equation
//####################################################
void conjunctionNum::jAQ(const time_c& timenet) {

//   int nparts = get_nparts() ;
//   int ndarts = get_ndarts() ;
//
//   SCALAR sumQ = ZERO, sumMx = ZERO, sumMy = ZERO, sumFe = ZERO, sumQHrbc = ZERO, sumQf = ZERO, sumQCpt = ZERO, sumQOpt = ZERO ;
//
//   if (nparts > 0 && ndarts > 0) {
//
//     printf("%Lf, %Lf, %20.20Lf, %20.20Lf, %20.20Lf, %20.20Lf, %20.20Lf\n", acos(VQx / sqrt(pow(VQx,TWO)+pow(VQy,TWO))) * 180L / PI, asin(VQy / sqrt(pow(VQx,TWO)+pow(VQy,TWO))) * 180L / PI, VQx/l, VQy/l, A, Q, VE );
//
//     //####################################
//     // Update volume of confluence
//     //####################################
//     for ( int i=0; i < nparts ; i++) {
//       sumQ -= parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) ;
//     }
//     for ( int i=0; i < ndarts ; i++) {
//       sumQ += darts[i]->get_interface_Scalar( "FA", 0 ) ;
//     }
//     V = V - timenet.get_dt() * sumQ ; ;
//     // Check positivity:
//     if (V <= ZERO) {
//       Error("stepConj V is negative") ;
//     }
//     // Update section of confluence
//     A = V / l ;
//
//     //################################################################################
//     // Update volume flow rate of confluence using conservation of momentum in the main direction
//     //################################################################################
//     SCALAR Fm = ZERO ;
//     for ( int i=0; i < nparts ; i++) {
//       if ( parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx()) >= ZERO ) {
//         Fm = Momentum (parts[i]->get_rho(),
//                   parts[i]->get_interface_Scalar( "Khr"     , parts[i]->get_cells().get_nx() ),
//                   pow( parts[i]->get_interface_Scalar( "Zhr", parts[i]->get_cells().get_nx() ) / parts[i]->get_interface_Scalar( "Khr", parts[i]->get_cells().get_nx() ), TWO) ,
//                   // min( parts[i]->get_interface_Vector( "Ahr"     , parts[i]->get_cells().get_nx() )[0], parts[i]->get_interface_Vector( "Ahr"     , parts[i]->get_cells().get_nx() )[1]),
//                   parts[i]->get_interface_Vector( "Ahr"     , parts[i]->get_cells().get_nx() )[0],
//                   parts[i]->get_interface_Vector( "Qhr"     , parts[i]->get_cells().get_nx() )[0]
//                 ) ;
//       }
//       else {
//         Fm = Momentum (parts[i]->get_rho(),
//                   parts[i]->get_interface_Scalar( "Khr"     , parts[i]->get_cells().get_nx() ),
//                   pow( parts[i]->get_interface_Scalar( "Zhr", parts[i]->get_cells().get_nx() ) / parts[i]->get_interface_Scalar( "Khr", parts[i]->get_cells().get_nx() ), TWO) ,
//                   // min( parts[i]->get_interface_Vector( "Ahr"     , parts[i]->get_cells().get_nx() )[0], parts[i]->get_interface_Vector( "Ahr"     , parts[i]->get_cells().get_nx() )[1]),
//                   parts[i]->get_interface_Vector( "Ahr"     , parts[i]->get_cells().get_nx() )[1],
//                   parts[i]->get_interface_Vector( "Qhr"     , parts[i]->get_cells().get_nx() )[1]
//                 ) ;
//       }
//
//       sumMx +=  cos( parts[i]->get_angleoutlet() ) * Fm ;
//       sumMy +=  sin( parts[i]->get_angleoutlet() ) * Fm ;
//     }
//     for ( int i=0; i < ndarts ; i++) {
//       if ( darts[i]->get_interface_Scalar( "FA", 0 ) <= ZERO ) {
//         Fm =  Momentum (darts[i]->get_rho(),
//                   darts[i]->get_interface_Scalar( "Khr"     , 0 ),
//                   pow( darts[i]->get_interface_Scalar( "Zhr", 0 ) / darts[i]->get_interface_Scalar( "Khr", 0 ), TWO) ,
//                   // min(darts[i]->get_interface_Vector( "Ahr"     , 0 )[0], darts[i]->get_interface_Vector( "Ahr"     , 0 )[1]),
//                   darts[i]->get_interface_Vector( "Ahr"     , 0 )[1],
//                   darts[i]->get_interface_Vector( "Qhr"     , 0 )[1]
//                 ) ;
//       }
//       else {
//         Fm = Momentum (darts[i]->get_rho(),
//                   darts[i]->get_interface_Scalar( "Khr"     , 0 ),
//                   pow( darts[i]->get_interface_Scalar( "Zhr", 0 ) / darts[i]->get_interface_Scalar( "Khr", 0 ), TWO) ,
//                   // max(darts[i]->get_interface_Vector( "Ahr"     , 0 )[0], darts[i]->get_interface_Vector( "Ahr"     , 0 )[1]),
//                   darts[i]->get_interface_Vector( "Ahr"     , 0 )[0],
//                   darts[i]->get_interface_Vector( "Qhr"     , 0 )[0]
//                 ) ;
//       }
//       sumMx -=  cos(darts[i]->get_angleinlet() ) * Fm ;
//       sumMy -=  sin(darts[i]->get_angleinlet() ) * Fm ;
//     }
//
//     VQx = VQx - timenet.get_dt() * ( sumMx ) ;
//     VQy = VQy - timenet.get_dt() * ( sumMy ) ;
//
//
//     //################################################################################
//     // Update volume flow rate of confluence using conservation of energy
//     //################################################################################
//     VECT LR(2,ZERO);
//     for ( int i=0; i < nparts ; i++) {
//       LR[0] = fluxE(  parts[i]->get_rho(),
//                       parts[i]->get_interface_Scalar( "Khr"     , parts[i]->get_cells().get_nx() ),
//                       pow( parts[i]->get_interface_Scalar( "Zhr", parts[i]->get_cells().get_nx() ) / parts[i]->get_interface_Scalar( "Khr", parts[i]->get_cells().get_nx() ), TWO) ,
//                       parts[i]->get_interface_Vector( "Ahr"     , parts[i]->get_cells().get_nx() )[0],
//                       parts[i]->get_interface_Vector( "Qhr"     , parts[i]->get_cells().get_nx() )[0]
//                     ) ;
//       LR[1] = fluxE(  parts[i]->get_rho(),
//                       parts[i]->get_interface_Scalar( "Khr"     , parts[i]->get_cells().get_nx() ),
//                       pow( parts[i]->get_interface_Scalar( "Zhr", parts[i]->get_cells().get_nx() ) / parts[i]->get_interface_Scalar( "Khr", parts[i]->get_cells().get_nx() ), TWO) ,
//                       parts[i]->get_interface_Vector( "Ahr"     , parts[i]->get_cells().get_nx() )[1],
//                       parts[i]->get_interface_Vector( "Qhr"     , parts[i]->get_cells().get_nx() )[1]
//                     ) ;
//       sumFe -=    max( ZERO,parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) )  * LR[0]
//                 + min( ZERO,parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) )  * LR[1] ;
//     }
//     for ( int i=0; i < ndarts ; i++) {
//       LR[0] = fluxE(  darts[i]->get_rho(),
//                       darts[i]->get_interface_Scalar( "Khr"     , 0 ),
//                       pow( darts[i]->get_interface_Scalar( "Zhr", 0 ) / darts[i]->get_interface_Scalar( "Khr", 0 ), TWO) ,
//                       darts[i]->get_interface_Vector( "Ahr"     , 0 )[0],
//                       darts[i]->get_interface_Vector( "Qhr"     , 0 )[0]
//                     ) ;
//       LR[1] = fluxE(  darts[i]->get_rho(),
//                       darts[i]->get_interface_Scalar( "Khr"     , 0 ),
//                       pow( darts[i]->get_interface_Scalar( "Zhr", 0 ) / darts[i]->get_interface_Scalar( "Khr", 0 ), TWO) ,
//                       darts[i]->get_interface_Vector( "Ahr"     , 0 )[1],
//                       darts[i]->get_interface_Vector( "Qhr"     , 0 )[1]
//                     ) ;
//       sumFe +=    max( ZERO,darts[i]->get_interface_Scalar( "FA", 0 ) )  * LR[0]
//                 + min( ZERO,darts[i]->get_interface_Scalar( "FA", 0 ) )  * LR[1] ;
//     }
//     // Update energy of confluence
//     VE  = VE - timenet.get_dt() * sumFe ;
//     E   = VE / l ;
//     // Update flow rate of confluence
//     Q = EtoQ(rho,k,a0,A,E) ;
//
//     if ( VQx <= ZERO) {
//       Q = - Q ;
//     }
//
//     //####################################
//     // Update shear rate
//     //####################################
//     gamma = ZERO ;
//     for ( int i=0; i < nparts ; i++) {
//       gamma += shearRate(phi,parts[i]->get_Aoutlet(0),parts[i]->get_Qoutlet(0)) ;
//     }
//     for ( int i=0; i < ndarts ; i++) {
//       gamma += shearRate(phi,darts[i]->get_Ainlet(0),darts[i]->get_Qinlet(0)) ;
//     }
//     gamma = gamma / double(nparts+ndarts) ;
//
//     //####################################
//     // Update structure function of confluence
//     //####################################
//     for ( int i=0; i < nparts ; i++) {
//       sumQf -=    max( ZERO,parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) )  * parts[i]->get_interface_Vector( "fo", parts[i]->get_cells().get_nx() )[0]
//                +  min( ZERO,parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) )  * parts[i]->get_interface_Vector( "fo", parts[i]->get_cells().get_nx() )[1] ;
//     }
//     for ( int i=0; i < ndarts ; i++) {
//       sumQf +=    max( ZERO,darts[i]->get_interface_Scalar( "FA", 0 ) )  * darts[i]->get_interface_Vector( "fo", 0 )[0]
//                +  min( ZERO,darts[i]->get_interface_Scalar( "FA", 0 ) )  * darts[i]->get_interface_Vector( "fo", 0 )[1] ;
//
//     }
//     Vf = Vf - timenet.get_dt() *  (
//                                   sumQf
//                                   - Vm1 * structureProductionDestruction(kmu,amu,gamma,Hrbc,f)
//                                   ) ;
//     // Check positivity:
//     if (Vf < ZERO) {
//       Error("stepConj Vf is negative") ;
//     }
//     // Udpate strucutre function of confluence
//     f = Vf / V ;
//
//     //####################################
//     // Update hematocrite of confluence
//     //####################################
//     for ( int i=0; i < nparts ; i++) {
//       sumQHrbc -=    max( ZERO,parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) )  * parts[i]->get_interface_Vector( "Hrbco", parts[i]->get_cells().get_nx() )[0]
//                   +  min( ZERO,parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) )  * parts[i]->get_interface_Vector( "Hrbco", parts[i]->get_cells().get_nx() )[1] ;
//     }
//     for ( int i=0; i < ndarts ; i++) {
//       sumQHrbc +=    max( ZERO,darts[i]->get_interface_Scalar( "FA", 0 ) )  * darts[i]->get_interface_Vector( "Hrbco", 0 )[0]
//                   +  min( ZERO,darts[i]->get_interface_Scalar( "FA", 0 ) )  * darts[i]->get_interface_Vector( "Hrbco", 0 )[1] ;
//
//     }
//     VHrbc = VHrbc - timenet.get_dt() *  (
//                                   sumQHrbc
//                                   ) ;
//     // Check positivity:
//     if (VHrbc < ZERO) {
//       Error("stepConj VHrbc is negative") ;
//     }
//     // Udpate hematocrite of confluence
//     Hrbc = VHrbc / V ;
//
//     //####################################
//     // Update viscous stress
//     //####################################
//     // Structure shear stress
//     taust = updateStructureStress(mu0,muinf,kmu,timenet.get_dt(),gamma,Hrbc,f,taust) ;
//     // Shear stress
//     tau   = shearStress(muinf,gamma,Hrbc,taust) ;
//
//     //####################################
//     // Update concentration of confluence
//     //####################################
//     for ( int i=0; i < nparts ; i++) {
//       sumQCpt -=      max( ZERO,parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) )  * parts[i]->get_interface_Vector( "Cpto", parts[i]->get_cells().get_nx() )[0]
//                   +   min( ZERO,parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) )  * parts[i]->get_interface_Vector( "Cpto", parts[i]->get_cells().get_nx() )[1] ;
//     }
//     for ( int i=0; i < ndarts ; i++) {
//       sumQCpt +=      max( ZERO,darts[i]->get_interface_Scalar( "FA", 0 ) )  * darts[i]->get_interface_Vector( "Cpto", 0 )[0]
//                   +   min( ZERO,darts[i]->get_interface_Scalar( "FA", 0 ) )  * darts[i]->get_interface_Vector( "Cpto", 0 )[1] ;
//
//     }
//     VCpt = VCpt - timenet.get_dt() *  (
//                                   sumQCpt
//                                   ) ;
//     // Check positivity:
//     if (VCpt < ZERO) {
//       Error("stepConj VCpt is negative") ;
//     }
//     // Udpate concentration of confluence
//     Cpt = VCpt / V ;
//
//     //####################################
//     // Update oxygen of confluence
//     //####################################
//     for ( int i=0; i < nparts ; i++) {
//       sumQOpt -=      max( ZERO,parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) )  * parts[i]->get_interface_Vector( "Opto", parts[i]->get_cells().get_nx() )[0]
//                   +   min( ZERO,parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ) )  * parts[i]->get_interface_Vector( "Opto", parts[i]->get_cells().get_nx() )[1] ;
//     }
//     for ( int i=0; i < ndarts ; i++) {
//       sumQOpt +=      max( ZERO,darts[i]->get_interface_Scalar( "FA", 0 ) )  * darts[i]->get_interface_Vector( "Opto", 0 )[0]
//                   +   min( ZERO,darts[i]->get_interface_Scalar( "FA", 0 ) )  * darts[i]->get_interface_Vector( "Opto", 0 )[1] ;
//
//     }
//     VOpt = VOpt - timenet.get_dt() *  (
//                                   sumQOpt
//                                   ) ;
//     // Check positivity:
//     if (VOpt < ZERO) {
//       Error("stepConj VOpt is negative") ;
//     }
//     // Udpate oxygen of confluence
//     Opt = VOpt / V ;
//
//     //####################################
//     // Update inlet and outlet ghost cells
//     //####################################
//     // Added viscous dissipation to the flow rate
//     for ( int i=0; i < nparts ; i++) {
//       parts[i]->set_Aoutlet( A );
//       parts[i]->set_Qoutlet(
//                               // Q
//                               // min(Q,ZERO) + max(parts[i]->get_interface_Scalar( "FA", parts[i]->get_cells().get_nx() ),ZERO)
//                               // sqrt( pow(VQx/l,TWO) + pow(VQy/l,TWO) )
//                               - (VQx / l * cos( parts[i]->get_angleoutlet() ) + VQy / l * sin( parts[i]->get_angleoutlet() ) )
//                               // * parts[i]->get_interface_Vector( "Ahr", parts[i]->get_cells().get_nx() )[0] / A
//                               // * ( parts[i]->get_a0outlet(0) * parts[i]->get_dxoutlet(0) / V0)
//                                + timenet.get_dt() * (
//                                                       TWO * PI / rho * sqrt(A/PI) * tau
//                                                     )
//                               );
//
//       parts[i]->set_Hrbcoutlet( Hrbc );
//       parts[i]->set_foutlet(    f );
//
//       parts[i]->set_Cptoutlet( Cpt );
//       parts[i]->set_Optoutlet( Opt );
//
//     }
//     for ( int i=0; i < ndarts ; i++) {
//       darts[i]->set_Ainlet( A );
//       darts[i]->set_Qinlet(
//                               // Q
//                               // max(Q,ZERO) + min( darts[i]->get_interface_Scalar( "FA", 0 ) ,ZERO)
//                               // sqrt( pow(VQx/l,TWO) + pow(VQy/l,TWO) )
//                               + (VQx / l * cos( darts[i]->get_angleinlet() ) + VQy / l * sin( darts[i]->get_angleinlet() ) )
//                               // * darts[i]->get_interface_Vector( "Ahr", 0 )[1] / A
//                               // * ( darts[i]->get_a0inlet(0) * darts[i]->get_dxinlet(0) / V0)
//                               + timenet.get_dt() * (
//                                                      TWO * PI / rho * sqrt(A/PI) * tau
//                                                    )
//                             );
//
//       darts[i]->set_Hrbcinlet( Hrbc );
//       darts[i]->set_finlet(    f );
//
//       darts[i]->set_Cptinlet( Cpt );
//       darts[i]->set_Optinlet( Opt );
//
//     }
//   }
//
}
//####################################################
// Help functions for static conjunction model
//####################################################
// 1 parent + 1 daughter
VECT conjunctionNum::fun_conj_PD(const VECT& AQ, const VECT& par){

  // Quantities to be determined
  SCALAR  Ap = AQ[0], Qp = AQ[1] ;
  SCALAR  Ad = AQ[2], Qd = AQ[3] ;
  // Fixed quantities
  SCALAR W1p    = par[0] , W2d  = par[1] ;
  SCALAR rho    = par[2] ;
  SCALAR kp     = par[3] , kd   = par[4] ;
  SCALAR a0p    = par[5] , a0d  = par[6] ;

  VECT res(4,ZERO) ;

  // Conservation of mass
  res[0] = Qp - Qd ;
  // Continuity of total pressure
  res[1] = Pt(rho,kp,a0p,Ap,Qp) - Pt(rho,kd,a0d,Ad,Qd);
  // Matching of outgoing characteristic
  res[2] = W1(rho,kp,Ap,Qp) - W1p ;
  // Matching of incoming characteristic
  res[3] = W2(rho,kd,Ad,Qd) - W2d ;

  return res;
}
// 1 parent + 2 daughters
VECT conjunctionNum::fun_conj_PDD(const VECT& AQ, const VECT& par){

  // Quantities to be determined
  SCALAR  Ap  = AQ[0] , Qp  = AQ[1] ;
  SCALAR  Ad1 = AQ[2] , Qd1 = AQ[3] ;
  SCALAR  Ad2 = AQ[4] , Qd2 = AQ[5] ;
  // Fixed quantities
  SCALAR W1p    = par[0] , W2d1  = par[1] , W2d2  = par[2] ;
  SCALAR rho    = par[3] ;
  SCALAR kp     = par[4] , kd1   = par[5] , kd2   = par[6] ;
  SCALAR a0p    = par[7] , a0d1  = par[8] , a0d2  = par[9] ;

  VECT res(6,ZERO) ;

  // Conservation of mass
  res[0] = Qp - Qd1 - Qd2 ;
  // Continuity of total pressure
  res[1] = Pt(rho,kp,a0p,Ap,Qp) - Pt(rho,kd1,a0d1,Ad1,Qd1);
  res[2] = Pt(rho,kp,a0p,Ap,Qp) - Pt(rho,kd2,a0d2,Ad2,Qd2);
  // Matching of outgoing characteristic
  res[3] = W1(rho,kp,Ap,Qp) - W1p ;
  // Matching of incoming characteristic
  res[4] = W2(rho,kd1,Ad1,Qd1) - W2d1 ;
  res[5] = W2(rho,kd2,Ad2,Qd2) - W2d2 ;

  return res;

}
// 1 parent + 3 daughters
VECT conjunctionNum::fun_conj_PDDD(const VECT& AQ, const VECT& par){

  // Quantities to be determined
  SCALAR  Ap  = AQ[0] , Qp  = AQ[1] ;
  SCALAR  Ad1 = AQ[2] , Qd1 = AQ[3] ;
  SCALAR  Ad2 = AQ[4] , Qd2 = AQ[5] ;
  SCALAR  Ad3 = AQ[6] , Qd3 = AQ[7] ;
  // Fixed quantities
  SCALAR W1p    = par[0] , W2d1  = par[1] , W2d2  = par[2] , W2d3  = par[3] ;
  SCALAR rho    = par[4] ;
  SCALAR kp     = par[5] , kd1   = par[6] , kd2   = par[7] , kd3   = par[8];
  SCALAR a0p    = par[9] , a0d1  = par[10], a0d2  = par[11], a0d3  = par[12] ;

  VECT res(8,ZERO) ;

  // Conservation of mass
  res[0] = Qp - Qd1 - Qd2 - Qd3;
  // Continuity of total pressure
  res[1] = Pt(rho,kp,a0p,Ap,Qp) - Pt(rho,kd1,a0d1,Ad1,Qd1);
  res[2] = Pt(rho,kp,a0p,Ap,Qp) - Pt(rho,kd2,a0d2,Ad2,Qd2);
  res[3] = Pt(rho,kp,a0p,Ap,Qp) - Pt(rho,kd3,a0d3,Ad3,Qd3);
  // Matching of outgoing characteristic
  res[4] = W1(rho,kp,Ap,Qp) - W1p ;
  // Matching of incoming characteristic
  res[5] = W2(rho,kd1,Ad1,Qd1) - W2d1 ;
  res[6] = W2(rho,kd2,Ad2,Qd2) - W2d2 ;
  res[7] = W2(rho,kd3,Ad3,Qd3) - W2d3 ;

  return res;

}
// 1 parent + 4 daughters
VECT conjunctionNum::fun_conj_PDDDD(const VECT& AQ, const VECT& par){

  // Quantities to be determined
  SCALAR  Ap  = AQ[0] , Qp  = AQ[1] ;
  SCALAR  Ad1 = AQ[2] , Qd1 = AQ[3] ;
  SCALAR  Ad2 = AQ[4] , Qd2 = AQ[5] ;
  SCALAR  Ad3 = AQ[6] , Qd3 = AQ[7] ;
  SCALAR  Ad4 = AQ[8] , Qd4 = AQ[9] ;
  // Fixed quantities
  SCALAR W1p    = par[0] , W2d1  = par[1] , W2d2  = par[2] , W2d3  = par[3] , W2d4  = par[4] ;
  SCALAR rho    = par[5] ;
  SCALAR kp     = par[6] , kd1   = par[7] , kd2   = par[8] , kd3   = par[9] , kd4   = par[10];
  SCALAR a0p    = par[11], a0d1  = par[12], a0d2  = par[13], a0d3  = par[14], a0d4  = par[15] ;

  VECT res(10,ZERO) ;

  // Conservation of mass
  res[0] = Qp - Qd1 - Qd2 - Qd3 - Qd4;
  // Continuity of total pressure
  res[1] = Pt(rho,kp,a0p,Ap,Qp) - Pt(rho,kd1,a0d1,Ad1,Qd1);
  res[2] = Pt(rho,kp,a0p,Ap,Qp) - Pt(rho,kd2,a0d2,Ad2,Qd2);
  res[3] = Pt(rho,kp,a0p,Ap,Qp) - Pt(rho,kd3,a0d3,Ad3,Qd3);
  res[4] = Pt(rho,kp,a0p,Ap,Qp) - Pt(rho,kd4,a0d4,Ad4,Qd4);
  // Matching of outgoing characteristic
  res[5] = W1(rho,kp,Ap,Qp) - W1p ;
  // Matching of incoming characteristic
  res[6] = W2(rho,kd1,Ad1,Qd1) - W2d1 ;
  res[7] = W2(rho,kd2,Ad2,Qd2) - W2d2 ;
  res[8] = W2(rho,kd3,Ad3,Qd3) - W2d3 ;
  res[9] = W2(rho,kd4,Ad4,Qd4) - W2d4 ;

  return res;

}
// 2 parent + 1 daughter
VECT conjunctionNum::fun_conj_PPD(const VECT& AQ, const VECT& par){

  // Quantities to be determined
  SCALAR  Ap1 = AQ[0], Qp1  = AQ[1] ;
  SCALAR  Ap2 = AQ[2], Qp2  = AQ[3] ;
  SCALAR  Ad1 = AQ[4], Qd1  = AQ[5] ;
  // Fixed quantities
  SCALAR W1p1   = par[0] , W1p2 = par[1] , W2d1  = par[2] ;
  SCALAR rho    = par[3] ;
  SCALAR kp1    = par[4] , kp2  = par[5] , kd1   = par[6] ;
  SCALAR a0p1   = par[7] , a0p2 = par[8] , a0d1  = par[9] ;

  VECT res(6,ZERO) ;

  // Conservation of mass
  res[0] = Qp1 + Qp2 - Qd1 ;
  // Continuity of total pressure
  res[1] = Pt(rho,kp1,a0p1,Ap1,Qp1) - Pt(rho,kd1,a0d1,Ad1,Qd1);
  res[2] = Pt(rho,kp2,a0p2,Ap2,Qp2) - Pt(rho,kd1,a0d1,Ad1,Qd1);
  // Matching of outgoing characteristic
  res[3] = W1(rho,kp1,Ap1,Qp1) - W1p1 ;
  res[4] = W1(rho,kp2,Ap2,Qp2) - W1p2 ;
  // Mtching of incoming characteristic
  res[5] = W2(rho,kd1,Ad1,Qd1) - W2d1 ;

  return res;

}
// 1 parent + 2 daughters
VECT conjunctionNum::fun_conj_PPDD(const VECT& AQ, const VECT& par){

  // Quantities to be determined
  SCALAR  Ap1 = AQ[0], Qp1  = AQ[1] ;
  SCALAR  Ap2 = AQ[2], Qp2  = AQ[3] ;
  SCALAR  Ad1 = AQ[4], Qd1  = AQ[5] ;
  SCALAR  Ad2 = AQ[6], Qd2  = AQ[7] ;
  // Fixed quantities
  SCALAR W1p1   = par[0] , W1p2 = par[1] , W2d1  = par[2] , W2d2  = par[3] ;
  SCALAR rho    = par[4] ;
  SCALAR kp1    = par[5] , kp2  = par[6] , kd1   = par[7] , kd2   = par[8] ;
  SCALAR a0p1   = par[9] , a0p2 = par[10], a0d1  = par[11], a0d2  = par[12];

  VECT res(8,ZERO) ;

  // Conservation of mass
  res[0] = Qp1 + Qp2 - Qd1 - Qd2 ;
  // Continuity of total pressure
  res[1] = Pt(rho,kp1,a0p1,Ap1,Qp1) - Pt(rho,kd1,a0d1,Ad1,Qd1);
  res[2] = Pt(rho,kp2,a0p2,Ap2,Qp2) - Pt(rho,kd2,a0d2,Ad2,Qd2);
  res[3] = Pt(rho,kp1,a0p1,Ap1,Qp1) - Pt(rho,kp2,a0p2,Ap2,Qp2);
  // Matching of outgoing characteristic
  res[4] = W1(rho,kp1,Ap1,Qp1) - W1p1 ;
  res[5] = W1(rho,kp2,Ap2,Qp2) - W1p2 ;
  // Mtching of incoming characteristic
  res[6] = W2(rho,kd1,Ad1,Qd1) - W2d1 ;
  res[7] = W2(rho,kd2,Ad2,Qd2) - W2d2 ;

  return res;

}
// 1 parent + 3 daughters
VECT conjunctionNum::fun_conj_PPDDD(const VECT& AQ, const VECT& par){

  // Quantities to be determined
  SCALAR  Ap1 = AQ[0], Qp1  = AQ[1] ;
  SCALAR  Ap2 = AQ[2], Qp2  = AQ[3] ;
  SCALAR  Ad1 = AQ[4], Qd1  = AQ[5] ;
  SCALAR  Ad2 = AQ[6], Qd2  = AQ[7] ;
  SCALAR  Ad3 = AQ[8], Qd3  = AQ[9] ;
  // Fixed quantities
  SCALAR W1p1   = par[0] , W1p2 = par[1] , W2d1  = par[2] , W2d2  = par[3] , W2d3  = par[4] ;
  SCALAR rho    = par[5] ;
  SCALAR kp1    = par[6] , kp2  = par[7] , kd1   = par[8] , kd2   = par[9] , kd3   = par[10];
  SCALAR a0p1   = par[11], a0p2 = par[12], a0d1  = par[13], a0d2  = par[14], a0d3  = par[15];

  VECT res(10,ZERO) ;

  // Conservation of mass
  res[0] = Qp1 + Qp2 - Qd1 - Qd2 - Qd3 ;
  // Continuity of total pressure
  res[1] = Pt(rho,kp1,a0p1,Ap1,Qp1) - Pt(rho,kd1,a0d1,Ad1,Qd1);
  res[2] = Pt(rho,kp2,a0p2,Ap2,Qp2) - Pt(rho,kd2,a0d2,Ad2,Qd2);
  res[3] = Pt(rho,kp1,a0p1,Ap1,Qp1) - Pt(rho,kp2,a0p2,Ap2,Qp2);
  res[4] = Pt(rho,kd1,a0d1,Ad1,Qd1) - Pt(rho,kd3,a0d3,Ad3,Qd3);
  // Matching of outgoing characteristic
  res[5] = W1(rho,kp1,Ap1,Qp1) - W1p1 ;
  res[6] = W1(rho,kp2,Ap2,Qp2) - W1p2 ;
  // Mtching of incoming characteristic
  res[7] = W2(rho,kd1,Ad1,Qd1) - W2d1 ;
  res[8] = W2(rho,kd2,Ad2,Qd2) - W2d2 ;
  res[9] = W2(rho,kd3,Ad3,Qd3) - W2d3 ;

  return res;

}
