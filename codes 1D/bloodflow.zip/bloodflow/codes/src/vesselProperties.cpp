#include "vesselProperties.h"

vesselProperties::vesselProperties () {}

vesselProperties::~vesselProperties () {}
