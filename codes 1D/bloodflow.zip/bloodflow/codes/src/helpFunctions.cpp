 #include "helpFunctions.h"

//#################################################
//#################################################
// Kahan Sum
SCALAR kahanSum(const VECT& IN) {
 SCALAR sum = IN[0] ;
 SCALAR c = 0. , y = 0., t= 0. ;          //A running compensation for lost low-order bits.
 for (int i=1; i<IN.get_dim(); i++) {
   y = IN[i] - c  ;    //So far, so good: c is zero.
   t = sum + y ;       //Alas, sum is big, y small, so low-order digits of y are lost.
   c = (t - sum) - y ;  //(t - sum) recovers the high-order part of y; subtracting y recovers -(low part of y)
   sum = t ;           //Algebraically, c should always be zero. Beware eagerly optimising compilers!
 }                    //Next time around, the lost low part will be added to y in a fresh attempt.
 return sum ;
}
// Sign
SCALAR sign(SCALAR a) {
  if ( a >= ZERO) {
    return ONE ;
  }
  else {
    return - ONE ;
  }
}
SCALAR interpOrder(const int order,const SCALAR x, const SCALAR x1, const SCALAR y1, const SCALAR x2, const SCALAR y2, const SCALAR x3, const SCALAR y3) {

  SCALAR a=ZERO, b=ZERO, c=ZERO;

  switch(order) {

    case 0:
      // Interpolation at x1
      c = y1 ;
      break;

    case 1:
      // Interpolation at x1, x1+x2
      b = (y2-y1) * TWO / (x3-x1) ;
      c = y1 + y2 - x2 * (y2-y1) * TWO / (x3-x1);
      break;

    // Default
    default:
        Error("helpOrder::recOrder order choosen not exist");

  }

  return a * pow(x,TWO) + b * x + c ;
}
//#################################################
//#################################################
// Pressure gradient flux
SCALAR fluxP(const SCALAR RHO, const SCALAR K, const SCALAR A) {
    return ONEsTHREE * K / RHO * pow(A,THREEsTWO) ;
}
// Nonlinear and pressure gradient flux
SCALAR fluxQ(const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR Q) {
    return pow(Q,TWO) / A + fluxP(RHO, K, A) ;
}

// Momentum
SCALAR Momentum(const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR Q) {
    SCALAR M = A * (pow(Q/A,TWO) + Pel(K,A0,A) / RHO) ;
    if ( abs(M) < EPSILON) {
      M = ZERO ;
    }
    return M ;
}
// Energy
SCALAR Energy(const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR Q) {
    SCALAR E = ONEsTWO * pow(Q,TWO) / A + K / RHO * (TWOsTHREE * pow(A, THREEsTWO) - sqrt(A0) * (A - ONEsTHREE * A0)) ;
    if ( abs(E) < EPSILON) {
      E = ZERO ;
    }
    return E ;
}
// Energy flux
SCALAR fluxQE(const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR Q) {
    return Q * ( ONEsTWO * pow(Q/A,TWO) + K / RHO * ( sqrt(A) - pow(A0, THREEsTWO) / A ) ) ;
}
SCALAR fluxE(const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR Q) {
    return ONEsTWO * pow(Q/A,TWO) + K / RHO * ( sqrt(A) - pow(A0, THREEsTWO) / A ) ;
}
// Get abs(Q) from energy
SCALAR EtoQ(const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR E) {
    return sqrt( TWO * A * abs( E - K / RHO * ( TWOsTHREE * pow(A, THREEsTWO) - sqrt(A0) * ( A - ONEsTHREE * A0) ) ) ) ;
}

// Riemann invariants (incoming and outgoing)
SCALAR W1(const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR Q) {
    return Q / A + FOUR * cmk(RHO,K,A);
}
SCALAR W2(const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR Q) {
    return Q / A - FOUR * cmk(RHO,K,A);
}
// Eigen values of the jacobian
SCALAR l1(const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR Q) {
    return Q / A + cmk(RHO,K,A);
}
SCALAR l2(const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR Q) {
    return Q / A - cmk(RHO,K,A);
}
// Moens-Korteweg celerity
SCALAR cmk(const SCALAR RHO, const SCALAR K, const SCALAR A)  {
    return sqrt( ONEsTWO * K / RHO * sqrt(A) );
}

// Functions for boundary conditions
SCALAR AfromW(const SCALAR RHO, const SCALAR K, const SCALAR W1,const SCALAR W2) {
  return pow( (W1 - W2), FOUR) * pow( 32.L * K / RHO , -TWO ) ;
}
SCALAR QfromW(const SCALAR A, const SCALAR W1, const SCALAR W2) {
  return A * ONEsTWO * (W1 + W2) ;
}
SCALAR QfromW1(const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR W1) {
  return A * (W1 - FOUR * cmk(RHO,K,A)) ;
}
SCALAR QfromW2(const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR W2) {
  return A * (W2 + FOUR * cmk(RHO,K,A)) ;
}

// Elastic pressure
SCALAR Pel(const SCALAR K, const SCALAR A0, const SCALAR A) {
    return K * ( sqrt(A) - sqrt(A0) ) ;
}
// Viscoelastic pressure correction
SCALAR Pvis(const SCALAR dt, const SCALAR RHO, const SCALAR Cv, const SCALAR A, const SCALAR Am1 )  {
    return Cv * RHO / A * ( A - Am1 ) / dt ;
}
// Total pressure
SCALAR Pt(const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR Q) {
    return ONEsTWO * RHO * pow( Q/A, TWO) + Pel(K,A0,A) ;
}
