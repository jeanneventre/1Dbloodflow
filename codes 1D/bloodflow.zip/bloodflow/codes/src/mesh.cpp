#include "mesh.h"

meshCell::meshCell  () {}
meshCell::~meshCell () {printf("\n%s\n", "meshCell deleted.");}

meshBC::meshBC      () {}
meshBC::~meshBC     () {printf("\n%s\n", "meshBC deleted.");}

meshFace::meshFace  () {}
meshFace::~meshFace () {printf("\n%s\n", "meshFace deleted.");}
//####################################################
// High Order Reconstruction
//####################################################
void meshCell::set_Auxillary() {
  // Auxillary variables used in high order reconstructiion
  for (int i=0; i<nx; i++) {
    Ho[i]   = k[i] * sqrt(A[i]) ;
    HmZo[i] = k[i] * ( sqrt(A[i]) - sqrt(a0[i]) ) ;
  }
}
void meshBC::set_Auxillary() {
  // Auxillary variables used in high order reconstructiion
  for (int i=0; i<2; i++) {
    Ho[i]   = k[i] * sqrt(A[i]) ;
    HmZo[i] = k[i] * ( sqrt(A[i]) - sqrt(a0[i]) ) ;
  }
}
