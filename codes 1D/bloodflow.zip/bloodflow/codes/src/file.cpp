#include "file.h"

file::file () {}

file::~file () {printf("\n%s\n\n", "file deleted." );}
