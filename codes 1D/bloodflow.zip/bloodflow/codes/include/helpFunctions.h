#ifndef HELPFUNCTIONS_H
#define HELPFUNCTIONS_H

#include <misc.h>
#include <VECT.h>

//#######
SCALAR kahanSum     (const VECT& IN) ;
SCALAR sign         (SCALAR a) ;
SCALAR interpOrder  (const int order,const SCALAR x, const SCALAR x1, const SCALAR y1, const SCALAR x2, const SCALAR y2, const SCALAR x3, const SCALAR y3)  ;
//#######
// Fluxes
SCALAR fluxP    (const SCALAR RHO, const SCALAR K, const SCALAR A) ;
SCALAR fluxQ    (const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR Q) ;

// Momentum
SCALAR Momentum (const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR Q) ;
// Energy
SCALAR Energy   (const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR Q) ;
SCALAR fluxQE   (const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR Q) ;
SCALAR fluxE    (const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR Q) ;
SCALAR EtoQ     (const SCALAR RHO, const SCALAR K, const SCALAR A0, const SCALAR A, const SCALAR E) ;

// Riemann invariants, eigenvalues and celerity
SCALAR W1       (const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR Q);
SCALAR W2       (const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR Q);
SCALAR l1       (const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR Q);
SCALAR l2       (const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR Q);
SCALAR cmk      (const SCALAR RHO, const SCALAR K, const SCALAR A)  ;
SCALAR AfromW   (const SCALAR RHO, const SCALAR K, const SCALAR W1,const SCALAR W2) ;
SCALAR QfromW   (const SCALAR A,   const SCALAR W1,const SCALAR W2) ;
SCALAR QfromW1  (const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR W1) ;
SCALAR QfromW2  (const SCALAR RHO, const SCALAR K, const SCALAR A, const SCALAR W2) ;

// Pressure (elastic, viscoelastic and total)
SCALAR Pel      (const SCALAR K,   const SCALAR A0,  const SCALAR A) ;
SCALAR Pvis     (const SCALAR dt,  const SCALAR RHO, const SCALAR Cv, const SCALAR A, const SCALAR Am1 )  ;
SCALAR Pt       (const SCALAR RHO, const SCALAR K,   const SCALAR A0, const SCALAR A, const SCALAR Q) ;

#endif // HELPFUNCTIONS_H
