#ifndef VESSELPROPERTIES_H
#define VESSELPROPERTIES_H

#include <misc.h>
#include <VECT.h>
#include <bc.h>

class vesselProperties {

  // Private variables can only be accessed by the base class
  private:

    // Numerics
    //#########
    string  solver,hr ;
    SCALAR  order ;

    int     nx ;
    VECT    dx ;

    // Physics
    SCALAR  rho ;
    VECT    k,cv,knl ;

    // Rheology
    VECT phi ;
    VECT mu0,mu1 ;
    VECT kmu,amu ;

    // Geometry
    //#########
    SCALAR  l ;
    VECT    a0 ;

    // Initial conditions
    //###################
    VECT initA,initQ ;
    VECT initF,initH ;
    VECT initC,initO ;

    // Boundary conditions
    //####################
    vector<bc> artbc ;
    VECT    ina0,outa0 ;
    VECT    ink,outk ;
    VECT    indx,outdx ;
    SCALAR  inang,outang ;
    SCALAR  outP ;
    // Others
    //#######
    string namefile;
  	string parser_output, parser_output2;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Default constructor
    //####################
    vesselProperties();
    // Default destructor
    //####################
    virtual ~vesselProperties();

    // Setters
    //########
    const string& get_solver() const   {return solver;}
    const string& get_hr()     const   {return hr;}
    SCALAR        get_order()  const   {return order;}
    int           get_nx()     const   {return nx;}
    const VECT&   get_dx()     const   {return dx;}

    SCALAR        get_rho()    const   {return rho;}
    const VECT&   get_k()      const   {return k;}
    const VECT&   get_cv()     const   {return cv;}
    const VECT&   get_knl()    const   {return knl;}

    const VECT&   get_phi()    const   {return phi;}
    const VECT&   get_mu0()    const   {return mu0;}
    const VECT&   get_mu1()    const   {return mu1;}
    const VECT&   get_kmu()    const   {return kmu;}
    const VECT&   get_amu()    const   {return amu;}

    SCALAR        get_l()      const   {return l;}
    const VECT&   get_a0()     const   {return a0;}

    const VECT&   get_initA()  const   {return initA;}
    const VECT&   get_initQ()  const   {return initQ;}
    const VECT&   get_initF()  const   {return initF;}
    const VECT&   get_initH()  const   {return initH;}
    const VECT&   get_initC()  const   {return initC;}
    const VECT&   get_initO()  const   {return initO;}

    const vector<bc>&   get_artbc()     const   {return artbc;}

    const VECT&   get_ina0()   const   {return ina0;}
    const VECT&   get_outa0()  const   {return outa0;}
    const VECT&   get_ink()    const   {return ink;}
    const VECT&   get_outk()   const   {return outk;}
    const VECT&   get_indx()   const   {return indx;}
    const VECT&   get_outdx()  const   {return outdx;}
    SCALAR        get_inang()  const   {return inang;}
    SCALAR        get_outang() const   {return outang;}
    SCALAR        get_outP()   const   {return outP;}

    // Getters
    //########
    void set_solver (const string& _x)    {solver=_x;}
    void set_hr     (const string& _x)    {hr=_x  ;}
    void set_order  (const SCALAR _x)     {order=_x;}
    void set_nx     (const int _x)        {nx=_x  ;}
    void set_dx     (const VECT& _x)      {dx=_x  ;}

    void set_rho    (const SCALAR _x)     {rho=_x ;}
    void set_k      (const VECT& _x)      {k=_x   ;}
    void set_cv     (const VECT& _x)      {cv=_x  ;}
    void set_knl    (const VECT& _x)      {knl=_x ;}

    void set_phi    (const VECT& _x)      {phi=_x ;}
    void set_mu0    (const VECT& _x)      {mu0=_x ;}
    void set_mu1    (const VECT& _x)      {mu1=_x ;}
    void set_kmu    (const VECT& _x)      {kmu=_x ;}
    void set_amu    (const VECT& _x)      {amu=_x ;}

    void set_l      (const SCALAR _x)     {l=_x;}
    void set_a0     (const VECT& _x)      {a0=_x;}

    void set_initA  (const VECT& _x)      {initA=_x ;}
    void set_initQ  (const VECT& _x)      {initQ=_x ;}
    void set_initF  (const VECT& _x)      {initF=_x ;}
    void set_initH  (const VECT& _x)      {initH=_x ;}
    void set_initC  (const VECT& _x)      {initC=_x ;}
    void set_initO  (const VECT& _x)      {initO=_x ;}

    // Boundary condition
    //###################
    void          add_bc  (bc& _bc)                         { artbc.push_back(_bc)        ;}
    int           size_bc ()                          const { return artbc.size()         ;}
    const string& type_bc (const int n)               const { return artbc[n].get_type()  ;}
    const VECT&   data_bc (const int n)               const { return artbc[n].get_data()  ;}
    SCALAR        data_bc (const int n, const int nt) const { return artbc[n].get_data(nt);}

    void set_ina0     (const VECT& _x)  {ina0   =_x ;}
    void set_outa0    (const VECT& _x)  {outa0  =_x ;}
    void set_ink      (const VECT& _x)  {ink    =_x ;}
    void set_outk     (const VECT& _x)  {outk   =_x ;}
    void set_indx     (const VECT& _x)  {indx   =_x ;}
    void set_outdx    (const VECT& _x)  {outdx  =_x ;}
    void set_inang    (const SCALAR _x) {inang  =_x ;}
    void set_outang   (const SCALAR _x) {outang =_x ;}
    void set_outP     (const SCALAR _x) {outP   =_x ;}

  };

#endif // VESSELPROPERTIES_H
