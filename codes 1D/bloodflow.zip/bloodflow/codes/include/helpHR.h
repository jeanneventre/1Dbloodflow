#ifndef HELPHR_H
#define HELPHR_H

#include <misc.h>

// Hydrostatic reconstruction
SCALAR recK   (const SCALAR kl,  const SCALAR kr) ;
SCALAR recZ   (const SCALAR Zl,  const SCALAR Zr) ;
SCALAR recA   (const SCALAR khr, const SCALAR a0hr, const SCALAR HmZo ) ;
// Centered values for high order hydrostatic reconstruction
SCALAR recKc  (const SCALAR Kl,  const SCALAR Kr) ;
SCALAR recZc  (const SCALAR Zl,  const SCALAR Zr) ;

#endif // HELPHR_H
