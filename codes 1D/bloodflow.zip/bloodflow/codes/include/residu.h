#ifndef RESIDU_H
#define RESIDU_H

#include <misc.h>

class residu {

  // Private variables can only be accessed by the base class
  private:

    SCALAR resA,resQ ;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Constructor
    //############
    residu() ;
    // Default destructor
    //####################
    virtual ~residu() ;

    // Setters
    //########
    void set_resA (const SCALAR _res) { resA = _res ;}
    void set_resQ (const SCALAR _res) { resQ = _res ;}

    // Getters
    //########
    SCALAR get_resA () const { return double(resA)  ;}
    SCALAR get_resQ () const { return double(resQ)  ;}
};

#endif // RESIDU_H
