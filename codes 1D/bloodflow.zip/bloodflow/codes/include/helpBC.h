#ifndef HELPBC_H
#define HELPBC_H

#include <misc.h>
#include <VECT.h>

#include <mesh.h>

#include <helpFunctions.h>
#include <helpFlux.h>
#include <helpOrder.h>
#include <helpHR.h>

#include <alger.h>
using namespace alger;

  VECT fun_inflow_Q     (const VECT& AQ, const VECT& par) ;
  VECT fun_inflow_AQ    (const VECT& AQ, const VECT& par) ;
  VECT fun_outflow_Q    (const VECT& AQ, const VECT& par) ;
  VECT fun_outflow_AQ   (const VECT& AQ, const VECT& par) ;
  VECT fun_outflow_R    (const VECT& AQ, const VECT& par) ;
  VECT fun_outflow_RC   (const VECT& AQ, const VECT& par) ;
  VECT fun_outflow_RCR  (const VECT& AQ, const VECT& par) ;

  // Inlet
  //######
  VECT inflow_Q   (const meshCell& cells, const meshBC& inlet, const VECT& inData) ;
  VECT inflow_U   (const meshCell& cells, const meshBC& inlet, const VECT& inData) ;
  VECT inflow_AQ  (const meshCell& cells, const meshBC& inlet, const VECT& inData) ;
  VECT inflow_AU  (const meshCell& cells, const meshBC& inlet, const VECT& inData) ;

  VECT inflow_A   (const meshCell& cells, const meshBC& inlet, const VECT& inData) ;
  VECT inflow_P   (const meshCell& cells, const meshBC& inlet, const VECT& inData) ;
  VECT inflow_Rt  (const meshCell& cells, const meshBC& inlet, const VECT& inData) ;

  // Outlet
  //#######
  VECT outflow_Q  (const meshCell& cells, const meshBC& outlet, const VECT& outData) ;
  VECT outflow_U  (const meshCell& cells, const meshBC& outlet, const VECT& outData) ;
  VECT outflow_AQ (const meshCell& cells, const meshBC& outlet, const VECT& outData) ;

  VECT outflow_A  (const meshCell& cells, const meshBC& outlet, const VECT& outData) ;
  VECT outflow_P  (const meshCell& cells, const meshBC& outlet, const VECT& outData) ;

  VECT outflow_Rt (const meshCell& cells, const meshBC& outlet, const VECT& outData) ;
  VECT outflow_R  (const meshCell& cells, const meshBC& outlet, const VECT& outData) ;
  VECT outflow_RC (const meshCell& cells, const meshBC& outlet, const VECT& outData) ;
  VECT outflow_RCR(const meshCell& cells, const meshBC& outlet, const VECT& outData) ;

#endif // HELPBC_H
