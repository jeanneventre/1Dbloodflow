#ifndef ARTERYNUM_H
#define ARTERYNUM_H

#include <misc.h>
#include <VECT.h>

#include <artery.h>
#include <mesh.h>
#include <timenet.h>
#include <vesselProperties.h>
#include <bc.h>

#include <triDiagMatrix.h>

#include <helpBC.h>
#include <helpFunctions.h>
#include <helpFlux.h>
#include <helpOrder.h>
#include <helpHR.h>
#include <helpViscous.h>

#include <alger.h>
using namespace alger;

// Inherited class artery
class arteryNum : public artery {

  // Private variables can only be accessed by the base class
  private:

    // Mesh
    //#####
    vector<meshFace> faces ;

    // Tridiagonal matrix
    //###################
    triDiagMatrix Amatrix, Bmatrix;

    // Boundary conditions
    void bcAQin (const time_c& timenet, const vector<bc>& _bc) ;
    void bcAQout(const time_c& timenet, const vector<bc>& _bc) ;
    void bcHF   (const time_c& timenet, const vector<bc>& _bc) ;
    void bcPS   (const time_c& timenet, const vector<bc>& _bc) ;


    // Time stepping
    void SSPRK2           (const time_c& timenet) ;
    void AB2              (const time_c& timenet) ;
    void CrankNicolson    () ;
    void NonDifferential  () ;

    // Time stepping hyperbolic reaction equation
    void SSPRK2Advection  (const SCALAR dt) ;
    void AB2Advection     (const SCALAR dt) ;
    void SSPRK2Reaction   (const SCALAR dt) ;
    void AB2Reaction      (const SCALAR dt) ;

    // Compute reaction terms
    void stepReacReaction (VECT& REACQ, VECT& REACF, VECT& REACTMU) ;
    void reacQ            (VECT& reacQ) ;
    void reacTmu          (VECT& reacTmu) ;
    void reacF            (VECT& reacF) ;

    // Compute right hand side
    void stepRhsAdvection (VECT& RHSA, VECT& RHSQ, VECT& RHSF, VECT& RHSH, VECT& RHSC, VECT& RHSO);
    void rhsAQ            (VECT& rhsA, VECT& rhsQ) ;
    void rhsF             (VECT& rhsF) ;
    void rhsPS            (VECT& rhsH, VECT& rhsC, VECT& rhsO) ;

    // Compute fluxes
    void stepFlux ();
    void fluxAQ   ();
    void fluxQhr  ();
    void fluxPS   ();

    // Reconstruct data (high order and hydrostatic reconstruction)
    void stepReconstruct  ();
    void reconstructOrder ();
    void reconstructHR    ();
    void set_HR           (const int i) ;

    // Initialize
    void set_interface      ();
    void set_diffusionMatrix(const SCALAR dt);

    // Residu
    void residu() ;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Constructor
    //############
    arteryNum(const vesselProperties& vP, const time_c& timenet);
    // Default destructor
    //####################
    virtual ~arteryNum() ;

    // Getters
    const meshFace& get_faces  (const int i) { return faces[i] ;}

    // Time advance
    void stepBC (const time_c& timenet) ;
    void step   (const time_c& timenet);
};

#endif // ARTERYNUM_H
