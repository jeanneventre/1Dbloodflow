#ifndef FILE_H
#define FILE_H

#include "misc.h"

class file {

  // Private variables can only be accessed by the base class
  private:

    string dagFile;
    string bcFile, bcpropertiesFile;

    string propertiesFile;
    string dxFile;
    string a0File, kFile, cvFile, knlFile;
    string phiFile, mu0File, mu1File, kmuFile, amuFile;

    string initAFile, initQFile;
    string initFFile, initHFile;
    string initCFile, initOFile;

    string outputFile;
    string timeFile;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Default constructor
    //####################
    file();
    // Default destructor
    //####################
    virtual ~file() ;

    // Setters
    //########
    const string& get_dagFile()          const   {return dagFile;}
    const string& get_bcFile()           const   {return bcFile;}
    const string& get_bcpropertiesFile() const   {return bcpropertiesFile;}
    const string& get_propertiesFile()   const   {return propertiesFile;}
    const string& get_dxFile()           const   {return dxFile;}
    const string& get_a0File()           const   {return a0File;}
    const string& get_kFile()            const   {return kFile;}
    const string& get_cvFile()           const   {return cvFile;}
    const string& get_knlFile()          const   {return knlFile;}

    const string& get_phiFile()          const   {return phiFile;}
    const string& get_mu0File()          const   {return mu0File;}
    const string& get_mu1File()          const   {return mu1File;}
    const string& get_kmuFile()          const   {return kmuFile;}
    const string& get_amuFile()          const   {return amuFile;}

    const string& get_initAFile()        const   {return initAFile;}
    const string& get_initQFile()        const   {return initQFile;}
    const string& get_initFFile()        const   {return initFFile;}
    const string& get_initHFile()        const   {return initHFile;}
    const string& get_initCFile()        const   {return initCFile;}
    const string& get_initOFile()        const   {return initOFile;}

    const string& get_outputFile()       const   {return outputFile;}
    const string& get_timeFile()         const   {return timeFile;}


    // Getters
    //########
    void set_dagFile          (const string & _x) {dagFile          =_x;}
    void set_bcFile           (const string & _x) {bcFile           =_x;}
    void set_bcpropertiesFile (const string & _x) {bcpropertiesFile =_x;}
    void set_propertiesFile   (const string & _x) {propertiesFile   =_x;}
    void set_dxFile           (const string & _x) {dxFile           =_x;}
    void set_a0File           (const string & _x) {a0File           =_x;}
    void set_kFile            (const string & _x) {kFile            =_x;}
    void set_cvFile           (const string & _x) {cvFile           =_x;}
    void set_knlFile          (const string & _x) {knlFile          =_x;}

    void set_phiFile          (const string & _x) {phiFile          =_x;}
    void set_mu0File          (const string & _x) {mu0File          =_x;}
    void set_mu1File          (const string & _x) {mu1File          =_x;}
    void set_kmuFile          (const string & _x) {kmuFile          =_x;}
    void set_amuFile          (const string & _x) {amuFile          =_x;}

    void set_initAFile        (const string & _x) {initAFile        =_x;}
    void set_initQFile        (const string & _x) {initQFile        =_x;}
    void set_initFFile        (const string & _x) {initFFile        =_x;}
    void set_initHFile        (const string & _x) {initHFile        =_x;}
    void set_initCFile        (const string & _x) {initCFile        =_x;}
    void set_initOFile        (const string & _x) {initOFile        =_x;}

    void set_outputFile       (const string & _x) {outputFile       =_x;}
    void set_timeFile         (const string & _x) {timeFile         =_x;}

  };

#endif // FILE_H
