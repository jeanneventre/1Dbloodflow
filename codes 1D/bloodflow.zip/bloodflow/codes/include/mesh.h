#ifndef MESH_H
#define MESH_H

#include <misc.h>
#include <VECT.h>

// Mesh Cell
//##########
class meshCell {

  // Private variables can only be accessed by the base class
  private:

    // Physics
    SCALAR  rho ;
    SCALAR  l ;
    VECT    a0 ;
    VECT    k,cv ;

    // Rheology
    VECT  phi ;
    VECT  mu0,mu1 ;
    VECT  kmu,amu ;

    // Mesh
    int   nx ;
    VECT  dx,x ;

    // Variables
    VECT  A,Q;
    VECT  H,C,O ;
    VECT  F,G,Tmu,T ;

    // Auxillary variables
    VECT  Ho,HmZo ;
    // rhs and reac variables
    VECT RHSA,RHSQ,RHSF,RHSH,RHSC,RHSO;
    VECT REACQ,REACF,REACTMU ;

    // Previous time variables
    VECT Am1,Qm1;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Default constructor
    //####################
    meshCell();
    // Default destructor
    //####################
    virtual ~meshCell() ;

    // Setters
    //########
    void    set_rho     (const SCALAR _x)   { rho = _x    ;}
    void    set_l       (const SCALAR _x)   { l   = _x    ;}
    void    set_a0      (const VECT& _x)    { a0  = _x    ;}
    void    set_k       (const VECT& _x)    { k   = _x    ;}
    void    set_cv      (const VECT& _x)    { cv  = _x    ;}
    void    set_phi     (const VECT& _x)    { phi = _x    ;}
    void    set_mu0     (const VECT& _x)    { mu0 = _x    ;}
    void    set_mu1     (const VECT& _x)    { mu1 = _x    ;}
    void    set_kmu     (const VECT& _x)    { kmu = _x    ;}
    void    set_amu     (const VECT& _x)    { amu = _x    ;}

    void    set_nx      (const int  _x)     { nx  = _x    ;}
    void    set_dx      (const VECT& _x)    { dx  = _x    ;}
    void    set_x       (const VECT& _x)    { x   = _x    ;}

    // By vector
    void    set_A       (const VECT& _x)    { A   = _x    ;}
    void    set_Q       (const VECT& _x)    { Q   = _x    ;}

    void    set_H       (const VECT& _x)    { H   = _x    ;}
    void    set_C       (const VECT& _x)    { C   = _x    ;}
    void    set_O       (const VECT& _x)    { O   = _x    ;}

    void    set_F       (const VECT& _x)    { F   = _x    ;}
    void    set_G       (const VECT& _x)    { G   = _x    ;}
    void    set_Tmu     (const VECT& _x)    { Tmu = _x    ;}
    void    set_T       (const VECT& _x)    { T   = _x    ;}

    void    set_Ho      (const VECT& _x)    { Ho  = _x    ;}
    void    set_HmZo    (const VECT& _x)    { HmZo= _x    ;}

    void    set_RHSA    (const VECT& _x)    { RHSA= _x    ;}
    void    set_RHSQ    (const VECT& _x)    { RHSQ= _x    ;}
    void    set_RHSF    (const VECT& _x)    { RHSF= _x    ;}
    void    set_RHSH    (const VECT& _x)    { RHSH= _x    ;}
    void    set_RHSC    (const VECT& _x)    { RHSC= _x    ;}
    void    set_RHSO    (const VECT& _x)    { RHSO= _x    ;}

    void    set_REACQ   (const VECT& _x)    { REACQ= _x   ;}
    void    set_REACF   (const VECT& _x)    { REACF= _x   ;}
    void    set_REACTMU (const VECT& _x)    { REACTMU= _x ;}

    void    set_Am1     (const VECT& _x)    { Am1 = _x    ;}
    void    set_Qm1     (const VECT& _x)    { Qm1 = _x    ;}

    // By indice
    void    set_A       (const int i, const SCALAR _x)  { A[i]  = _x  ;}
    void    set_Q       (const int i, const SCALAR _x)  { Q[i]  = _x  ;}

    void    set_H       (const int i, const SCALAR _x)  { H[i]  = _x  ;}
    void    set_C       (const int i, const SCALAR _x)  { C[i]  = _x  ;}
    void    set_O       (const int i, const SCALAR _x)  { O[i]  = _x  ;}

    void    set_F       (const int i, const SCALAR _x)  { F[i]  = _x  ;}
    void    set_G       (const int i, const SCALAR _x)  { G[i]  = _x  ;}
    void    set_Tmu     (const int i, const SCALAR _x)  { Tmu[i]= _x  ;}
    void    set_T       (const int i, const SCALAR _x)  { T[i]  = _x  ;}

    void    set_Auxillary() ;

    // Getters
    //########
    SCALAR        get_rho       () const { return rho  ;}
    SCALAR        get_l         () const { return l    ;}
    const VECT&   get_a0        () const { return a0   ;}
    const VECT&   get_k         () const { return k    ;}
    const VECT&   get_cv        () const { return cv   ;}
    const VECT&   get_phi       () const { return phi  ;}
    const VECT&   get_mu0       () const { return mu0  ;}
    const VECT&   get_mu1       () const { return mu1  ;}
    const VECT&   get_kmu       () const { return kmu  ;}
    const VECT&   get_amu       () const { return amu  ;}

    int           get_nx        () const { return nx   ;}
    const VECT&   get_dx        () const { return dx   ;}
    const VECT&   get_x         () const { return x    ;}

    const VECT&   get_A         () const { return A    ;}
    const VECT&   get_Q         () const { return Q    ;}

    const VECT&   get_H         () const { return H    ;}
    const VECT&   get_C         () const { return C    ;}
    const VECT&   get_O         () const { return O    ;}

    const VECT&   get_F         () const { return F    ;}
    const VECT&   get_G         () const { return G    ;}
    const VECT&   get_Tmu       () const { return Tmu  ;}
    const VECT&   get_T         () const { return T    ;}

    const VECT&   get_Ho        () const { return Ho   ;}
    const VECT&   get_HmZo      () const { return HmZo ;}

    const VECT&   get_RHSA      () const { return RHSA ;}
    const VECT&   get_RHSQ      () const { return RHSQ ;}
    const VECT&   get_RHSF      () const { return RHSF ;}
    const VECT&   get_RHSH      () const { return RHSH ;}
    const VECT&   get_RHSC      () const { return RHSC ;}
    const VECT&   get_RHSO      () const { return RHSO ;}

    const VECT&   get_REACQ     () const { return REACQ;}
    const VECT&   get_REACF     () const { return REACF;}
    const VECT&   get_REACTMU   () const { return REACTMU;}

    const VECT&   get_Am1       () const { return Am1  ;}
    const VECT&   get_Qm1       () const { return Qm1  ;}

};

// Mesh Boundary
//##############
class meshBC {

  // Private variables can only be accessed by the base class
  private:

    // Physics
    VECT  a0 ;
    VECT  k ;

    // Mesh
    VECT    dx ;
    SCALAR  angle ; // Angle of bifurcation
    SCALAR  P ;     // Capillary pressure (used in resistive BC)

    // Variables
    VECT  A,Q;
    VECT  H,C,O ;
    VECT  F,G,Tmu,T ;

    // Riemann invariants
    SCALAR W10,W20 ;

    // Auxillary variables
    VECT  Ho,HmZo ;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Default constructor
    //####################
    meshBC();
    // Default destructor
    //####################
    virtual ~meshBC() ;

    // Setters
    //########
    void    set_a0      (const VECT& _x)    { a0    = _x  ;}
    void    set_k       (const VECT& _x)    { k     = _x  ;}

    void    set_dx      (const VECT& _x)    { dx    = _x  ;}
    void    set_angle   (const SCALAR _x)   { angle = _x  ;}
    void    set_P       (const SCALAR _x)   { P     = _x  ;}

    void    set_A       (const VECT& _x)    { A     = _x  ;}
    void    set_Q       (const VECT& _x)    { Q     = _x  ;}

    void    set_H       (const VECT& _x)    { H     = _x  ;}
    void    set_C       (const VECT& _x)    { C     = _x  ;}
    void    set_O       (const VECT& _x)    { O     = _x  ;}

    void    set_F       (const VECT& _x)    { F     = _x  ;}
    void    set_G       (const VECT& _x)    { G     = _x  ;}
    void    set_Tmu     (const VECT& _x)    { Tmu   = _x  ;}
    void    set_T       (const VECT& _x)    { T     = _x  ;}

    void    set_Ho      (const VECT& _x)    { Ho    = _x  ;}
    void    set_HmZo    (const VECT& _x)    { HmZo  = _x  ;}

    void    set_a0      (int i, const SCALAR _x)   { a0[i]= _x  ;}
    void    set_k       (int i, const SCALAR _x)   { k[i] = _x  ;}

    void    set_dx      (int i, const SCALAR _x)   { dx[i]= _x  ;}

    void    set_A       (int i, const SCALAR _x)   { A[i] = _x  ;}
    void    set_Q       (int i, const SCALAR _x)   { Q[i] = _x  ;}

    void    set_H       (int i, const SCALAR _x)   { H[i] = _x  ;}
    void    set_C       (int i, const SCALAR _x)   { C[i] = _x  ;}
    void    set_O       (int i, const SCALAR _x)   { O[i] = _x  ;}

    void    set_F       (int i, const SCALAR _x)   { F[i] = _x  ;}
    void    set_G       (int i, const SCALAR _x)   { G[i] = _x  ;}
    void    set_Tmu     (int i, const SCALAR _x)   { Tmu[i]= _x ;}
    void    set_T       (int i, const SCALAR _x)   { T[i] = _x  ;}

    void    set_W10     (const SCALAR _x)   { W10   = _x  ;}
    void    set_W20     (const SCALAR _x)   { W20   = _x  ;}

    void    set_Auxillary() ;

    // Getters
    //########
    const VECT&   get_a0      () const { return a0     ;}
    const VECT&   get_k       () const { return k      ;}

    const VECT&   get_dx      () const { return dx     ;}
    SCALAR        get_angle   () const { return angle  ;}
    SCALAR        get_P       () const { return P      ;}

    const VECT&   get_A       () const { return A      ;}
    const VECT&   get_Q       () const { return Q      ;}

    const VECT&   get_H       () const { return H      ;}
    const VECT&   get_C       () const { return C      ;}
    const VECT&   get_O       () const { return O      ;}

    const VECT&   get_F       () const { return F      ;}
    const VECT&   get_G       () const { return G      ;}
    const VECT&   get_Tmu     () const { return Tmu    ;}
    const VECT&   get_T       () const { return T      ;}

    SCALAR        get_W10     () const { return W10    ;}
    SCALAR        get_W20     () const { return W20    ;}

    const VECT&   get_Ho      () const { return Ho     ;}
    const VECT&   get_HmZo    () const { return HmZo   ;}

};

// Mesh Interface
//###############
class meshFace {

  // Private variables can only be accessed by the base class
  private:

    // Physics
    VECT  a0 ;
    VECT  k ;

    // Variables
    VECT    A,Q ;
    VECT    H,C,O ;
    VECT    F ;

    // Fluxes
    SCALAR  FA,FQ ;
    SCALAR  FH,FC,FO ;
    SCALAR  FF;
    VECT    FQhr ;

    // Auxillary variables for hydrostatic reconstruction
    SCALAR  khr,a0hr;
    VECT    Ahr,Ac ;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Default constructor
    //####################
    meshFace();
    // Default destructor
    //####################
    virtual ~meshFace() ;

    // Setters
    //########
    void    set_a0      (const VECT& _x)    { a0    = _x  ;}
    void    set_k       (const VECT& _x)    { k     = _x  ;}

    void    set_A       (const VECT& _x)    { A     = _x  ;}
    void    set_Q       (const VECT& _x)    { Q     = _x  ;}

    void    set_H       (const VECT& _x)    { H     = _x  ;}
    void    set_C       (const VECT& _x)    { C     = _x  ;}
    void    set_O       (const VECT& _x)    { O     = _x  ;}

    void    set_F       (const VECT& _x)    { F     = _x  ;}

    void    set_khr     (const SCALAR _x)   { khr   = _x  ;}
    void    set_a0hr    (const SCALAR _x)   { a0hr  = _x  ;}
    void    set_Ahr     (const VECT& _x)    { Ahr   = _x  ;}
    void    set_Ac      (const VECT& _x)    { Ac    = _x  ;}

    void    set_FA      (const SCALAR _x)   { FA    = _x  ;}
    void    set_FQ      (const SCALAR _x)   { FQ    = _x  ;}
    void    set_FH      (const SCALAR _x)   { FH    = _x  ;}
    void    set_FC      (const SCALAR _x)   { FC    = _x  ;}
    void    set_FO      (const SCALAR _x)   { FO    = _x  ;}
    void    set_FF      (const SCALAR _x)   { FF    = _x  ;}

    void    set_FQhr    (const VECT& _x)            { FQhr    = _x  ;}
    void    set_FQhr    (int i, const SCALAR _x)    { FQhr[i] = _x  ;}

    // Getters
    //########
    const VECT&   get_a0      () const { return a0   ;}
    const VECT&   get_k       () const { return k    ;}

    const VECT&   get_A       () const { return A    ;}
    const VECT&   get_Q       () const { return Q    ;}

    const VECT&   get_H       () const { return H    ;}
    const VECT&   get_C       () const { return C    ;}
    const VECT&   get_O       () const { return O    ;}

    const VECT&   get_F       () const { return F    ;}

    SCALAR        get_khr     () const { return khr  ;}
    SCALAR        get_a0hr    () const { return a0hr ;}
    const VECT&   get_Ahr     () const { return Ahr  ;}
    const VECT&   get_Ac      () const { return Ac   ;}

    SCALAR        get_FA      () const { return FA   ;}
    SCALAR        get_FQ      () const { return FQ   ;}
    SCALAR        get_FH      () const { return FH   ;}
    SCALAR        get_FC      () const { return FC   ;}
    SCALAR        get_FO      () const { return FO   ;}
    SCALAR        get_FF      () const { return FF   ;}

    const VECT&   get_FQhr    () const { return FQhr ;}

};

#endif // MESH_H
