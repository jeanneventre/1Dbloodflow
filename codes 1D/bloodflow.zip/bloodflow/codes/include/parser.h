#ifndef PARSER_H
#define PARSER_H

#include <misc.h>
#include <vesselProperties.h>
#include <stringManage.h>
#include <file.h>
#include <bc.h>
#include <timenet.h>
#include <output.h>
#include <artery.h>
#include <conjunction.h>
#include <conjunctionNum.h>

using namespace std;
using namespace stringManage;

class parser {

	// Private variables can only be accessed by the base class
  private:

		string * propertiesData;
    string * bcData ;
    string * bcpropertiesData ;
    string * timeData ;
    MATR dagData, outputData;
		MATR dxData,a0Data,kData,cvData,knlData;
    MATR phiData,mu0Data,mu1Data,kmuData,amuData;
    MATR initAData,initQData;
    MATR initFData,initHData;
    MATR initCData,initOData;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

		// Constructor
	  //############
		parser(const file& dataFile);
    // Default destructor
    //####################
    virtual ~parser() ;

		// Read all files
		void readtoString( const char* file, string*& data ) ;
    void readtoMatrix( const char* file, MATR& data ) ;

    // Setters
    //########
    int   nSet            ( const char* file) ;
	  void  propertiesSet   (vector<vesselProperties>&, const int n);
    void  bcSet           (vector<vesselProperties>&, const int n);
    void  bcpropertiesSet (vector<vesselProperties>&, const int n);
    void  tSet            (time_c& timenet) ;
    void  outputSet       (output& outnet) ;
    int   dagSet          (vector<artery*>&,vector<conjunction*>&) ;
};


#endif // PARSER_H
