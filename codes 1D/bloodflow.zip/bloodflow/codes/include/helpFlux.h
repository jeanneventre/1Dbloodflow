#ifndef HELPFLUX_H
#define HELPFLUX_H

#include <misc.h>
#include <VECT.h>
#include <helpFunctions.h>

// Kinetic flux with hat function
VECT flux_hat         (const SCALAR RHO,const SCALAR K,const SCALAR A_r,const SCALAR A_l,const SCALAR Q_r,const SCALAR Q_l);
// HLL flux
VECT flux_hll         (const SCALAR RHO,const SCALAR K,const SCALAR A_r,const SCALAR A_l,const SCALAR Q_r,const SCALAR Q_l);
// Flux for transport
SCALAR flux_transport (const SCALAR Q,const SCALAR Xl,const SCALAR Xr);

#endif // HELPFLUX_H
