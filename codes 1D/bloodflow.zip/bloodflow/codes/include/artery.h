#ifndef ARTERY_H
#define ARTERY_H

#include <misc.h>
#include <VECT.h>

#include <mesh.h>
#include <timenet.h>
#include <bc.h>
#include <vesselProperties.h>

#include <helpFunctions.h>
#include <helpViscous.h>

// Base class artery
class artery {

  // Private variables can only be accessed by the base class
  private:

    // Set the mesh, boundary and face classes
    void set_mesh     (const vesselProperties& vP) ;
    void set_boundary (const vesselProperties& vP) ;
    void set_boundaryConditions() ;
    // Define the position
    VECT set_x        (const VECT& dx, const SCALAR l) ;

  // Protected variables can be accessed by any derived class
  protected:

    // Numerics
    string solver;
    string hr;
    const SCALAR xorder;

    // Mesh
    meshCell  cells ;
    meshBC    inlet,outlet ;

    // Boundary conditions
    vector<bc> bcART  ;
    vector<bc> bcIN   ;
    vector<bc> bcOUT  ;
    vector<bc> bcVIS ;
    vector<bc> bcPAS ;
    vector<bc> bcJUN    ;

    // Residu variables
    SCALAR resA,resQ ;

    // Set second ghost cell for high order reconstruction
    void set_ghostCell() ;      // a0,k,A,Q,H,C,O,F

  // Public variables, accessible from outside the class
  public:

    // Constructor
    //############
    artery(const vesselProperties& vP, const time_c& timenet);
    // Default destructor
    //####################
    virtual ~artery() ;

    // Getters
    const meshCell&   get_cells   () { return cells   ;}
    meshBC&           get_inlet   () { return inlet   ;}
    meshBC&           get_outlet  () { return outlet  ;}
    const vector<bc>& get_bcJ     () { return bcJUN   ;}

    SCALAR            get_resA    () const { return resA    ;}
    SCALAR            get_resQ    () const { return resQ    ;}

    // Checkers
    SCALAR check_dt(const SCALAR dt, const SCALAR cfl) ;

    // Readers
    SCALAR read_x     (int pos) { return double(cells.get_x()[pos])   ;}
    SCALAR read_a0    (int pos) { return double(cells.get_a0()[pos])  ;}
    SCALAR read_k     (int pos) { return double(cells.get_k()[pos])   ;}

    SCALAR read_A     (int pos) { return double(cells.get_A()[pos])   ;}
    SCALAR read_Q     (int pos) { return double(cells.get_Q()[pos])   ;}

    SCALAR read_H     (int pos) { return double(cells.get_H()[pos])   ;}
    SCALAR read_C     (int pos) { return double(cells.get_C()[pos])   ;}
    SCALAR read_O     (int pos) { return double(cells.get_O()[pos])   ;}

    SCALAR read_G     (int pos) { return double(cells.get_G()[pos])   ;}
    SCALAR read_F     (int pos) { return double(cells.get_F()[pos])   ;}
    SCALAR read_Tmu   (int pos) { return double(cells.get_Tmu()[pos]) ;}
    SCALAR read_T     (int pos) { return double(cells.get_T()[pos])   ;}

    SCALAR read_P     (int pos, const SCALAR dt) ;

    // Help functions
    void verbose(const time_c& timenet) ;

    // Virtual functions (members of arteryNum)
    virtual const meshFace& get_faces(const int i) =0 ;

    virtual void stepBC (const time_c& timenet) =0 ;
    virtual void step   (const time_c& timenet) =0 ;

};

#endif // ARTERY_H
