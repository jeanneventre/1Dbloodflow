#ifndef TIMENET_H
#define TIMENET_H

#include <misc.h>
#include <VECT.h>

class time_c {

  // Private variables can only be accessed by the base class
  private:

    SCALAR ts,te,dt;
    int nt,nstore,n;
    SCALAR cfl, dtcfl;
    int order;
    VECT t;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Constructor
    //############
    time_c() ;
    // Default destructor
    //####################
    virtual ~time_c();

    // Setters
    //########
    void set_ts     (const SCALAR _x) {ts=_x    ;}
    void set_te     (const SCALAR _x) {te=_x    ;}
    void set_dt     (const SCALAR _x) {dt=_x    ;}
    void set_nt     (const int _x)    {nt=_x    ;}
    void set_nstore (const int _x)    {nstore=_x;}
    void set_t      (const VECT& _x)  {t=_x     ;}
    void set_cfl    (const SCALAR _x) {cfl=_x   ;}
    void set_dtcfl  (const SCALAR _x) {dtcfl=_x ;}
    void set_order  (const int _x)    {order=_x ;}
    void set_n      (const int _x)    {n=_x     ;}

    // Getters
    //########
    SCALAR  get_ts()      const {return ts      ;}
    SCALAR  get_te()      const {return te      ;}
    SCALAR  get_dt()      const {return dt      ;}
    int     get_nt()      const {return nt      ;}
    int     get_nstore()  const {return nstore  ;}
    SCALAR  get_t(int i)  const {return t[i]    ;}
    SCALAR  get_cfl()     const {return cfl     ;}
    SCALAR  get_dtcfl()   const {return dtcfl   ;}
    int     get_order()   const {return order   ;}
    int     get_n()       const {return n       ;}
};

#endif // TIMENET_H
