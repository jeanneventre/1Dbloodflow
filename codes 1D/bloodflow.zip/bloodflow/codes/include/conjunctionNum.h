#ifndef CONJUNCTIONNUM_H
#define CONJUNCTIONNUM_H

#include <misc.h>
#include <VECT.h>
#include <timenet.h>

#include <artery.h>
#include <conjunction.h>
#include <mesh.h>

#include <helpFunctions.h>
#include <helpViscous.h>

#include <alger.h>

using namespace alger;

// Inherited class artery
class conjunctionNum : public conjunction {

  // Private variables can only be accessed by the base class
  private:

    SCALAR Vm1, VEm1 ;

    static VECT fun_conj_PD     (const VECT& AQ, const VECT& par);
    static VECT fun_conj_PDD    (const VECT& AQ, const VECT& par);
    static VECT fun_conj_PDDD   (const VECT& AQ, const VECT& par);
    static VECT fun_conj_PDDDD  (const VECT& AQ, const VECT& par);
    static VECT fun_conj_PPD    (const VECT& AQ, const VECT& par);
    static VECT fun_conj_PPDD   (const VECT& AQ, const VECT& par);
    static VECT fun_conj_PPDDD  (const VECT& AQ, const VECT& par);

    // Specific junction treatment
    //############################
    void jS   (const time_c& timenet) ;
    void jA   (const time_c& timenet) ;
    void jAQ  (const time_c& timenet) ;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Constructor
    //############
    conjunctionNum();
    // Default destructor
    //####################
    virtual ~conjunctionNum() ;

    // Time advance
    //#############
    void stepConj(const time_c& timenet) ;


};

#endif // CONJUNCTIONNUM_H
