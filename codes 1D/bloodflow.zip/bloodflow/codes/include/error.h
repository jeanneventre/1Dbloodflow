#ifndef ERROR_H_INCLUDED
#define ERROR_H_INCLUDED

#include <lib.h>

void Error    ( std::string );
void Warning  ( std::string );

#endif // ERROR_H_INCLUDED
