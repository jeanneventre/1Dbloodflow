#ifndef HELPVISCOUS_H
#define HELPVISCOUS_H

#include <misc.h>

// Rheology & Aggregation

SCALAR mu0      (const SCALAR mu0,  const SCALAR H) ;
SCALAR mu1      (const SCALAR m1,   const SCALAR H) ;
SCALAR kmu      (const SCALAR kmu,  const SCALAR H) ;
SCALAR amu      (const SCALAR amu,  const SCALAR H) ;

SCALAR lst      (const SCALAR k,   const SCALAR F) ;
SCALAR oneSlst  (const SCALAR k,   const SCALAR F) ;
SCALAR must     (const SCALAR mu0, const SCALAR m1, const SCALAR F) ;

SCALAR prodesF  (const SCALAR k,   const SCALAR a,   const SCALAR G,   const SCALAR H, const SCALAR F) ;
SCALAR prodTmu  (const SCALAR mu0, const SCALAR m1, const SCALAR kmu, const SCALAR G, const SCALAR H, const SCALAR F, const SCALAR Tmu ) ;

SCALAR shearRate      (const SCALAR phi,  const SCALAR A,  const SCALAR Q) ;
SCALAR shearStress    (const SCALAR mu1,  const SCALAR G,  const SCALAR H, const SCALAR Tmu ) ;
SCALAR shearStressMu  (const SCALAR m0,   const SCALAR m1, const SCALAR G, const SCALAR H,  const SCALAR F ) ;

SCALAR shearLaplacian (const SCALAR RHO, const SCALAR A, const SCALAR T) ;

#endif // HELPVISCOUS_H
