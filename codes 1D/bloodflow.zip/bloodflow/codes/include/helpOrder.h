#ifndef HELPORDER_H
#define HELPORDER_H

#include <misc.h>
#include <VECT.h>

#include <helpFunctions.h>

// Reconstruct
void    recOrder  (const SCALAR order, const VECT& artX, const VECT& artdx, const VECT& inX, const VECT& indx, const VECT& outX, const VECT& outdx, VECT& Xl, VECT& Xr ) ;

void    tvdOrder  (const SCALAR order, const VECT& artX, const VECT& artdx, const VECT& inX, const VECT& indx, const VECT& outX, const VECT& outdx, VECT& Xl, VECT& Xr ) ;
void    bvdOrder  (                    const VECT& artX, const VECT& artdx, const VECT& inX, const VECT& indx, const VECT& outX, const VECT& outdx, VECT& Xl, VECT& Xr ) ;

// Muscl
VECT    muscl     (const SCALAR ul, const SCALAR dxl, const SCALAR u, const SCALAR dx, const SCALAR ur, const SCALAR dxr);
SCALAR  minmod    (const SCALAR a,   const SCALAR b);

// Thinc
VECT    thinc     (const SCALAR ul, const SCALAR u, const SCALAR ur);
SCALAR  phiThinc  (const SCALAR sigma, const SCALAR beta,const SCALAR m, const SCALAR x) ;
SCALAR  mThinc    (const SCALAR sigma, const SCALAR beta, const SCALAR umin, const SCALAR u, const SCALAR umax) ;
// Boundary value algorithm

#endif // HELPORDER_H
