#ifndef CONJUNCTION_H
#define CONJUNCTION_H

#include <misc.h>
#include <VECT.h>
#include <artery.h>
#include <mesh.h>

class conjunction {

  // Private variables can only be accessed by the base class
  private:

  // Protected variables can be accessed by any derived class
  protected:

    // Parent and daughter arteries
    //#############################
    vector<artery*> parts ;
    vector<artery*> darts ;

    // Junction type
    string typeJ ;

    // Physics
    //#########
    SCALAR rho ;
    SCALAR l  ;
    SCALAR k ;
    SCALAR V0 ;
    SCALAR a0 ;

    // Rheology
    //#########
    SCALAR phi ;
    SCALAR mu0, mu1 ;
    SCALAR kmu, amu ;

    // Variables
    //##########
    SCALAR V, A ;

    SCALAR VQ, Q ;
    SCALAR VE, E ;

    SCALAR VH, H ;
    SCALAR VC, C ;
    SCALAR VO, O ;

    SCALAR VF, F ;
    SCALAR G, Tmu, T ;

  // Public variables, accessible from outside the class
  public:

    // Constructor
    //############
    conjunction() ;
    // Default destructor
    //####################
    virtual ~conjunction() ;

    // Setters
    //########
    void set_properties() ;

    // Adders
    //#######
    void add_part(artery* _part) { parts.push_back(_part) ;}
    void add_dart(artery* _dart) { darts.push_back(_dart) ;}

    // Getters
    //########
    int get_nparts () const { return int(parts.size()) ;}
    int get_ndarts () const { return int(darts.size()) ;}

    // Readers
    //########
    SCALAR read_l     () const { return double(l)   ;}
    SCALAR read_a0    () const { return double(a0)  ;}
    SCALAR read_k     () const { return double(k)   ;}
    SCALAR read_A     () const { return double(A)   ;}
    SCALAR read_Q     () const { return double(Q)   ;}
    SCALAR read_P     () const { return Pel(k,a0,A) ;}

    SCALAR read_H     () const { return double(H)   ;}
    SCALAR read_C     () const { return double(C)   ;}
    SCALAR read_O     () const { return double(O)   ;}

    SCALAR read_F     () const { return double(F)   ;}
    SCALAR read_G     () const { return double(G)   ;}
    SCALAR read_Tmu   () const { return double(Tmu) ;}
    SCALAR read_T     () const { return double(T)   ;}

    // Time advance
    //#############
    virtual void stepConj(const time_c& timenet) = 0 ;

  };

#endif // CONJUNCTION_H
