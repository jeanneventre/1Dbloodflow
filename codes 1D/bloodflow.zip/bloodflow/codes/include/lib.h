#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED

#include <iostream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <stdio.h>
#include <fstream>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <iomanip>
#include <stdlib.h>
#include <vector>
#include <unistd.h>
#include <time.h>
#include <algorithm>
#include <iterator>
#include <math.h>
#include <assert.h>
#include <map>

#endif // LIB_H_INCLUDED
