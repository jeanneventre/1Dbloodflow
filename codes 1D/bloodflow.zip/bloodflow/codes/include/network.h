#ifndef NETWORK_H
#define NETWORK_H

#include <misc.h>

#include <parser.h>
#include <timenet.h>
#include <output.h>
#include <residu.h>

#include <artery.h>
#include <conjunction.h>
#include <arteryNum.h>

class network
{
  // Private variables can only be accessed by the base class
  private:

    // Network
    //########
    int nart, nconj, nbc ;
    vector<vesselProperties> vP ;
    vector<artery*> arts ;
    vector<conjunction*> conjs ;

    // Time
    //#####
    time_c timenet ;

    // Output
    //#######
    output outnet ;
    residu resnet ;
    FILE** file_record;
    FILE** file_record_junction;
    FILE*  file_residu;

    string dataFolder;
    string suffix;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Constructor
	  //############
    network(const string&);
    // Default destructor
    //####################
    virtual ~network() ;

    // Run
    //####
    void run() ;
    void run_omp() ;

    // Network
    //########
    void appointSolver(artery*& art, vesselProperties& vP, time_c& timenet ) ;

    // Setters
    //########
    void set_dataFolder(const string& destiFolder) {dataFolder  = destiFolder ;}
    void set_suffix(const string& destiFolder)     {suffix      = destiFolder ;}

    // Writers
    //########
    void openFile() ;
    void closeFile() ;
    void writeToFile(const SCALAR _t) const;

    // Checkers
    //#########
    void check_dt() ;
    void check_nan(const int n) ;
    // Residu
    //#########
    void get_residu(residu& resnet);

    // Functions
    //##########
    bool fileExist (const string&) ;

};

#endif // NETWORK_H
