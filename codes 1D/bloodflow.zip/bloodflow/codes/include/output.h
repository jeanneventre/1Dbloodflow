#ifndef OUTPUT_H
#define OUTPUT_H

#include <misc.h>

class output {

  // Private variables can only be accessed by the base class
  private:

    vector <int> arteryRecord;
    vector <int> posRecord;
    vector <int> storeArt;

  // Protected variables can be accessed by any derived class
  protected:

  // Public variables, accessible from outside the class
  public:

    // Constructor
    //############
    output() ;
    // Default destructor
    //####################
    virtual ~output() ;

    // Setters
    //########

    // Getters
    //########
    int get_arteryRecord    (const int n) const { return arteryRecord[n]  ;}
    int get_posRecord       (const int n) const { return posRecord[n]     ;}
    int get_storeArt        (const int n) const { return storeArt[n]      ;}

    // Sizers
    //########
    int size_storeArt       () const { return storeArt.size()     ;}
    int size_posRecord      () const { return posRecord.size()    ;}
    int size_arteryRecord   () const { return arteryRecord.size() ;}

    // Adders
    //#######
    void add_arteryRecord   (const int nArt) { arteryRecord.push_back(nArt) ;}
    void add_posRecord      (const int nPos) { posRecord.push_back(nPos)    ;}
    void add_storeArt       (const int nArt) { storeArt.push_back(nArt)     ;}

};

#endif // OUTPUT_H
