#!/usr/bin/python3
import  sys, getopt

from    bfS_libData     import *
from    bfS_libWrite    import *

def main(argv) :
    PATH = "";
    # COMMAND LINE ARGUMENTS
    #############################
    try :
        opts, args = getopt.getopt(argv,"hp:",["path="])
    except getopt.GetoptError:
          print ('plot.py -p <PATH>')
          sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('plot.py -p <PATH>')
            sys.exit()
        elif opt in ("-p", "--PATH"):
            PATH = arg

	if not os.path.exists(str(PATH)+"Figures"):
		os.makedirs(str(PATH)+"Figures")
	folderPath_store = str(PATH) + "Figures/"

    folderPath= str(PATH)

    # DATA CLASS :
    ##############

    wb = dataS_Opt(folderPath,folderPath_store,logo="Sane")

    # PLOTING :
    ###########
    nfig = 1

    L =  [
            3.6,    2.8,    14.5,   21.8,   16.5,
            23.5,   17.7,   2.1,    17.8,   2.9,
            22.7,   17.5,   24.5,   19.1,   5.6,
            19.5,   7.2,    3.8,    1.3,    19.1,
            19.8,   18.6,   6.2,    12.0,   0.7,
            11.8,   10.4,   20.5,   21.6,   20.6,
            20.1,   19.5,   20.7,   16.3,   15.1,
            14.9,   12.6
        ]

    for iArt in [ 6, 9, 10, 13, 16, 19, 28, 33 ] :

        lX = [ 0., L[iArt]/2., L[iArt]]

        for pType in ["Q","P","RmR0"] :
            write_Opt_t(cls=wb,numArt=int(iArt),lX=lX,pType=pType)

        lXmid = [L[iArt]/2.]

if __name__ == "__main__":
   main(sys.argv[1:])
