#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot_Network import *

def main(argv) :

    # PATHS
    ###########

    HOME    = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Network/37Arteries-Boileau/"

    nfig        = 1

    Nxstr       = "3"
    xOrderstr   = "2"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Conjstr     = "jS"

    Store   = PATH1D + "Figures/"

    for BC in "R" :

        PATH    = PATH1D + BC + "/" + NNstr + "/" + Conjstr + "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/"

        for pType in ["P"] :

            pName,pLabel = out.getType(pType)

            # FILE :
            ###########
            dName10  = "Artery_10_t_"

            Data10  = PATH + "Figures/" + dName10  + pName

            lDag    = [ [0,1],[1,2],[2,3],[2,4],[4,5],[5,6],[5,7],[1,8],[8,9],[8,10],
                        [10,11],[11,12],[12,13],[12,14],[10,15],[15,16],[15,17],[17,18],[18,19],[19,20],
                        [19,21],[18,22],[17,23],[23,24],[23,25],[25,26],[25,27],[27,28],[28,29],[29,30],
                        [27,31],[31,32],[32,33],[30,34],[30,35],[33,36],[33,37] ]


            # Length of the vessels (cm)
            lL  =   [   3.6,    2.8,    14.5,   21.8,   16.5,
                        23.5,   17.7,   2.1,    17.8,   2.9,
                        22.7,   17.5,   24.5,   19.1,   5.6,
                        19.5,   7.2,    3.8,    1.3,    19.1,
                        19.8,   18.6,   6.2,    12.0,   0.7,
                        11.8,   10.4,   20.5,   21.6,   20.6,
                        20.1,   19.5,   20.7,   16.3,   15.1,
                        14.9,   12.6 ]
            # Radius of the artery (cm)
            lR  =   [   1.44,   1.1,    0.537,  0.436,  0.334,
                        0.207,  0.21,   1.3,    0.558,  1.25,
                        0.442,  0.339,  0.207,  0.207,  1.18,
                        0.412,  1.1,    0.397,  0.431,  0.183,
                        0.192,  0.331,  0.926,  0.259,  0.79,
                        0.255,  0.78,   0.39,   0.338,  0.231,
                        0.402,  0.334,  0.226,  0.155,  0.153,
                        0.158,  0.155 ]
            lAngle  = [ 0.,             -np.pi/2.,      -np.pi*4./6.,   -np.pi*2./6.,   -np.pi*2./6.,   -np.pi*3./8.,   -np.pi*1./4.,   0.,             np.pi/2.,       0.,
                        np.pi*2./6.,    np.pi*2./6.,    np.pi*3./8.,    np.pi*1./4.,    0.,             np.pi*2./6.,    0.,             -np.pi/2.,      -np.pi*3./8.,   -np.pi*11./20.,
                        -np.pi*3./8.,   -np.pi*1./4.,   0.,             np.pi*3./8.,    0.,             -np.pi*2./8.,   0.,             -np.pi*1./4.,   -np.pi*1./4.,   -np.pi*1./4.,
                        np.pi*1./4.,    np.pi*1./4.,    np.pi*1./4.,    -np.pi/6.,      np.pi/6.,       -np.pi/6.,      np.pi/6. ]

            xRange  = [-60.,80.]
            yRange  = [-110.,10.]

            xStart  = 0.
            yStart  = 0.

            if (pType == "Q") :
                cbScale = 1.
                cbRange = [-40.,100.]
                cbMid   = 2./7.
                colorMap = "BlueMidRed"
            elif (pType == "P") :
                cbScale = 1./0.0007500615613026439
                cbRange = [40,130]
                cbMid   = 0.5
                colorMap = "Black" #"Segmented"

            cbLabel = pLabel

            liX         = []
            liY         = []
            lFileSep    = []
            lFile       = []
            for i in range(37) :
                liX.append(     0)
                liY.append(     [1,2,3])
                lFileSep.append(",")
                lFile.append(   Data10)

            lText       = [r"$Matthys$ $37$-$Artery$ $Network$"]
            lTextPos    = [[0.5,.01]]
            lTextAlign  = ["center"]
            lTextColor  = ["black"]

            Time    = 7.2

            title   = "Network-Matthys.pdf"

            nfig = plot_csv_network(pathStore=Store,title=title,
                                    Time = Time,
                                    lFile=lFile,lFileSep=lFileSep,
                                    liX=liX,liY=liY,
                                    cbLabel=cbLabel,
                                    lDag=lDag,
                                    lL=lL,lR=lR,lAngle=lAngle,
                                    xStart=xStart,yStart=yStart,
                                    xRange=xRange,yRange=yRange,
                                    cbScale=cbScale,cbRange=cbRange,cbMid=cbMid,colorMap=colorMap,
                                    lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                    nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
