#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *
from    help_Wave   import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Network/37Arteries-Boileau/"
    PATHEXP = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Network/SuppMaterial_1DBenchmark_Boileau_etal/Benchmark5_37ArteryNetwork/"

    nfig = 1

    Nxstr       = "3"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    xOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    PATHSTART   = "/" + NNstr + "/"
    PATHEND     = "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/Figures/"
    Store       = PATH1D + "Tree/" + "Figures/"

    # REFERENCE DATA
    ################
    T_c         = 0.827 ;
    ts          = 9.*T_c;
    te          = 10.*T_c;
    lTitle      = [ "RUlnar","AorticArch2","LSubclavian1","LUlnar",
                    "ThoracicAorta2","Splenic","RIliacFemoral2","RAnteriorTibial"]
    lName       = [ "Right Ulnar","Aortic Arch 2","Left Subclavian 1","Left Ulnar",
                    "Thoracic Aorta 2","Splenic","Right Iliac-Femoral 2","Right Anterior Tibial"]
    lArtNum     = [ 6,9,10,13,16,19,28,33]
    lYSim       = [ 7,1,3,5,2,8,4,6]
    ltsSim      = [ 14.136 , 14.075, 14.097, 14.138, 14.09, 14.134, 14.162, 14.200]
    lts         = [ 14.136 , 14.075, 14.097, 14.138, 14.09, 14.134, 14.162, 14.200] - 17.*T_c * np.ones(8)
    lYRangeP    = [ [8.9e4,16.e4], [8.9e4,16.e4], [8.9e4,16.e4], [8.9e4,16.e4],
                    [8.9e4,16.e4], [8.9e4,16.e4], [7.e4,18.e4], [7.5e4,19.e4]    ]
    lYRangeQ    = [ [1.9,5.5], [-131.,200.], [-3.,23.], [1.2,5.5],
                    [-90.,150.], [1.,6.], [-5.,16.], [0.7,5.2] ]

    # NUMERICAL DATA
    ################
    for pType in ["P","Q"] :

        pName,pLabel = out.getType(pType)

        EXP_RUlnar          = PATHEXP + "ExpData/" + "RUlnar_"          + pType + ".txt"
        EXP_AorticArch2     = PATHEXP + "ExpData/" + "AorticArchII_"    + pType + ".txt"
        EXP_LSubclavian1    = PATHEXP + "ExpData/" + "LSubclavianI_"    + pType + ".txt"
        EXP_LUlnar          = PATHEXP + "ExpData/" + "LUlnar_"          + pType + ".txt"
        EXP_ThoracicAorta2  = PATHEXP + "ExpData/" + "ThoracicAortaII_" + pType + ".txt"
        EXP_Splenic         = PATHEXP + "ExpData/" + "Splenic_"         + pType + ".txt"
        EXP_RIliacFemoral2  = PATHEXP + "ExpData/" + "RIliacFemoralII_" + pType + ".txt"
        EXP_RAnteriorTibial = PATHEXP + "ExpData/" + "RAnteriorTibial_" + pType + ".txt"

        lFileExp    = [ EXP_RUlnar,EXP_AorticArch2,EXP_LSubclavian1,EXP_LUlnar,
                        EXP_ThoracicAorta2,EXP_Splenic,EXP_RIliacFemoral2,EXP_RAnteriorTibial]

        SIM         = PATHEXP + "NumData/" + "FVM_" + pType + ".txt"

        for i in range(8) :

            dName   = "Artery_" + str(lArtNum[i]) + "_t_"

            BC1 = "Tree"; J1 = "jS" ; R1 = "100e-4" ; J1p = r"jP"
            Data1   = PATH1D + BC1 + PATHSTART + J1 + "/Rc="+ R1 + PATHEND + dName + pName

            BC2 = "Tree"; J2 = "jS" ; R2 = "75e-4" ; J2p = r"jP"
            Data2   = PATH1D + BC2 + PATHSTART + J2 + "/Rc="+ R2 + PATHEND + dName + pName

            BC3 = "Tree"; J3 = "jS" ; R3 = "50e-4" ; J3p = r"jP"
            Data3   = PATH1D + BC3 + PATHSTART + J3 + "/Rc="+ R3 + PATHEND + dName + pName

            BC4 = "Tree"; J4 = "jS" ; R4 = "1e-4" ; J4p = r"jP"
            Data4   = PATH1D + BC4 + PATHSTART + J4 + "/Rc="+ R4 + PATHEND + dName + pName

            ######################################
            ######################################

            lCol        = [ "black","black","blue","red","seagreen","purple" ]
            lMark       = [ "","","^","s","*","o"]
            lMarkSize   = [ 1,1,8,8,8,8]
            lMarkWidth  = [ 1,1,1,1,1,1]
            MarkPoints  = 120

            lLineSize   = [ 2,2,2,2,2,2]
            lStyle      = [ "-","--","","","",""]
            lAlpha      = [ 1,1,1,1,1,1]

            LegLoc      = 1
            LegPos      = [1.,1.]
            LegCol      = 1
            LegSize     = 25

            xRange      = [0.,0.8]
            # if (pType == "P") :
            #     yRange      = lYRangeP[i]
            # if (pType == "Q") :
            #     yRange      = lYRangeQ[i]
            yRange = []

            xBins       = 2 ;
            yBins       = 2 ;

            lHline      = []
            lHlineColor = []
            lHlineWidth = []
            lHlineStyle = []

            lVline      = []
            lVlineColor = []
            lVlineWidth = []
            lVlineStyle = []

            if (pType == "P") :
                yScale = 1.e-4
            else :
                yScale = 1.

            lXScale     = [ 1.,1.,1.,1.,1.,1.]
            lYScale     = [ yScale,yScale,1.,1.,1.,1.]
            pScale      = "linear"

            lXOffset    = [ 0.,ltsSim[i],ts + lts[i],ts + lts[i],ts + lts[i],ts + lts[i]]
            lYOffset    = [ 0.,0.,0.,0.,0.,0.]

            lText       = [lName[i], r"$N_x$=" + Nxstr + ", order " + xOrderstr, "jCV"]
            lTextAlign  = ["left","right","left"]
            lTextPos    = [[0.02,0.945],[0.98,0.05],[0.02,0.05]]
            lTextColor  = ["black","black","black"]

            xLabel      = r"$\left[t-t_{ref}\right]/T$"
            yLabel      = pLabel
            lLabel      = [ r"Exp",
                            r"1D, FV",
                            r"1D, $R_{min}$=" + str(float(R1)),
                            r"1D, $R_{min}$=" + str(float(R2)),
                            r"1D, $R_{min}$=" + str(float(R3)),
                            r"1D, $R_{min}$=" + str(float(R4))]

            liX         = [ 0,0,0,0,0,0]

            iYSim       = lYSim[i]
            iY          = 2
            liY         = [ 1,iYSim,iY,iY,iY,iY ]

            lFileSep    = [ "","",",",",",",","," ]

            lFile       = [ lFileExp[i],SIM,Data1,Data2,Data3]#,Data4 ]

            title       = "Tree-" + lTitle[i] + "-" + pType + "-t.pdf"

            nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                                liX=liX,liY=liY,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,pScale=pScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
