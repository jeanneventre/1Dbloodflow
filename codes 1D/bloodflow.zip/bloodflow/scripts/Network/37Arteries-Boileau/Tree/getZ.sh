#!/bin/bash

PATHZ=/Documents/UPMC/These/Codes/bloodflow/Examples/Network/37Arteries-Boileau/Tree

# mkdir -p ${HOME}${folderHR}/Tree/Data
# scp -r ${SSHACCOUNT}:${HOME_SSH}${PATHZ}/Tree/Data ${HOME}${PATHZ}/Tree

mkdir -p ${HOME}${folderHR}/zST
scp -r ${SSHACCOUNT}:${HOME_SSH}${PATHZ}/zST ${HOME}${PATHZ}/

# mkdir -p ${HOME}${PATHZ}/zST
# scp -r -P 2222 ghigo@localhost:${HOME_SSH}${PATHZ}/zST ${HOME}${PATHZ}/
