#!/usr/local/bin/python3
import sys, getopt
import os

import numpy                as np

import help_StructuredTree as tree

HOME    = "/Users/Arthur/"
# HOME    = "/home/ghigo/"
PATH    = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Network/37Arteries-Boileau/Tree/Data/"

fileName= PATH + "Results.csv"

Rr = 0.373
Rc = 20.e-4

iRr = 0
iRc = 1

iR1 = 5
R1  = tree.interpRLC(fileName=fileName,Rr=Rr,Rc=Rc,iRr=iRr,iRc=iRc,iZ=iR1)

iR2 = 6
R2  = tree.interpRLC(fileName=fileName,Rr=Rr,Rc=Rc,iRr=iRr,iRc=iRc,iZ=iR2)

iC1 = 8
C1  = tree.interpRLC(fileName=fileName,Rr=Rr,Rc=Rc,iRr=iRr,iRc=iRc,iZ=iC1)

print("R1=",R1,", R2=",R2,", C1=",C1)
