#!/usr/bin/python3
import  sys

import  help_Output as out

from    csv_libPlot import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "/Documents/UPMC/These/Codes/bloodflow/Examples/Network/1Artery/Upper-Thoracic-Boileau/"
    PATHEXP = HOME + "/Documents/UPMC/These/Codes/bloodflow/Examples/Network/SuppMaterial_1DBenchmark_Boileau_etal/Benchmark3_UpperThoracicAorta/"

    nfig = 1

    Nxstr       = "50"
    xOrderstr   = "2"

    dtstr       = "1e-4"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    PATH    = PATH1D + NNstr
    Store   = PATH1D + "/Figures/"

    for pType in ["Q","P","RmR0"] :

        pName,pLabel = out.getType(pType)

        # FILE :
        ###########
        dName0  = "Artery_0_t_"
        PATHEND = "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/Figures/" + dName0 + pName

        O1 = "1"
        Data0_1     = PATH + "/Nx=" + Nxstr + "/xOrder=" + O1 + PATHEND
        O2 = "2"
        Data0_2     = PATH + "/Nx=" + Nxstr + "/xOrder=" + O2 + PATHEND

        D3_0       = PATHEXP + "NumData" + "/3D.txt"
        D3_1       = PATHEXP + "NumData" + "/FEM.txt"
        D3_2       = PATHEXP + "NumData" + "/FVM.txt"

        ######################################
        ######################################

        if (pType == "Q") :
            iYExp   = 2
            yScale  = 1.
            yOffset = 0.
            yR      = [-100.,500.]
        if (pType == "P") :
            iYExp   = 1
            yScale  = 1.e-4
            yOffset = 9.46
            yR      = [0.,8.e4]
        if (pType == "RmR0") :
            iYExp   = 3
            yScale  = 10
            yOffset = 0.
            yR      = [0.,0.16]

        ######################################
        ######################################

        lCol        = [ "blue","green","red","purple" ]
        lMark       = [ "","","",""]
        lMarkSize   = [ 1,1,1,1]
        lMarkWidth  = [ 2,2,2,2]
        MarkPoints  = 40

        lLineSize   = [ 2,2,2,2]
        lStyle      = [ "--","--","-","-"]
        lAlpha      = [ 1,1,1,1]

        LegLoc      = 1
        LegPos      = [1.,1.]
        LegCol      = 1

        lHline      = []
        lHlineColor = []
        lHlineWidth = []
        lHlineStyle = []

        lVline      = []
        lVlineColor = []
        lVlineWidth = []
        lVlineStyle = []

        T_c         = 0.955 ;
        ts          = 20.*T_c;
        te          = 21.*T_c;
        ts3D        = 20.*T_c;

        xRange      = [ts3D,te]
        yRange      = yR

        xBins       = 4
        yBins       = 4


        lXScale     = [ 1.,1.,1.,1.]
        lYScale     = [ yScale,yScale,1.,1.]

        lXOffset    = [ -ts3D,-ts,0.,0.]
        lYOffset    = [ yOffset,yOffset,0.,0.]

        lText       = [ r"$N_x$=" + Nxstr, r"$N_x$ " + str(Nxstr)]
        lTextAlign  = [ "center", "center"]
        lTextPos    = [ [0.25,0.04], [0.75,0.05] ]
        lTextColor  = [ "black", "black" ]

        xLabel      = r"$t$ $\left[s\right]$"
        yLabel      = pLabel
        lLabel      = [ r"$3D$", r"$FV$", O1, O2]

        liX         = [ 0,0,0,0]
        liY         = [ iYExp,iYExp,1,1 ]
        lFileSep    = [ "", "", ",", "," ]
        lFile       = [ D3_0, D3_2, Data0_1, Data0_2 ]

        title = pType + "_t.pdf"

        nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                            liX=liX,liY=liY,
                            xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                            xRange=xRange,yRange=yRange,
                            xBins=xBins,yBins=yBins,
                            lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                            lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                            lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                            LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                            lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                            lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                            lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
