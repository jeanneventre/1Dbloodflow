#! /usr/bin/python2.7
import sys, getopt
import os
import numpy    as np
import math     as mt

from bfS_libDef import *

from help_Input     import *

from help_Sum       import *
from help_Wave      import *
from help_Geometry  import *
from help_Inlet     import *

def main(argv) :

    # Read input parameters and store them in hd
    hd = header()
    hd.headerInput(argv) ;

    rho_c   = 1.06 ;

    if      (hd.NNstr == "Newtonian") :
        phi_c   = -4. ;
        mu0_c   = 0.    ;
        mu1_c   = 4.e-2 ;
        kmu_c   = 0. ;
        amu_c   = 0. ;
    elif    (hd.NNstr == "NonNewtonian") :
        phi_c   = float(hd.phistr) ;
        mu0_c   = 1.2 ;
        mu1_c   = 4.e-2 ;
        kmu_c   = 2.5e-1 ;
        amu_c   = 1.2 ;
    elif    (hd.NNstr == "Inviscid") :
        phi_c   = 0. ;
        mu0_c   = 0. ;
        mu1_c   = 0. ;
        kmu_c   = 0. ;
        amu_c   = 0. ;

    # Geometrical properties
    L_c     = 12.6  ;
    R0_c    = 0.3   ;

    # Mechanical properties
    h_c     = 0.03
    E_c     = 700. * 1.e4 ;
    Cv_c    = 0.
    Knl_c   = 0.

    # Numerical properties
    Nx_c        = float (hd.Nxstr)
    xOrder_c    = int   (hd.xOrderstr)
    dt_c        = float (hd.dtstr)
    tOrder_c    = int   (hd.tOrderstr)

    # Time properties
    T_c     = 1.1 ;
    ts_c    = 8. * T_c
    te_c    = 9. * T_c

    # Boundary properties
    # Inlet
    # Outlet
    R1_c    = 2.4875 * 1.e3 ;
    R2_c    = 1.8697 * 1.e4 ;
    C1_c    = 1.7529 * 1.e-5 ;
    Pout_c  = -10.933 * 1.e4 ; # Capillary pressure (used in RLC outflow bc)
    # Junction
    fact_c  = 1 ;

    # Rheology
    if (hd.NNstr == "NonNewtonian") :
        F_c     = 1.
        H_c     = 0.45
    else :
        F_c     = 0.
        H_c     = 0.

    # Passive Transport
    C_c    = 0. ;
    O_c    = 0. ;

    # Stenosis
    # dR_c    = 0.
    # dK_c    = 0.

    ############################################################################
    ############################################################################
    # Network
    ############################################################################
    ############################################################################

    # Angle of bifurcation
    Angle = array( [ [0.*np.pi,np.pi] ] )

    #############################
    # Geometrical parameters
    #############################

    # Length of the vessels (cm)
    L = array( [ L_c ] )
    # Radius of the artery (cm)
    R = array( [ R0_c ] )
    D = R * 2.
    A = pi * R * R

    A_init= array( [ 0.22038 ] )

    NArt = len(L)

    # Check length of array
    if NArt != len(A) :
        print ('Dimension error in geometric parameters A_ref or L')
        sys.exit()

    #############################
    # Mechanical parameters
    #############################

    # Density (g/cm^3)
    rho = rho_c
    # Stiffness coefficient beta (g/cm^2/s^2 ~ Pa/m = 0.1 g/(cm*s)^2)
    h = array( [ h_c ] )
    E = array( [ E_c ] )
    K = 4./3. * np.sqrt(np.pi) * E * h / A
    # Viscoelasticity coefficient C_v (cm^2/s)
    Cv  = Cv_c  * np.ones(NArt)
    # Nonlinear stiffness coefficient beta (g/cm^3/s^2)
    Knl = Knl_c * np.ones(NArt)
    # Moens-Korteweg celerity (cm/s)
    c   = celerity(rho,K,A)

    # Check length of array
    if NArt != len(K) or NArt != len(Cv) or NArt != len(Knl) or NArt != len(c) :
        print ('Dimension error in geometric parameters K, Cv, Knl, c or L')
        sys.exit()

    #############################
    # Rheology
    #############################

    # Profile coefficient phi
    phi = phi_c * np.ones(NArt)
    # Newtonian viscosities
    mu0 = mu0_c * np.ones(NArt)
    mu1 = mu1_c * np.ones(NArt)
    # Aggregation coefficient
    kmu = kmu_c * np.ones(NArt)
    # Desaggregation coefficient
    amu = amu_c * np.ones(NArt)

    #############################
    # Artery
    #############################

    arts = [artery(i) for i in range(NArt)]

    # Define default arterial properties
    hd.headerNum    (arts,L,c)
    hd.headerProp   (arts,rho,L,R,K,Cv,Knl)
    hd.headerRheo   (arts,phi,mu0,mu1,kmu,amu)

    hd.headerInit   (arts,F_c,H_c,C_c,O_c)
    # Specific initial conditions
    for i in range(NArt) :
        arts[i].initA       = A_init[i] * np.ones(arts[i].N)
        arts[i].initQ       = np.zeros(arts[i].N)

    hd.headerBC     (arts,fact_c,Pout_c)
    hd.headerOutput (arts)

    #############################
    # Time setup
    #############################

    # CFL
    Ct      = 1.
    dt_CFL  = hd.headerCFL(arts,Ct)

    # Analytic input signal
    #######################

    t_start = ts_c
    t_end   = te_c

    # Time step
    dt        = float(dt_c)
    if (dt > dt_CFL) :
        print("Error dt>dt_CFL", dt, dt_CFL)
        sys.exit()

    timeSteps = int(t_end/dt)
    tt = ones(timeSteps)
    for it in range(timeSteps) :
        tt[it] = float(it) * dt

    # Experimental Input Signal
    ###########################

    # inputPath   = "/home/ghigo/Dropbox/These/Codes/1D/bloodflow-Single/scripts/Japan/Input/"
    # Input       = np.genfromtxt(inputPath + "Q_Straight_30mm.csv", delimiter=',',dtype = ("float","float"))
    # tt          = Input[:,0]
    # pulse_Input = Input[:,1]
    #
    # Q_c     = V_c / integrate(tt,pulse_Input)
    # Q_Input = Q_c * pulse_Input
    #
    # t_start = tt[0] # (s)
    # t_end   = tt[len(tt)-1] # (s)
    # dt      = tt[1]-tt[0] ;
    #
    # if (t_start != 0.) :
    #     print("Error in starting time of experimental input file")
    #     sys.exit
    # if (dt > dt_CFL) :
    #     print("Error dt>dt_CFL", dt, dt_CFL)
    #     sys.exit()
    #
    # # Store step
    # timeSteps   = len(tt)

    #######################

    dt_store    = 1.e-3 * (t_end-t_start)
    storeStep   = max(1,int(dt_store / dt))

    print ("---->Time step dt = ", dt)
    print ("---->CFL Time step dt_CFL = ",dt_CFL)

    tS              = timeSetup()
    tS.tt           = tt
    tS.dt           = dt
    tS.t_start      = t_start
    tS.t_end        = t_end
    tS.Nt           = timeSteps
    tS.storeStep    = storeStep
    tS.CFL          = Ct
    tS.timeOrder    = int(hd.tOrderstr)

    #############################
    # Boundary condition
    #############################

    #Inlet
    Q_Input     =   (6.5    +   3.294       *   np.sin( 2  * np.pi / T_c * tt -0.023974)
                            +   1.9262      *   np.sin( 4  * np.pi / T_c * tt -1.1801)
                            -   1.4219      *   np.sin( 6  * np.pi / T_c * tt +0.92701)
                            -   0.66627     *   np.sin( 8  * np.pi / T_c * tt -0.24118)
                            -   0.33933     *   np.sin( 10 * np.pi / T_c * tt -0.27471)
                            -   0.37914     *   np.sin( 12 * np.pi / T_c * tt -1.0557)
                            +   0.22396     *   np.sin( 14 * np.pi / T_c * tt +1.22)
                            +   0.1507      *   np.sin( 16 * np.pi / T_c * tt +1.0984)
                            +   0.18735     *   np.sin( 18 * np.pi / T_c * tt +0.067483)
                            +   0.038625    *   np.sin( 20 * np.pi / T_c * tt +0.22262)
                            +   0.012643    *   np.sin( 22 * np.pi / T_c * tt -0.10093)
                            -   0.0042453   *   np.sin( 24 * np.pi / T_c * tt -1.1044)
                            -   0.012781    *   np.sin( 26 * np.pi / T_c * tt -1.3739)
                            +   0.014805    *   np.sin( 28 * np.pi / T_c * tt +1.2797)
                            +   0.012249    *   np.sin( 30 * np.pi / T_c * tt +0.80827)
                            +   0.0076502   *   np.sin( 32 * np.pi / T_c * tt +0.40757)
                            +   0.0030692   *   np.sin( 34 * np.pi / T_c * tt +0.195)
                            -   0.0012271   *   np.sin( 36 * np.pi / T_c * tt -1.1371)
                            -   0.0042581   *   np.sin( 38 * np.pi / T_c * tt -0.92102)
                            -   0.0069785   *   np.sin( 40 * np.pi / T_c * tt -1.2364)
                            +   0.0085652   *   np.sin( 42 * np.pi / T_c * tt +1.4539)
                            +   0.0081881   *   np.sin( 44 * np.pi / T_c * tt +0.89599)
                            +   0.0056549   *   np.sin( 46 * np.pi / T_c * tt +0.17623)
                            +   0.0026358   *   np.sin( 48 * np.pi / T_c * tt -1.3003)
                            -   0.0050868   *   np.sin( 50 * np.pi / T_c * tt -0.011056)
                            -   0.0085829   *   np.sin( 52 * np.pi / T_c * tt -0.86463)
                    )

    #Outlet
    R1_Output = R1_c * np.ones(timeSteps)
    R2_Output = R2_c * np.ones(timeSteps)
    C1_Output = C1_c * np.ones(timeSteps)

    # Rheology
    H_Input     = np.zeros(timeSteps)
    F_Input     = np.zeros(timeSteps)
    H_Output    = np.zeros(timeSteps)
    F_Output    = np.zeros(timeSteps)

    # Passive transport
    C_Input   = np.zeros(timeSteps)
    O_Input   = np.zeros(timeSteps)
    C_Output  = np.zeros(timeSteps)
    O_Output  = np.zeros(timeSteps)

    #############################
    # Construct network
    #############################

    iart = 0 ; ihconj = 0 ; itconj = iart + 1 ;
    arts[iart].daughterArts = [] ;
    # Head point
    arts[iart].headPt.append(point(ihconj));
    arts[iart].headPt[0].type   = "inQ"             ; arts[iart].headPt[0].data  = Q_Input ;
    # Tail point
    arts[iart].tailPt.append(point(itconj));
    arts[iart].tailPt.append(point(itconj));
    arts[iart].tailPt.append(point(itconj));
    arts[iart].tailPt[0].type   = "outR1"           ; arts[iart].tailPt[0].data  = R1_Output ;
    arts[iart].tailPt[1].type   = "outC1"           ; arts[iart].tailPt[1].data  = C1_Output ;
    arts[iart].tailPt[2].type   = "outR2"           ; arts[iart].tailPt[2].data  = R2_Output ;

    #############################
    # Network definition
    #############################

    net=network(ARTS=arts,tS=tS)

    #############################
    # Create necessary files
    #############################

    hd.headerFile() ;

    #############################
    # Write parameters
    #############################

    net.writeParam(str(hd.PATH)+"parameters_"+str(hd.LOGO))

if __name__ == "__main__":
   main(sys.argv[1:])
