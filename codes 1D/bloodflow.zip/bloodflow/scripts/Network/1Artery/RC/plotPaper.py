#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *

import  help_Output as out
import  help_Inlet  as hin
import  help_Wave   as wa

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Network/1Artery/RC/"

    nfig = 1

    dtstr       = "1e-4"
    tOrderstr   = "2"

    Kstr        = "1e4"
    NNstr       = "Inviscid"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    for Shstr in ["1e-3"] :

        for Rtstr in ["0.5"] :

            for Cstr in ["0","1e-5","1e-4","1e-3","1e-2","1e-1"] :

                PATH    = PATH1D    + "K=" + Kstr + "/" + NNstr + "/Sh=" + Shstr + "/Rt=" + Rtstr + "/C=" + Cstr
                Store   = PATH1D    + "Figures" + "/Sh=" + Shstr + "/Rt=" + Rtstr + "/C=" + Cstr + "/"

                for pType in ["P","RmR0","Q"] :

                    pName,pLabel = out.getType(pType)

                    # FILE :
                    ###########
                    ArtName0    = "Artery_0_x_"
                    PATHEND     = "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

                    J1 = "50"
                    Art0_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + PATHEND
                    Art0_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + PATHEND

                    J2 = "100"
                    Art0_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + PATHEND
                    Art0_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + PATHEND

                    J3 = "200"
                    Art0_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + PATHEND
                    Art0_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + PATHEND

                    ######################################
                    ######################################
                    lCol = [    "black","blue",
                                "black","blue",
                                "black","blue"]
                    lMark = [   "o","o",
                                "s","s",
                                "^","^"]
                    lMarkSize = [   5,5,
                                    5,5,
                                    5,5]
                    lMarkWidth = [  1,1,
                                    1,1,
                                    1,1]
                    MarkPoints = 30

                    lLineSize = [   1,1,
                                    1,1,
                                    1,1]
                    lStyle = [      "-","-",
                                    "-","-",
                                    "-","-"]
                    lAlpha = [  1,1,
                                1,1,
                                1,1]

                    LegLoc      = 1
                    LegPos      = [1.,0.995]
                    LegCol      = 6

                    xRange      = []
                    yRange      = []

                    xBins       = 6 ;
                    yBins       = 2 ;

                    # Set lines representing amplitude of reflection
                    if (pType == "P") :
                        Amp  = hin.ShtoP(float(Shstr),float(Kstr),1.)
                        RAmp = float(Rtstr) * Amp
                    if (pType == "RmR0") :
                        Amp  = hin.ShtoP(float(Shstr),float(Kstr),1.) / float(Kstr) / np.sqrt(np.pi)
                        RAmp = float(Rtstr) * Amp
                    if (pType == "Q") :
                        Amp  = hin.ShtoP(float(Shstr),float(Kstr),1.) * wa.Admittance(1.,float(Kstr),hin.ShtoA(float(Shstr),1.))
                        RAmp = -float(Rtstr) * Amp

                    lHline      = [Amp/abs(Amp),RAmp/abs(Amp)]
                    lHlineColor = ["black","black"]
                    lHlineWidth = [2,2]
                    lHlineStyle = ["--",":"]

                    lVline      = []
                    lVlineColor = []
                    lVlineWidth = []
                    lVlineStyle = []

                    L = 20.
                    lXScale     = [ L,L,
                                    L,L,
                                    L,L]

                    lYScale     = [ Amp,Amp,
                                    Amp,Amp,
                                    Amp,Amp]

                    lXOffset    = [ 0.,0.,
                                    0.,0.,
                                    0.,0.]
                    lYOffset    = [ 0.,0.,
                                    0.,0.,
                                    0.,0.]

                    lText       = [ r"$t$=$\left\{1,3.5\right\}T$", r"$Order$", r"$S_h$=" + out.latex_power(float(Shstr),1,1) + r", $R_t$=" + Rtstr ]
                    lTextAlign  = [ "left", "right" , "left"]
                    lTextPos    = [ [0.02,0.05],[0.98,0.05],[0.01,0.92] ]
                    lTextColor  = [ "black", "black","black" ]

                    xLabel=r"$x/L$"

                    if (pType == "P") :
                        yLabel = r"$P /\left[\sqrt{\pi} K R S_h \right]$"
                    if (pType == "RmR0") :
                        yLabel = r"$ \left[R-R_0\right] /\left[ R S_h \right]$"
                    if (pType == "Q") :
                        yLabel = r"$Q /\left[\sqrt{\pi} K R S_h Y \right]$"

                    lLabel = [  J1,"",
                                J2,"",
                                J3,""]

                    lFileSep    = [ ",",",",
                                    ",",",",
                                    ",",","]
                    liX         = [ 0,0,
                                    0,0,
                                    0,0]
                    liY         = [ 2,7,
                                    2,7,
                                    2,7]

                    lFile_O1 = [    Art0_11,Art0_11,
                                    Art0_21,Art0_21,
                                    Art0_31,Art0_31
                                    ]

                    lFile_O2 = [    Art0_12,Art0_12,
                                    Art0_22,Art0_22,
                                    Art0_32,Art0_32]

                    title = pType + "_O1_x.pdf"
                    lText[1] = r"$Order$ $1$"
                    nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile_O1,lFileSep=lFileSep,
                                        liX=liX,liY=liY,
                                        xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                        xRange=xRange,yRange=yRange,
                                        xBins=xBins,yBins=yBins,
                                        lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                        lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                        lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                        LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                                        lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                        lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                        lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

                    title = pType + "_O2_x.pdf"
                    lText[1] = r"$Order$ $2$"
                    nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile_O2,lFileSep=lFileSep,
                                        liX=liX,liY=liY,
                                        xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                        xRange=xRange,yRange=yRange,
                                        xBins=xBins,yBins=yBins,
                                        lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                        lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                        lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                        LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                                        lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                        lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                        lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
