#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *

import  help_Output as out
import  help_Inlet  as hin
import  help_Wave   as wa

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Network/1Artery/RC/"

    nfig = 1

    dtstr       = "1e-4"
    tOrderstr   = "2"

    Nxstr       = "200"
    xOrderstr   = "2"

    Kstr        = "1e4"
    NNstr       = "Inviscid"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"


    for Shstr in ["1e-3"] :

        for Rtstr in ["0.5"] :

                PATH    = PATH1D    + "K=" + Kstr + "/" + NNstr + "/Sh=" + Shstr + "/Rt=" + Rtstr
                Store   = PATH1D    + "Figures" + "/Sh=" + Shstr + "/Rt=" + Rtstr + "/"

                for pType in ["P","RmR0","Q"] :

                    pName,pLabel = out.getType(pType)

                    # FILE :
                    ###########
                    ArtName0    = "Artery_0_x_"
                    PATHEND     = "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

                    C1 = "0"
                    Art0_1      = PATH + "/C=" + C1 + PATHEND

                    C2 = "1e-5"
                    Art0_2      = PATH + "/C=" + C2 + PATHEND

                    C3 = "1e-4"
                    Art0_3      = PATH + "/C=" + C3 + PATHEND

                    C4 = "1e-3"
                    Art0_4      = PATH + "/C=" + C4 + PATHEND

                    C5 = "1e-2"
                    Art0_5      = PATH + "/C=" + C5 + PATHEND

                    C6 = "1e-1"
                    Art0_6      = PATH + "/C=" + C6 + PATHEND

                    ######################################
                    ######################################
                    lCol        = [ "black","blue","red","green","purple","orange",
                                    "black","blue","red","green","purple","orange"]
                    lMark       = [ "o","s","^","*","<","h",
                                    "o","s","^","*","<","h",]
                    lMarkSize   = [ 5,5,5,5,5,5,
                                    5,5,5,5,5,5]
                    lMarkWidth  = [ 1,1,1,1,1,1,
                                    1,1,1,1,1,1]
                    MarkPoints  = 30

                    lLineSize   = [ 2,2,2,2,2,2,
                                    2,2,2,2,2,2]
                    lStyle      = [ "-","-","-","-","-","-",
                                    "-","-","-","-","-","-"]
                    lAlpha      = [ 0.7,0.7,0.7,0.7,0.7,0.7,
                                    0.7,0.7,0.7,0.7,0.7,0.7]

                    LegLoc      = 1
                    LegPos      = [1.,1.]
                    LegCol      = 6

                    xRange      = []
                    yRange      = []

                    xBins       = 6 ;
                    yBins       = 2 ;

                    # Set lines representing amplitude of reflection
                    if (pType == "P") :
                        Amp  = hin.ShtoP(float(Shstr),float(Kstr),1.)
                        RAmp = float(Rtstr) * Amp
                    if (pType == "RmR0") :
                        Amp  = hin.ShtoP(float(Shstr),float(Kstr),1.) / float(Kstr) / np.sqrt(np.pi)
                        RAmp = float(Rtstr) * Amp
                    if (pType == "Q") :
                        Amp  = hin.ShtoP(float(Shstr),float(Kstr),1.) * wa.Admittance(1.,float(Kstr),hin.ShtoA(float(Shstr),1.))
                        RAmp = -float(Rtstr) * Amp

                    lHline      = [RAmp/abs(Amp)]
                    lHlineColor = ["black"]
                    lHlineWidth = [2]
                    lHlineStyle = [":"]

                    lVline      = []
                    lVlineColor = []
                    lVlineWidth = []
                    lVlineStyle = []

                    L = 20.
                    lXScale     = [ L,L,L,L,L,L,
                                    L,L,L,L,L,L]

                    lYScale     = [ Amp,Amp,Amp,Amp,Amp,Amp,
                                    Amp,Amp,Amp,Amp,Amp,Amp]

                    lXOffset    = [ 0.,0.,0.,0.,0.,0.,
                                    0.,0.,0.,0.,0.,0.]
                    lYOffset    = [ 0.,0.,0.,0.,0.,0.,
                                    0.,0.,0.,0.,0.,0.]

                    lText       = [ r"$t$=$\left\{3.5,4\right\}T$", r"$Order$" + xOrderstr, r"$S_h$=" + out.latex_power(float(Shstr),1,1) + r", $R_t$=" + Rtstr ]
                    lTextAlign  = [ "left", "right", "left"]
                    lTextPos    = [ [0.02,0.05],[0.98,0.05],[0.01,0.85] ]
                    lTextColor  = [ "black", "black","black" ]

                    xLabel=r"$x/L$"

                    if (pType == "P") :
                        yLabel = r"$P /\left[\sqrt{\pi} K R S_h \right]$"
                    if (pType == "RmR0") :
                        yLabel = r"$ \left[R-R_0\right] /\left[ R S_h \right]$"
                    if (pType == "Q") :
                        yLabel = r"$Q /\left[\sqrt{\pi} K R S_h Y \right]$"

                    lLabel      = [ C1,C2,C3,C4,C5,C6,
                                    "","","","","",""]

                    lFileSep    = [ ",",",",",",",",",",",",
                                    ",",",",",",",",",",","]
                    liX         = [ 0,0,0,0,0,0,
                                    0,0,0,0,0,0]
                    liY         = [ 7,7,7,7,7,7,
                                    8,8,8,8,8,8]

                    lFile       = [ Art0_1,Art0_2,Art0_3,Art0_4,Art0_5,Art0_6,
                                    Art0_1,Art0_2,Art0_3,Art0_4,Art0_5,Art0_6]

                    title = pType + "_x.pdf"
                    nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                                        liX=liX,liY=liY,
                                        xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                        xRange=xRange,yRange=yRange,
                                        xBins=xBins,yBins=yBins,
                                        lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                        lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                        lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                        LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                                        lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                        lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                        lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
