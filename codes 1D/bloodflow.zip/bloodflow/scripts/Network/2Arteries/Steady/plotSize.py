#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *

import  help_Output as out
import  help_Inlet  as hin
import  help_Wave   as wa

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D = HOME + "/Documents/UPMC/These/Codes/bloodflow/Examples/Network/2Arteries/Steady/"

    nfig = 1

    dtstr       = "1e-4"
    tOrderstr   = "2"

    Nxstr       = "50"

    Kstr        = "1e4"
    NNstr       = "Inviscid"

    jstr        = "jA"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Store       = PATH1D + "Figures/"

    for Shstr in ["0","1e-3","1e-1"] :

        for pType in ["Q","P","E"] :

            pName,pLabel = out.getType(pType)

            # FILE :
            ###########
            ArtName0    = "Artery_0_x_" + pName
            ArtName1    = "Artery_1_x_" + pName
            PATHSTART   = "K=" + Kstr + "/" + NNstr + "/Sh=" + Shstr
            PATHEND     = "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/"

            J1 = "1"
            Art0_11  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J1 + "/Nx=" + Nxstr + "/xOrder=" + "1" + PATHEND + ArtName0
            Art0_12  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J1 + "/Nx=" + Nxstr + "/xOrder=" + "2" + PATHEND + ArtName0
            Art1_11  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J1 + "/Nx=" + Nxstr + "/xOrder=" + "1" + PATHEND + ArtName1
            Art1_12  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J1 + "/Nx=" + Nxstr + "/xOrder=" + "2" + PATHEND + ArtName1

            J2 = "0.1"
            Art0_21  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J2 + "/Nx=" + Nxstr + "/xOrder=" + "1" + PATHEND + ArtName0
            Art0_22  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J2 + "/Nx=" + Nxstr + "/xOrder=" + "2" + PATHEND + ArtName0
            Art1_21  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J2 + "/Nx=" + Nxstr + "/xOrder=" + "1" + PATHEND + ArtName1
            Art1_22  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J2 + "/Nx=" + Nxstr + "/xOrder=" + "2" + PATHEND + ArtName1

            J3 = "0.01"
            Art0_31  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J3 + "/Nx=" + Nxstr + "/xOrder=" + "1" + PATHEND + ArtName0
            Art0_32  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J3 + "/Nx=" + Nxstr + "/xOrder=" + "2" + PATHEND + ArtName0
            Art1_31  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J3 + "/Nx=" + Nxstr + "/xOrder=" + "1" + PATHEND + ArtName1
            Art1_32  = PATH1D + PATHSTART + "/" + jstr + "/Fact=" + J3 + "/Nx=" + Nxstr + "/xOrder=" + "2" + PATHEND + ArtName1

            ######################################
            ######################################
            lCol = [    "blue","blue","red","red","seagreen","seagreen"]
            lMark = [   "o","o","s","s","^","^"]
            lMarkSize = [   7,7,7,7,7,7]
            lMarkWidth = [  1,1,1,1,1,1]
            MarkPoints = 25

            lLineSize = [   1,1,1,1,1,1]
            lStyle = [      "","","","","",""]
            lAlpha = [      1,1,1,1,1,1]

            LegLoc      = 1
            LegPos      = [1.,1.]
            LegCol      = 1
            LegSize     = 20

            xRange      = []
            yRange      = []

            xBins       = 2 ;
            yBins       = 2 ;

            lHline      = []
            lHlineColor = []
            lHlineWidth = []
            lHlineStyle = []

            lVline      = [1]
            lVlineColor = ["black"]
            lVlineWidth = ["2"]
            lVlineStyle = ["--"]

            xScale = 10.
            lXScale     = [ xScale,xScale,xScale,xScale,xScale,xScale]
            yScale      = 1
            lYScale     = [ yScale,yScale,yScale,yScale,yScale,yScale]
            pScale      = "linear"

            lXOffset    = [ 0,-xScale,0,-xScale,0,-xScale]
            lYOffset    = [ 0.,0.,0.,0.,0.,0.]

            lText1       = [ r"$S_h$=" + out.latex_power(float(Shstr),1,1), r"$jA$, $N_x$=" + Nxstr + r", order 1", r"Steady" ]
            lText2       = [ r"$S_h$=" + out.latex_power(float(Shstr),1,1), r"$jA$, $N_x$=" + Nxstr + r", order 2", r"Steady" ]

            lTextAlign  = [ "left","right","left"]
            lTextPos    = [ [0.02,0.04],[0.98,0.04],[0.02,0.945] ]
            lTextColor  = [ "black","black","black"]

            xLabel=r"$x/L$"
            yLabel = pLabel
            lLabel = [  J1,"",J2,"",J3,"",
                        "","","","","",""
                        ]

            lFileSep    = [ ",",",",",",",",",",","]
            liX         = [ 0,0,0,0,0,0]
            liY         = [ 1,1,1,1,1,1
                            ]

            lFile1      = [ Art0_11,Art1_11,Art0_21,Art1_21,Art0_31,Art1_31
                            ]

            title = "Sh-" + Shstr + "-" + pType + "-O1-x.pdf"
            nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile1,lFileSep=lFileSep,
                                liX=liX,liY=liY,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,pScale=pScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                lText=lText1,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

            lFile2      = [ Art0_12,Art1_12,Art0_22,Art1_22,Art0_32,Art1_32
                            ]

            title = "Sh-" + Shstr + "-" + pType + "-O2-x.pdf"
            nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile2,lFileSep=lFileSep,
                                liX=liX,liY=liY,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,pScale=pScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                lText=lText2,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
    main(sys.argv[1:])
