#!/usr/bin/python3
import  sys, getopt

from    bfS_libData     import *
from    bfS_libWrite    import *

def main(argv) :
    PATH    = "";
    pA      = "" ;
    # COMMAND LINE ARGUMENTS
    #############################
    try :
        opts, args = getopt.getopt(argv,"hp:a:",["path=","A="])
    except getopt.GetoptError:
          print ('plot.py -p <PATH> -a <A>')
          sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('plot.py -p <PATH> -a <A>')
            sys.exit()
        elif opt in ("-p", "--PATH"):
            PATH = arg
        elif opt in ("-a", "--A"):
            pA = arg

	if not os.path.exists(str(PATH)+"Figures"):
		os.makedirs(str(PATH)+"Figures")
	folderPath_store = str(PATH) + "Figures/"

    folderPath= str(PATH)

    # DATA CLASS :
    ##############

    wb = dataS_Opt(folderPath,folderPath_store,logo="Sane")

    # PLOTING :
    ###########
    nfig = 1

    if (float(pA) == 1.) :
        T_c = 1.
    if (float(pA) == 0.1) :
        T_c = 0.25

    lTime = [
            0.25 *T_c,0.5*T_c,0.75*T_c,1.*T_c
            ]

    for pType in ["Q", "P", "RmR0", "E"] :

        write_Opt_x(cls=wb,numArt=0,lTime=lTime,pType=pType)
        write_Opt_x(cls=wb,numArt=1,lTime=lTime,pType=pType)
        write_Opt_Conj(cls=wb,numConj=1,lTime=lTime,pType=pType)



if __name__ == "__main__":
   main(sys.argv[1:])
