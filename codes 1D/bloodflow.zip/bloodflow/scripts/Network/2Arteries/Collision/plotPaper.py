#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *

import  help_Output as out
import  help_Inlet  as hin
import  help_Wave   as wa

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D = HOME + "/Documents/UPMC/These/Codes/bloodflow/Examples/Network/2Arteries/Collision/"

    nfig = 1

    dtstr       = "1e-4"
    tOrderstr   = "2"

    Kstr        = "1e4"
    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    for Shstr in ["1e-1"] :

        for Conjstr in ["jA"] :

            PATH        = PATH1D + "K=" + Kstr + "/" + NNstr + "/Sh=" + Shstr + "/" + Conjstr
            Store       = PATH1D + "Figures/"

            for pType in ["Q","P","RmR0"] :

                pName,pLabel = out.getType(pType)

                # FILE :
                ###########

                PATHEND     = "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/"

                ArtName0    = PATHEND + "Artery_0_x_" + pName
                JunName1    = PATHEND + "Junction_1_" + pName
                ArtName1    = PATHEND + "Artery_1_x_" + pName

                J1 = "50"
                Art0_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + ArtName0
                Art0_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + ArtName0

                Jun1_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + JunName1
                Jun1_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + JunName1

                Art1_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + ArtName1
                Art1_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + ArtName1

                J2 = "100"

                Art0_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + ArtName0
                Art0_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + ArtName0

                Jun1_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + JunName1
                Jun1_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + JunName1

                Art1_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + ArtName1
                Art1_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + ArtName1

                J3 = "200"

                Art0_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + ArtName0
                Art0_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + ArtName0

                Jun1_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + JunName1
                Jun1_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + JunName1

                Art1_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + ArtName1
                Art1_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + ArtName1

                ######################################
                ######################################
                lCol = [    "black","blue","red","green","purple",
                            "black","blue","red","green","purple",
                            "black","blue","red","green","purple"]
                lMark = [   "o","o","o","o","o",
                            "s","s","s","s","s",
                            "^","^","^","^","^"]
                lMarkSize = [   5,5,5,5,5,
                                5,5,5,5,5,
                                5,5,5,5,5]
                lMarkWidth = [  1,1,1,1,1,
                                1,1,1,1,1,
                                1,1,1,1,1]
                MarkPoints = 15

                lLineSize = [   1,1,1,1,1,
                                1,1,1,1,1,
                                1,1,1,1,1]
                lStyle = [      "-","-","-","-","-",
                                "-","-","-","-","-",
                                "-","-","-","-","-"]
                lAlpha = [  1,1,1,1,1,
                            1,1,1,1,1,
                            1,1,1,1,1]

                LegLoc      = 1
                LegPos      = [1.,0.995]
                LegCol      = 6

                xRange      = [0,2]
                yRange      = [-1,2]

                xBins       = 6 ;
                yBins       = 2 ;

                # Set lines representing amplitude of reflection
                RHO = 1 ;
                RP = 1. ; RD = RP/2.
                AP = np.pi*RP*RP ; AD = np.pi*RD*RD ;
                KP = float(Kstr) ; KD = KP * 3. ;

                Y1 = wa.Impedance(RHO,KP,AP) ;  Y2 = wa.Impedance(RHO,KD,AD)
                Rt, Tt = wa.Reflection_2Arteries(RHO,AP,AD,KP,KD)

                if (pType == "P") :
                    Amp  = hin.ShtoP(float(Shstr),float(Kstr),1.)
                    RAmp = Rt * Amp
                    TAmp = Tt * Amp
                if (pType == "RmR0") :
                    Amp  = hin.ShtoP(float(Shstr),float(Kstr),1.) / float(Kstr) / np.sqrt(np.pi)
                    RAmp = Rt * Amp
                    TAmp = KP / KD * Tt * Amp
                if (pType == "Q") :
                    Amp  = hin.ShtoP(float(Shstr),float(Kstr),1.) * wa.Admittance(1.,float(Kstr),hin.ShtoA(float(Shstr),1.))
                    RAmp = -Rt * Amp
                    TAmp = Y1 / Y2 * Tt * Amp

                lHline      = [Amp/abs(Amp),RAmp/abs(Amp),TAmp/abs(Amp)]
                lHlineColor = ["black","black","black"]
                lHlineWidth = [2,2,2]
                lHlineStyle = ["--",":","-."]

                lVline      = []
                lVlineColor = []
                lVlineWidth = []
                lVlineStyle = []

                L = 10.
                lXScale     = [ L,L,L,L,L,
                                L,L,L,L,L,
                                L,L,L,L,L]

                lYScale     = [ Amp,Amp,Amp,Amp,Amp,
                                Amp,Amp,Amp,Amp,Amp,
                                Amp,Amp,Amp,Amp,Amp]

                lXOffset    = [ 0.,0.,-1.005*L,-1.01*L,-1.01*L,
                                0.,0.,-1.005*L,-1.01*L,-1.01*L,
                                0.,0.,-1.005*L,-1.01*L,-1.01*L]
                lYOffset    = [ 0.,0.,0.,0.,0.,
                                0.,0.,0.,0.,0.,
                                0.,0.,0.,0.,0.]

                lText       = [ r"$t$=$\left\{0.5,1.8\right\}T$", r"$Order$", r"$S_h$=" + out.latex_power(float(Shstr),1,1)]
                lTextAlign  = [ "left", "right" , "left"]
                lTextPos    = [ [0.02,0.05],[0.98,0.05],[0.01,0.92] ]
                lTextColor  = [ "black", "black","black" ]

                xLabel=r"$x/L$"

                if (pType == "P") :
                    yLabel = r"$P /\left[\sqrt{\pi} K R S_h \right]$"
                if (pType == "RmR0") :
                    yLabel = r"$ \left[R-R_0\right] /\left[ R S_h \right]$"
                if (pType == "Q") :
                    yLabel = r"$Q /\left[\sqrt{\pi} K R S_h Y \right]$"

                lLabel = [  J1,"","","","",
                            J2,"","","","",
                            J3,"","","",""]

                lFileSep    = [ ",",",",",",",",",",
                                ",",",",",",",",",",
                                ",",",",",",",",","]
                liX         = [ 0,0,0,0,0,
                                0,0,0,0,0,
                                0,0,0,0,0]
                liY         = [ 1,9,9,1,9,
                                1,9,9,1,9,
                                1,9,9,1,9]

                lFile_O1 = [    Art0_11,Art0_11,Jun1_11,Art1_11,Art1_11,
                                Art0_21,Art0_21,Jun1_21,Art1_21,Art1_21,
                                Art0_31,Art0_31,Jun1_31,Art1_31,Art1_31
                                ]

                lFile_O2 = [    Art0_12,Art0_12,Jun1_12,Art1_12,Art1_12,
                                Art0_22,Art0_22,Jun1_22,Art1_22,Art1_22,
                                Art0_32,Art0_32,Jun1_32,Art1_32,Art1_32]

                title = pType + "_O1_x.pdf"
                lText[1] = r"$Order$ $1$"
                nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile_O1,lFileSep=lFileSep,
                                    liX=liX,liY=liY,
                                    xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                    xRange=xRange,yRange=yRange,
                                    xBins=xBins,yBins=yBins,
                                    lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                    lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                    lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                    LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                                    lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                    lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                    lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

                title = pType + "_O2_x.pdf"
                lText[1] = r"$Order$ $2$"
                nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile_O2,lFileSep=lFileSep,
                                    liX=liX,liY=liY,
                                    xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                    xRange=xRange,yRange=yRange,
                                    xBins=xBins,yBins=yBins,
                                    lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                    lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                    lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                    LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                                    lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                    lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                    lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
