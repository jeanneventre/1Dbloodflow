#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *

import  help_Output as out
import  help_Inlet  as hin
import  help_Wave   as wa

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D = HOME + "/Documents/UPMC/These/Codes/bloodflow/Examples/Fistule/3Arteries/"

    nfig = 1

    dtstr       = "1e-4"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    Conjstr     = "jA"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    for dRstr in ["0"] :
        for dKstr in ["0"] :

            PATH        = PATH1D + NNstr + "/dR=" + dRstr + "/dK=" + dKstr + "/" + Conjstr
            Store       = PATH1D + "Figures/"

            for pType in ["Q","U","P","R","RmR0","E"] :

                pName,pLabel = out.getType(pType)

                # FILE :
                ###########

                PATHEND     = "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/"

                ArtName0    = PATHEND + "Artery_0_t_" + pName
                ArtName1    = PATHEND + "Artery_1_t_" + pName
                ArtName2    = PATHEND + "Artery_2_t_" + pName

                J1 = "10"
                Art0_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + ArtName0
                Art0_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + ArtName0

                Art1_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + ArtName1
                Art1_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + ArtName1

                Art2_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + ArtName2
                Art2_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + ArtName2

                J2 = "20"

                Art0_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + ArtName0
                Art0_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + ArtName0

                Art1_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + ArtName1
                Art1_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + ArtName1

                Art2_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + ArtName2
                Art2_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + ArtName2

                J3 = "40"

                Art0_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + ArtName0
                Art0_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + ArtName0

                Art1_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + ArtName1
                Art1_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + ArtName1

                Art2_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + ArtName2
                Art2_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + ArtName2

                ######################################
                ######################################
                lCol = [    "blue","red","green",
                            "blue","red","green",
                            "blue","red","green"]
                lMark = [   "o","o","o",
                            "s","s","s",
                            "^","^","^"]
                lMarkSize = [   5,5,5,
                                5,5,5,
                                5,5,5]
                lMarkWidth = [  1,1,1,
                                1,1,1,
                                1,1,1]
                MarkPoints = 15

                lLineSize   = [ 1,1,1,
                                1,1,1,
                                1,1,1]
                lStyle      = [ "-","-","-",
                                "-","-","-",
                                "-","-","-"]
                lAlpha      = [ 1,1,1,
                                1,1,1,
                                1,1,1]

                LegLoc      = 1
                LegPos      = [1.,0.995]
                LegCol      = 6

                xRange      = [0,1]
                yRange      = []

                xBins       = 6 ;
                yBins       = 2 ;

                lHline      = []
                lHlineColor = []
                lHlineWidth = []
                lHlineStyle = []

                lVline      = []
                lVlineColor = []
                lVlineWidth = []
                lVlineStyle = []

                T           = 0.8
                ts          = 2. * T
                te          = 3. * T
                lXScale     = [ te-ts,te-ts,te-ts,te-ts,
                                te-ts,te-ts,te-ts,te-ts,
                                te-ts,te-ts,te-ts,te-ts]

                lYScale     = [ 1.,1.,1.,1.,
                                1.,1.,1.,1.,
                                1.,1.,1.,1.]

                lXOffset    = [ ts,ts,ts,ts,
                                ts,ts,ts,ts,
                                ts,ts,ts,ts]
                lYOffset    = [ 0.,0.,0.,0.,
                                0.,0.,0.,0.,
                                0.,0.,0.,0.]

                lText       = []
                lTextAlign  = []
                lTextPos    = []
                lTextColor  = []

                xLabel      = r"$\bar{t}$"
                yLabel      = pLabel
                lLabel      = [ J1,"","",
                                J2,"","",
                                J3,"",""]

                lFileSep    = [ ",",",",",",
                                ",",",",",",
                                ",",",",","]
                liX         = [ 0,0,0,
                                0,0,0,
                                0,0,0]
                liY         = [ 2,2,1,
                                2,2,1,
                                2,2,1]

                lFile_O1    = [ Art0_11,Art1_11,Art2_11,
                                Art0_21,Art1_21,Art2_21,
                                Art0_31,Art1_31,Art2_31
                                ]

                lFile_O2 = [    Art0_12,Art1_12,Art2_12,
                                Art0_22,Art1_22,Art2_22,
                                Art0_32,Art1_32,Art2_32
                                ]

                title = pType + "_O1_t.pdf"
                nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile_O1,lFileSep=lFileSep,
                                    liX=liX,liY=liY,
                                    xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                    xRange=xRange,yRange=yRange,
                                    xBins=xBins,yBins=yBins,
                                    lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                    lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                    lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                    LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                                    lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                    lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                    lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

                # title = pType + "_O2_t.pdf"
                # nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile_O2,lFileSep=lFileSep,
                #                     liX=liX,liY=liY,
                #                     xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                #                     xRange=xRange,yRange=yRange,
                #                     xBins=xBins,yBins=yBins,
                #                     lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                #                     lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                #                     lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                #                     LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                #                     lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                #                     lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                #                     lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
