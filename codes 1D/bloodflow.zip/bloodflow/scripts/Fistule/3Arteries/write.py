#!/usr/bin/python3
import  sys, getopt

from    bfS_libData     import *
from    bfS_libWrite    import *

def main(argv) :
    PATH = "";
    # COMMAND LINE ARGUMENTS
    #############################
    try :
        opts, args = getopt.getopt(argv,"hp:",["path="])
    except getopt.GetoptError:
          print ('plot.py -p <PATH>')
          sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('plot.py -p <PATH>')
            sys.exit()
        elif opt in ("-p", "--PATH"):
            PATH = arg

	if not os.path.exists(str(PATH)+"Figures"):
		os.makedirs(str(PATH)+"Figures")
	folderPath_store = str(PATH) + "Figures/"

    folderPath= str(PATH)

    # DATA CLASS :
    ##############

    wb = dataS_Opt(folderPath,folderPath_store,logo="Sane")

    # PLOTING :
    ###########
    nfig = 1

    T_c     = 0.8

    lTime = [
            2.5 * T_c
            ]

    L0 = 20. ;
    L1 = 10. ;
    L2 = 20. ;
    lX0 = [0., L0/2., L0]
    lX1 = [0., L1/2., L1]
    lX2 = [0., L2/2., L2]

    for pType in ["Q", "U", "P", "R", "RmR0", "E", "Sh"] :

        write_Opt_x(cls=wb,numArt=0,lTime=lTime,pType=pType)
        write_Opt_x(cls=wb,numArt=1,lTime=lTime,pType=pType)
        write_Opt_x(cls=wb,numArt=2,lTime=lTime,pType=pType)

        write_Opt_Conj(cls=wb,numConj=1,lTime=lTime,pType=pType)

        write_Opt_t(cls=wb,numArt=0,lX=lX0,pType=pType)
        write_Opt_t(cls=wb,numArt=1,lX=lX1,pType=pType)
        write_Opt_t(cls=wb,numArt=2,lX=lX2,pType=pType)




if __name__ == "__main__":
   main(sys.argv[1:])
