#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *
from    help_Wave   import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Steady/Cos/"
    PATHANA = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Steady/Cos/Analytic/"

    nfig = 1

    dtstr       = "1e-5"
    tOrderstr   = "2"

    Kstr        = "1e4"
    NNstr       = "Inviscid"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Shstr       = "1e-3"

    PATH    = PATH1D    + "K=" + Kstr + "/" + NNstr + "/Sh=" + Shstr
    Store   = PATH1D    + "Figures/"

    for pType in ["E","P","Q"] :

        pName,pLabel = out.getType(pType)

        # FILE :
        ###########
        ArtName0    = "Artery_0_x_"
        PATHEND     = "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        J1 = "100"
        Art0_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + PATHEND
        Art0_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + PATHEND

        # ANALYTIC
        ###########
        ANA = PATHANA + "Sh=" + Shstr + "/" + pType + ".csv"

        ######################################
        ######################################
        lCol        = [ "black","blue","red","seagreen","purple"]
        lMark       = [ "","o","s"]
        lMarkSize   = [ 1,5,5]
        lMarkWidth  = [ 1,1,1]
        MarkPoints  = 100

        lLineSize   = [ 2,2,2]
        lStyle      = [ "-","",""]
        lAlpha      = [ 1,1,1]

        LegLoc      = 1
        LegPos      = [1.,1.]
        LegCol      = 1
        LegSize     = 19

        xRange      = []
        yRange      = []

        xBins       = 2 ;
        yBins       = 2 ;

        lHline      = []
        lHlineColor = []
        lHlineWidth = []
        lHlineStyle = []

        lVline      = []
        lVlineColor = []
        lVlineWidth = []
        lVlineStyle = []

        xScale = 10.
        lXScale     = [ xScale,xScale,xScale]
        yScale      = 1.
        if (pType == "E") :
            yScale = 17.72897407481705132684
        if (pType == "P") :
            yScale = 17.72453850905516027298
        if (pType == "Q") :
            yScale = 0.29648828415696235796
        lYScale     = [ yScale,yScale,yScale]
        pScale      = "linear"

        lXOffset    = [ 0.,0.,0.]
        lYOffset    = [ yScale,yScale,yScale]

        lText       = [ r"$\Delta \mathcal{G}$=$10^{-1}$", r"$S_h$=" + out.latex_power(float(Shstr),1,1), "Steady" ]
        lTextAlign  = [ "left", "right", "left" ]
        lTextPos    = [ [0.02,0.05],[0.98,0.04],[0.02,0.945] ]
        lTextColor  = [ "black", "black","black" ]

        xLabel=r"$x/L$"
        if (pType == "E") :
            yLabel = r"$[ E-E\rvert_{x=0} ] / E \rvert_{x=0}$"
        if (pType == "P") :
            yLabel = r"$[ p-p\rvert_{x=0} ] / p \rvert_{x=0}$"
        if (pType == "Q") :
            yLabel = r"$[ Q-Q\rvert_{x=0} ] / Q \rvert_{x=0}$"
        lLabel = [  r"$Analytic$",r"$N_x$="+J1+", order 1",r"$N_x$="+J1+", MUSCL"]

        lFileSep    = [ ",",",",","]
        liX         = [ 0,0,0]
        liY         = [ 1,1,1]

        lFile       = [ ANA,Art0_11,Art0_12]

        title = pType + "-x.pdf"
        nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                            liX=liX,liY=liY,
                            xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                            xRange=xRange,yRange=yRange,
                            xBins=xBins,yBins=yBins,
                            lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                            lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                            lXScale=lXScale,lYScale=lYScale,pScale=pScale,lXOffset=lXOffset,lYOffset=lYOffset,
                            LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                            lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                            lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                            lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
