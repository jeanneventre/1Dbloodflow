#!/usr/bin/python3
import sys, getopt

import  help_Output as out

from csv_libPlot_Err import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Delestre/Viscous/"
    PATHANA = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Delestre/Viscous/Analytic/"
    PATHCV  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Delestre/Viscous/CV/"

    nfig = 1

    dtstr       = "1e-5"
    tOrderstr   = "2"

    Kstr        = "1e4"
    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    PATH    = PATH1D    + "K=" + Kstr + "/" + NNstr
    Store   = PATH1D + "Figures/"

    for pType in ["Q","U","A"] :

        pName,pLabel = out.getType(pType)

        # FILE :
        ###########
        ArtName0    = "Artery_0_x_"
        PATHEND     = "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        J1 = "50"
        Art0_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + PATHEND
        Art0_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + PATHEND

        J2 = "100"
        Art0_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + PATHEND
        Art0_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + PATHEND

        J3 = "200"
        Art0_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + PATHEND
        Art0_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + PATHEND

        J4 = "400"
        Art0_41  = PATH + "/Nx=" + J4 + "/xOrder=" + "1" + PATHEND
        Art0_42  = PATH + "/Nx=" + J4 + "/xOrder=" + "2" + PATHEND

        J5 = "800"
        Art0_51  = PATH + "/Nx=" + J5 + "/xOrder=" + "1" + PATHEND
        Art0_52  = PATH + "/Nx=" + J5 + "/xOrder=" + "2" + PATHEND

        J6 = "1600"
        Art0_61  = PATH + "/Nx=" + J6 + "/xOrder=" + "1" + PATHEND
        Art0_62  = PATH + "/Nx=" + J6 + "/xOrder=" + "2" + PATHEND


        # ANALYTIC
        ###########
        if (pType == "Q") :
            ANA = PATHANA + "/Q.csv"
            CV  = PATHCV  + "/Q.csv"
        if (pType == "U") :
            ANA = PATHANA + "/U.csv"
            CV  = PATHCV  + "/U.csv"
        if (pType == "A") :
            ANA = PATHANA + "/A.csv"
            CV  = PATHCV  + "/A.csv"

        # ERROR
        #######

        xrType  = "x"
        pScale  = "log"

        for Ltype in  ["L1","L2","Linf"] :

            lllFact      =   [
                                [ [1.], [1.], [1.], [1.], [1.], [1.]  ],
                                [ [1.], [1.], [1.], [1.], [1.], [1.]  ]
                            ]
            llFactOrder =   [
                                [ 1., 1., 1., 1., 1., 1. ],
                                [ 1., 1., 1., 1., 1., 1. ]
                            ]
            lllX        =   [
                                [ [[0,0]], [[0,0]], [[0,0]], [[0,0]], [[0,0]], [[0,0]] ],
                                [ [[0,0]], [[0,0]], [[0,0]], [[0,0]], [[0,0]], [[0,0]] ]
                            ]
            # t=0.3
            #######
            lllY        =   [
                                [ [[3,3]], [[3,3]], [[3,3]], [[3,3]], [[3,3]], [[3,3]] ],
                                [ [[3,3]], [[3,3]], [[3,3]], [[3,3]], [[3,3]], [[3,3]] ]
                            ]
            lllFileSep  =   [
                                [ [",",","], [",",","], [",",","], [",",","], [",",","], [",",","] ],
                                [ [",",","], [",",","], [",",","], [",",","], [",",","], [",",","] ]
                            ]
            lllFile     =   [
                                [ [ANA,Art0_11], [ANA,Art0_21], [ANA,Art0_31], [ANA,Art0_41], [ANA,Art0_51], [ANA,Art0_61] ],
                                [ [ANA,Art0_12], [ANA,Art0_22], [ANA,Art0_32], [ANA,Art0_42], [ANA,Art0_52], [ANA,Art0_62] ]
                            ]

            ######################################
            ######################################
            lCol        = ["black","blue"]
            lMark       = ["s","o"]
            lMarkSize   = [ 7,7]
            lMarkWidth  = [1,1]
            MarkPoints  = 30

            lLineSize   = [3,3]
            lStyle      = ["-","-"]
            lAlpha      = [1.,1.]

            LegLoc      = 1
            LegPos      = [1.,1.]
            LegCol      = 1

            xRange      = []
            yRange      = []

            xBins       = 6 ;
            yBins       = 2 ;

            lHline      = []
            lHlineColor = []
            lHlineWidth = []
            lHlineStyle = []

            lVline      = []
            lVlineColor = []
            lVlineWidth = []
            lVlineStyle = []

            lXScale     = [1.,1.]
            lYScale     = [1.,1.]

            lXOffset    = [0.,0.]
            lYOffset    = [0.,0.]

            lText       = [ r"$t$=$0.3$" ]
            lTextAlign  = [ "left" ]
            lTextPos    = [ [0.02,0.05] ]
            lTextColor  = [ "black" ]

            xLabel      = r"$N_x$"
            yLabel      = Ltype + r"$\left[\right.$" + pType + r"$\left.\right]$"
            lLabel      = [ r"$Order$ $1$",r"$Order$ $2$"]

            title = Ltype + "_" + pType + ".pdf"
            nfig = plot_csv_Err_CV(pathStore=Store,title=title,
                                lllFile=lllFile,lllFileSep=lllFileSep,lllX=lllX,lllY=lllY,
                                lllFact=lllFact,llFactOrder=llFactOrder,xrType=xrType,Ltype=Ltype,
                                pScale = pScale,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                                lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
