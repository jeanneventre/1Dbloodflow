#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *
from    help_Wave   import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Tourniquet/Inviscid/"
    PATHANA = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Tourniquet/Inviscid/Analytic/"

    nfig = 1

    dtstr       = "1e-5"
    tOrderstr   = "2"

    Kstr        = "1e4"
    NNstr       = "Inviscid"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    dRstr       = "1e-1"

    PATH    = PATH1D + "K=" + Kstr + "/" + NNstr + "/dR=" + dRstr
    Store   = PATH1D + "Figures/"

    for pType in ["Q","A","U"] :

        pName,pLabel = out.getType(pType)

        # FILE :
        ###########
        ArtName0    = "Artery_0_x_"
        PATHEND     = "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        J1 = "100"
        Art0_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + PATHEND
        Art0_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + PATHEND

        # ANALYTIC
        ###########
        ANA = PATHANA + pType + ".csv"

        ######################################
        ######################################
        lCol = [    "black","blue","red","seagreen","purple",
                    "black","blue","red","seagreen","purple",
                    "black","blue","red","seagreen","purple"]
        lMark = [   "","","","","",
                    "o","o","o","o","o",
                    "s","s","s","s","s"]
        lMarkSize = [   1,1,1,1,1,
                        5,5,5,5,5,
                        5,5,5,5,5]
        lMarkWidth = [  1,1,1,1,1,
                        1,1,1,1,1,
                        1,1,1,1,1]
        MarkPoints = 100

        lLineSize = [   2,2,2,2,2,
                        2,2,2,2,2,
                        2,2,2,2,2]
        lStyle = [      "-","-","-","-","-",
                        "","","","","",
                        "","","","","",]
        lAlpha = [  1,1,1,1,1,
                    1,1,1,1,1,
                    1,1,1,1,1]

        LegLoc      = 1
        LegPos      = [1.,1.]
        LegCol      = 1
        LegSize     = 19

        xRange      = []
        yRange      = []

        xBins       = 2 ;
        yBins       = 2 ;

        lHline      = []
        lHlineColor = []
        lHlineWidth = []
        lHlineStyle = []

        lVline      = []
        lVlineColor = []
        lVlineWidth = []
        lVlineStyle = []

        xScale = 10.
        lXScale     = [ xScale,xScale,xScale,xScale,xScale,
                        xScale,xScale,xScale,xScale,xScale,
                        xScale,xScale,xScale,xScale,xScale]
        yScale      = 1.
        lYScale     = [ yScale,yScale,yScale,yScale,yScale,
                        yScale,yScale,yScale,yScale,yScale,
                        yScale,yScale,yScale,yScale,yScale]
        pScale      = "linear"

        xOffset     = xScale / 2.
        lXOffset    = [ xOffset,xOffset,xOffset,xOffset,xOffset,
                        xOffset,xOffset,xOffset,xOffset,xOffset,
                        xOffset,xOffset,xOffset,xOffset,xOffset]
        lYOffset    = [ 0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.]

        lText       = [ r"$t$=$\left\{0,1,2,3,4\right\}\times 10^{-3}$", r"$S_h$=" + out.latex_power(float(dRstr),1,1), "Inviscid tourniquet" ]
        lTextAlign  = [ "left", "right", "left" ]
        lTextPos    = [ [0.02,0.05],[0.98,0.04],[0.02,0.945] ]
        lTextColor  = [ "black", "black","black" ]

        xLabel=r"$x/L$"
        yLabel = pLabel
        lLabel = [  r"$Analytic$","","","","",
                    r"$N_x$="+J1+", order 1","","","","",
                    r"$N_x$="+J1+", MUSCL","","","",""
                    ]

        lFileSep    = [ ",",",",",",",",",",
                        ",",",",",",",",",",
                        ",",",",",",",",","]
        liX         = [ 0,0,0,0,0,
                        0,0,0,0,0,
                        0,0,0,0,0]
        liY         = [ 1,2,3,4,5,
                        1,2,3,4,5,
                        1,2,3,4,5]

        lFile       = [ ANA,ANA,ANA,ANA,ANA,
                        Art0_11,Art0_11,Art0_11,Art0_11,Art0_11,
                        Art0_12,Art0_12,Art0_12,Art0_12,Art0_12
                        ]

        title = pType + "-x.pdf"
        nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                            liX=liX,liY=liY,
                            xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                            xRange=xRange,yRange=yRange,
                            xBins=xBins,yBins=yBins,
                            lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                            lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                            lXScale=lXScale,lYScale=lYScale,pScale=pScale,lXOffset=lXOffset,lYOffset=lYOffset,
                            LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                            lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                            lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                            lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
