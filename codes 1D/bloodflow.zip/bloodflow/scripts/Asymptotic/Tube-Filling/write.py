#!/usr/bin/python3
import  sys, getopt

from    bfS_libData     import *
from    bfS_libWrite    import *

def main(argv) :
    PATH = "";
    # COMMAND LINE ARGUMENTS
    #############################
    try :
        opts, args = getopt.getopt(argv,"hp:",["path="])
    except getopt.GetoptError:
          print ('plot.py -p <PATH>')
          sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('plot.py -p <PATH>')
            sys.exit()
        elif opt in ("-p", "--PATH"):
            PATH = arg

	if not os.path.exists(str(PATH)+"Figures"):
		os.makedirs(str(PATH)+"Figures")
	folderPath_store = str(PATH) + "Figures/"

    folderPath= str(PATH)

    # DATA CLASS :
    ##############

    wb = dataS_Opt(folderPath,folderPath_store,logo="Sane")

    # PLOTING :
    ###########
    nfig = 1

    lTime = [
            0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,
            1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2.0,
            2.1,2.2,2.3,2.4,2.5,2.6,2.7,2.8,2.9,3.0,
            3.1,3.2,3.3,3.4,3.5,3.6,3.7,3.8,3.9
            ]

    for pType in ["A"] :
        write_Opt_x(cls=wb,numArt=0,lTime=lTime,pType=pType)

if __name__ == "__main__":
   main(sys.argv[1:])
