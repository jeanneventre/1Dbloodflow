#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Tube-Filling/"
    PATHANA = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Tube-Filling/Analytic/"

    nfig = 1

    dtstr       = "1e-4"
    tOrderstr   = "2"

    Kstr        = "1e4"
    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Store       = PATH1D + "Figures/"

    for pType in ["A"] :

        pName,pLabel = out.getType(pType)

        for Nxstr in ["25"] :

            # FILE :
            ###########
            ArtName0    = "Artery_0_x_"
            PATHSTART   = PATH1D + "K=" + Kstr + "/" + NNstr
            PATHEND     = "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

            S1 = "1e-3"
            Data11  = PATHSTART + "/Sh=" + S1 + "/Nx=" + Nxstr + "/xOrder=" + "1" + PATHEND
            Data12  = PATHSTART + "/Sh=" + S1 + "/Nx=" + Nxstr + "/xOrder=" + "2" + PATHEND

            # ANALYTIC
            ###########
            ANA1 = PATHANA + "Sh=" + S1 + "/And.csv"

            ######################################
            ######################################
            # CHARACTERISTIC PARAMETERS
            rho = 1
            Cf  = 10.
            C   = float(Kstr) / 2. / rho / Cf

            R0  = 1.
            A0  = np.pi * R0 * R0
            R1   = R0 * (1. + float(S1) )
            A1   = np.pi * R1 * R1

            ######################################
            ######################################
            lCol        = [ "black","blue","red"]
            lMark       = [ "","o","s"]
            lMarkSize   = [ 1,5,5]
            lMarkWidth  = [ 1,1,1]
            MarkPoints  = 200

            lLineSize   = [ 3,1,1]
            lStyle      = [ "-","",""]
            lAlpha      = [ 1,1,1]

            LegLoc      = 1
            LegPos      = [1.,1.]
            LegCol      = 1
            LegSize     = 25

            xRange      = []
            yRange      = []

            xBins       = 4 ;
            yBins       = 2 ;

            lHline      = []
            lHlineColor = []
            lHlineWidth = []
            lHlineStyle = []

            lVline      = []
            lVlineColor = []
            lVlineWidth = []
            lVlineStyle = []

            t           = 3.9
            xScale1     = np.sqrt( C * (A1**(3./2.)) )
            lXScale     = [ 1., np.sqrt(t)*xScale1, np.sqrt(t)*xScale1]
            yScale1     = A1 - A0
            lYScale     = [ 1.,yScale1,yScale1]
            pScale      = "linear"

            lXOffset    = [ 0.,0.,0.,
                            0.,0.,0.]
            yOffset     = A0
            lYOffset    = [ 0.,yOffset,yOffset]

            lText       = [ r"$t$=$3.9$", "Wave front propagation" ]
            lTextAlign  = [ "left", "right" ]
            lTextPos    = [ [0.02,0.05],[0.98,0.05] ]
            lTextColor  = [ "black","black" ]

            xLabel      = r"$\bar{x}/\sqrt{\bar{t}}$"
            yLabel      = r"$\left[A/A\rvert_{x=0}-\psi\right]/\left[1-\psi\right]$"
            lLabel      =   [
                            r"$S_h$="+S1+r", $Asymptotic$",r"$S_h$="+S1+r", $N_x$="+Nxstr+", order 1",r"$S_h$="+S1+r", $N_x$="+Nxstr+", MUSCL",
                            ]

            lFileSep    = [ ",",",",",",
                            ",",",",","]
            liX         = [ 0,0,0,
                            0,0,0]
            iY          = 39
            liY         = [ 1,iY,iY,
                            1,iY,iY]

            lFile       = [ ANA1,Data11,Data12
                            ]

            title = pType + "-Nx-" + Nxstr + "-x.pdf"
            nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                                liX=liX,liY=liY,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,pScale=pScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
