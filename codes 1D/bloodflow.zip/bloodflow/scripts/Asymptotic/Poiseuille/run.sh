#!/bin/bash

export folderGeneral=/Documents/UPMC/These/Codes/bloodflowSingle/example/Well-Balance/Asymptotic/Poiseuille

for K in 1e8 ; do
  folderK=${folderGeneral}/K=${K}
  for Re in 1000 ; do
    folderRe=${folderK}/Re=${Re}
    for U in 100 ; do
      export folderU=${folderRe}/U=${U}
      for L in 250 ; do
        export folderL=${folderU}/Length=${L}
        for phi in 8 40; do
          for J in 1600 ; do
            for HR in HRQ ; do
              for Order in 1 ; do
                for solver in KIN_HAT; do
                  export folderHR=${folderL}/phi=${phi}/J=${J}/${HR}/Order=${Order}/${solver}

                  # python2.7 writeParameter.py -p ${HOME}${folderHR}/ -l Sane -s ${solver} -y ${HR} -j ${J} -o ${Order} -k ${K} -f ${phi} -u ${U} -e ${Re} -d ${L}
                  # bloodflowSingle -i ${HOME}${folderHR}/parameters_Sane/ -o ${HOME}${folderHR}/data/ -s Sane -q
                  # python2.7 write.py -p ${HOME}${folderHR}/ -u ${U} -r ${Re}
                  # python2.7 plot.py -p ${HOME}${folderHR}/

                  # mkdir -p ${HOME}${folderHR}/Figures
                  # scp -r ${SSHACCOUNT}:${HOME_SSH}${folderHR}/Figures ${HOME}${folderHR}/

                  # ssh -f -N -L 2222:${ACCOUNT}:22 ${SSHCHAGALL}
                  mkdir -p ${HOME}${folderHR}/Figures
                  scp -r -P 2222 ghigo@localhost:${HOME_SSH}${folderHR}/Figures ${HOME}${folderHR}/

                done
              done
            done
          done
        done
      done
    done
  done
done
