#!/usr/bin/python3
import sys, getopt
from bfS_libData_Opt import *
from bfS_libWrite_Opt import *

def main(argv) :
    PATH = ""
    U = "" ; Re = "" ;
    # COMMAND LINE ARGUMENTS
    #############################
    try :
        opts, args = getopt.getopt(argv,"hp:u:r:",["path=",'U=','Re='])
    except getopt.GetoptError:
          print ('plot.py -p <PATH> -u <U> -r <Re>')
          sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('plot.py -p <PATH> -u <U> -r <Re>')
            sys.exit()
        elif opt in ("-p", "--PATH"):
            PATH = arg
        elif opt in ("-u", "--U"):
            U = float(arg)
        elif opt in ("-r", "--Re"):
            Re = float(arg)

	if not os.path.exists(str(PATH)+"Figures"):
		os.makedirs(str(PATH)+"Figures")
	folderPath_store = str(PATH) + "Figures/"

    folderPath= str(PATH)


    # DATA CLASS :
    ##############

    wb = dataS_Opt(folderPath,folderPath_store,logo="Sane")

    # PLOTING :
    ###########
    nfig = 1

    R = 1.
    L = 250.
    Le = float(Re * R)
    te = float(Le)/float(U) * 0.2

    lTime = [te * 0.9]
    write_Opt_x_R_RmR0_A_Q_U_P_E_Tw_Cf_Fr(cls=wb,numArt=0,lTime=lTime)
    
if __name__ == "__main__":
   main(sys.argv[1:])
