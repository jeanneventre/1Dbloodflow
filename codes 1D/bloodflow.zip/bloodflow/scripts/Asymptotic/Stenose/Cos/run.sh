#!/bin/bash

export folderGeneral=/Documents/UPMC/These/Codes/bloodflowSingle/example/Well-Balance/Asymptotic/Stenose/Established/Cos/Rvar

for K in 1e7 ; do
  folderK=${folderGeneral}/K=${K}

  for Re in 100 ; do
    folderRe=${folderK}/Re=${Re}
    for U in 100 ; do
      export folderU=${folderRe}/U=${U}
      for L in 25 ; do
        export folderL=${folderU}/Length=${L}
        for dR in -0.4 +0.4; do
          export folderdR=${folderL}/dR=${dR}
          for Lst in 10 ; do
            export folderLst=${folderdR}/Lst=${Lst}

            for NN in "Newtonian" ; do
              for phi in -4 ; do
                for J in 1600 ; do
                  for HR in HRQ ; do
                    for Order in 1 ; do
                      for solver in KIN_HAT; do
                        export folderHR=${folderLst}/${NN}/phi=${phi}/J=${J}/${HR}/Order=${Order}/${solver}

                        # python2.7 writeParameter.py -p ${HOME}${folderHR}/ -l Sane -s ${solver} -y ${HR} -j ${J} -o ${Order} -k ${K} -n ${NN} -f ${phi} -u ${U} -e ${Re} -d ${L} -t ${dR} -w ${Lst}
                        # bloodflowSingle -i ${HOME}${folderHR}/parameters_Sane/ -o ${HOME}${folderHR}/data/ -s Sane -q
                        # python2.7 write.py -p ${HOME}${folderHR}/ -u ${U} -r ${Re}

                        # mkdir -p ${HOME}${folderHR}/Figures
                        # scp -r ${SSHACCOUNT}:${HOME_SSH}${folderHR}/Figures ${HOME}${folderHR}/

                        mkdir -p ${HOME}${folderHR}/Figures
                        scp -r -P 2222 ghigo@localhost:${HOME_SSH}${folderHR}/Figures ${HOME}${folderHR}/

                      done
                    done
                  done
                done
              done
            done
          done
        done
      done
    done
  done
done
