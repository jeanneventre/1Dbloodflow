#! /usr/bin/python2.7
import sys, getopt
import os
import numpy as np
import math as mt
from bfS_libDef import *

def main(argv) :
    PATH = "" ; logo = "" ;
    Solver = '' ; HR = '' ; Cells = '' ; Order = '' ;

    Kstr = "" ;
    NNstr = "" ; phistr = "" ;

    Ustr = "" ; Restr = "" ; Lstr = ""
    dRstr = "" ; Lststr = ""
    # COMMAND LINE ARGUMENTS
    #############################
    try :
        opts, args = getopt.getopt(argv,"hp:l:s:y:j:o:k:n:f:u:e:d:t:w:",["path=","logo=","Solver","HR","Cells=","Order=","K=","NN=","Phi=","U=","Re=","Length=","dR=","Lst="])
    except getopt.GetoptError:
          print ('writeParameter-55.py -p <PATH> -l <logo> -s <Solver> -y <HR> -j <Cells> -o <Order> -k <K> -n <NN> -f <Phi> -u <U> -e <Re> -d <Length>')
          sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('writeParameter-55.py -p <PATH> -l <logo> -s <Solver> -y <HR> -j <Cells> -o <Order> -k <K> -n <NN> -f <Phi> -u <U> -e <Re> -d <Length>')
            sys.exit()
        if opt in ("-p", "--PATH"):
            PATH = arg
        if opt in ("-l", "--logo"):
            logo = arg

        if opt in ("-j", "--Cells"):
            Cells = arg
        if opt in ("-o", "--Order"):
            Order = arg
        if opt in ("-s", "--Sol"):
            Solver = arg
        if opt in ("-y", "--HR"):
            HR = arg

        if opt in ("-k", "--K"):
            Kstr = arg
        if opt in ("-f", "--Phi"):
            phistr = arg
        if opt in ("-n", "--NN"):
            NNstr = arg

        if opt in ("-u", "--U"):
            Ustr = arg
        if opt in ("-e", "--Re"):
            Restr = arg
        if opt in ("-d", "--L"):
            Lstr = arg
        if opt in ("-t", "--Rst"):
            dRstr = arg
        if opt in ("-w", "--Lst"):
            Lststr = arg

    if (PATH == "" ) :
        print("Empty PATH -----> EXIT")
        sys.exit()
    if (Solver == "" ) :
        print("Empty Solver -----> EXIT")
        sys.exit()
    if (HR == '' ) :
        print("Empty HR -----> EXIT")
        sys.exit()
    if (Cells == '' ) :
        print("Empty Cells -----> EXIT")
        sys.exit()
    if (Order == '' ) :
        print("Empty Order -----> EXIT")
        sys.exit()
    if (Kstr == '' ) :
        print("Empty Kstr -----> EXIT")
        sys.exit()
    if (NNstr == '' ) :
        print("Empty NNstr -----> EXIT")
        sys.exit()
    if (phistr == '' ) :
        print("Empty phistr -----> EXIT")
        sys.exit()
    if (Ustr == '' ) :
        print("Empty Ustr -----> EXIT")
        sys.exit()
    if (Restr == '' ) :
        print("Empty Restr -----> EXIT")
        sys.exit()
    if (Lstr == '' ) :
        print("Empty Lstr -----> EXIT")
        sys.exit()
    if (dRstr == '' ) :
        print("Empty dRstr -----> EXIT")
        sys.exit()
    if (Lststr == '' ) :
        print("Empty Lststr -----> EXIT")
        sys.exit()

    print("---------------------")
    print("UNITS : cm, g, s")
    print("---------------------")
    print

    R0_c    = 1.
    L_c     = double(Lstr)
    K_c     = double(Kstr)
    rho_c   = 1.

    Re_c    = double(Restr)
    U_c     = double(Ustr)

    mu_c    = U_c * R0_c * rho_c / Re_c

    Lst_c   = double(Lststr)
    dR_c    = double(dRstr)

    te_c    =  Re_c * R0_c / U_c

    if (NNstr == "Newtonian") :
        phi_c   = float(phistr) ;
        mu0_c   = 0. ;
        muinf_c = mu_c ;
        kmu_c   = 0. ;
        amu_c   = 0. ;
    else :
        print("Fluid must be Newtonian")
        sys.exit()

    ###################################
    # NETWORK
    #############################
    N_art_tot = 1

    #############################
    # GEOMETRICAL PARAMETERS

    # Length of the vessels (cm)

    L =     array( [ L_c ] )

    # Radius of the artery (cm)
    R_ref = array( [ R0_c ] )
    D_ref = R_ref * 2.
    A_ref = pi * R_ref * R_ref

    NbrArt=len(L)

    # Check for number of arteries :
    if NbrArt != N_art_tot :
        print ( "Wrong number of arteries" )
        sys.exit()

    # Check length of array
    if len(L) != len(A_ref) :
        print ('Dimension error in geometric parameters A_ref or L')
        sys.exit()

    #####################
    # MECHANICAL PARAMETERS

    # Density (g/cm^3)
    rho = rho_c # rho of water

    # Stiffness coefficient beta (g/cm^2/s^2 ~ Pa/m = 0.1 g/(cm*s)^2)
    K = array( [ K_c ] )

    # Viscoelasticity coefficient C_v (cm^2/s)
    Cv = np.zeros(NbrArt)

    # Moens-Korteweg celerity (cm/s)
    c_ref = np.sqrt( 0.5 * K / rho * np.sqrt(A_ref) )

        # Check length of array
    if len(L) != len(K) or len(L) != len(c_ref):# or len(L) != len(C_v):
        print ('Dimension error in geometric parameters h, A_ref or L')
        sys.exit()

    ######################
    # RHEOLOGY

    # Profile coefficient phi
    phi     = np.ones(NbrArt) * phi_c # Friction paramenter, depending on the Wormelsey number and the non-linear coeffcient alpha

    # Newtonian viscosities
    mu0     = np.ones(NbrArt) * mu0_c
    muinf   = np.ones(NbrArt) * muinf_c

    # Aggregation coefficient
    kmu     = np.ones(NbrArt) * kmu_c
    # Desaggregation coefficient
    amu     = np.ones(NbrArt) * amu_c

    ######################
    # NUMBER OF MESH POINTS

    N       =  array( [ float(Cells) ] )
    dx      = L / N
    dx_min  = min(dx)

    ###################
    # SHAPES (Well-balance)
    def mesh(L,N) :
        dx = float(L/N)
        shape = dx * ones(int(N))
        return shape ;

    def space(dx) :
        N = len(dx) ;
        shape = zeros(N) ;
        shape[0] = dx[0]/2.
        for i in range(1,N) :
            shape[i] = shape[i-1] + (dx[i-1]+dx[i])/2.
        return shape

    def shape_h(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_R(x) :
        N = len(x)
        shape = ones(N)
        #Position the stenosis in the middle of the artery
        LS = 1./5. * L_c ; LE = LS + Lst_c
        for i in range (N) :
            if (x[i] >= LS and x[i] <= LE ) :
                shape[i] = shape[i] + dR_c * 0.5 *( 1. + cos( pi + 2. * pi * float( x[i]-LS )/float(LE-LS) ) )
        return shape ;

    def shape_K(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_Cv(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    ###################
    # RHEOLOGY

    def shape_phi(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_mu0(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_muinf(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_kmu(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_amu(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_f(x) :
        N = len(x)
        shape = np.ones (N)
        return shape ;

    def shape_Hrbc(x) :
        N = len(x)
        shape = np.ones(N)
        return shape ;

    ###################
    # ARTERY

    arts = [artery(i) for i in range(NbrArt)]

    # Define the properties of each artery

    for i in range(NbrArt):

        arts[i].solver      =str(Solver)
        arts[i].solverOrder =int(Order)
        arts[i].HR          =str(HR)
        arts[i].N           =int(N[i])

        arts[i].rho         = rho

        arts[i].L           = L[i]

        #Create the mesh
        arts[i].dx          = mesh(arts[i].L,arts[i].N)
        arts[i].x           = space(arts[i].dx)
        #Geometrical and mechanical parameters
        arts[i].R           = R_ref[i]  * shape_R(arts[i].x)
        arts[i].K           = K[i]      * shape_K(arts[i].x)
        arts[i].Cv          = Cv[i]     * shape_Cv(arts[i].x)
        #Rheology
        arts[i].phi         = phi[i]    * shape_phi(arts[i].x)
        arts[i].mu0         = mu0[i]    * shape_mu0(arts[i].x)
        arts[i].muinf       = muinf[i]  * shape_muinf(arts[i].x)
        arts[i].kmu         = kmu[i]    * shape_kmu(arts[i].x)
        arts[i].amu         = amu[i]    * shape_amu(arts[i].x)

        #Initial condition
        arts[i].initA       = np.pi * arts[i].R * arts[i].R
        arts[i].initQ       = U_c * arts[i].initA

        #Initial aggregation condition
        if (NNstr == "Newtonian" or NNstr == "Inviscid") :
            arts[i].initf       = np.zeros(arts[i].N)
            arts[i].initHrbc    = np.zeros(arts[i].N)
        else :
            arts[i].initf       = np.zeros(arts[i].N)
            arts[i].initHrbc    = np.zeros(arts[i].N)

        #Boundary properties
        fact = 1.
        arts[i].Ain         = np.pi * arts[i].R[0] * arts[i].R[0]
        arts[i].Aout        = np.pi * arts[i].R[arts[i].N-1] * arts[i].R[arts[i].N-1]
        arts[i].Kin         = arts[i].K[0]
        arts[i].Kout        = arts[i].K[arts[i].N-1]
        arts[i].dxin        = fact * arts[i].dx[0]
        arts[i].dxout       = fact * arts[i].dx[arts[i].N-1]

        #Output points
        arts[i].outPut=[0]	# Mesh points for which data will be stored
        num_measpt = int(arts[i].N)
        L_measpt=[float(n)*L[i]/float(num_measpt-1) for n in range(1,num_measpt-1)] # (m)
        for k in range(len(L_measpt)) :
            arts[i].outPut.append(int(L_measpt[k]/dx[i]))

        arts[i].outPut.append( arts[i].N-1 )

    #####################
    # Time setup

    t_start = 0.45  * te_c # (s)
    t_end   = 0.5   * te_c # (s)

    # CFL
    Ct      = 1.
    dt_CFL  = Ct * min(dx/(U_c+c_ref))

    # Time step
    power   = float(floor(mt.log10(dt_CFL)))
    fact    = floor(dt_CFL / (10. ** power))
    dt      = min(float(fact) * 10. ** (power),1.e-6)
    # Store step
    dt_store    = 1.e-3 * te_c
    storeStep   = max(1,int(dt_store / dt))

    print ("---->Time step dt = ", dt)
    print ("---->CFL Time step dt_CFL = ",dt_CFL)

    timeSteps = int(t_end/dt)
    tt = ones(timeSteps)
    for it in range(timeSteps) :
        tt[it] = float(it) * dt

    tS              = timeSetup()
    tS.tt           = tt
    tS.dt           = dt
    tS.t_start      = t_start
    tS.t_end        = t_end
    tS.Nt           = timeSteps
    tS.storeStep    = storeStep
    tS.CFL          = Ct
    tS.timeOrder    = 1

    ###################
    # Boundary condition

    #Inlet
    U_Input     = U_c * np.ones(timeSteps)
    H_Input     = np.zeros(timeSteps)
    f_Input     = np.zeros(timeSteps)
    #Oulet
    Rt_Output   = np.zeros(timeSteps);

    ###################
    # daugher arteries, headPt and tailPt  :
    arts[0].daughterArts = [] ;

    arts[0].headPt.append(point(0))  ;
    arts[0].headPt[0].type  = "inU"             ; arts[0].headPt[0].data    = U_Input ;
    arts[0].headPt[0].typeH = "inHrbc"          ; arts[0].headPt[0].dataH   = H_Input ;
    arts[0].headPt[0].typef = "infrbc"          ; arts[0].headPt[0].dataf   = f_Input ;
    arts[0].tailPt.append(point(1))  ;
    arts[0].tailPt[0].type  = "outRt"           ; arts[0].tailPt[0].data    = Rt_Output;

    ####################
    # Network definition :
    net=network(ARTS=arts,tS=tS)

    #####################
    # CREATE NECESSARY FILES
    if not os.path.exists(str(PATH)+"parameters_"+str(logo)) :
        os.makedirs(str(PATH)+"/parameters_"+str(logo))
    if not os.path.exists(str(PATH)+"parameters_"+str(logo)+"/Parameters") :
        os.makedirs(str(PATH)+"/parameters_"+str(logo)+"/Parameters")
    if not os.path.exists(str(PATH)+"/data"):
        os.makedirs(str(PATH)+"/data")
    if not os.path.exists(str(PATH)+"/Figures"):
        os.makedirs(str(PATH)+"/Figures")
    if not os.path.exists(str(PATH)+"/Movies"):
        os.makedirs(str(PATH)+"/Movies")

    #####################
    # WRITE PARAMETERS
    net.writeParam(str(PATH)+"parameters_"+str(logo))

if __name__ == "__main__":
   main(sys.argv[1:])
