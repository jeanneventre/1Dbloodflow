#!/bin/bash

# export OMP_NUM_THREADS=27
# echo "OMP_NUM_THREADS=" $OMP_NUM_THREADS

export folderGeneral=/Documents/UPMC/These/Codes/bloodflowSingle/example/Well-Balance/Asymptotic/Womersley

for wom in 5 20 ; do
  export folderWom=${folderGeneral}/a=${wom}

  for K in 1.e4 ; do
    for dR in 1e-3; do

      for NN in "Newtonian" ; do
        for phi in -21 ; do
          for HR in HRQ; do
            for J in 1600 ; do
              for Order in 1 ; do
                for solver in KIN_HAT; do

                  export folderHR=${folderWom}/K=${K}/dR=${dR}/${NN}/phi=${phi}/J=${J}/${HR}/Order=${Order}/${solver}

                  # python2.7 writeParameter.py -p ${HOME}${folderHR}/ -l Sane -s ${solver} -y ${HR} -j ${J} -o ${Order} -n ${NN} -f ${phi} -k ${K} -d ${dR} -w ${wom}
                  # bloodflowSingle -i ${HOME}${folderHR}/parameters_Sane/ -o ${HOME}${folderHR}/data/ -s Sane -q
                  # python2.7 write.py -p ${HOME}${folderHR}/

                  # mkdir -p ${HOME}${folderHR}/Figures
                  # scp -r ${SSHACCOUNT}:${HOME_SSH}${folderHR}/Figures ${HOME}${folderHR}/

                  # mkdir -p ${HOME}${folderHR}/Movies
                  # scp -r ${SSHACCOUNT}:${HOME_SSH}${folderHR}/Movies ${HOME}${folderHR}/

                  mkdir -p ${HOME}${folderHR}/Figures
                  scp -r -P 2222 ghigo@localhost:${HOME_SSH}${folderHR}/Figures ${HOME}${folderHR}/

                  # mkdir -p ${HOME}${folderHR}/Movies
                  # scp -r -P 2222 ghigo@localhost:${HOME_SSH}${folderHR}/Movies ${HOME}${folderHR}/

                done
              done
            done
          done
        done
      done
    done
  done
done
