#!/bin/bash

# export OMP_NUM_THREADS=27
# echo "OMP_NUM_THREADS=" $OMP_NUM_THREADS

export folderGeneral=/Documents/UPMC/These/Codes/bloodflowSingle/example/Well-Balance/Network/1Artery/Reflection

for solver in "KIN_HAT"; do
  folderSolver=${folderGeneral}/${solver}

  for K in 1e4 ; do
    folderK=${folderSolver}/K=${K}
    for dR in 1e-3 ; do
      folderdR=${folderK}/dR=${dR}
      for NN in "Inviscid" ; do
        folderNN=${folderdR}/${NN}

        for HR in HRS; do
          for J in 400; do
            for Order in 2 ; do
              export folderHR=${folderNN}/${HR}/J=${J}/Order=${Order}

                # python2.7 writeParameter.py -p ${HOME}${folderHR}/ -l Sane -y ${HR} -s ${solver} -j ${J} -o ${Order} -k ${K} -r ${dR} -n ${NN}
                # bloodflowSingle -i ${HOME}${folderHR}/parameters_Sane/ -o ${HOME}${folderHR}/data/ -s Sane -q
                # python2.7 write.py -p ${HOME}${folderHR}/

                # mkdir -p ${HOME}${folderHR}/Figures
                # scp -r ${SSHACCOUNT}:${HOME_SSH}${folderHR}/Figures ${HOME}${folderHR}/

                mkdir -p ${HOME}${folderHR}/Figures
                scp -r -P 2222 ghigo@localhost:${HOME_SSH}${folderHR}/Figures ${HOME}${folderHR}/

            done
          done
        done
      done
    done
  done
done
