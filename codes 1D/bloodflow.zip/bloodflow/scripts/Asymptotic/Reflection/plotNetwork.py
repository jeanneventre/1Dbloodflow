#!/usr/bin/python3
import sys, getopt
from csv_libPlot import *
from csv_libData import *

import numpy as np

def cmk(RHO,K,A) :
    return np.sqrt( 0.5 * K / RHO * np.sqrt(A) )

def Impendance(RHO,K,A) :
    return A / RHO / cmk(RHO,K,A)

def Reflection_2Arteries(RHO,AP,AD,KP,KD) :

    YP = Impendance(RHO,KP,AP) ;
    YD = Impendance(RHO,KD,AD) ;
    Rt = (YP-YD)/(YP+YD) ;
    Tt = 1. + Rt ;

    return Rt , Tt

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D = HOME + "/Documents/UPMC/These/Codes/bloodflowSingle/example/Well-Balance/Network/2Arteries/Reflection/"

    nfig = 1

    HRstr   = "HRQ"
    Orderstr= "2"
    Kstr    = "1e4"
    dRstr   = "1e-1"
    NNstr   = "Inviscid"

    PATH    = PATH1D + "KIN_HAT" + "/K=" + Kstr + "/dR=" + dRstr + "/" + NNstr + "/" + HRstr
    Store   = PATH + "/Figures/"

    for pType in ["Q","P","RmR0"] :

        # FILE :
        ###########
        dName0 = "Artery_0_x_"
        dName1 = "Artery_1_x_"

        JName1  = "Junction_1_"

        if (pType == "Q") :
            pName = "Q.csv"
            pLabel = r"$Q$ $\left[\frac{cm^3}{s}\right]$"
        if (pType == "P") :
            pName = "P.csv"
            pLabel = r"$p$ $\left[\frac{g}{cm.s^{2}}\right]$"
        if (pType == "RmR0") :
            pName = "RmR0.csv"
            pLabel = r"$R-R_0$ $\left[cm\right]$"

        J1 = "400"
        Data0_1     = PATH + "/J=" + str(J1) + "/Order=" + str(Orderstr) + "/Figures/" + dName0 + pName
        Data1_1     = PATH + "/J=" + str(J1) + "/Order=" + str(Orderstr) + "/Figures/" + dName1 + pName
        JData1_1    = PATH + "/J=" + str(J1) + "/Order=" + str(Orderstr) + "/Figures/" + JName1 + pName

        iX = 0;

        ######################################
        ######################################

        lCol        = [ "blue","green","red",
                        "blue","green","red",
                        "blue","green","red"]

        lMark       = [ "","s","",
                        "","^","",
                        "","D",""]
        lMarkSize   = [ 5,5,5,
                        5,5,5,
                        5,5,5]
        lMarkWidth  = [ 2,2,2,
                        2,2,2,
                        2,2,2]
        MarkPoints  = 40

        lLineSize   = [ 2,2,2,
                        2,2,2,
                        2,2,2]
        lStyle      = [ "-","","-",
                        "--","","--",
                        "-.","","-."]
        lAlpha      = [ 1,1,1,
                        1,1,1,
                        1,1,1]

        LegLoc      = 1
        LegPos      = [0.98, 1.1]
        LegCol      = 3

        liX         = [ iX,iX,iX,
                        iX,iX,iX,
                        iX,iX,iX]

        lFile       = [ Data0_1,JData1_1,Data1_1]

        t1 = 0.05

        lLabel      = [ r"$Artery$ $0$", r"$Junction$", r"$Artery$ $1$" ]

        xRange = []
        yRange = []

        # Reflection coefficient
        RHO = 1 ;
        RP = 1. ; RD = RP/2.
        AP = np.pi*RP*RP ; AD = np.pi*RD*RD ;
        KP = float(Kstr) ; KD = KP ;

        Y1 = Impendance(RHO=RHO,K=KP,A=AP)
        Y2 = Impendance(RHO=RHO,K=KD,A=AD)
        Rt, Tt = Reflection_2Arteries(RHO=1,AP=AP,AD=AD,KP=KP,KD=KD)

        if (pType == "Q") :
            Qmax = 0.59
            lHline = [Qmax,-Rt*Qmax,Y2/Y1*Tt*Qmax]
        if (pType == "P") :
            Pmax = float(Kstr) * np.sqrt(np.pi) * float(dRstr)
            lHline = [Pmax,Rt*Pmax,Tt*Pmax]
        if (pType == "RmR0") :
            RmR0max = float(dRstr)
            lHline = [RmR0max,Rt*RmR0max,Tt*RmR0max]
        lHlineColor = [ "black","blue","red"]
        lHlineWidth = [ 1,1,1]
        lHlineStyle = [ "--","--","--"]

        lVline      = []
        lVlineColor = []
        lVlineWidth = []
        lVlineStyle = []

        iY = 5
        liY         = [ iY, iY, iY ]

        lXScale     = [ 1.,1.,1.,
                        1.,1.,1.,
                        1.,1.,1.]
        lYScale     = [ 1.,1.,1.,
                        1.,1.,1.,
                        1.,1.,1.]
        lXOffset    = [ 0.,-10.05,-10.1,
                        0.,-10.05,-10.1,
                        0.,-10.05,-10.1]
        lYOffset    = [ 0.,0.,0.,
                        0.,0.,0.,
                        0.,0.,0.]

        xLabel=r"$x$ $\left[cm\right]$"
        yLabel=pLabel

        lText       = [ r"$N_x=\left\{\right.$" + str(J1) + r"$\left. \right\}$", r"$Order$ " + str(Orderstr)]
        lTextAlign  = [ "left", "center"]
        lTextPos    = [ [0.05,0.04], [0.75,0.05] ]
        lTextColor  = [ "black", "black" ]

        title = pType + "_Network_x.pdf"

        nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,
                            liX=liX,liY=liY,
                            xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                            xRange=xRange,yRange=yRange,
                            lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                            lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                            lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                            LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                            lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                            lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                            lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
