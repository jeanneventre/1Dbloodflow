#!/usr/bin/python3
import  sys, getopt

import  help_Output as out

from    csv_libWrite_Err import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Thacker/Inviscid/"
    PATHANA = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Thacker/Inviscid/Analytic/"

    nfig = 1

    dtstr       = "1e-5"
    tOrderstr   = "2"

    Kstr        = "1e4"
    NNstr       = "Inviscid"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    PATH    = PATH1D    + "K=" + Kstr + "/" + NNstr
    Store   = PATH1D + "Figures/"

    for pType in ["A","U","Q"] :

        pName,pLabel = out.getType(pType)

        # FILE :
        ###########
        ArtName0    = "Artery_0_x_"
        PATHEND     = "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        J1 = "50"
        Art0_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + PATHEND
        Art0_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + PATHEND

        J2 = "100"
        Art0_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + PATHEND
        Art0_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + PATHEND

        J3 = "200"
        Art0_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + PATHEND
        Art0_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + PATHEND

        J4 = "400"
        Art0_41  = PATH + "/Nx=" + J4 + "/xOrder=" + "1" + PATHEND
        Art0_42  = PATH + "/Nx=" + J4 + "/xOrder=" + "2" + PATHEND

        J5 = "800"
        Art0_51  = PATH + "/Nx=" + J5 + "/xOrder=" + "1" + PATHEND
        Art0_52  = PATH + "/Nx=" + J5 + "/xOrder=" + "2" + PATHEND

        J6 = "1600"
        Art0_61  = PATH + "/Nx=" + J6 + "/xOrder=" + "1" + PATHEND
        Art0_62  = PATH + "/Nx=" + J6 + "/xOrder=" + "2" + PATHEND

        J7 = "3200"
        Art0_71  = PATH + "/Nx=" + J7 + "/xOrder=" + "1" + PATHEND
        Art0_72  = PATH + "/Nx=" + J7 + "/xOrder=" + "2" + PATHEND

        J8 = "1600"
        Art0_81  = PATH + "/Nx=" + J8 + "/xOrder=" + "1" + PATHEND
        Art0_82  = PATH + "/Nx=" + J8 + "/xOrder=" + "2" + PATHEND

        # ANALYTIC
        ###########
        ANA = PATHANA +  pType + ".csv"

        # ERROR
        #######
        for Ltype in ["L1","L2","Linf"] :

            xrType  = "x"

            llFact      = [ [1.], [1.], [1.], [1.], [1.], [1.], [1.], [1.]  ]
            lFactOrder  = [ 1., 1., 1., 1., 1., 1. , 1., 1. ]

            llX         = [ [[0,0]], [[0,0]], [[0,0]], [[0,0]], [[0,0]], [[0,0]], [[0,0]], [[0,0]] ]
            llFileSep   = [ [",",","], [",",","], [",",","], [",",","], [",",","], [",",","], [",",","], [",",","] ]
            llFile_O1   = [ [ANA,Art0_11], [ANA,Art0_21], [ANA,Art0_31], [ANA,Art0_41] ]#, [ANA,Art0_51], [ANA,Art0_61], [ANA,Art0_71], [ANA,Art0_81] ]
            llFile_O2   = [ [ANA,Art0_12], [ANA,Art0_22], [ANA,Art0_32], [ANA,Art0_42] ]#, [ANA,Art0_52], [ANA,Art0_62], [ANA,Art0_72], [ANA,Art0_82] ]


            # t=0.3 (Only time for which BC don't play on important role)
            #######
            iY  = 5 # 4
            llY = [ [[iY,iY]], [[iY,iY]], [[iY,iY]], [[iY,iY]], [[iY,iY]], [[iY,iY]], [[iY,iY]], [[iY,iY]] ]

            title = "Err-" + Ltype + "-" + pType + "-O1.csv"
            write_csv_Err_Cv(   pathStore=Store,title=title,
                                llFile=llFile_O1,llFileSep=llFileSep,
                                llX=llX,llY=llY,
                                llFact=llFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)
            title = "Err-" + Ltype + "-" + pType + "-O2.csv"
            write_csv_Err_Cv(   pathStore=Store,title=title,
                                llFile=llFile_O2,llFileSep=llFileSep,
                                llX=llX,llY=llY,
                                llFact=llFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)


if __name__ == "__main__":
    main(sys.argv[1:])
