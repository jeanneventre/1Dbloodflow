#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Thacker/Inviscid/"

    nfig = 1

    nfig = 1

    Store   = PATH1D + "Figures/"

    for pType in ["P","U","Q"] :

        pName,pLabel = out.getType(pType)

        # FILE :
        ###########
        Data11 = PATH1D + "Figures/" + "Err-" + "L1" + "-" + pType + "-O1.csv"
        Data12 = PATH1D + "Figures/" + "Err-" + "L1" + "-" + pType + "-O2.csv"

        Data21 = PATH1D + "Figures/" + "Err-" + "L2" + "-" + pType + "-O1.csv"
        Data22 = PATH1D + "Figures/" + "Err-" + "L2" + "-" + pType + "-O2.csv"

        Data31 = PATH1D + "Figures/" + "Err-" + "Linf" + "-" + pType + "-O1.csv"
        Data32 = PATH1D + "Figures/" + "Err-" + "Linf" + "-" + pType + "-O2.csv"

        ######################################
        ######################################
        lCol        = [ "black","black","black","black",
                        "blue","blue","blue","blue",
                        "red","red","red","red",
                        "seagreen","seagreen","seagreen","seagreen"]
        lMark       = [ "o","","s","",
                        "^","","v","",
                        "+","","x","",
                        "D","","h",""
                      ]
        lMarkSize   = [ 10,10,10,10,
                        10,10,10,10,
                        10,10,10,10,
                        10,10,10,10
                      ]
        lMarkWidth  = [ 1,1,1,1,
                        1,1,1,1,
                        1,1,1,1,
                        1,1,1,1]
        MarkPoints  = 30

        lLineSize   = [ 3,1,3,1,
                        3,1,3,1,
                        3,1,3,1,
                        3,1,3,1,]
        lStyle      = [ "-","","--","",
                        "-","","--","",
                        "-","","--","",
                        "-","","--",""]
        lAlpha      = [ 1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.]

        LegLoc      = 4
        LegPos      = [1.,0.]
        LegCol      = 3
        LegSize     = 23

        xRange      = []
        yRange      = []

        xBins       = 2 ;
        yBins       = 2 ;

        lHline      = []
        lHlineColor = []
        lHlineWidth = []
        lHlineStyle = []

        lVline      = []
        lVlineColor = []
        lVlineWidth = []
        lVlineStyle = []

        lXScale     = [ 1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.]
        lYScale     = [ 1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.]
        pScale      = "log"

        lXOffset    = [ 0.,0.,0.,0.,
                        0.,0.,0.,0.,
                        0.,0.,0.,0.,
                        0.,0.,0.,0.]
        lYOffset    = [ 0.,0.,0.,0.,
                        0.,0.,0.,0.,
                        0.,0.,0.,0.,
                        0.,0.,0.,0.]

        lText       = [ r"$t$=$0.8 T$", r"$\Delta \mathcal{G}$=$10^{-1}$", "Inviscid Thacker" ]
        lTextAlign  = [ "left", "right", "left" ]
        lTextPos    = [ [0.53,0.935],[0.98,0.935],[0.02,0.935] ]
        lTextColor  = [ "black", "black","black" ]


        xLabel      = r"$N_x$"
        yLabel      = r"$L_{1,\, 2 ,\, \infty}\left[\right.$" + pType + r"$\left.\right]$"
        lLabel      = [ r"$L_1$, order 1","",r"$L_1$, MUSCL","",
                        r"$L_2$, order 1","",r"$L_2$, MUSCL","",
                        r"$L_\infty$, order 1","",r"$L_\infty$, MUSCL",""
                      ]

        lFileSep    = [ ",",",",",",",",
                        ",",",",",",",",
                        ",",",",",",",",
                        ",",",",",",","]
        liX         = [ 0,0,0,0,
                        0,0,0,0,
                        0,0,0,0,
                        0,0,0,0]
        liY         = [ 1,2,1,2,
                        1,2,1,2,
                        1,2,1,2,
                        1,2,1,2]

        lFile       = [ Data11,Data11,Data12,Data12,
                        Data21,Data21,Data22,Data22,
                        Data31,Data31,Data32,Data32
                      ]

        title = "Err-" + pType + ".pdf"
        nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                            liX=liX,liY=liY,
                            xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                            xRange=xRange,yRange=yRange,
                            xBins=xBins,yBins=yBins,
                            lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                            lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                            lXScale=lXScale,lYScale=lYScale,pScale=pScale,lXOffset=lXOffset,lYOffset=lYOffset,
                            LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                            lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                            lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                            lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
