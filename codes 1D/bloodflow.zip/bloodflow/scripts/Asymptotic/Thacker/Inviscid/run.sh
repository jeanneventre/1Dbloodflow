#!/bin/bash

# export OMP_NUM_THREADS=27
# echo "OMP_NUM_THREADS=" $OMP_NUM_THREADS

export folderGeneral=/Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Thacker/Inviscid

for K in 1e4 ; do
  for NN in "Inviscid" ; do

    for Nx in 50 100 200 400 ; do
      for xOrder in 1 2 ; do
        for dt in 1e-5 ; do
          for tOrder in 2 ; do
            for solver in "KIN_HAT"; do
              for HR in HRQ; do

                export folderHR=${folderGeneral}/K=${K}/${NN}/Nx=${Nx}/xOrder=${xOrder}/dt=${dt}/tOrder=${tOrder}/${solver}/${HR}

                # python2.7 writeParameter.py -a ${HOME}${folderHR}/ -b Sane -d ${solver} -e ${HR} -f ${Nx} -g ${xOrder} -i ${dt} -j ${tOrder} -k ${K} -l ${NN}
                # bloodflow -i ${HOME}${folderHR}/parameters_Sane/ -o ${HOME}${folderHR}/data/ -s Sane -q
                # python2.7 write.py -p ${HOME}${folderHR}/

                # mkdir -p ${HOME}${folderHR}/Figures
                # scp -r ${SSHACCOUNT}:${HOME_SSH}${folderHR}/Figures ${HOME}${folderHR}/

                mkdir -p ${HOME}${folderHR}/Figures
                scp -r -P 2222 ghigo@localhost:${HOME_SSH}${folderHR}/Figures ${HOME}${folderHR}/

              done
            done
          done
        done
      done
    done
  done
done
