#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

from    csv_libPlot import *
from    help_Wave   import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Effects/TapperTriangle/"
    PATHANA = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Effects/TapperTriangle/Analytic/"

    nfig = 1

    # Nxstr       = "400"
    # xOrderstr   = "2"

    dtstr       = "1e-4"
    tOrderstr   = "3"

    Kstr        = "1e4"
    NNstr       = "Inviscid"
    # phistr      = "0"
    # Cvstr       = "0"
    # Knlstr      = "0"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"
    # Conjstr     = "conjA"

    Shstr       = "1e-3"

    PATH    = PATH1D    + "K=" + Kstr + "/" + NNstr + "/Sh=" + Shstr
    # PATH    = PATH      + "/phi=" + str(phistr) + "/Cv=" + str(Cvstr) + "/Knl=" + Knlstr
    # PATH    = PATH      + "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr

    Store   = PATH1D + "Figures/"

    for pType in ["Q"] :

        # FILE :
        ###########
        ArtName0    = "Artery_0_x_"

        if (pType == "Q") :
            pName = "Q.csv"
            pLabel = r"$Q$ $\left[\frac{cm^3}{s}\right]$"
        if (pType == "U") :
            pName = "U.csv"
            pLabel = r"$U$ $\left[\frac{cm}{s}\right]$"
        if (pType == "P") :
            pName = "P.csv"
            pLabel = r"$p$ $\left[\frac{g}{cm.s^{2}}\right]$"
        if (pType == "A") :
            pName = "A.csv"
            pLabel = r"$A$ $\left[cm^{2}\right]$"
        if (pType == "RmR0") :
            pName = "RmR0.csv"
            pLabel = r"$R-R_0$ $\left[cm\right]$"
        if (pType == "E") :
            pName = "E.csv"
            pLabel = r"$E$ $\left[\frac{g}{cm.s^{2}}\right]$"
        if (pType == "Sh") :
            pName = "Sh.csv"
            pLabel = r"$Sh$"

        if (pType == "G") :
            pName = "G.csv"
            pLabel = r"$\dot{\gamma}$ $\left[s^{-1}\right]$"
        if (pType == "f") :
            pName = "f.csv"
            pLabel = r"$f$"
        if (pType == "taust") :
            pName = "taust.csv"
            pLabel = r"$\tau_{st}$ $\left[\frac{g}{cm.s^{2}}\right]$"
        if (pType == "tau") :
            pName = "tau.csv"
            pLabel = r"$\tau$ $\left[\frac{g}{cm.s^{2}}\right]$"
        if (pType == "Hrbc") :
            pName = "Hrbc.csv"
            pLabel = r"$Hrbc$ $\left[cm^{-3}\right]$"
        if (pType == "Nrbc") :
            pName = "Nrbc.csv"
            pLabel = r"$Nrbc$"
        if (pType == "f") :
            pName = "f.csv"
            pLabel = r"$f$"
        if (pType == "Cpt") :
            pName = "Cpt.csv"
            pLabel = r"$Cpt$ $\left[cm^{-3}\right]$"
        if (pType == "NCpt") :
            pName = "NCpt.csv"
            pLabel = r"$NCpt$"
        if (pType == "Opt") :
            pName = "Opt.csv"
            pLabel = r"$Opt$ $\left[cm^{-3}\right]$"
        if (pType == "NOpt") :
            pName = "NOpt.csv"
            pLabel = r"$NOpt$"

        J1 = "800"
        Art0_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName
        Art0_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        J2 = "1600"
        Art0_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName
        Art0_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        J3 = "3200"
        Art0_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName
        Art0_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        # ANALYTIC
        ###########
        ANA_SHORT   = PATHANA + "Sh=" + Shstr + "/Q-Short-Times.csv"
        ANA_LONG    = PATHANA + "Sh=" + Shstr + "/Q-Long-Times.csv"

        ######################################
        ######################################
        lCol = [    "black","black","black","black","black",
                    "black","black","black","black","black",
                    "blue","blue","blue","blue","blue",
                    "green","green","green","green","green",
                    "red","red","red","red","red"]
        lMark = [   "","","","","",
                    "","","","","",
                    "","","","","",
                    "","","","","",
                    "","","","",""]
        lMarkSize = [   1,1,1,1,1,
                        1,1,1,1,1,
                        5,5,5,5,5,
                        5,5,5,5,5,
                        5,5,5,5,5]
        lMarkWidth = [  1,1,1,1,1,
                        1,1,1,1,1,
                        2,2,2,2,2,
                        2,2,2,2,2,
                        2,2,2,2,2]
        MarkPoints = 20

        lLineSize = [   2,2,2,2,2,
                        2,2,2,2,2,
                        2,2,2,2,2,
                        2,2,2,2,2,
                        2,2,2,2,2]
        lStyle = [      "-","-","-","-","-",
                        "--","--","--","--","--",
                        "-","-","-","-","-",
                        "-","-","-","-","-",
                        "-","-","-","-","-"]
        lAlpha = [  1,1,1,1,1,
                    1,1,1,1,1,
                    0.7,0.7,0.7,0.7,0.7,
                    0.7,0.7,0.7,0.7,0.7,
                    0.7,0.7,0.7,0.7,0.7]

        LegLoc      = 1
        LegPos      = [1.,1.]
        LegCol      = 4

        xRange      = []
        yRange      = []

        lHline      = []
        lHlineColor = []
        lHlineWidth = []
        lHlineStyle = []

        lVline      = []
        lVlineColor = []
        lVlineWidth = []
        lVlineStyle = []

        lXScale     = [ 1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.]
        lYScale     = [ 1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.]

        lXOffset    = [ 0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.]
        lYOffset    = [ 0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.]

        lText       = [ r"$t$=$0.1$, $t$=$0.2$, $t$=$0.3$, $t$=$0.4$, $t$=$0.5$"]
        lTextAlign  = [ "center" ]
        lTextPos    = [ [0.5,0.04] ]
        lTextColor  = [ "black" ]

        xLabel=r"$x$ $\left[cm\right]$"
        yLabel = pLabel
        lLabel = [  r"$Short$","","","","",
                    r"$Long$","","","","",
                    J1,"","","","",
                    J2,"","","","",
                    J3,"","","",""]

        lFileSep    = [ ",",",",",",",",",",
                        ",",",",",",",",",",
                        ",",",",",",",",",",
                        ",",",",",",",",",",
                        ",",",",",",",",","]
        liX         = [ 0,0,0,0,0,
                        0,0,0,0,0,
                        0,0,0,0,0,
                        0,0,0,0,0,
                        0,0,0,0,0]
        liY         = [ 1,2,3,4,5,
                        1,2,3,4,5,
                        1,2,3,4,5,
                        1,2,3,4,5,
                        1,2,3,4,5]

        lFile_O1 = [    ANA_SHORT,ANA_SHORT,ANA_SHORT,ANA_SHORT,ANA_SHORT,
                        ANA_LONG,ANA_LONG,ANA_LONG,ANA_LONG,ANA_LONG,
                        Art0_11,Art0_11,Art0_11,Art0_11,Art0_11,
                        Art0_21,Art0_21,Art0_21,Art0_21,Art0_21,
                        Art0_31,Art0_31,Art0_31,Art0_31,Art0_31
                        ]

        lFile_O2 = [    ANA_SHORT,ANA_SHORT,ANA_SHORT,ANA_SHORT,ANA_SHORT,
                        ANA_LONG,ANA_LONG,ANA_LONG,ANA_LONG,ANA_LONG,
                        Art0_12,Art0_12,Art0_12,Art0_12,Art0_12,
                        Art0_22,Art0_22,Art0_22,Art0_22,Art0_22,
                        Art0_32,Art0_32,Art0_32,Art0_32,Art0_32]

        title = pType + "_O1_x.pdf"

        nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile_O1,lFileSep=lFileSep,
                            liX=liX,liY=liY,
                            xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                            xRange=xRange,yRange=yRange,
                            lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                            lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                            lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                            LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                            lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                            lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                            lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

        title = pType + "_O2_x.pdf"

        nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile_O2,lFileSep=lFileSep,
                            liX=liX,liY=liY,
                            xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                            xRange=xRange,yRange=yRange,
                            lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                            lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                            lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                            LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                            lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                            lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                            lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
