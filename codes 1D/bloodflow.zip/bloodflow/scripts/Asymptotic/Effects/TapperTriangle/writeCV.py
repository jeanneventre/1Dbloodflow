#!/usr/bin/python3
import sys, getopt
from csv_libWrite_Err import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Effects/Wave/"
    PATHANA = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Effects/Wave/Analytic/"

    nfig = 1

    # Nxstr       = "400"
    # xOrderstr   = "2"

    dtstr       = "1e-4"
    tOrderstr   = "3"

    Kstr        = "1e4"
    NNstr       = "Inviscid"
    # phistr      = "0"
    # Cvstr       = "0"
    # Knlstr      = "0"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"
    # Conjstr     = "conjA"

    Shstr       = "1e-3"

    PATH    = PATH1D    + "K=" + Kstr + "/" + NNstr + "/Sh=" + Shstr
    # PATH    = PATH      + "/phi=" + str(phistr) + "/Cv=" + str(Cvstr) + "/Knl=" + Knlstr
    # PATH    = PATH      + "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr

    Store   = PATH1D + "Figures/"

    for pType in ["P"] :

        # FILE :
        ###########
        ArtName0    = "Artery_0_x_"

        if (pType == "P") :
            pName = "P.csv"

        J1 = "50"
        Art0_11  = PATH + "/Nx=" + J1 + "/xOrder=" + "1" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName
        Art0_12  = PATH + "/Nx=" + J1 + "/xOrder=" + "2" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        J2 = "100"
        Art0_21  = PATH + "/Nx=" + J2 + "/xOrder=" + "1" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName
        Art0_22  = PATH + "/Nx=" + J2 + "/xOrder=" + "2" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        J3 = "200"
        Art0_31  = PATH + "/Nx=" + J3 + "/xOrder=" + "1" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName
        Art0_32  = PATH + "/Nx=" + J3 + "/xOrder=" + "2" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        J4 = "400"
        Art0_41  = PATH + "/Nx=" + J4 + "/xOrder=" + "1" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName
        Art0_42  = PATH + "/Nx=" + J4 + "/xOrder=" + "2" + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/KIN_HAT" + "/" + HRstr + "/Figures/" + ArtName0 + pName

        # ANALYTIC
        ###########
        ANA = PATHANA + "Sh=" + Shstr + "/P.csv"

        xrType  = "x"
        Ltype   = "L1"

        lFact       = [ [1.], [1.], [1.], [1.], [1.] ]
        lFactOrder  = [ 1., 1., 1., 1., 1. ]

        llX         = [ [[0,0]], [[0,0]], [[0,0]], [[0,0]], [[0,0]] ]
        llFile_O1   = [ [ANA,Art0_11], [ANA,Art0_21], [ANA,Art0_31], [ANA,Art0_41] ]
        llFile_O2   = [ [ANA,Art0_12], [ANA,Art0_22], [ANA,Art0_32], [ANA,Art0_42] ]

        # t=0.1
        #######
        llY = [ [[1,1]], [[1,1]], [[1,1]], [[1,1]], [[1,1]] ]

        title = "Err_P_t0p1_O1.csv"
        write_csv_Err_Cv(   pathStore=Store,title=title,
                            llFile=llFile_O1,llX=llX,llY=llY,
                            lFact=lFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)
        title = "Err_P_t0p1_O2.csv"
        write_csv_Err_Cv(   pathStore=Store,title=title,
                            llFile=llFile_O2,llX=llX,llY=llY,
                            lFact=lFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)

        # t=0.2
        #######
        llY = [ [[2,2]], [[2,2]], [[2,2]], [[2,2]], [[2,2]] ]

        title = "Err_P_t0p2_O1.csv"
        write_csv_Err_Cv(   pathStore=Store,title=title,
                            llFile=llFile_O1,llX=llX,llY=llY,
                            lFact=lFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)
        title = "Err_P_t0p2_O2.csv"
        write_csv_Err_Cv(   pathStore=Store,title=title,
                            llFile=llFile_O2,llX=llX,llY=llY,
                            lFact=lFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)

        # t=0.3
        #######
        llY = [ [[3,3]], [[3,3]], [[3,3]], [[3,3]], [[3,3]] ]

        title = "Err_P_t0p3_O1.csv"
        write_csv_Err_Cv(   pathStore=Store,title=title,
                            llFile=llFile_O1,llX=llX,llY=llY,
                            lFact=lFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)
        title = "Err_P_t0p3_O2.csv"
        write_csv_Err_Cv(   pathStore=Store,title=title,
                            llFile=llFile_O2,llX=llX,llY=llY,
                            lFact=lFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)

        # t=0.4
        #######
        llY = [ [[4,4]], [[4,4]], [[4,4]], [[4,4]], [[4,4]] ]

        title = "Err_P_t0p4_O1.csv"
        write_csv_Err_Cv(   pathStore=Store,title=title,
                            llFile=llFile_O1,llX=llX,llY=llY,
                            lFact=lFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)
        title = "Err_P_t0p4_O2.csv"
        write_csv_Err_Cv(   pathStore=Store,title=title,
                            llFile=llFile_O2,llX=llX,llY=llY,
                            lFact=lFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)

        # t=0.5
        #######
        llY = [ [[5,5]], [[5,5]], [[5,5]], [[5,5]], [[5,5]] ]

        title = "Err_P_t0p5_O1.csv"
        write_csv_Err_Cv(   pathStore=Store,title=title,
                            llFile=llFile_O1,llX=llX,llY=llY,
                            lFact=lFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)
        title = "Err_P_t0p5_O2.csv"
        write_csv_Err_Cv(   pathStore=Store,title=title,
                            llFile=llFile_O2,llX=llX,llY=llY,
                            lFact=lFact,lFactOrder=lFactOrder,xrType=xrType,Ltype=Ltype)
                            
if __name__ == "__main__":
   main(sys.argv[1:])
