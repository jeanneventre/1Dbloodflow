#! /usr/bin/python2.7
import sys, getopt
import os
import numpy    as np
import math     as mt

from bfS_libDef import *

from help_Sum   import *
from help_Raff  import *
from help_Wave  import *

from help_NonDimensional import *

def main(argv) :

    PATH    = ""    ; LOGO      = "" ;
    SOLVER  = ""    ; HR        = "" ;

    CONJ    = ""    ;

    Nxstr   = ""    ; xOrderstr = "" ;
    dtstr   = ""    ; tOrderstr = "" ;

    Kstr    = ""    ;
    NNstr   = ""    ;
    phistr  = ""    ;
    Cvstr   = ""    ;
    Knlstr  = ""    ;

    Shstr   = ""    ;
    Restr   = ""    ;
    Womstr  = ""    ;

    # COMMAND LINE ARGUMENTS
    #############################
    try :

        opts, args = getopt.getopt(argv,"a:b:c:d:e:f:g:i:j:k:l:m:n:o:p:q:r:h",["Path=","Logo=","Conj=","Solver","HR","Nx=","xOrder=","dt=","tOrder=","K=","NN=","Phi=","Cv=","Knl=","Sh=","Re=","Wom="])

    except getopt.GetoptError:

          print ('writeParameter.py -a <path> -b <logo> -c <conj> -d <solver> -e <hr> -f <nx> -g <xorder> -i <dt> -j <torder> -k <k> -l <nn> -m <phi> -n <cv> -o <knl> -p <sh> -q <re> -r <wom>')
          sys.exit(2)

    for opt, arg in opts:

        if opt == '-h':
            print ('writeParameter.py -a <path> -b <logo> -c <conj> -d <solver> -e <hr> -f <nx> -g <xorder> -i <dt> -j <torder> -k <k> -l <nn> -m <phi> -n <cv> -o <knl> -p <sh> -q <re> -r <wom>')
            sys.exit()

        if opt in ("-a", "--path"):
            PATH = arg
        if opt in ("-b", "--logo"):
            LOGO = arg

        if opt in ("-c", "--conj"):
            CONJ = arg

        if opt in ("-d", "--solver"):
            SOLVER = arg
        if opt in ("-e", "--hr"):
            HR = arg

        if opt in ("-f", "--nx"):
            Nxstr = arg
        if opt in ("-g", "--xorder"):
            xOrderstr = arg

        if opt in ("-i", "--dt"):
            dtstr = arg
        if opt in ("-j", "--torder"):
            tOrderstr = arg

        if opt in ("-k", "--k"):
            Kstr = arg
        if opt in ("-l", "--nn"):
            NNstr = arg
        if opt in ("-m", "--phi"):
            phistr = arg
        if opt in ("-n", "--cv"):
            Cvstr = arg
        if opt in ("-o", "--knl"):
            Knlstr = arg

        if opt in ("-p", "--sh"):
            Shstr = arg
        if opt in ("-q", "--re"):
            Restr = arg
        if opt in ("-r", "--wom"):
            Womstr = arg

    if (PATH == "" ) :
        print("Empty PATH -----> EXIT")
        sys.exit()
    if (LOGO == "" ) :
        print("Empty LOGO -----> EXIT")
        sys.exit()

    # if (CONJ == "" ) :
    #     print("Empty CONJ -----> EXIT")
    #     sys.exit()

    if (SOLVER == "" ) :
        print("Empty SOLVER -----> EXIT")
        sys.exit()
    if (HR == "" ) :
        print("Empty HR -----> EXIT")
        sys.exit()

    if (Nxstr == "" ) :
        print("Empty Nx -----> EXIT")
        sys.exit()
    if (xOrderstr == "" ) :
        print("Empty xOrder -----> EXIT")
        sys.exit()

    if (dtstr == "" ) :
        print("Empty dt -----> EXIT")
        sys.exit()
    if (tOrderstr == "" ) :
        print("Empty tOrder -----> EXIT")
        sys.exit()

    if (Kstr == "" ) :
        print("Empty Kstr -----> EXIT")
        sys.exit()

    if (NNstr == "" ) :
        print("Empty NNstr -----> EXIT")
        sys.exit()

    # if (phistr == "" ) :
    #     print("Empty phistr -----> EXIT")
    #     sys.exit()
    #
    # if (Cvstr == "" ) :
    #     print("Empty Cvstr -----> EXIT")
    #     sys.exit()
    # if (Knlstr == "" ) :
    #     print("Empty Knlstr -----> EXIT")
    #     sys.exit()

    if (Shstr == "" ) :
        print("Empty Shstr -----> EXIT")
        sys.exit()
    # if (Restr == "" ) :
    #     print("Empty Restr -----> EXIT")
    #     sys.exit()
    # if (Womstr == "" ) :
    #     print("Empty Womstr -----> EXIT")
    #     sys.exit()

    print("---------------------")
    print("UNITS : cm, g, s")
    print("---------------------")
    print

    # Fluid properties
    ##################
    rho_c   = 1. ;

    if (NNstr == "Newtonian") :
        phi_c   = float(phistr) ;
        mu0_c   = 1.2 ;
        muinf_c = 4.e-2 ;
        kmu_c   = 0. ;
        amu_c   = 0. ;
    elif (NNstr == "NonNewtonian") :
        phi_c   = float(phistr) ;
        mu0_c   = 1.2 ;
        muinf_c = 4.e-2 ;
        kmu_c   = 2.5e-1 ;
        amu_c   = 1.2 ;
    elif (NNstr == "Inviscid") :
        phi_c   = 0. ;
        mu0_c   = 0. ;
        muinf_c = 0. ;
        kmu_c   = 0. ;
        amu_c   = 0. ;

    # Geometrical properties
    ########################
    L_c     = 200.   ;
    R0_c    = 1.    ;

    # Tapper
    #######################
    xms_c   = 4.5/10. * L_c ;
    xme_c   = 5.5/10. * L_c ;
    dR0_c   = - 0.   / (xme_c-xms_c) ;
    dK0_c   = + 0.1  / (xme_c-xms_c) ;

    # Mechanical properties
    #######################
    K_c     = float(Kstr)
    Cv_c    = 0.
    Knl_c   = 0.

    # Numerical properties
    ######################
    Nx_c        = float(Nxstr)
    xOrder_c    = int(xOrderstr)
    dt_c        = float(dtstr)
    tOrder_c    = int(tOrderstr)
    # Define the coarse mesh size
    dxCoarse    = float(L_c)/float(Nx_c)

    # Boundary properties
    #####################
    ts_c    = 0. ;
    te_c    = 1.2

    Sh_c    = float(Shstr)
    dR_c    = Sh_c * R0_c ;
    # P_c     = K_c * np.sqrt(np.pi) * dR_c
    # Q_c     =  ;
    Rt_c    = 0. ;

    # Rhelology
    ###########
    f_c     = 0. ;
    H_c     = 0. ;

    # Passive Transport
    ###################
    Cpt_c    = 0. ;
    Opt_c    = 0. ;

    ############################################################################
    ############################################################################
    # Network
    ############################################################################
    ############################################################################

    # Angle of bifurcation
    Angle = array( [ [0.*np.pi,np.pi] ] )

    #############################
    # Geometrical parameters
    #############################

    # Length of the vessels (cm)
    L = array( [ L_c ] )
    # Radius of the artery (cm)
    R = array( [ R0_c ] )
    D = R * 2.
    A = pi * R * R

    NArt = len(L)

    # Check length of array
    if NArt != len(A) :
        print ('Dimension error in geometric parameters A_ref or L')
        sys.exit()

    #############################
    # Mechanical parameters
    #############################

    # Density (g/cm^3)
    rho = rho_c
    # Stiffness coefficient beta (g/cm^2/s^2 ~ Pa/m = 0.1 g/(cm*s)^2)
    K   = array( [ K_c ] )
    # Viscoelasticity coefficient C_v (cm^2/s)
    Cv  = Cv_c  * np.ones(NArt)
    # Nonlinear stiffness coefficient beta (g/cm^3/s^2)
    Knl = Knl_c * np.ones(NArt)
    # Moens-Korteweg celerity (cm/s)
    c = celerity(rho,K,A)

    # Check length of array
    if NArt != len(K) or NArt != len(Cv) or NArt != len(Knl) or NArt != len(c) :
        print ('Dimension error in geometric parameters K, Cv, Knl, c or L')
        sys.exit()

    #############################
    # Rheology
    #############################

    # Profile coefficient phi
    phi     = phi_c     * np.ones(NArt)
    # Newtonian viscosities
    mu0     = mu0_c     * np.ones(NArt)
    muinf   = muinf_c   * np.ones(NArt)
    # Aggregation coefficient
    kmu     = kmu_c     * np.ones(NArt)
    # Desaggregation coefficient
    amu     = amu_c     * np.ones(NArt)

    #############################
    # Shapes (Well-balance)
    #############################

    def space(dx) :
        N = len(dx) ;
        shape = zeros(N) ;
        shape[0] = dx[0]/2.
        for i in range(1,N) :
            shape[i] = shape[i-1] + (dx[i-1]+dx[i])/2.
        return shape

    def shape_R(x) :
        N = len(x)
        shape = ones(N)
        for ix in range(N) :
            shape[ix] = TapperAsymptoticTriangle(dR0_c,xms_c,xme_c,x[ix])
        return shape ;

    def shape_K(x) :
        N = len(x)
        shape = ones(N)
        for ix in range(N) :
            shape[ix] = TapperAsymptoticTriangle(dK0_c,xms_c,xme_c,x[ix])
        return shape ;

    def shape_Cv(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_Knl(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_phi(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_mu0(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_muinf(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_kmu(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_amu(x) :
        N = len(x)
        shape = ones(N)
        return shape ;

    def shape_f(x) :
        N = len(x)
        shape = np.ones (N)
        return shape ;

    def shape_Hrbc(x) :
        N = len(x)
        shape = np.ones(N)
        return shape ;

    def shape_Cpt(x) :
        N = len(x)
        shape = np.ones (N)
        return shape ;

    def shape_Opt(x) :
        N = len(x)
        shape = np.ones(N)
        return shape ;

    #############################
    # Artery
    #############################

    arts = [artery(i) for i in range(NArt)]

    # Define the properties of each artery
    for i in range(NArt) :
        # Create the mesh
        arts[i].dx          = geometricRaffinement_Axial(  L=L_c,L1=0,L2=0,Lbuf=0,dxmax=dxCoarse, dxmin=dxCoarse )
        arts[i].x           = space(arts[i].dx)
        arts[i].N           = len(arts[i].dx)
        # Define numerical parameters
        arts[i].solver      = SOLVER
        arts[i].HR          = HR
        arts[i].solverOrder = int(xOrder_c)

        # Geometrical and mechanical parameters
        arts[i].rho         = rho
        arts[i].L           = L[i]
        arts[i].R           = R[i]      * shape_R(  arts[i].x)
        arts[i].K           = K[i]      * shape_K(  arts[i].x)
        arts[i].Cv          = Cv[i]     * shape_Cv( arts[i].x)
        arts[i].Knl         = Knl[i]    * shape_Knl(arts[i].x)

        # Verification of the length
        if( abs(arts[i].x[arts[i].N-1] + arts[i].dx[arts[i].N-1]/2. - arts[i].L) > 1.e-10) :
            print("Error in the geometrical parameters",arts[i].x[arts[i].N-1] + arts[i].dx[arts[i].N-1]/2., arts[i].L)
            sys.exit()

        # Rheology
        arts[i].phi         = phi[i]    * shape_phi(    arts[i].x)
        arts[i].mu0         = mu0[i]    * shape_mu0(    arts[i].x)
        arts[i].muinf       = muinf[i]  * shape_muinf(  arts[i].x)
        arts[i].kmu         = kmu[i]    * shape_kmu(    arts[i].x)
        arts[i].amu         = amu[i]    * shape_amu(    arts[i].x)

        # Initial condition
        arts[i].initA       = np.ones(arts[i].N)
        for ix in range(arts[i].N) :
            arts[i].initA[ix] = np.pi *arts[i].R[ix] * arts[i].R[ix] * cosStenosis(dR_c,xms_c,xme_c,arts[i].x[ix]) * cosStenosis(dR_c,xms_c,xme_c,arts[i].x[ix])

        arts[i].initQ       = np.zeros(arts[i].N)

        # Initial aggregation condition
        arts[i].initf       = np.zeros(arts[i].N)
        arts[i].initHrbc    = np.zeros(arts[i].N)

        # Initial passive transport condition
        arts[i].initCpt     = np.zeros(arts[i].N)
        arts[i].initOpt     = np.zeros(arts[i].N)

        # Boundary properties
        fact = 1.
        arts[i].dxin        = fact  * arts[i].dx[0]
        arts[i].dxout       = fact  * arts[i].dx[arts[i].N-1]
        arts[i].Ain         = np.pi * arts[i].R[0] * arts[i].R[0]
        arts[i].Aout        = np.pi * arts[i].R[arts[i].N-1] * arts[i].R[arts[i].N-1]
        arts[i].Kin         = arts[i].K[0]
        arts[i].Kout        = arts[i].K[arts[i].N-1]
        arts[i].anglein     = Angle[i][0]
        arts[i].angleout    = Angle[i][1]

        #Output points
        arts[i].outPut=[0]

        for ix in range(1,arts[i].N-1) :
            arts[i].outPut.append( ix )

        arts[i].outPut.append( arts[i].N-1 )

    #############################
    # Time setup
    #############################

    # CFL
    Ct      = 1.
    dt_CFL  = 1.e3
    for i in range(NArt) :
        dt_CFL  = min( dt_CFL , Ct * min( arts[i].dx / celerity( arts[i].rho,arts[i].K,arts[i].initA ) ) )

    # Analytic input signal
    #######################

    t_start = ts_c
    t_end   = te_c

    # Time step
    # power   = float(floor(mt.log10(dt_CFL)))
    # fact    = floor(dt_CFL / (10. ** power))
    # dt      = min(float(fact) * 10. ** (power),1.e-5)

    dt        = float(dt_c)
    if (dt > dt_CFL) :
        print("Error dt>dt_CFL", dt, dt_CFL)
        sys.exit()

    timeSteps = int(t_end/dt)
    tt = ones(timeSteps)
    for it in range(timeSteps) :
        tt[it] = float(it) * dt

    # Experimental Input Signal
    ###########################

    # inputPath   = "/home/ghigo/Dropbox/These/Codes/1D/bloodflow-Single/scripts/Japan/Input/"
    # Input       = np.genfromtxt(inputPath + "Q_Straight_30mm.csv", delimiter=',',dtype = ("float","float"))
    # tt          = Input[:,0]
    # pulse_Input = Input[:,1]
    #
    # Q_c     = V_c / integrate(tt,pulse_Input)
    # Q_Input = Q_c * pulse_Input
    #
    # t_start = tt[0] # (s)
    # t_end   = tt[len(tt)-1] # (s)
    # dt      = tt[1]-tt[0] ;
    #
    # if (t_start != 0.) :
    #     print("Error in starting time of experimental input file")
    #     sys.exit
    # if (dt > dt_CFL) :
    #     print("Error dt>dt_CFL", dt, dt_CFL)
    #     sys.exit()
    #
    # # Store step
    # timeSteps   = len(tt)

    #######################

    dt_store    = 1.e-2 * (t_end-t_start)
    storeStep   = max(1,int(dt_store / dt))

    print ("---->Time step dt = ", dt)
    print ("---->CFL Time step dt_CFL = ",dt_CFL)

    tS              = timeSetup()
    tS.tt           = tt
    tS.dt           = dt
    tS.t_start      = t_start
    tS.t_end        = t_end
    tS.Nt           = timeSteps
    tS.storeStep    = storeStep
    tS.CFL          = Ct
    tS.timeOrder    = int(tOrder_c)

    #############################
    # Boundary condition
    #############################

    # Inlet
    Rt_Input    = Rt_c * np.ones(timeSteps);

    # Oulet
    Rt_Output   = Rt_c * np.ones(timeSteps);

    # Rheology
    H_Input     = np.zeros(timeSteps)
    f_Input     = np.zeros(timeSteps)
    H_Output    = np.zeros(timeSteps)
    f_Output    = np.zeros(timeSteps)

    # Passive transport
    Cpt_Input   = np.zeros(timeSteps)
    Opt_Input   = np.zeros(timeSteps)
    Cpt_Output  = np.zeros(timeSteps)
    Opt_Output  = np.zeros(timeSteps)

    #############################
    # Construct network
    #############################

    iart = 0 ; ihconj = 0 ; itconj = iart + 1 ;
    arts[iart].daughterArts = [] ;
    # Head point
    arts[iart].headPt.append(point(ihconj));
    arts[iart].headPt[0].type       = "inRt"        ; arts[iart].headPt[0].data     = Rt_Input  ;
    arts[iart].headPt[0].typeH      = "inHrbc"      ; arts[iart].headPt[0].dataH    = H_Input   ;
    arts[iart].headPt[0].typef      = "infrbc"      ; arts[iart].headPt[0].dataf    = f_Input   ;
    arts[iart].headPt[0].typeCpt    = "inCpt"       ; arts[iart].headPt[0].dataCpt  = Cpt_Input ;
    arts[iart].headPt[0].typeOpt    = "inOpt"       ; arts[iart].headPt[0].dataOpt  = Opt_Input ;
    # Tail point
    arts[iart].tailPt.append(point(itconj));
    arts[iart].tailPt[0].type       = "outRt"       ; arts[iart].tailPt[0].data     = Rt_Output     ;
    arts[iart].tailPt[0].typeH      = "outHrbc"     ; arts[iart].tailPt[0].dataH    = H_Output      ;
    arts[iart].tailPt[0].typef      = "outfrbc"     ; arts[iart].tailPt[0].dataf    = f_Output      ;
    arts[iart].tailPt[0].typeCpt    = "outCpt"      ; arts[iart].tailPt[0].dataCpt  = Cpt_Output    ;
    arts[iart].tailPt[0].typeOpt    = "outOpt"      ; arts[iart].tailPt[0].dataOpt  = Opt_Output    ;

    #############################
    # Network definition
    #############################

    net=network(ARTS=arts,tS=tS)

    #############################
    # Create necessary files
    #############################

    if not os.path.exists(str(PATH)+"parameters_"+str(LOGO)) :
        os.makedirs(str(PATH)+"/parameters_"+str(LOGO))
    if not os.path.exists(str(PATH)+"parameters_"+str(LOGO)+"/Parameters") :
        os.makedirs(str(PATH)+"/parameters_"+str(LOGO)+"/Parameters")
    if not os.path.exists(str(PATH)+"/data"):
        os.makedirs(str(PATH)+"/data")
    if not os.path.exists(str(PATH)+"/Figures"):
        os.makedirs(str(PATH)+"/Figures")
    if not os.path.exists(str(PATH)+"/Movies"):
        os.makedirs(str(PATH)+"/Movies")

    #############################
    # Write parameters
    #############################

    net.writeParam(str(PATH)+"parameters_"+str(LOGO))

if __name__ == "__main__":
   main(sys.argv[1:])
