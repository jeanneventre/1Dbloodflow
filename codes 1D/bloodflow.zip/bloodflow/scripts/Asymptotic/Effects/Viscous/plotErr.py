#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Effects/Viscous/"

    nfig = 1

    Store   = PATH1D + "Figures/"

    for pType in ["P"] :

        pName,pLabel = out.getType(pType)

        # FILE :
        ###########
        S1 = "1e-3"
        Data11 = PATH1D + "Figures/" + "Sh-" + S1 + "-Err-" + "L1" + "-P-O1.csv"
        Data12 = PATH1D + "Figures/" + "Sh-" + S1 + "-Err-" + "L1" + "-P-O2.csv"

        S2 = "1e-4"
        Data21 = PATH1D + "Figures/" + "Sh-" + S2 + "-Err-" + "L1" + "-P-O1.csv"
        Data22 = PATH1D + "Figures/" + "Sh-" + S2 + "-Err-" + "L1" + "-P-O2.csv"

        S3 = "1e-5"
        Data31 = PATH1D + "Figures/" + "Sh-" + S3 + "-Err-" + "L1" + "-P-O1.csv"
        Data32 = PATH1D + "Figures/" + "Sh-" + S3 + "-Err-" + "L1" + "-P-O2.csv"

        S4 = "1e-5"
        Data41 = PATH1D + "Figures/" + "Sh-" + S4 + "-Err-" + "L1" + "-P-O1.csv"
        Data42 = PATH1D + "Figures/" + "Sh-" + S4 + "-Err-" + "L1" + "-P-O2.csv"

        ######################################
        ######################################
        lCol        = [ "black","black","black","black",
                        "blue","blue","blue","blue",
                        "red","red","red","red",
                        "seagreen","seagreen","seagreen","seagreen"]
        lMark       = [ "o","","s","",
                        "^","","v","",
                        "+","","x","",
                        "D","","h",""
                      ]
        lMarkSize   = [ 10,10,10,10,
                        10,10,10,10,
                        10,10,10,10,
                        10,10,10,10
                      ]
        lMarkWidth  = [ 1,1,1,1,
                        1,1,1,1,
                        1,1,1,1,
                        1,1,1,1]
        MarkPoints  = 30

        lLineSize   = [ 3,1,3,1,
                        3,1,3,1,
                        3,1,3,1,
                        3,1,3,1,]
        lStyle      = [ "-","","--","",
                        "-","","--","",
                        "-","","--","",
                        "-","","--",""]
        lAlpha      = [ 1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.]

        LegLoc      = 4
        LegPos      = [1.,0.]
        LegCol      = 3
        LegSize     = 17

        xRange      = []
        yRange      = []

        xBins       = 2 ;
        yBins       = 2 ;

        lHline      = []
        lHlineColor = []
        lHlineWidth = []
        lHlineStyle = []

        lVline      = []
        lVlineColor = []
        lVlineWidth = []
        lVlineStyle = []

        lXScale     = [ 1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.]
        lYScale     = [ 1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.,
                        1.,1.,1.,1.]
        pScale      = "log"

        lXOffset    = [ 0.,0.,0.,0.,
                        0.,0.,0.,0.,
                        0.,0.,0.,0.,
                        0.,0.,0.,0.]
        lYOffset    = [ 0.,0.,0.,0.,
                        0.,0.,0.,0.,
                        0.,0.,0.,0.,
                        0.,0.,0.,0.]

        lText       = [ r"$t$=$1.5T$","Viscous wave propagation" ]
        lTextAlign  = [ "right","left" ]
        lTextPos    = [ [0.98,0.945],[0.02,0.945] ]
        lTextColor  = [ "black","black" ]

        xLabel      = r"$N_x$"
        yLabel      = r"$L_1 \left[\right.$" + pType + r"$\left.\right]$"
        lLabel      = [ r"$S_h$=$10^{-3}$, order 1","",r"$S_h$=$10^{-3}$, MUSCL","",
                        r"$S_h$=$10^{-4}$, order 1","",r"$S_h$=$10^{-4}$, MUSCL","",
                        r"$S_h$=$10^{-5}$, order 1","",r"$S_h$=$10^{-5}$, MUSCL",""
                      ]

        lFileSep    = [ ",",",",",",",",
                        ",",",",",",",",
                        ",",",",",",",",
                        ",",",",",",","]
        liX         = [ 0,0,0,0,
                        0,0,0,0,
                        0,0,0,0,
                        0,0,0,0]
        liY         = [ 1,2,1,2,
                        1,2,1,2,
                        1,2,1,2,
                        1,2,1,2]

        lFile       = [ Data11,Data11,Data12,Data12,
                        Data21,Data21,Data22,Data22,
                        Data31,Data31,Data32,Data32#,
                        # Data41,Data41,Data42,Data42
                      ]

        title = "Err-" + pType + ".pdf"
        nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                            liX=liX,liY=liY,
                            xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                            xRange=xRange,yRange=yRange,
                            xBins=xBins,yBins=yBins,
                            lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                            lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                            lXScale=lXScale,lYScale=lYScale,pScale=pScale,lXOffset=lXOffset,lYOffset=lYOffset,
                            LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                            lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                            lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                            lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
