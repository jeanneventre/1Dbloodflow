#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

from    csv_libPlot import *
from    help_Wave   import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATHANA     = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Asymptotic/Effects/"
    PATHWAVE    = PATHANA + "Wave/Analytic/"
    PATHVISC    = PATHANA + "Viscous/Analytic/"
    PATHVISCOEL = PATHANA + "Viscoelastic/Analytic/"

    nfig = 1

    Shstr       = "1e-3"

    Store   = PATHANA + "Figures/"

    for pType in ["P"] :

        if (pType == "Q") :
            pName = "Q.csv"
            pLabel = r"$Q$ $\left[\frac{cm^3}{s}\right]$"
        if (pType == "U") :
            pName = "U.csv"
            pLabel = r"$U$ $\left[\frac{cm}{s}\right]$"
        if (pType == "P") :
            pName = "P.csv"
            pLabel = r"$p$ $\left[\frac{g}{cm.s^{2}}\right]$"
        if (pType == "A") :
            pName = "A.csv"
            pLabel = r"$A$ $\left[cm^{2}\right]$"
        if (pType == "RmR0") :
            pName = "RmR0.csv"
            pLabel = r"$R-R_0$ $\left[cm\right]$"
        if (pType == "E") :
            pName = "E.csv"
            pLabel = r"$E$ $\left[\frac{g}{cm.s^{2}}\right]$"
        if (pType == "Sh") :
            pName = "Sh.csv"
            pLabel = r"$Sh$"

        ANA_Wave    = PATHWAVE      + "Sh=" + Shstr + "/P.csv"
        ANA_Visc    = PATHVISC      + "Sh=" + Shstr + "/P.csv"
        ANA_Viscoel = PATHVISCOEL   + "Sh=" + Shstr + "/P.csv"

        ######################################
        ######################################
        lCol = [    "black","black","black","black","black",
                    "blue","blue","blue","blue","blue",
                    "red","red","red","red","red",
                    "green","green","green","green","green"]
        lMark = [   "","","","","",
                    "o","s","h","^","*",
                    "o","s","h","^","*",
                    "o","s","h","^","*"]
        lMarkSize = [   1,1,1,1,1,
                        1,1,1,1,1,
                        1,1,1,1,1,
                        1,1,1,1,1]
        lMarkWidth = [   1,1,1,1,1,
                        1,1,1,1,1,
                        1,1,1,1,1,
                        1,1,1,1,1]
        MarkPoints = 20

        lLineSize = [   3,3,3,3,3,
                        3,3,3,3,3,
                        3,3,3,3,3,
                        3,3,3,3,3]
        lStyle = [      "-","-","-","-","-",
                        "-","-","-","-","-",
                        "-","-","-","-","-",
                        "-","-","-","-","-"]
        lAlpha = [  1,1,1,1,1,
                    1,1,1,1,1,
                    1,1,1,1,1,
                    1,1,1,1,1]

        LegLoc      = 1
        LegPos      = [1.,1.]
        LegCol      = 4

        xRange      = []
        yRange      = []

        lHline      = []
        lHlineColor = []
        lHlineWidth = []
        lHlineStyle = []

        lVline      = []
        lVlineColor = []
        lVlineWidth = []
        lVlineStyle = []

        lXScale     = [ 1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.]
        lYScale     = [ 1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.]

        lXOffset    = [ 0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.]
        lYOffset    = [ 0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.,
                        0.,0.,0.,0.,0.]

        lText       = [ r"$t$=$0.1$, $t$=$0.2$, $t$=$0.3$, $t$=$0.4$, $t$=$0.5$"]
        lTextAlign  = [ "center" ]
        lTextPos    = [ [0.5,0.04] ]
        lTextColor  = [ "black" ]

        xLabel=r"$x$ $\left[cm\right]$"
        yLabel = pLabel
        lLabel = [  r"$Wave$","","","","",
                    r"$Viscous$","","","","",
                    r"$Viscoelastic$","","","","",
                    r"$Tapper$","","","",""]

        lFileSep    = [ ",",",",",",",",",",
                        ",",",",",",",",",",
                        ",",",",",",",",",",
                        ",",",",",",",",","]
        liX         = [ 0,0,0,0,0,
                        0,0,0,0,0,
                        0,0,0,0,0,
                        0,0,0,0,0]
        liY         = [ 1,2,3,4,5,
                        1,2,3,4,5,
                        1,2,3,4,5,
                        1,2,3,4,5]

        lFile = [   ANA_Wave,ANA_Wave,ANA_Wave,ANA_Wave,ANA_Wave
                    # ,ANA_Visc,ANA_Visc,ANA_Visc,ANA_Visc,ANA_Visc
                    # ,ANA_Viscoel,ANA_Viscoel,ANA_Viscoel,ANA_Viscoel,ANA_Viscoel
                ]

        title = pType + "_Ana_x.pdf"

        nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                            liX=liX,liY=liY,
                            xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                            xRange=xRange,yRange=yRange,
                            lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                            lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                            lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                            LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,
                            lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                            lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                            lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
