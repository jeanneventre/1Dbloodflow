#! /usr/bin/python2.7
import sys, getopt
import os
import numpy    as np
import math     as mt

from bfS_libDef import *

from help_Input     import *

from help_Sum       import *
from help_Wave      import *
from help_Geometry  import *
from help_Inlet     import *

from scipy.interpolate import interp1d

def main(argv) :

    # Read input parameters and store them in hd
    hd = header()
    hd.headerInput(argv) ;

    # Fluid properties
    ##################
    rho_c   = 1. ;

    if      (hd.NNstr == "Newtonian") :
        phi_c   = -4. ;
        mu0_c   = 0. ;
        mu1_c   = 0.05 ;
        kmu_c   = 0. ;
        amu_c   = 0. ;
    elif    (hd.NNstr == "NonNewtonian") :
        phi_c   = -4. ;
        mu0_c   = 1.3    ;
        mu1_c   = 0.05 ;
        kmu_c   = 0.2 ;
        amu_c   = 1.5  ;
    elif    (hd.NNstr == "Inviscid") :
        phi_c   = 0. ;
        mu0_c   = 0. ;
        mu1_c   = 0. ;
        kmu_c   = 0. ;
        amu_c   = 0. ;

    # Mechanical properties
    # Cv_c    = 0.
    nuv_c   = float(hd.Cvstr)
    Knl_c   = 0.

    # Numerical properties
    Nx_c        = float (hd.Nxstr)
    xOrder_c    = int   (hd.xOrderstr)
    dt_c        = float (hd.dtstr)
    tOrder_c    = int   (hd.tOrderstr)
    hd.Nxmax    = 200

    # Time properties
    T_c     = 1. ;
    ts_c    = 9. * T_c
    te_c    = 10.* T_c

    # Boundary properties
    # Inlet
    Q_c = 300.
    # Outlet
    Pout_c  = 0. ; # Capillary pressure (used in RLC outflow bc)
    # Junction
    fact_c  = 1. ;

    # Rheology
    if (hd.NNstr == "NonNewtonian") :
        F_c     = 1.
        H_c     = 0.45
    else :
        F_c     = 0.
        H_c     = 0.

    # Passive Transport
    C_c    = 0. ;
    O_c    = 0. ;

    # Stenosis
    dR_c    = 0. ;

    ############################################################################
    ############################################################################
    # Network
    ############################################################################
    ############################################################################

    # Angle of bifurcation
    # Angle = array( [ [0.*np.pi,np.pi], [1./4.*np.pi,np.pi], [7./4.*np.pi,np.pi] ] )

    #############################
    # Geometrical parameters
    #############################

    # Length of the vessels (cm)
    L   = np.array([
    	    4.00000000, 	2.00000000, 	3.40000000, 	8.90000000, 	3.90000000, 	3.40000000, 	15.00000000, 	6.80000000, 	14.80000000, 	8.90000000,
     	    5.20000000, 	8.90000000, 	14.80000000, 	6.80000000, 	15.00000000, 	5.00000000, 	6.10000000, 	10.00000000, 	5.00000000, 	3.10000000,
     	    5.20000000, 	8.90000000, 	5.00000000, 	10.00000000, 	6.10000000, 	5.00000000, 	3.00000000, 	5.60000000, 	5.00000000, 	8.00000000,
     	    5.90000000, 	11.80000000, 	4.00000000, 	5.20000000, 	4.00000000, 	11.80000000, 	5.90000000, 	8.00000000, 	5.00000000, 	5.60000000,
     	    3.00000000, 	6.30000000, 	3.00000000, 	5.90000000, 	4.00000000, 	3.00000000, 	5.90000000, 	3.00000000, 	1.00000000, 	5.30000000,
     	    3.00000000, 	5.90000000, 	3.00000000, 	4.00000000, 	5.90000000, 	3.00000000, 	6.30000000, 	15.00000000, 	6.30000000, 	5.90000000,
     	    7.10000000, 	6.30000000, 	6.60000000, 	3.20000000, 	5.30000000, 	5.90000000, 	3.20000000, 	5.90000000, 	6.30000000, 	15.00000000,
     	    6.30000000, 	5.00000000, 	4.00000000, 	5.00000000, 	5.30000000, 	5.00000000, 	4.00000000, 	5.00000000, 	6.30000000, 	5.00000000,
     	    4.60000000, 	5.80000000, 	5.00000000, 	5.80000000, 	4.60000000, 	5.00000000, 	6.70000000, 	11.70000000, 	8.30000000, 	5.00000000,
     	    5.00000000, 	8.30000000, 	11.70000000, 	6.70000000, 	8.50000000, 	7.90000000, 	11.70000000, 	6.10000000, 	6.10000000, 	11.70000000,
     	    7.90000000, 	8.50000000, 	8.50000000, 	12.70000000, 	12.60000000, 	12.60000000, 	12.70000000, 	8.50000000, 	12.70000000, 	12.70000000,
     	    9.40000000, 	9.40000000, 	9.40000000, 	9.40000000, 	2.50000000, 	16.10000000, 	16.10000000, 	2.50000000, 	15.00000000, 	15.90000000,
     	    16.10000000, 	16.10000000, 	15.90000000, 	15.00000000, 	15.00000000, 	15.90000000, 	15.90000000, 	15.00000000
        ]) ;
    # Radius of the artery (cm)
    R   = np.array([
    	    1.45000000, 	1.12000000, 	0.42000000, 	0.37000000, 	1.07000000, 	0.62000000, 	0.10000000, 	0.40000000, 	0.19000000, 	0.37000000,
     	    1.00000000, 	0.37000000, 	0.19000000, 	0.40000000, 	0.10000000, 	0.10000000, 	0.36000000, 	0.20000000, 	0.10000000, 	0.37000000,
     	    0.95000000, 	0.37000000, 	0.10000000, 	0.20000000, 	0.36000000, 	0.10000000, 	0.15000000, 	0.31000000, 	0.10000000, 	0.15000000,
     	    0.18000000, 	0.15000000, 	0.07000000, 	0.95000000, 	0.07000000, 	0.15000000, 	0.18000000, 	0.15000000, 	0.10000000, 	0.31000000,
     	    0.15000000, 	0.28000000, 	0.10000000, 	0.13000000, 	0.10000000, 	0.06000000, 	0.08000000, 	0.07000000, 	0.39000000, 	0.87000000,
     	    0.07000000, 	0.08000000, 	0.06000000, 	0.10000000, 	0.13000000, 	0.10000000, 	0.28000000, 	0.15000000, 	0.26000000, 	0.08000000,
     	    0.18000000, 	0.28000000, 	0.22000000, 	0.26000000, 	0.57000000, 	0.43000000, 	0.26000000, 	0.08000000, 	0.26000000, 	0.15000000,
     	    0.25000000, 	0.07000000, 	0.06000000, 	0.07000000, 	0.57000000, 	0.07000000, 	0.06000000, 	0.07000000, 	0.25000000, 	0.06000000,
     	    0.24000000, 	0.52000000, 	0.16000000, 	0.52000000, 	0.24000000, 	0.06000000, 	0.21000000, 	0.16000000, 	0.29000000, 	0.20000000,
     	    0.20000000, 	0.29000000, 	0.16000000, 	0.21000000, 	0.19000000, 	0.09000000, 	0.16000000, 	0.27000000, 	0.27000000, 	0.16000000,
     	    0.09000000, 	0.19000000, 	0.19000000, 	0.24000000, 	0.23000000, 	0.23000000, 	0.24000000, 	0.19000000, 	0.24000000, 	0.24000000,
     	    0.20000000, 	0.20000000, 	0.20000000, 	0.20000000, 	0.13000000, 	0.18000000, 	0.18000000, 	0.13000000, 	0.10000000, 	0.13000000,
     	    0.18000000, 	0.18000000, 	0.13000000, 	0.10000000, 	0.10000000, 	0.13000000, 	0.13000000, 	0.10000000
        ]) ;

    D   = 2. * R
    A   = np.pi * R * R

    NArt = len(L)

    # Check length of array
    if NArt != len(R) :
        print ('Dimension error in geometric parameters Rd, Rp or L')
        sys.exit()

    #############################
    # Mechanical parameters
    #############################

    # Density (g/cm^3)
    rho = rho_c
    # Stiffness coefficient beta (g/cm^2/s^2 ~ Pa/m = 0.1 g/(cm*s)^2)
    h   = np.array([
    	    0.16300000, 	0.13200000, 	0.06700000, 	0.06300000, 	0.12700000, 	0.08600000, 	0.03000000, 	0.06600000, 	0.04500000, 	0.06300000,
     	    0.12000000, 	0.06300000, 	0.04500000, 	0.06600000, 	0.03000000, 	0.03000000, 	0.06200000, 	0.05200000, 	0.03000000, 	0.06300000,
     	    0.11600000, 	0.06300000, 	0.03000000, 	0.05200000, 	0.06200000, 	0.03000000, 	0.03500000, 	0.05700000, 	0.03000000, 	0.03500000,
     	    0.04500000, 	0.04200000, 	0.02000000, 	0.11600000, 	0.02000000, 	0.04200000, 	0.04500000, 	0.03500000, 	0.03000000, 	0.05700000,
     	    0.03500000, 	0.05500000, 	0.03000000, 	0.03900000, 	0.03000000, 	0.02000000, 	0.02600000, 	0.02000000, 	0.06400000, 	0.10800000,
     	    0.02000000, 	0.02600000, 	0.02000000, 	0.03000000, 	0.03900000, 	0.03000000, 	0.05500000, 	0.03500000, 	0.05300000, 	0.02600000,
     	    0.04500000, 	0.05400000, 	0.04900000, 	0.05300000, 	0.08000000, 	0.06900000, 	0.05300000, 	0.02600000, 	0.05300000, 	0.03500000,
     	    0.05200000, 	0.02000000, 	0.02000000, 	0.02000000, 	0.08000000, 	0.02000000, 	0.02000000, 	0.02000000, 	0.05200000, 	0.02000000,
     	    0.05000000, 	0.07600000, 	0.04300000, 	0.07600000, 	0.05000000, 	0.02000000, 	0.04900000, 	0.04300000, 	0.05500000, 	0.04000000,
     	    0.04000000, 	0.05500000, 	0.04300000, 	0.04900000, 	0.04600000, 	0.02800000, 	0.04300000, 	0.05300000, 	0.05300000, 	0.04300000,
     	    0.02800000, 	0.04600000, 	0.04600000, 	0.05000000, 	0.04900000, 	0.04900000, 	0.05000000, 	0.04600000, 	0.05000000, 	0.05000000,
     	    0.04700000, 	0.04700000, 	0.05000000, 	0.05000000, 	0.03900000, 	0.04500000, 	0.04500000, 	0.03900000, 	0.02000000, 	0.03900000,
     	    0.04500000, 	0.04500000, 	0.03900000, 	0.02000000, 	0.02000000, 	0.01900000, 	0.01900000, 	0.02000000
        ]) ;
    E   = np.array([
    	    4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	8000000.00000000, 	4000000.00000000, 	8000000.00000000, 	4000000.00000000,
     	    4000000.00000000, 	4000000.00000000, 	8000000.00000000, 	4000000.00000000, 	8000000.00000000, 	8000000.00000000, 	4000000.00000000, 	8000000.00000000, 	8000000.00000000, 	4000000.00000000,
     	    4000000.00000000, 	4000000.00000000, 	8000000.00000000, 	8000000.00000000, 	4000000.00000000, 	8000000.00000000, 	16000000.00000000, 	4000000.00000000, 	16000000.00000000, 	16000000.00000000,
     	    8000000.00000000, 	8000000.00000000, 	8000000.00000000, 	4000000.00000000, 	8000000.00000000, 	8000000.00000000, 	8000000.00000000, 	16000000.00000000, 	16000000.00000000, 	4000000.00000000,
     	    16000000.00000000, 	4000000.00000000, 	8000000.00000000, 	8000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	4000000.00000000, 	4000000.00000000,
     	    16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	8000000.00000000, 	8000000.00000000, 	4000000.00000000, 	8000000.00000000, 	4000000.00000000, 	16000000.00000000,
     	    4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	16000000.00000000, 	4000000.00000000, 	8000000.00000000,
     	    4000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	4000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	4000000.00000000, 	16000000.00000000,
     	    4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	4000000.00000000, 	16000000.00000000, 	8000000.00000000, 	8000000.00000000, 	4000000.00000000, 	16000000.00000000,
     	    16000000.00000000, 	4000000.00000000, 	8000000.00000000, 	8000000.00000000, 	8000000.00000000, 	16000000.00000000, 	8000000.00000000, 	4000000.00000000, 	4000000.00000000, 	8000000.00000000,
     	    16000000.00000000, 	8000000.00000000, 	8000000.00000000, 	8000000.00000000, 	16000000.00000000, 	16000000.00000000, 	8000000.00000000, 	8000000.00000000, 	8000000.00000000, 	8000000.00000000,
     	    8000000.00000000, 	8000000.00000000, 	4000000.00000000, 	4000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000,
     	    16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000, 	16000000.00000000
        ]) ;
    K   = rigidity(E,h,R)
    # Viscoelasticity coefficient C_v (cm^2/s)
    nuv = nuv_c
    Cv  = viscoelasticity(rho,nuv,h,R)
    # Nonlinear stiffness coefficient beta (g/cm^3/s^2)
    Knl = Knl_c * np.ones(NArt)
    # Moens-Korteweg celerity (cm/s)
    c   = celerity(rho,K,A)

    # Check length of array
    if NArt != len(K) or NArt != len(Cv) or NArt != len(Knl) or NArt != len(c) :
        print ('Dimension error in geometric parameters K, Cv, Knl, c or L')
        sys.exit()

    #############################
    # Rheology
    #############################

    # Profile coefficient phi
    phi = phi_c * np.ones(NArt)
    # Newtonian viscosities
    mu0 = mu0_c * np.ones(NArt)
    mu1 = mu1_c * np.ones(NArt)
    # Aggregation coefficient
    kmu = kmu_c * np.ones(NArt)
    # Desaggregation coefficient
    amu = amu_c * np.ones(NArt)

    #############################
    # Artery
    #############################

    arts = [artery(i) for i in range(NArt)]

    # Define default arterial properties
    hd.headerNum    (arts,L,c)
    hd.headerProp   (arts,rho,L,R,K,Cv,Knl)
    hd.headerRheo   (arts,phi,mu0,mu1,kmu,amu)
    hd.headerInit   (arts,F_c,H_c,C_c,O_c)
    hd.headerBC     (arts,fact_c,Pout_c)

    hd.headerOutput (arts)
    # Specific output
    for i in range(NArt) :
        arts[i].outPut = []
        arts[i].outPut.append(0)
        arts[i].outPut.append(arts[i].N/2)
        arts[i].outPut.append(arts[i].N-1)

    #############################
    # Time setup
    #############################

    # CFL
    Ct      = 1.
    dt_CFL  = hd.headerCFL(arts,Ct)

    # Analytic input signal
    t_start = ts_c
    t_end   = te_c

    # Time step
    dt        = float(dt_c)
    if (dt > dt_CFL) :
        print("Error dt>dt_CFL", dt, dt_CFL)
        sys.exit()

    timeSteps = int(t_end/dt)
    tt = np.ones(timeSteps)
    for it in range(timeSteps) :
        tt[it] = float(it) * dt

    #######################

    dt_store    = 1.e-3 * (t_end-t_start)
    storeStep   = max(1,int(dt_store / dt))

    print ("---->Time step dt = ", dt)
    print ("---->CFL Time step dt_CFL = ",dt_CFL)

    tS              = timeSetup()
    tS.tt           = tt
    tS.dt           = dt
    tS.t_start      = t_start
    tS.t_end        = t_end
    tS.Nt           = timeSteps
    tS.storeStep    = storeStep
    tS.CFL          = Ct
    tS.timeOrder    = int(hd.tOrderstr)

    #############################
    # Boundary condition
    #############################

    # Inlet
    Q_Input = Q_c * PulseSin(T_c,tt)

    # Heart model
    V_c         = integrate(tt,Q_Input) / ( te_c / T_c)
    print ("---->Ejection period (s)                : ", T_c)
    print ("---->Stroke Volume (cm^3)               : ", V_c)
    print ("---->Cardiac Output (L/min)             : ", V_c / T_c * 60./1000.)
    print ("---->Maximum Input Flow Rate (cm^3/s)   : ", Q_c)
    print ("---->Maximum Input Speed (cm/s)         : ", Q_c / A[0] )
    print ("---->Reynolds number                    : ", Reynolds(rho_c,mu1_c,R[0],Q_c/A[0]))
    print ("---->Womersley number                   : ", Womersley(rho_c,mu1_c,R[0],T_c))

    # Rheology
    H_Input     = H_c * np.ones(timeSteps)
    F_Input     = np.zeros(timeSteps)

    # Passive transport
    C_Input   = np.zeros(timeSteps)
    O_Input   = np.zeros(timeSteps)
    C_Output  = np.zeros(timeSteps)
    O_Output  = np.zeros(timeSteps)

    #############################
    # Construct network
    #############################

    # Right cerebral
    arts[11].jDAG(      hConj=6,    dArts=[arts[21]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[21].jDAG(      hConj=12,   dArts=[arts[34],arts[35],arts[36]], tConj=hd.CONJ,nt=timeSteps)
    arts[35].jDAG(      hConj=22,   dArts=[arts[50],arts[51],arts[53]], tConj=hd.CONJ,nt=timeSteps)
    arts[36].jDAG(      hConj=22,   dArts=[arts[53],arts[54],arts[55]], tConj=hd.CONJ,nt=timeSteps)
    arts[54].jDAG(      hConj=37,   dArts=[arts[67]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[67].jDAG(      hConj=55,   dArts=[arts[75],arts[76]],          tConj=hd.CONJ,nt=timeSteps)

    arts[34].RCRDAG(    hConj=22,   R1=44303,   C1=1.e-6,R2=176750,     tConj=hd.CONJ,nt=timeSteps)
    arts[50].RCRDAG(    hConj=36,   R1=62666.8, C1=1.e-6,R2=250208,     tConj=hd.CONJ,nt=timeSteps)
    arts[51].RCRDAG(    hConj=36,   R1=51189.6, C1=1.e-6,R2=204302,     tConj=hd.CONJ,nt=timeSteps)
    arts[52].RCRDAG(    hConj=36,   R1=92163.4, C1=1.e-6,R2=368424,     tConj=hd.CONJ,nt=timeSteps)
    arts[53].RCRDAG(    hConj=37,   R1=31448.2, C1=1.e-6,R2=126252,      tConj=hd.CONJ,nt=timeSteps)
    arts[55].RCRDAG(    hConj=37,   R1=22265.6, C1=2.e-6,R2=88950.4,     tConj=hd.CONJ,nt=timeSteps)
    arts[75].RCRDAG(    hConj=68,   R1=62666.8, C1=1.e-6,R2=250208,      tConj=hd.CONJ,nt=timeSteps)
    arts[76].RCRDAG(    hConj=68,   R1=92163.4, C1=1.e-6,R2=368424,      tConj=hd.CONJ,nt=timeSteps)

    # Left cerebral
    arts[3].jDAG(       hConj=2,    dArts=[arts[9]],                    tConj=hd.CONJ,nt=timeSteps)
    arts[9].jDAG(       hConj=4,    dArts=[arts[19]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[19].jDAG(      hConj=10,   dArts=[arts[30],arts[31],arts[32]], tConj=hd.CONJ,nt=timeSteps)
    arts[31].jDAG(      hConj=20,   dArts=[arts[45],arts[46],arts[47]], tConj=hd.CONJ,nt=timeSteps)
    arts[30].jDAG(      hConj=20,   dArts=[arts[42],arts[43],arts[44]], tConj=hd.CONJ,nt=timeSteps)
    arts[43].jDAG(      hConj=31,   dArts=[arts[59]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[59].jDAG(      hConj=44,   dArts=[arts[72],arts[73]],          tConj=hd.CONJ,nt=timeSteps)

    arts[32].RCRDAG(    hConj=20,   R1=44303,   C1=1.e-6,R2=176750,     tConj=hd.CONJ,nt=timeSteps)
    arts[47].RCRDAG(    hConj=32,   R1=62666.8, C1=1.e-6,R2=250208,     tConj=hd.CONJ,nt=timeSteps)
    arts[46].RCRDAG(    hConj=32,   R1=51189.6, C1=1.e-6,R2=204302,     tConj=hd.CONJ,nt=timeSteps)
    arts[45].RCRDAG(    hConj=32,   R1=92163.4, C1=1.e-6,R2=368424,     tConj=hd.CONJ,nt=timeSteps)
    arts[44].RCRDAG(    hConj=31,   R1=31448.2, C1=1.e-6,R2=126252,      tConj=hd.CONJ,nt=timeSteps)
    arts[42].RCRDAG(    hConj=31,   R1=22265.6, C1=2.e-6,R2=88950.4,     tConj=hd.CONJ,nt=timeSteps)
    arts[72].RCRDAG(    hConj=60,   R1=62666.8, C1=1.e-6,R2=250208,      tConj=hd.CONJ,nt=timeSteps)
    arts[73].RCRDAG(    hConj=60,   R1=92163.4, C1=1.e-6,R2=368424,      tConj=hd.CONJ,nt=timeSteps)


    # Aorta
    arts[0].iDAG(       hConj=0,        dArts=[arts[1]],
                        xType="inQ",    xData=Q_Input,
                        FData=F_Input,  HData=H_Input,                  tConj=hd.CONJ,nt=timeSteps)
    arts[1].jDAG(       hConj=1,    dArts=[arts[2],arts[3],arts[4],arts[5]],    tConj=hd.CONJ,nt=timeSteps)
    arts[4].jDAG(       hConj=2,    dArts=[arts[10]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[10].jDAG(      hConj=5,    dArts=[arts[20]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[20].jDAG(      hConj=11,   dArts=[arts[33]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[33].jDAG(      hConj=21,   dArts=[arts[48],arts[49]],          tConj=hd.CONJ,nt=timeSteps)
    arts[49].jDAG(      hConj=34,   dArts=[arts[63],arts[64],arts[65],arts[66]],tConj=hd.CONJ,nt=timeSteps)
    arts[64].jDAG(      hConj=50,   dArts=[arts[74]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[74].jDAG(      hConj=65,   dArts=[arts[81],arts[82],arts[83]], tConj=hd.CONJ,nt=timeSteps)

    # Intercostals

    # Coeliac, Spleen, Hepatic
    arts[48].jDAG(      hConj=34,   dArts=[arts[60],arts[61],arts[62]], tConj=hd.CONJ,nt=timeSteps)

    arts[60].RCRDAG(    hConj=49,   R1=23758,   C1=2.e-6,R2=94918.6,    tConj=hd.CONJ,nt=timeSteps)
    arts[61].RCRDAG(    hConj=49,   R1=98608.6, C1=5.e-6,R2=34433,      tConj=hd.CONJ,nt=timeSteps)
    arts[62].RCRDAG(    hConj=49,   R1=6851.6,  C1=7.e-6,R2=27431.6,    tConj=hd.CONJ,nt=timeSteps)

    # Gastric
    arts[66].RCRDAG(    hConj=50,   R1=3971.8, C1=1.2e-5,R2=15839.6,    tConj=hd.CONJ,nt=timeSteps)

    # Renal
    arts[63].RCRDAG(    hConj=50,   R1=15839.6, C1=1.2e-5,R2=94918.6,   tConj=hd.CONJ,nt=timeSteps)

    # Mesentric
    arts[65].RCRDAG(    hConj=50,   R1=3329.2,  C1=1.4e-5,R2=13314,     tConj=hd.CONJ,nt=timeSteps)
    arts[82].RCRDAG(    hConj=75,   R1=125104,  C1=2.e-6,R2=94918.6,    tConj=hd.CONJ,nt=timeSteps)

    # Right arm
    arts[5].jDAG(      hConj=2,     dArts=[arts[11],arts[12],arts[13],arts[14]],tConj=hd.CONJ,nt=timeSteps)
    arts[13].jDAG(     hConj=6,     dArts=[arts[22],arts[23],arts[24],arts[25]],tConj=hd.CONJ,nt=timeSteps)
    arts[24].jDAG(     hConj=14,    dArts=[arts[37],arts[38],arts[39],arts[40]],tConj=hd.CONJ,nt=timeSteps)
    arts[39].jDAG(     hConj=25,    dArts=[arts[56]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[56].jDAG(     hConj=40,    dArts=[arts[68],arts[69]],          tConj=hd.CONJ,nt=timeSteps)
    arts[68].jDAG(     hConj=57,    dArts=[arts[77],arts[78]],          tConj=hd.CONJ,nt=timeSteps)
    arts[78].jDAG(     hConj=69,    dArts=[arts[84],arts[85]],          tConj=hd.CONJ,nt=timeSteps)
    arts[84].jDAG(     hConj=79,    dArts=[arts[92],arts[93]],          tConj=hd.CONJ,nt=timeSteps)
    arts[93].jDAG(     hConj=85,    dArts=[arts[100],arts[101]],        tConj=hd.CONJ,nt=timeSteps)
    arts[92].jDAG(     hConj=85,    dArts=[arts[99]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[101].jDAG(    hConj=94,    dArts=[arts[107]],                  tConj=hd.CONJ,nt=timeSteps)

    arts[14].RCRDAG(   hConj=6,     R1=89409.6, C1=1.e-6,R2=358092,     tConj=hd.CONJ,nt=timeSteps)
    arts[12].RCRDAG(   hConj=6,     R1=22037.4, C1=2.e-6,R2=88032,      tConj=hd.CONJ,nt=timeSteps)
    arts[25].RCRDAG(   hConj=14,    R1=89409.6, C1=1.e-6,R2=358092,     tConj=hd.CONJ,nt=timeSteps)
    arts[23].RCRDAG(   hConj=14,    R1=20774.6, C1=2.e-6,R2=83326.6,    tConj=hd.CONJ,nt=timeSteps)
    arts[22].RCRDAG(   hConj=14,    R1=89409.6, C1=1.e-6,R2=358092,     tConj=hd.CONJ,nt=timeSteps)
    arts[40].RCRDAG(   hConj=25,    R1=84015.4, C1=1.e-6,R2=198562,     tConj=hd.CONJ,nt=timeSteps)
    arts[38].RCRDAG(   hConj=25,    R1=126252,  C1=0.,   R2=506156,     tConj=hd.CONJ,nt=timeSteps)
    arts[37].RCRDAG(   hConj=25,    R1=84015.4, C1=1.e-6,R2=198562,     tConj=hd.CONJ,nt=timeSteps)
    arts[69].RCRDAG(   hConj=57,    R1=35120.4, C1=1.e-6,R2=140280,     tConj=hd.CONJ,nt=timeSteps)
    arts[77].RCRDAG(   hConj=69,    R1=252504,  C1=0.,   R2=1007720,    tConj=hd.CONJ,nt=timeSteps)
    arts[85].RCRDAG(   hConj=79,    R1=370720,  C1=0.,   R2=1480640,    tConj=hd.CONJ,nt=timeSteps)
    arts[100].RCRDAG(  hConj=94,    R1=159530,  C1=0.,   R2=635852,     tConj=hd.CONJ,nt=timeSteps)
    arts[99].RCRDAG(   hConj=93,    R1=33055.4, C1=1.e-6,R2=131990.6,   tConj=hd.CONJ,nt=timeSteps)
    arts[107].RCRDAG(  hConj=102,   R1=22265.6, C1=2.e-6,R2=89065.2,    tConj=hd.CONJ,nt=timeSteps)


    # Left arm
    arts[2].jDAG(      hConj=2,     dArts=[arts[6],arts[7],arts[8]],    tConj=hd.CONJ,nt=timeSteps)
    arts[7].jDAG(      hConj=3,     dArts=[arts[15],arts[16],arts[17],arts[18]],tConj=hd.CONJ,nt=timeSteps)
    arts[16].jDAG(     hConj=8,     dArts=[arts[26],arts[27],arts[28],arts[29]],tConj=hd.CONJ,nt=timeSteps)
    arts[27].jDAG(     hConj=17,    dArts=[arts[41]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[41].jDAG(     hConj=28,    dArts=[arts[57],arts[58]],          tConj=hd.CONJ,nt=timeSteps)
    arts[58].jDAG(     hConj=42,    dArts=[arts[70],arts[71]],          tConj=hd.CONJ,nt=timeSteps)
    arts[70].jDAG(     hConj=59,    dArts=[arts[79],arts[80]],          tConj=hd.CONJ,nt=timeSteps)
    arts[80].jDAG(     hConj=71,    dArts=[arts[86],arts[87]],          tConj=hd.CONJ,nt=timeSteps)
    arts[86].jDAG(     hConj=81,    dArts=[arts[94],arts[95]],          tConj=hd.CONJ,nt=timeSteps)
    arts[87].jDAG(     hConj=81,    dArts=[arts[96]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[94].jDAG(     hConj=87,    dArts=[arts[102]],                  tConj=hd.CONJ,nt=timeSteps)

    arts[6].RCRDAG(    hConj=3,     R1=89409.6, C1=1.e-6,R2=358092,     tConj=hd.CONJ,nt=timeSteps)
    arts[8].RCRDAG(    hConj=3,     R1=22037.4, C1=2.e-6,R2=88032,      tConj=hd.CONJ,nt=timeSteps)
    arts[15].RCRDAG(   hConj=8,     R1=89409.6, C1=1.e-6,R2=358092,     tConj=hd.CONJ,nt=timeSteps)
    arts[17].RCRDAG(   hConj=8,     R1=20774.6, C1=2.e-6,R2=83326.6,    tConj=hd.CONJ,nt=timeSteps)
    arts[18].RCRDAG(   hConj=8,     R1=89409.6, C1=1.e-6,R2=358092,     tConj=hd.CONJ,nt=timeSteps)
    arts[26].RCRDAG(   hConj=17,    R1=84015.4, C1=1.e-6,R2=198562,     tConj=hd.CONJ,nt=timeSteps)
    arts[28].RCRDAG(   hConj=17,    R1=126252,  C1=0.,   R2=506156,     tConj=hd.CONJ,nt=timeSteps)
    arts[29].RCRDAG(   hConj=17,    R1=84015.4, C1=1.e-6,R2=198562,     tConj=hd.CONJ,nt=timeSteps)
    arts[57].RCRDAG(   hConj=42,    R1=35120.4, C1=1.e-6,R2=140280,     tConj=hd.CONJ,nt=timeSteps)
    arts[71].RCRDAG(   hConj=59,    R1=252504,  C1=0.,   R2=1007720,    tConj=hd.CONJ,nt=timeSteps)
    arts[79].RCRDAG(   hConj=71,    R1=370720,  C1=0.,   R2=1480640,    tConj=hd.CONJ,nt=timeSteps)
    arts[95].RCRDAG(   hConj=87,    R1=159530,  C1=0.,   R2=635852,     tConj=hd.CONJ,nt=timeSteps)
    arts[96].RCRDAG(   hConj=88,    R1=33055.4, C1=1.e-6,R2=131990.6,   tConj=hd.CONJ,nt=timeSteps)
    arts[102].RCRDAG(  hConj=95,    R1=22265.6, C1=2.e-6,R2=89065.2,    tConj=hd.CONJ,nt=timeSteps)

    # Right leg
    arts[83].jDAG(      hConj=75,   dArts=[arts[90],arts[91]],          tConj=hd.CONJ,nt=timeSteps)
    arts[91].jDAG(      hConj=84,   dArts=[arts[98]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[98].jDAG(      hConj=92,   dArts=[arts[105],arts[106]],        tConj=hd.CONJ,nt=timeSteps)
    arts[106].jDAG(     hConj=99,   dArts=[arts[108]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[109].jDAG(     hConj=107,  dArts=[arts[110]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[111].jDAG(     hConj=110,  dArts=[arts[112]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[113].jDAG(     hConj=112,  dArts=[arts[116],arts[117]],        tConj=hd.CONJ,nt=timeSteps)
    arts[116].jDAG(     hConj=114,  dArts=[arts[121]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[117].jDAG(     hConj=114,  dArts=[arts[122],arts[123]],        tConj=hd.CONJ,nt=timeSteps)
    arts[122].jDAG(     hConj=118,  dArts=[arts[126]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[123].jDAG(     hConj=118,  dArts=[arts[127]],                  tConj=hd.CONJ,nt=timeSteps)

    arts[90].RCRDAG(    hConj=84,   R1=15724.8, C1=3.e-6,R2=62781.6,    tConj=hd.CONJ,nt=timeSteps)
    arts[105].RCRDAG(   hConj=99,   R1=12280.8, C1=4.e-6,R2=49008.4,    tConj=hd.CONJ,nt=timeSteps)
    arts[121].RCRDAG(   hConj=117,  R1=21693,   C1=2.e-6,R2=86769.2,    tConj=hd.CONJ,nt=timeSteps)
    arts[127].RCRDAG(   hConj=124,  R1=62781.6, C1=1.e-6,R2=251356,     tConj=hd.CONJ,nt=timeSteps)
    arts[126].RCRDAG(   hConj=123,  R1=31792.6, C1=2.e-6,R2=127400,     tConj=hd.CONJ,nt=timeSteps)

    # Left leg
    arts[81].jDAG(      hConj=75,   dArts=[arts[88],arts[89]],          tConj=hd.CONJ,nt=timeSteps)
    arts[88].jDAG(      hConj=82,   dArts=[arts[97]],                   tConj=hd.CONJ,nt=timeSteps)
    arts[97].jDAG(      hConj=89,   dArts=[arts[103],arts[104]],        tConj=hd.CONJ,nt=timeSteps)
    arts[103].jDAG(     hConj=98,   dArts=[arts[108]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[108].jDAG(     hConj=104,  dArts=[arts[110]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[110].jDAG(     hConj=109,  dArts=[arts[112]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[112].jDAG(     hConj=111,  dArts=[arts[114],arts[115]],        tConj=hd.CONJ,nt=timeSteps)
    arts[114].jDAG(     hConj=113,  dArts=[arts[118],arts[119]],        tConj=hd.CONJ,nt=timeSteps)
    arts[115].jDAG(     hConj=113,  dArts=[arts[120]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[118].jDAG(     hConj=115,  dArts=[arts[124]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[119].jDAG(     hConj=115,  dArts=[arts[125]],                  tConj=hd.CONJ,nt=timeSteps)

    arts[89].RCRDAG(    hConj=82,   R1=15724.8, C1=3.e-6,R2=62781.6,    tConj=hd.CONJ,nt=timeSteps)
    arts[104].RCRDAG(   hConj=98,   R1=12280.8, C1=4.e-6,R2=49008.4,    tConj=hd.CONJ,nt=timeSteps)
    arts[120].RCRDAG(   hConj=116,  R1=21693,   C1=2.e-6,R2=86769.2,    tConj=hd.CONJ,nt=timeSteps)
    arts[124].RCRDAG(   hConj=119,  R1=62781.6, C1=1.e-6,R2=251356,     tConj=hd.CONJ,nt=timeSteps)
    arts[125].RCRDAG(   hConj=120,  R1=31792.6, C1=2.e-6,R2=127400,     tConj=hd.CONJ,nt=timeSteps)

    #############################
    # Network definition
    #############################

    net=network(ARTS=arts,tS=tS)

    #############################
    # Create necessary files
    #############################

    hd.headerFile() ;

    #############################
    # Write parameters
    #############################

    net.writeParam(str(hd.PATH)+"parameters_"+str(hd.LOGO))

if __name__ == "__main__":
   main(sys.argv[1:])
