#!/usr/bin/python2.7
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *
from    help_Wave   import *

from    Dict        import Arteries

def main(argv) :

    # PATHS
    ###########

    HOME    = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Clamping/"

    nfig = 1

    Nxstr       = "3"
    xOrderstr   = "2"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Conjstr     = "jS"

    nuvstr      = "5e4"

    PATH        = PATH1D
    Store       = PATH1D + "Figures/"

    for Netstr in ["Avolio"] :

        # FILE :
        ###########
        PATHEND = "/" + NNstr + "/" + Conjstr + "/nuv=" + nuvstr + "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/"

        for art in ["Aorta","RRadial","LRadial"] :

            S1      = "Sane"
            Data1  = PATH + Netstr + "/" + S1 + PATHEND + "Figures/" + "Artery_" + str(Arteries[Netstr][art]) + "_t.csv"

            S2      = "Iliac"
            Data2  = PATH + Netstr + "/" + S2 + PATHEND + "Figures/" + "Artery_" + str(Arteries[Netstr][art]) + "_t.csv"

            S3      = "Aorta"
            Data3  = PATH + Netstr + "/" + S3 + PATHEND + "Figures/" + "Artery_" + str(Arteries[Netstr][art]) + "_t.csv"

            ######################################
            ######################################

            lCol        = [ "blue","red","seagreen" ]
            lMark       = [ "","",""]
            lMarkSize   = [ 5,5,5]
            lMarkWidth  = [ 2,2,2]
            MarkPoints  = 40

            lLineSize   = [ 3,3,3]
            lStyle      = [ "-","--","-."]
            lAlpha      = [ 1.,1.,1.]

            LegLoc      = 2
            LegPos      = [0.,1.]
            LegCol      = 1
            LegSize     = 25

            xRange      = []
            yRange      = []

            xBins       = 2 ;
            yBins       = 2 ;

            lHline      = []
            lHlineColor = []
            lHlineWidth = []
            lHlineStyle = []

            lVline      = []
            lVlineColor = []
            lVlineWidth = []
            lVlineStyle = []

            # Convert to mmHg
            yScale = 1./0.0007500615613026439

            lXScale     = [ 1.,1.,1.]
            lYScale     = [ yScale,yScale,yScale]

            lXOffset    = [ 0.,0.,0.]
            lYOffset    = [ 0.,0.,0.]

            lText       = [art,Netstr]
            lTextAlign  = ["right","left"]
            lTextPos    = [[0.99,0.93],[0.65,0.93]]
            lTextColor  = ["black","black"]

            xLabel      = r"$R$ [cm]"
            yLabel      = r"$p$ [mmHg]"

            lLabel      = [ S1,S2,S3]

            liX         = [ 5,5,5]
            liY         = [ 10,10,10]
            lFileSep    = [ ",",",",","]

            lFile       = [ Data1,Data2,Data3]

            title = "Viscoelasticity-" + Netstr + "-PR-" + art + ".pdf"

            nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                                liX=liX,liY=liY,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
