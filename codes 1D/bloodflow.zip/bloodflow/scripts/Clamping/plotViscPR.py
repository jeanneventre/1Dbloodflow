#!/usr/bin/python2.7
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *
from    help_Wave   import *

from    Dict        import Arteries

def main(argv) :

    # PATHS
    ###########

    HOME    = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Clamping/"

    nfig = 1

    Nxstr       = "3"
    xOrderstr   = "2"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Conjstr     = "jS"

    PATH        = PATH1D
    Store       = PATH1D + "Figures/"

    for Netstr in ["Wang"] :

        # FILE :
        ###########
        PATHSTART   = "/" + NNstr + "/" + Conjstr
        PATHEND     = "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/"

        for Clampstr in ["Sane"] :

            for art in ["Aorta","RRadial","LCarotid","RCommonIliac"] :

                n1      = "0"
                Data1   = PATH + Netstr + "/" + Clampstr + PATHSTART + "/nuv=" + n1 + PATHEND + "Figures/" + "Artery_" + str(Arteries[Netstr][art]) + "_t.csv"

                n2      = "1e4"
                Data2   = PATH + Netstr + "/" + Clampstr + PATHSTART + "/nuv=" + n2 + PATHEND + "Figures/" + "Artery_" + str(Arteries[Netstr][art]) + "_t.csv"

                n3      = "5e4"
                Data3   = PATH + Netstr + "/" + Clampstr + PATHSTART + "/nuv=" + n3 + PATHEND + "Figures/" + "Artery_" + str(Arteries[Netstr][art]) + "_t.csv"

                n4      = "1e5"
                Data4   = PATH + Netstr + "/" + Clampstr + PATHSTART + "/nuv=" + n4 + PATHEND + "Figures/" + "Artery_" + str(Arteries[Netstr][art]) + "_t.csv"

                ######################################
                ######################################

                lCol        = [ "blue","red","seagreen","orange" ]
                lMark       = [ "","","",""]
                lMarkSize   = [ 5,5,5,5]
                lMarkWidth  = [ 2,2,2,2]
                MarkPoints  = 40

                lLineSize   = [ 3,3,3,3]
                lStyle      = [ "-","--","-.",":"]
                lAlpha      = [ 1.,1.,1.,1.]

                LegLoc      = 2
                LegPos      = [0.,1.]
                LegCol      = 1
                LegSize     = 25

                xRange      = []
                yRange      = []

                xBins       = 2 ;
                yBins       = 2 ;

                lHline      = []
                lHlineColor = []
                lHlineWidth = []
                lHlineStyle = []

                lVline      = []
                lVlineColor = []
                lVlineWidth = []
                lVlineStyle = []

                # Convert to mmHg
                yScale = 1./0.0007500615613026439

                lXScale     = [ 1.,1.,1.,1.]
                lYScale     = [ yScale,yScale,yScale,yScale]

                lXOffset    = [ 0.,0.,0.,0.]
                lYOffset    = [ 0.,0.,0.,0.]

                lText       = [art,Netstr]
                lTextAlign  = ["right","center"]
                lTextPos    = [[0.99,0.93],[0.5,0.02]]
                lTextColor  = ["black","black"]

                xLabel      = r"$R$ [cm]"
                yLabel      = r"$p$ [mmHg]"

                lLabel      = [ n1,n2,n3,n4]

                liX         = [ 5,5,5,5]
                liY         = [ 10,10,10,10]
                lFileSep    = [ ",",",",",",","]

                lFile       = [ Data1,Data2,Data3,Data4]

                title = "PR-" + Netstr + "-" + Clampstr + "-" + art + ".pdf"

                nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                                    liX=liX,liY=liY,
                                    xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                    xRange=xRange,yRange=yRange,
                                    xBins=xBins,yBins=yBins,
                                    lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                    lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                    lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                    LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                    lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                    lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                    lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
