#!/usr/bin/python2.7
import  sys, getopt
import  numpy       as np

Arteries =  {
                "Matthys"       :   {"Aorta" : 0, "LRadial" : 12, "RRadial" : 5,  "LCarotid" : 8,  "RCarotid" : 2,  "LCommonIliac" : 30, "RCommonIliac" : 27, "LAnteriorTibial" : 36,  "RAnteriorTibial" : 33},
                "Wang"          :   {"Aorta" : 0, "LRadial" : 21, "RRadial" : 7,  "LCarotid" : 14, "RCarotid" : 4,  "LCommonIliac" : 42, "RCommonIliac" : 41, "LAnteriorTibial" : 48,  "RAnteriorTibial" : 54},
                "ADAN"          :   {"Aorta" : 0, "LRadial" : 27, "RRadial" : 9,  "LCarotid" : 16, "RCarotid" : 4,  "LCommonIliac" : 56, "RCommonIliac" : 55, "LAnteriorTibial" : 73,  "RAnteriorTibial" : 63},
                "Liang"         :   {"Aorta" : 0, "LRadial" : 18, "RRadial" : 7,  "LCarotid" : 10, "RCarotid" : 4,  "LCommonIliac" : 48, "RCommonIliac" : 33, "LAnteriorTibial" : 54,  "RAnteriorTibial" : 41},
                "Avolio"        :   {"Aorta" : 0, "LRadial" : 87, "RRadial" : 92, "LCarotid" : 3,  "RCarotid" : 11, "LCommonIliac" : 81, "RCommonIliac" : 83, "LAnteriorTibial" : 114, "RAnteriorTibial" : 117},
                "Mynard"        :   {"Aorta" : 0, "LRadial" : 28, "RRadial" : 14, "LCarotid" : 8,  "RCarotid" : 2,  "LCommonIliac" : 27, "RCommonIliac" : 30, "LAnteriorTibial" : 36,  "RAnteriorTibial" : 33}
            }
