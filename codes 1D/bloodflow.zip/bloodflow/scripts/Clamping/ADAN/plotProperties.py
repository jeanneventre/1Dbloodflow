#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot_Network import *

def main(argv) :

    # PATHS
    ###########

    HOME    = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Clamping/ADAN/"

    nfig    = 1

    Nxstr       = "3"
    xOrderstr   = "2"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Conjstr     = "jS"

    nuvstr      = "0"

    for State in ["Sane"] :

        PATH    = PATH1D + State + "/" + NNstr + "/" + Conjstr + "/nuv=" + nuvstr + "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/"
        Store   = PATH1D + "Figures/"

        for pType in ["K","A0","Cv"] :

            pName,pLabel = out.getType(pType)

            # FILE :
            ###########

            lDag    = [
                        [0,1],[1,2],[1,3],[2,4],[2,5],[4,6],[4,7],[7,8],[8,9],[9,10],
                        [9,11],[11,12],[12,13],[11,14],[5,15],[5,16],[3,17],[3,18],[17,19],[17,20],
                        [18,21],[18,22],[22,23],[21,24],[21,25],[25,26],[26,27],[27,28],[27,29],[29,30],
                        [30,31],[29,32],[23,33],[23,34],[34,35],[34,36],[36,37],[36,38],[38,39],[38,40],
                        [40,41],[41,42],[41,43],[42,44],[42,45],[45,46],[45,47],[43,48],[43,49],[49,50],
                        [49,51],[51,52],[51,53],[53,54],[53,55],[55,56],[55,57],[56,58],[58,59],[56,60],
                        [59,61],[59,62],[62,63],[63,64],[63,65],[65,66],[66,67],[57,68],[68,69],[57,70],
                        [69,71],[69,72],[72,73],[73,74],[73,75],[75,76],[76,77]
                    ]

            # Length of the vessels (cm)
            lL  =   [
                    7.44137655, 4.735127776, 0.960383639, 1.574062903, 8.121935807, 20.44531883, 4.111878208, 12.00020481, 22.31082046, 30.08857661,
                    2.975624075, 1.62660658, 23.05613685, 23.92616296, 6.089687742, 13.21099628, 12.13190392, 0.697853133, 6.089705994, 13.21103835,
                    4.938412527, 4.305767013, 0.989708126, 20.41538087, 4.11187859, 12.0002137, 22.31087827, 31.08844061, 2.975578989, 1.626606267,
                    23.05624697, 23.92621589, 19.68810988, 0.788038441, 17.803022, 1.55559176, 20.15603447, 0.532704865, 18.51762417, 12.15607465,
                    0.324766674, 1.682383336, 1.398843447, 6.655455225, 0.394874505, 9.286691414, 6.440274183, 21.63983238, 0.431912564, 2.183653502,
                    1.197728268, 3.77174249, 5.408937663, 9.023854354, 4.222474204, 7.642856399, 7.403801835, 10.2210634, 3.159122443, 7.250942087,
                    23.83937248, 31.92853229, 13.20290229, 38.62156733, 0.879742886, 3.616267664, 38.28848516, 10.22106793, 3.159122355, 7.250939241,
                    23.83937548, 31.92853183, 13.20280854, 38.62164058, 0.879738236, 3.616364034, 38.28846476
                    ]

            # Radius of the artery (cm)
            lR  =   [
                    1.595, 0.672809, 1.295243987, 0.489563, 0.447559, 0.133527, 0.41773477, 0.2301, 0.2077, 0.1378,
                    0.1408, 0.0959, 0.0676, 0.1408, 0.226547, 0.276538, 0.447559, 1.256557493, 0.226547, 0.276538,
                    0.489563, 1.228446341, 1.055, 0.133527, 0.347983539, 0.2301, 0.2077, 0.1378, 0.1408, 0.0959,
                    0.0676, 0.1408, 0.14, 1.036380504, 0.14, 1.021555043, 0.155, 0.992289512, 0.155, 0.982267672,
                    0.753574, 0.334998, 0.749492414, 0.268614, 0.216682, 0.150666, 0.216682, 0.392612, 0.731912098, 0.27089,
                    0.726483929, 0.309737, 0.711431179, 0.207748, 0.643453001, 0.449868, 0.449868, 0.337758, 0.3189, 0.281829,
                    0.214445, 0.314372492, 0.268614, 0.11663, 0.236767981, 0.234646, 0.122936, 0.337758, 0.3189, 0.281829,
                    0.214445, 0.314372492, 0.268614, 0.11663, 0.236767985, 0.234646, 0.122936
                    ]
            lAngle  = [
                        np.pi*3./4.,    -np.pi/2.,      np.pi/2.,       -np.pi/2.,      np.pi*9./8.,    np.pi*5./4.,    -np.pi*7./16.,  -np.pi*3./8.,   -np.pi*2./8.,   -np.pi/4.,
                        0.,             -np.pi*1./8.,   -np.pi*1./8.,   np.pi*1./8.,    np.pi*19./16,   np.pi,          np.pi*7./8.,    np.pi/2.,       np.pi*13./16.,  np.pi,
                        np.pi/2.,       np.pi*3./8.,    np.pi*2./8.,    np.pi*3./4.,    np.pi*7./16.,   np.pi*3./8.,    np.pi*2./8.,    np.pi/4.,       0.,             np.pi*1./8.,
                        np.pi*1./8.,    0.,             -np.pi*5./16.,  0.,             np.pi*5./16.,   0.,             -np.pi/4.,      0.,             np.pi/4.,       0.,
                        0.,             -np.pi/2.,      0.,             -np.pi*3./8.,   -np.pi/2.,      -np.pi/2.,      -np.pi*5./8.,   np.pi/2.,       0.,             np.pi*3./8.,
                        0.,             -np.pi/2.,      0.,             np.pi/2.,       0.,             -np.pi*3./8.,   np.pi*3./8.,    -np.pi*3./8.,   -np.pi*2./8.,   0.,
                        -np.pi*1./4.,   0.,             0.,             -np.pi*1./8.,   np.pi*1./8.,    np.pi*1./8.,    np.pi*1./8.,    np.pi*3./8.,    np.pi*2./8.,    0.,
                        np.pi*1./4.,    0.,             0.,             np.pi*1./8.,    -np.pi*1./8.,   -np.pi*1./8.,   -np.pi*1./8.
                        ]

            xRange  = [-60.,70.]
            yRange  = [-130.,40.]

            xStart  = 0.
            yStart  = 0.

            if (pType == "K") :
                cbScale = 1.e7
                cbRange = [0,7]
                cbMid   = 0.5
                colorMap = "Segmented3"
            elif (pType == "A0") :
                cbScale = 1.
                cbRange = [0,8]
                cbMid   = 0.05
                colorMap = "Segmented"
            elif (pType == "Cv") :
                cbScale = 1.e3
                cbRange = [3.5,11.5]
                cbMid   = 0.5
                colorMap = "Segmented3"
            else :
                cbScale = 1.
                cbRange = []
                cbMid   = 0.5
                colorMap = "Segmented"

            if (pType == "K") :
                cbLabel = r"$K$ $10^{7} \left[ \frac{g}{cm^{2}.s^{2}} \right]$"
            elif (pType == "Cv") :
                cbLabel = r"$C_\nu$ $10^{3} \left[ \frac{cm^2}{s} \right]$"
            else :
                cbLabel = pLabel

            liX         = []
            liY         = []
            lFileSep    = []
            lFile       = []
            for i in range(77) :
                liX.append(0)
                liY.append([1,2,3])
                lFileSep.append(",")
                lFile.append( PATH + "Figures/" + "Artery_" + str(i) + "_t_"  + pName )

            T_c = 1.
            ts  = 9. * T_c

            for Time in [ ts ] :

                lText       = [r"$ADAN$ $77$-$Artery$ $Network$"]
                lTextPos    = [[0.5,.01]]
                lTextAlign  = ["center"]
                lTextColor  = ["black"]

                title   = "Properties-ADAN-" + State + "-" + pType + ".pdf"

                nfig = plot_csv_network(pathStore=Store,title=title,
                                        Time = Time,
                                        lFile=lFile,lFileSep=lFileSep,
                                        liX=liX,liY=liY,
                                        cbLabel=cbLabel,
                                        lDag=lDag,
                                        lL=lL,lR=lR,lAngle=lAngle,
                                        xStart=xStart,yStart=yStart,
                                        xRange=xRange,yRange=yRange,
                                        cbScale=cbScale,cbRange=cbRange,cbMid=cbMid,colorMap=colorMap,
                                        lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                        nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
