#! /usr/bin/python2.7
import sys, getopt
import os
import numpy    as np
import math     as mt

from bfS_libDef import *

from help_Input     import *

from help_Sum       import *
from help_Wave      import *
from help_Geometry  import *
from help_Inlet     import *
from help_Network   import *

from scipy.interpolate import interp1d

def main(argv) :

    # Read input parameters and store them in hd
    hd = header()
    hd.headerInput(argv) ;

    # Fluid properties
    ##################
    rho_c   = 1. ;

    if      (hd.NNstr == "Newtonian") :
        phi_c   = -4. ;
        mu0_c   = 0. ;
        mu1_c   = 0.05 ;
        kmu_c   = 0. ;
        amu_c   = 0. ;
    elif    (hd.NNstr == "NonNewtonian") :
        phi_c   = -4. ;
        mu0_c   = 1.3    ;
        mu1_c   = 0.05 ;
        kmu_c   = 0.2 ;
        amu_c   = 1.5  ;
    elif    (hd.NNstr == "Inviscid") :
        phi_c   = 0. ;
        mu0_c   = 0. ;
        mu1_c   = 0. ;
        kmu_c   = 0. ;
        amu_c   = 0. ;

    # Mechanical properties
    E_c     = 225.e4
    # Cv_c    = 0.
    nuv_c   = float(hd.Cvstr)
    Knl_c   = 0.

    # Numerical properties
    Nx_c        = float (hd.Nxstr)
    xOrder_c    = int   (hd.xOrderstr)
    dt_c        = float (hd.dtstr)
    tOrder_c    = int   (hd.tOrderstr)
    hd.Nxmax    = 200

    # Time properties
    T_c     = 1. ;
    ts_c    = 9. * T_c
    te_c    = 10.* T_c

    # Boundary properties
    # Inlet
    Q_c = 300.
    # Outlet
    Pout_c  = 0. ; # Capillary pressure (used in RLC outflow bc)
    # Junction
    fact_c  = 1. ;

    # Rheology
    if (hd.NNstr == "NonNewtonian") :
        F_c     = 1.
        H_c     = 0.45
    else :
        F_c     = 0.
        H_c     = 0.

    # Passive Transport
    C_c    = 0. ;
    O_c    = 0. ;

    # Stenosis
    dR_c    = 0. ;

    ############################################################################
    ############################################################################
    # Network
    ############################################################################
    ############################################################################

    # Angle of bifurcation
    # Angle = array( [ [0.*np.pi,np.pi], [1./4.*np.pi,np.pi], [7./4.*np.pi,np.pi] ] )

    #############################
    # Geometrical parameters
    #############################

    # Length of the vessels (cm)
    L   = np.array([
                    7.44137655, 4.735127776, 0.960383639, 1.574062903, 8.121935807, 20.44531883, 4.111878208, 12.00020481, 22.31082046, 30.08857661,
                    2.975624075, 1.62660658, 23.05613685, 23.92616296, 6.089687742, 13.21099628, 12.13190392, 0.697853133, 6.089705994, 13.21103835,
                    4.938412527, 4.305767013, 0.989708126, 20.41538087, 4.11187859, 12.0002137, 22.31087827, 31.08844061, 2.975578989, 1.626606267,
                    23.05624697, 23.92621589, 19.68810988, 0.788038441, 17.803022, 1.55559176, 20.15603447, 0.532704865, 18.51762417, 12.15607465,
                    0.324766674, 1.682383336, 1.398843447, 6.655455225, 0.394874505, 9.286691414, 6.440274183, 21.63983238, 0.431912564, 2.183653502,
                    1.197728268, 3.77174249, 5.408937663, 9.023854354, 4.222474204, 7.642856399, 7.403801835, 10.2210634, 3.159122443, 7.250942087,
                    23.83937248, 31.92853229, 13.20290229, 38.62156733, 0.879742886, 3.616267664, 38.28848516, 10.22106793, 3.159122355, 7.250939241,
                    23.83937548, 31.92853183, 13.20280854, 38.62164058, 0.879738236, 3.616364034, 38.28846476
                ] )
    # Radius of the artery (cm)
    # Proximal radius
    Rp  = np.array([
                    1.595, 0.672809, 1.295243987, 0.489563, 0.447559, 0.133527, 0.41773477, 0.2301, 0.2077, 0.1378,
                    0.1408, 0.0959, 0.0676, 0.1408, 0.226547, 0.276538, 0.447559, 1.256557493, 0.226547, 0.276538,
                    0.489563, 1.228446341, 1.055, 0.133527, 0.347983539, 0.2301, 0.2077, 0.1378, 0.1408, 0.0959,
                    0.0676, 0.1408, 0.14, 1.036380504, 0.14, 1.021555043, 0.155, 0.992289512, 0.155, 0.982267672,
                    0.753574, 0.334998, 0.749492414, 0.268614, 0.216682, 0.150666, 0.216682, 0.392612, 0.731912098, 0.27089,
                    0.726483929, 0.309737, 0.711431179, 0.207748, 0.643453001, 0.449868, 0.449868, 0.337758, 0.3189, 0.281829,
                    0.214445, 0.314372492, 0.268614, 0.11663, 0.236767981, 0.234646, 0.122936, 0.337758, 0.3189, 0.281829,
                    0.214445, 0.314372492, 0.268614, 0.11663, 0.236767985, 0.234646, 0.122936
                ] )

    # Distal radius
    Rd  = np.array([
                    1.295243987, 0.615874, 1.256557493, 0.41773477, 0.332624, 0.133527, 0.2301, 0.2077, 0.182827, 0.1378,
                    0.1408, 0.0959, 0.0676, 0.1408, 0.226547, 0.276538, 0.332624, 1.228446341, 0.226547, 0.276538,
                    0.347983539, 1.055, 1.036380504, 0.133527, 0.2301, 0.2077, 0.182827, 0.1378, 0.1408, 0.0959,
                    0.0676, 0.1408, 0.14, 1.021555043, 0.14, 0.992289512, 0.155, 0.982267672, 0.155, 0.753574,
                    0.749492414, 0.321246, 0.731912098, 0.268614, 0.216682, 0.150666, 0.216682, 0.392612, 0.726483929, 0.27089,
                    0.711431179, 0.309737, 0.643453001, 0.207748, 0.590386, 0.409113, 0.409113, 0.3189, 0.314372492, 0.281829,
                    0.214445, 0.268614, 0.236767981, 0.11663, 0.234646, 0.234646, 0.122936, 0.3189, 0.314372492, 0.281829,
                    0.214445, 0.268614, 0.236767985, 0.11663, 0.234646, 0.234646, 0.122936
                ] )

    R = meanR(Rp,Rd)
    A = np.pi * R * R

    NArt = len(L)

    # Check length of array
    if NArt != len(Rp) or NArt != len(Rd) :
        print ('Dimension error in geometric parameters Rd, Rp or L')
        sys.exit()

    #############################
    # Mechanical parameters
    #############################

    # Density (g/cm^3)
    rho = rho_c
    # Stiffness coefficient beta (g/cm^2/s^2 ~ Pa/m = 0.1 g/(cm*s)^2)
    h   = network_h(R)
    E   = E_c * np.ones(NArt)
    K   = rigidity(E,h,R)
    # Viscoelasticity coefficient C_v (cm^2/s)
    nuv = nuv_c
    Cv  = viscoelasticity(rho,nuv,h,R)
    # Nonlinear stiffness coefficient beta (g/cm^3/s^2)
    Knl = Knl_c * np.ones(NArt)
    # Moens-Korteweg celerity (cm/s)
    c   = celerity(rho,K,A)

    # Check length of array
    if NArt != len(K) or NArt != len(Cv) or NArt != len(Knl) or NArt != len(c) :
        print ('Dimension error in geometric parameters K, Cv, Knl, c or L')
        sys.exit()

    #############################
    # Rheology
    #############################

    # Profile coefficient phi
    phi = phi_c * np.ones(NArt)
    # Newtonian viscosities
    mu0 = mu0_c * np.ones(NArt)
    mu1 = mu1_c * np.ones(NArt)
    # Aggregation coefficient
    kmu = kmu_c * np.ones(NArt)
    # Desaggregation coefficient
    amu = amu_c * np.ones(NArt)

    #############################
    # Artery
    #############################

    arts = [artery(i) for i in range(NArt)]

    # Define default arterial properties
    hd.headerNum    (arts,L,c)

    hd.headerProp   (arts,rho,L,R,K,Cv,Knl)
    # Specific properties
    for i in range(NArt) :
        for ix in range(arts[i].N) :
            arts[i].R[ix] = Rp[i] * Tapper( (Rd[i]-Rp[i])/Rp[i],0.,arts[i].L,arts[i].x[ix])

    hd.headerRheo   (arts,phi,mu0,mu1,kmu,amu)
    hd.headerInit   (arts,F_c,H_c,C_c,O_c)
    hd.headerBC     (arts,fact_c,Pout_c)

    hd.headerOutput (arts)
    # Specific output
    for i in range(NArt) :
        arts[i].outPut = []
        arts[i].outPut.append(0)
        arts[i].outPut.append(arts[i].N/2)
        arts[i].outPut.append(arts[i].N-1)

    #############################
    # Time setup
    #############################

    # CFL
    Ct      = 1.
    dt_CFL  = hd.headerCFL(arts,Ct)

    # Analytic input signal
    t_start = ts_c
    t_end   = te_c

    # Time step
    dt        = float(dt_c)
    if (dt > dt_CFL) :
        print("Error dt>dt_CFL", dt, dt_CFL)
        sys.exit()

    timeSteps = int(t_end/dt)
    tt = np.ones(timeSteps)
    for it in range(timeSteps) :
        tt[it] = float(it) * dt

    #######################

    dt_store    = 1.e-3 * (t_end-t_start)
    storeStep   = max(1,int(dt_store / dt))

    print ("---->Time step dt = ", dt)
    print ("---->CFL Time step dt_CFL = ",dt_CFL)

    tS              = timeSetup()
    tS.tt           = tt
    tS.dt           = dt
    tS.t_start      = t_start
    tS.t_end        = t_end
    tS.Nt           = timeSteps
    tS.storeStep    = storeStep
    tS.CFL          = Ct
    tS.timeOrder    = int(hd.tOrderstr)

    #############################
    # Boundary condition
    #############################

    # Inlet
    Q_Input = Q_c * PulseSin(T_c,tt)

    # Heart model
    V_c         = integrate(tt,Q_Input) / ( te_c / T_c)
    print ("---->Ejection period (s)                : ", T_c)
    print ("---->Stroke Volume (cm^3)               : ", V_c)
    print ("---->Cardiac Output (L/min)             : ", V_c / T_c * 60./1000.)
    print ("---->Maximum Input Flow Rate (cm^3/s)   : ", Q_c)
    print ("---->Maximum Input Speed (cm/s)         : ", Q_c / A[0] )
    print ("---->Reynolds number                    : ", Reynolds(rho_c,mu1_c,R[0],Q_c/A[0]))
    print ("---->Womersley number                   : ", Womersley(rho_c,mu1_c,R[0],T_c))

    # Rheology
    H_Input     = H_c * np.ones(timeSteps)
    F_Input     = np.zeros(timeSteps)

    # Passive transport
    C_Input   = np.zeros(timeSteps)
    O_Input   = np.zeros(timeSteps)
    C_Output  = np.zeros(timeSteps)
    O_Output  = np.zeros(timeSteps)

    #############################
    # Construct network
    #############################

    # Right cerebral
    arts[4].jDAG(   hConj=2,dArts=[arts[14],arts[15]],  tConj=hd.CONJ,nt=timeSteps)

    arts[14].RCRDAG(hConj=5,    R1=9391,C1=6.032e-6,R2=37563,   tConj=hd.CONJ,nt=timeSteps)
    arts[15].RCRDAG(hConj=5,    R1=5760,C1=9.833e-6,R2=23041,   tConj=hd.CONJ,nt=timeSteps)

    # Left cerebral
    arts[16].jDAG(  hConj=3,    dArts=[arts[18],arts[19]],      tConj=hd.CONJ,nt=timeSteps)

    arts[18].RCRDAG(hConj=17,   R1=9424,C1=6.011e-6,R2=37696,   tConj=hd.CONJ,nt=timeSteps)
    arts[19].RCRDAG(hConj=17,   R1=5779,C1=9.801e-6,R2=23118,   tConj=hd.CONJ,nt=timeSteps)

    # Aorta
    arts[0].iDAG(   hConj=0,        dArts=[arts[1]],
                    xType="inQ",    xData=Q_Input,
                    FData=F_Input,  HData=H_Input,              tConj=hd.CONJ,nt=timeSteps)
    arts[21].jDAG(  hConj=18,   dArts=[arts[22]],               tConj=hd.CONJ,nt=timeSteps)
    arts[22].jDAG(  hConj=22,   dArts=[arts[32],arts[33]],      tConj=hd.CONJ,nt=timeSteps)
    arts[33].jDAG(  hConj=23,   dArts=[arts[34],arts[35]],      tConj=hd.CONJ,nt=timeSteps)
    arts[35].jDAG(  hConj=34,   dArts=[arts[36],arts[37]],      tConj=hd.CONJ,nt=timeSteps)
    arts[37].jDAG(  hConj=36,   dArts=[arts[38],arts[39]],      tConj=hd.CONJ,nt=timeSteps)
    arts[39].jDAG(  hConj=38,dArts=[arts[40]],                  tConj=hd.CONJ,nt=timeSteps)
    arts[40].jDAG(  hConj=40,dArts=[arts[41],arts[42]],         tConj=hd.CONJ,nt=timeSteps)
    arts[42].jDAG(  hConj=41,dArts=[arts[47],arts[48]],         tConj=hd.CONJ,nt=timeSteps)
    arts[48].jDAG(  hConj=43,dArts=[arts[49],arts[50]],         tConj=hd.CONJ,nt=timeSteps)
    arts[50].jDAG(  hConj=49,dArts=[arts[51],arts[52]],         tConj=hd.CONJ,nt=timeSteps)
    arts[52].jDAG(  hConj=51,dArts=[arts[53],arts[54]],         tConj=hd.CONJ,nt=timeSteps)
    arts[54].jDAG(  hConj=53,dArts=[arts[55],arts[56]],         tConj=hd.CONJ,nt=timeSteps)

    # Intercostals
    arts[32].RCRDAG(hConj=23,   R1=249127,C1=2.274e-7,R2=996508,    tConj=hd.CONJ,nt=timeSteps)
    arts[34].RCRDAG(hConj=34,   R1=255583,C1=2.216e-7,R2=1022333,   tConj=hd.CONJ,nt=timeSteps)
    arts[36].RCRDAG(hConj=36,   R1=232434,C1=2.437e-7,R2=929735,    tConj=hd.CONJ,nt=timeSteps)
    arts[38].RCRDAG(hConj=38,   R1=234425,C1=2.416e-7,R2=937702,    tConj=hd.CONJ,nt=timeSteps)

    # Celiac, Spleen, Hepatic
    arts[41].jDAG(  hConj=41,   dArts=[arts[43],arts[44]],          tConj=hd.CONJ,nt=timeSteps)
    arts[44].jDAG(  hConj=42,   dArts=[arts[45],arts[46]],          tConj=hd.CONJ,nt=timeSteps)

    arts[43].RCRDAG(hConj=42,   R1=3349,C1=1.692e-5,R2=13394,       tConj=hd.CONJ,nt=timeSteps)
    arts[45].RCRDAG(hConj=45,   R1=343394,C1=1.650e-7,R2=1373574,   tConj=hd.CONJ,nt=timeSteps)
    arts[46].RCRDAG(hConj=45,   R1=4733,C1=1.1976e-5,R2=18933,      tConj=hd.CONJ,nt=timeSteps)

    # Renal
    arts[49].RCRDAG(hConj=49,   R1=2263,C1=2.503-5,R2=9051,         tConj=hd.CONJ,nt=timeSteps)
    arts[51].RCRDAG(hConj=51,   R1=2270,C1=2.495e-5,R2=9082,        tConj=hd.CONJ,nt=timeSteps)

    # Mesentric
    arts[47].RCRDAG(hConj=43,   R1=2182,C1=2.596e-5,R2=8728,        tConj=hd.CONJ,nt=timeSteps)
    arts[53].RCRDAG(hConj=53,   R1=23913,C1=2.369e-6,R2=95652,      tConj=hd.CONJ,nt=timeSteps)

    # Right arm
    arts[1].jDAG(   hConj=1,    dArts=[arts[3],arts[4]],        tConj=hd.CONJ,nt=timeSteps)
    arts[3].jDAG(   hConj=2,    dArts=[arts[5],arts[6]],        tConj=hd.CONJ,nt=timeSteps)
    arts[6].jDAG(   hConj=4,    dArts=[arts[7]],                tConj=hd.CONJ,nt=timeSteps)
    arts[7].jDAG(   hConj=7,    dArts=[arts[8]],                tConj=hd.CONJ,nt=timeSteps)
    arts[8].jDAG(   hConj=8,    dArts=[arts[9],arts[10]],       tConj=hd.CONJ,nt=timeSteps)
    arts[10].jDAG(  hConj=9,    dArts=[arts[11],arts[13]],      tConj=hd.CONJ,nt=timeSteps)
    arts[11].jDAG(  hConj=11,   dArts=[arts[12]],               tConj=hd.CONJ,nt=timeSteps)

    arts[5].RCRDAG( hConj=4,    R1=18104,C1=3.129e-6,R2=72417,  tConj=hd.CONJ,nt=timeSteps)
    arts[9].RCRDAG( hConj=9,    R1=11539,C1=4.909e-6,R2=46155,  tConj=hd.CONJ,nt=timeSteps)
    arts[12].RCRDAG(hConj=12,   R1=47813,C1=1.185e-6,R2=191252, tConj=hd.CONJ,nt=timeSteps)
    arts[13].RCRDAG(hConj=11,   R1=11749,C1=4.821e-6,R2=46995,  tConj=hd.CONJ,nt=timeSteps)

    # Left arm
    arts[2].jDAG(   hConj=1,    dArts=[arts[16],arts[17]],      tConj=hd.CONJ,nt=timeSteps)
    arts[17].jDAG(  hConj=3,    dArts=[arts[20],arts[21]],      tConj=hd.CONJ,nt=timeSteps)
    arts[20].jDAG(  hConj=18,   dArts=[arts[23],arts[24]],      tConj=hd.CONJ,nt=timeSteps)
    arts[24].jDAG(  hConj=21,   dArts=[arts[25]],               tConj=hd.CONJ,nt=timeSteps)
    arts[25].jDAG(  hConj=25,   dArts=[arts[26]],               tConj=hd.CONJ,nt=timeSteps)
    arts[26].jDAG(  hConj=26,   dArts=[arts[27],arts[28]],      tConj=hd.CONJ,nt=timeSteps)
    arts[28].jDAG(  hConj=27,   dArts=[arts[29],arts[31]],      tConj=hd.CONJ,nt=timeSteps)
    arts[29].jDAG(  hConj=29,   dArts=[arts[30]],               tConj=hd.CONJ,nt=timeSteps)

    arts[23].RCRDAG(hConj=21,   R1=19243,C1=2.944e-6,R2=76972,  tConj=hd.CONJ,nt=timeSteps)
    arts[27].RCRDAG(hConj=27,   R1=11332,C1=4.998e-6,R2=45329,  tConj=hd.CONJ,nt=timeSteps)
    arts[30].RCRDAG(hConj=30,   R1=47986,C1=1.180e-6,R2=191945, tConj=hd.CONJ,nt=timeSteps)
    arts[31].RCRDAG(hConj=29,   R1=11976,C1=4.730e-6,R2=47905,  tConj=hd.CONJ,nt=timeSteps)

    # Right leg
    arts[55].jDAG(  hConj=55,   dArts=[arts[57],arts[59]],      tConj=hd.CONJ,nt=timeSteps)
    arts[57].jDAG(  hConj=56,   dArts=[arts[58]],               tConj=hd.CONJ,nt=timeSteps)
    arts[58].jDAG(  hConj=58,   dArts=[arts[60],arts[61]],      tConj=hd.CONJ,nt=timeSteps)
    arts[61].jDAG(  hConj=59,   dArts=[arts[62]],               tConj=hd.CONJ,nt=timeSteps)
    arts[62].jDAG(  hConj=62,   dArts=[arts[63],arts[64]],      tConj=hd.CONJ,nt=timeSteps)
    arts[64].jDAG(  hConj=63,   dArts=[arts[65]],               tConj=hd.CONJ,nt=timeSteps)
    arts[65].jDAG(  hConj=65,   dArts=[arts[66]],               tConj=hd.CONJ,nt=timeSteps)

    arts[59].RCRDAG(hConj=56,   R1=4146,C1=1.366e-5,R2=16582,   tConj=hd.CONJ,nt=timeSteps)
    arts[60].RCRDAG(hConj=59,   R1=3427,C1=1.653e-5,R2=13707,   tConj=hd.CONJ,nt=timeSteps)
    arts[63].RCRDAG(hConj=63,   R1=24525,C1=2.310e-6,R2=98100,  tConj=hd.CONJ,nt=timeSteps)
    arts[66].RCRDAG(hConj=66,   R1=21156,C1=2.677e-6,R2=84625,  tConj=hd.CONJ,nt=timeSteps)

    # Left leg
    arts[56].jDAG(  hConj=55,   dArts=[arts[67],arts[69]],      tConj=hd.CONJ,nt=timeSteps)
    arts[67].jDAG(  hConj=57,   dArts=[arts[68]],               tConj=hd.CONJ,nt=timeSteps)
    arts[68].jDAG(  hConj=68,   dArts=[arts[70],arts[71]],      tConj=hd.CONJ,nt=timeSteps)
    arts[71].jDAG(  hConj=69,   dArts=[arts[72]],               tConj=hd.CONJ,nt=timeSteps)
    arts[72].jDAG(  hConj=72,   dArts=[arts[73],arts[74]],      tConj=hd.CONJ,nt=timeSteps)
    arts[74].jDAG(  hConj=73,   dArts=[arts[75]],               tConj=hd.CONJ,nt=timeSteps)
    arts[75].jDAG(  hConj=75,   dArts=[arts[76]],               tConj=hd.CONJ,nt=timeSteps)

    arts[69].RCRDAG(hConj=57,   R1=4158,C1=1.362e-5,R2=16632,   tConj=hd.CONJ,nt=timeSteps)
    arts[70].RCRDAG(hConj=69,   R1=3429,C1=1.652e-5,R2=13715,   tConj=hd.CONJ,nt=timeSteps)
    arts[73].RCRDAG(hConj=73,   R1=24533,C1=2.309e-6,R2=98131,  tConj=hd.CONJ,nt=timeSteps)
    arts[76].RCRDAG(hConj=76,   R1=21166,C1=2.676e-6,R2=84662,  tConj=hd.CONJ,nt=timeSteps)

    #############################
    # Network definition
    #############################

    net=network(ARTS=arts,tS=tS)

    #############################
    # Create necessary files
    #############################

    hd.headerFile() ;

    #############################
    # Write parameters
    #############################

    net.writeParam(str(hd.PATH)+"parameters_"+str(hd.LOGO))

if __name__ == "__main__":
   main(sys.argv[1:])
