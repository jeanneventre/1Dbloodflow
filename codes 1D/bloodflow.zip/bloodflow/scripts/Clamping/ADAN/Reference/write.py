#!/usr/bin/python3
import  sys, getopt

from    bfS_libData     import *
from    bfS_libWrite    import *

def main(argv) :
    PATH = "";
    # COMMAND LINE ARGUMENTS
    #############################
    try :
        opts, args = getopt.getopt(argv,"hp:",["path="])
    except getopt.GetoptError:
          print ('plot.py -p <PATH>')
          sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('plot.py -p <PATH>')
            sys.exit()
        elif opt in ("-p", "--PATH"):
            PATH = arg

	if not os.path.exists(str(PATH)+"Figures"):
		os.makedirs(str(PATH)+"Figures")
	folderPath_store = str(PATH) + "Figures/"

    folderPath= str(PATH)

    # DATA CLASS :
    ##############

    wb = dataS_Opt(folderPath,folderPath_store,logo="Sane")

    # PLOTING :
    ###########
    nfig = 1

    L = [
            7.44137655, 4.735127776, 0.960383639, 1.574062903, 8.121935807, 20.44531883, 4.111878208, 12.00020481, 22.31082046, 30.08857661,
            2.975624075, 1.62660658, 23.05613685, 23.92616296, 6.089687742, 13.21099628, 12.13190392, 0.697853133, 6.089705994, 13.21103835,
            4.938412527, 4.305767013, 0.989708126, 20.41538087, 4.11187859, 12.0002137, 22.31087827, 31.08844061, 2.975578989, 1.626606267,
            23.05624697, 23.92621589, 19.68810988, 0.788038441, 17.803022, 1.55559176, 20.15603447, 0.532704865, 18.51762417, 12.15607465,
            0.324766674, 1.682383336, 1.398843447, 6.655455225, 0.394874505, 9.286691414, 6.440274183, 21.63983238, 0.431912564, 2.183653502,
            1.197728268, 3.77174249, 5.408937663, 9.023854354, 4.222474204, 7.642856399, 7.403801835, 10.2210634, 3.159122443, 7.250942087,
            23.83937248, 31.92853229, 13.20290229, 38.62156733, 0.879742886, 3.616267664, 38.28848516, 10.22106793, 3.159122355, 7.250939241,
            23.83937548, 31.92853183, 13.20280854, 38.62164058, 0.879738236, 3.616364034, 38.28846476
        ]

    T_c = 1.
    ts  = 9. * T_c

    for iArt in range(77) :

        lX = [ 0., L[iArt]/2., L[iArt]]
        lT = [ts + 0.1*T_c,ts + 0.2*T_c,ts + 0.3*T_c,ts + 0.5*T_c,ts + 0.7*T_c]

        for pType in ["Q","P"] :
            write_Opt_t(cls=wb,numArt=int(iArt),lX=lX,pType=pType)
            write_Opt_x(cls=wb,numArt=int(iArt),lTime=lT,pType=pType)

if __name__ == "__main__":
   main(sys.argv[1:])
