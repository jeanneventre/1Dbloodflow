#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *
from    help_Wave   import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Clamping/ADAN/Reference/"
    PATHEXP = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Network/SuppMaterial_1DBenchmark_Boileau_etal/Benchmark6_ADAN56/"

    nfig = 1

    Nxstr       = "3"
    xOrderstr   = "2"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Conjstr     = "jS"

    nuvstr      = "0"

    T_c         = 1. ;
    ts          = 9.*T_c;
    te          = 10.*T_c;

    PATH    = PATH1D + NNstr + "/" + Conjstr + "/nuv=" + nuvstr + "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/"
    Store   = PATH1D + "Figures/"

    for pType in ["P"] :

        pName,pLabel = out.getType(pType)

        # FILE :
        ###########

        # REFERENCE
        SIM     = PATHEXP + "NumData/" + "FVM.txt"

        dName0   = "Artery_" + str(0) + "_x_" + pName
        dName2   = "Artery_" + str(2) + "_x_" + pName
        dName17  = "Artery_" + str(17) + "_x_" + pName
        dName21  = "Artery_" + str(21) + "_x_" + pName
        dName22  = "Artery_" + str(22) + "_x_" + pName
        dName33  = "Artery_" + str(33) + "_x_" + pName
        dName35  = "Artery_" + str(35) + "_x_" + pName
        dName37  = "Artery_" + str(37) + "_x_" + pName
        dName39  = "Artery_" + str(39) + "_x_" + pName
        dName40  = "Artery_" + str(40) + "_x_" + pName
        dName42  = "Artery_" + str(42) + "_x_" + pName
        dName48  = "Artery_" + str(48) + "_x_" + pName
        dName50  = "Artery_" + str(50) + "_x_" + pName
        dName52  = "Artery_" + str(52) + "_x_" + pName
        dName54  = "Artery_" + str(54) + "_x_" + pName

        NUM_0   = PATH + "Figures/" + dName0
        NUM_2   = PATH + "Figures/" + dName2
        NUM_17  = PATH + "Figures/" + dName17
        NUM_21  = PATH + "Figures/" + dName21
        NUM_22  = PATH + "Figures/" + dName22
        NUM_33  = PATH + "Figures/" + dName33
        NUM_35  = PATH + "Figures/" + dName35
        NUM_37  = PATH + "Figures/" + dName37
        NUM_39  = PATH + "Figures/" + dName39
        NUM_40  = PATH + "Figures/" + dName40
        NUM_42  = PATH + "Figures/" + dName42
        NUM_48  = PATH + "Figures/" + dName48
        NUM_50  = PATH + "Figures/" + dName50
        NUM_52  = PATH + "Figures/" + dName52
        NUM_54  = PATH + "Figures/" + dName54

        L = [   7.44137655, 4.735127776, 0.960383639, 1.574062903, 8.121935807, 20.44531883, 4.111878208, 12.00020481, 22.31082046, 30.08857661,
                2.975624075, 1.62660658, 23.05613685, 23.92616296, 6.089687742, 13.21099628, 12.13190392, 0.697853133, 6.089705994, 13.21103835,
                4.938412527, 4.305767013, 0.989708126, 20.41538087, 4.11187859, 12.0002137, 22.31087827, 31.08844061, 2.975578989, 1.626606267,
                23.05624697, 23.92621589, 19.68810988, 0.788038441, 17.803022, 1.55559176, 20.15603447, 0.532704865, 18.51762417, 12.15607465,
                0.324766674, 1.682383336, 1.398843447, 6.655455225, 0.394874505, 9.286691414, 6.440274183, 21.63983238, 0.431912564, 2.183653502,
                1.197728268, 3.77174249, 5.408937663, 9.023854354, 4.222474204, 7.642856399, 7.403801835, 10.2210634, 3.159122443, 7.250942087,
                23.83937248, 31.92853229, 13.20290229, 38.62156733, 0.879742886, 3.616267664, 38.28848516, 10.22106793, 3.159122355, 7.250939241,
                23.83937548, 31.92853183, 13.20280854, 38.62164058, 0.879738236, 3.616364034, 38.28846476
            ]

        Loffset = np.zeros(14)

        i = 0 ;
        Loffset[0] = L[0]
        for iArt in [2,17,21,22,33,35,37,39,40,42,48,50,52] :
            i = i + 1 ;
            Loffset[i] = Loffset[i-1] + L[iArt]

        lTime = [ts + 0.1*T_c,ts + 0.2*T_c,ts + 0.3*T_c,ts + 0.5*T_c,ts + 0.7*T_c]

        ######################################
        ######################################

        lCol        = [ "black",
                        "blue","blue","blue","blue","blue",
                        "blue","blue","blue","blue","blue",
                        "blue","blue","blue","blue","blue",
                        "blue","blue" ]
        lMark       = [ "s",
                        "*","*","*","*","*",
                        "*","*","*","*","*",
                        "*","*","*","*","*",
                        "*","*"]
        lMarkSize   = [ 5,
                        5,5,5,5,5,
                        5,5,5,5,5,
                        5,5,5,5,5,
                        5,5]
        lMarkWidth  = [ 2,
                        2,2,2,2,2,
                        2,2,2,2,2,
                        2,2,2,2,2,
                        2,2]
        MarkPoints  = 40

        lLineSize   = [ 1,
                        1,1,1,1,1,
                        1,1,1,1,1,
                        1,1,1,1,1,
                        1,1]
        lStyle      = [ "",
                        "","","","","",
                        "","","","","",
                        "","","","","",
                        "",""]
        lAlpha      = [ 1,
                        0.8,0.8,0.8,0.8,0.8,
                        0.8,0.8,0.8,0.8,0.8,
                        0.8,0.8,0.8,0.8,0.8,
                        0.8,0.8]

        LegLoc      = 1
        LegPos      = [1.,1.]
        LegCol      = 1
        LegSize     = 25

        xRange      = [0.,42]
        yRange      = []

        xBins       = 2 ;
        yBins       = 10 ;

        lHline      = []
        lHlineColor = []
        lHlineWidth = []
        lHlineStyle = []

        lVline      = []
        lVlineColor = []
        lVlineWidth = []
        lVlineStyle = []

        lXScale     = [ 0.01,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.]
        lYScale     = [ 1.e-4,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.,1.,1.,1.,
                        1.,1.]

        lXOffset    = [ 0.,
                        0.,-Loffset[0],-Loffset[1],-Loffset[2],-Loffset[3],
                        -Loffset[4],-Loffset[5],-Loffset[6],-Loffset[7],-Loffset[8],
                        -Loffset[9],-Loffset[10],-Loffset[11],-Loffset[12],-Loffset[13] ]#,
                        # -Loffset[14],-Loffset[15] ]

        yOffset = - 1.e5
        lYOffset    = [ 0.,
                        yOffset,yOffset,yOffset,yOffset,yOffset,
                        yOffset,yOffset,yOffset,yOffset,yOffset,
                        yOffset,yOffset,yOffset,yOffset,yOffset,
                        yOffset,yOffset]

        # lText       = []
        lTextAlign  = ["center"]
        lTextPos    = [[0.5,0.05]]
        lTextColor  = ["black"]

        xLabel      = r"$x$ $\left[cm\right]$"
        yLabel      = pLabel
        lLabel      = [ r"$Ref$",
                        r"$Num$","","","","",
                        "","","","","",
                        "","","","","",
                        "",""]

        liX         = [ 0,
                        0,0,0,0,0,
                        0,0,0,0,0,
                        0,0,0,0,0,
                        0,0]

        for iY in [1,2,3,4,5] :

            lText       = ["t=" + str(ts+lTime[iY-1])]

            liY         = [ iY,
                            iY,iY,iY,iY,iY,
                            iY,iY,iY,iY,iY,
                            iY,iY,iY,iY,iY,
                            iY,iY ]

            lFileSep    = [ "",
                            ",",",",",",",",",",
                            ",",",",",",",",",",
                            ",",",",",",",",",",
                            ",","," ]

            lFile       = [ SIM,
                            NUM_0,NUM_2,NUM_17,NUM_21,NUM_22,
                            NUM_33,NUM_35,NUM_37,NUM_39,NUM_40,
                            NUM_42,NUM_48,NUM_50,NUM_52,NUM_54 ]

            title = "Aorta_" + str(iY) + "_x.pdf"

            nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                                liX=liX,liY=liY,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
