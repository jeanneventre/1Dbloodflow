#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *
from    help_Wave   import *

def main(argv) :

    # PATHS
    ###########

    HOME    = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Clamping/ADAN/Reference/"
    PATHEXP = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Network/SuppMaterial_1DBenchmark_Boileau_etal/Benchmark6_ADAN56/"

    nfig = 1

    Nxstr       = "3"
    xOrderstr   = "2"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Conjstr     = "jS"

    nuvstr      = "0"

    T_c         = 1. ;
    ts          = 9.*T_c;
    te          = 10.*T_c;

    PATH    = PATH1D + NNstr + "/" + Conjstr + "/nuv=" + nuvstr + "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/"
    Store   = PATH1D + "Figures/"

    for pType in ["P","Q"] :

        pName,pLabel = out.getType(pType)

        # FILE :
        ###########

        # REFERENCE
        SIM     = PATHEXP + "NumData/" + "FVM_" + pType + ".txt"
        lYSim   = [1,4,8,10,7,2,5,3,6,9,11,12]

        lName   = [ "Aortic Arch 1","Right Common Carotid","Right Radial",
                    "Right Posterior Interosseus","Right Internal Carotid","Thoracic Aorta 3",
                    "Right Renal","Abdominal Aorta 5","Right Common Iliac",
                    "Right Internal Iliac","Right Femoral II","Right Anterior Tibial"
                    ]

        i = -1
        for iArt in [0,4,9,12,15,35,51,54,55,59,61,63] :

            i = i+1

            dName   = "Artery_" + str(iArt) + "_t_" + pName

            NUM   = PATH + "Figures/" + dName

            ######################################
            ######################################

            lCol        = [ "blue","red" ]
            lMark       = [ "",""]
            lMarkSize   = [ 5,5]
            lMarkWidth  = [ 2,2]
            MarkPoints  = 40

            lLineSize   = [ 3,3]
            lStyle      = [ "-","--"]
            lAlpha      = [ 1.,1.]

            LegLoc      = 1
            LegPos      = [1.,1.]
            LegCol      = 1
            LegSize     = 25

            xRange      = [ts,te]
            yRange      = []

            xBins       = 2 ;
            yBins       = 2 ;

            lHline      = []
            lHlineColor = []
            lHlineWidth = []
            lHlineStyle = []

            lVline      = []
            lVlineColor = []
            lVlineWidth = []
            lVlineStyle = []

            if (pType == "P") :
                yScale = 1.e-4
            else :
                yScale = 1.

            lXScale     = [ 1.,1.]
            lYScale     = [ yScale,1.]

            lXOffset    = [ 0.,0]

            if (pType == "P") :
                yOffset = - 1.e5
            else :
                yOffset = 0
            lYOffset    = [ 0.,yOffset]

            lText       = [lName[i]]
            lTextAlign  = ["center"]
            lTextPos    = [[0.5,0.05]]
            lTextColor  = ["black"]

            xLabel      = r"$t$ $\left[s\right]$"
            yLabel      = pLabel
            lLabel      = [ r"$Ref$",r"$1D$"]

            liX         = [ 0,0]

            iYSim       = lYSim[i]
            iY          = 2
            liY         = [ iYSim,iY]

            lFileSep    = [ "",","]

            lFile       = [ SIM,NUM]

            title       = "Artery_" + str(iArt) + "_" + pType + "_t.pdf"

            nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                                liX=liX,liY=liY,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
