#!/usr/bin/python2.7
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *
from    help_Wave   import *

from    Dict        import Arteries

def main(argv) :

    # PATHS
    ###########

    HOME    = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Clamping/"

    nfig = 1

    Nxstr       = "3"
    xOrderstr   = "2"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Conjstr     = "jS"

    nuvstr      = "5e4"

    T_c         = 1. ;
    ts          = 9.*T_c;
    te          = 10.*T_c;

    for art in ["RRadial","LRadial"] :

        PATH        = PATH1D
        Store       = PATH1D + "Figures/"

        for pType in ["P"] :

            pName,pLabel = out.getType(pType)

            # FILE :
            ###########
            PATHEND = "/" + NNstr + "/" + Conjstr + "/nuv=" + nuvstr + "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/"

            N1      = "Wang55"
            Data11  = PATH + N1 + "/" + "Sane"  + PATHEND + "Figures/" + "Artery_" + str(Arteries[N1][art]) + "_t_" + pName
            Data12  = PATH + N1 + "/" + "Iliac" + PATHEND + "Figures/" + "Artery_" + str(Arteries[N1][art]) + "_t_" + pName
            Data13  = PATH + N1 + "/" + "Aorta" + PATHEND + "Figures/" + "Artery_" + str(Arteries[N1][art]) + "_t_" + pName

            N2      = "ADAN"
            Data21  = PATH + N2 + "/" + "Sane"  + PATHEND + "Figures/" + "Artery_" + str(Arteries[N2][art]) + "_t_" + pName
            Data22  = PATH + N2 + "/" + "Iliac" + PATHEND + "Figures/" + "Artery_" + str(Arteries[N2][art]) + "_t_" + pName
            Data23  = PATH + N2 + "/" + "Aorta" + PATHEND + "Figures/" + "Artery_" + str(Arteries[N2][art]) + "_t_" + pName

            N3      = "Liang"
            Data31  = PATH + N3 + "/" + "Sane"  + PATHEND + "Figures/" + "Artery_" + str(Arteries[N3][art]) + "_t_" + pName
            Data32  = PATH + N3 + "/" + "Iliac" + PATHEND + "Figures/" + "Artery_" + str(Arteries[N3][art]) + "_t_" + pName
            Data33  = PATH + N3 + "/" + "Aorta" + PATHEND + "Figures/" + "Artery_" + str(Arteries[N3][art]) + "_t_" + pName

            N4      = "Avolio"
            Data41  = PATH + N4 + "/" + "Sane"  + PATHEND + "Figures/" + "Artery_" + str(Arteries[N4][art]) + "_t_" + pName
            Data42  = PATH + N4 + "/" + "Iliac" + PATHEND + "Figures/" + "Artery_" + str(Arteries[N4][art]) + "_t_" + pName
            Data43  = PATH + N4 + "/" + "Aorta" + PATHEND + "Figures/" + "Artery_" + str(Arteries[N4][art]) + "_t_" + pName

            ######################################
            ######################################

            lCol        = [ "blue","red","seagreen",
                            "blue","red","seagreen",
                            "blue","red","seagreen",
                            "blue","red","seagreen"]
            lMark       = [ "","","",
                            "","","",
                            "","","",
                            "","",""]
            lMarkSize   = [ 5,5,5,
                            5,5,5,
                            5,5,5,
                            5,5,5]
            lMarkWidth  = [ 2,2,2,
                            2,2,2,
                            2,2,2,
                            2,2,2]
            MarkPoints  = 40

            lLineSize   = [ 3,3,3,
                            3,3,3,
                            3,3,3,
                            3,3,3]
            lStyle      = [ "-","-","-",
                            "--","--","--",
                            "-.","-.","-.",
                            ":",":",":"]
            lAlpha      = [ 1.,1.,1.,
                            1.,1.,1.,
                            1.,1.,1.,
                            1.,1.,1.]

            LegLoc      = 2
            LegPos      = [0.,1.]
            LegCol      = 1
            LegSize     = 18

            xRange      = [0,3]
            yRange      = []

            xBins       = 2 ;
            yBins       = 2 ;

            lHline      = []
            lHlineColor = []
            lHlineWidth = []
            lHlineStyle = []

            lVline      = [1,2]
            lVlineColor = ["black","black"]
            lVlineWidth = [3,3]
            lVlineStyle = ["--","--"]

            # Convert to mmHg
            if (pType == "P") :
                yScale = 1./0.0007500615613026439
            else :
                yScale = 1.

            lXScale     = [ T_c,T_c,T_c,
                            T_c,T_c,T_c,
                            T_c,T_c,T_c,
                            T_c,T_c,T_c]
            lYScale     = [ yScale,yScale,yScale,
                            yScale,yScale,yScale,
                            yScale,yScale,yScale,
                            yScale,yScale,yScale]

            lXOffset    = [ ts,ts-T_c,ts-2.*T_c,
                            ts,ts-T_c,ts-2.*T_c,
                            ts,ts-T_c,ts-2.*T_c,
                            ts,ts-T_c,ts-2.*T_c]
            lYOffset    = [ "first","first","first",
                            "first","first","first",
                            "first","first","first",
                            "first","first","first"]

            lText       = [art,"Pre-Clamp","Iliac-Clamp",r"Aorta-Clamp"]
            lTextAlign  = ["right","center","center","center"]
            lTextPos    = [[0.99,0.93],[0.165,0.03],[0.50,0.03],[0.835,0.03]]
            lTextColor  = ["black","black","black","black"]

            xLabel      = r"$\frac{t}{T_h}$"
            if (pType == "P") :
                yLabel      = r"$p-p_i$ [mmHg]"
            else :
                yLabel      = pLabel

            lLabel      = [ N1,"","",
                            N2,"","",
                            N3,"","",
                            N4,"",""]

            liX         = [ 0,0,0,
                            0,0,0,
                            0,0,0,
                            0,0,0]
            liY         = [ 2,2,2,
                            2,2,2,
                            2,2,2,
                            2,2,2]
            lFileSep    = [ ",",",",",",
                            ",",",",",",
                            ",",",",",",
                            ",",",",","]

            lFile       = [ Data11,Data12,Data13,
                            Data21,Data22,Data23,
                            Data31,Data32,Data33,
                            Data41,Data42,Data43]

            title = "Network-" + pType + "-" + art + ".pdf"

            nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                                liX=liX,liY=liY,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
