#!/bin/bash

# Matthys
cd Matthys/Pathological/Aorta/
./run.sh
cd ../Iliac/
./run.sh
cd ../../../

# Wang
# cd Wang/Sane
# ./run.sh
# cd ../../
cd Wang/Pathological/Aorta/
./run.sh
cd ../Iliac/
./run.sh
cd ../../../
# ./Wang/Iliac/run.sh
# ./Wang/Aorta/run.sh

# ADAN
# cd ADAN/Sane
# ./run.sh
# cd ../../
cd ADAN/Pathological/Aorta/
./run.sh
cd ../Iliac/
./run.sh
cd ../../../
# ./ADAN/Iliac/run.sh
# ./ADAN/Aorta/run.sh

# Liang
# cd Liang/Sane
# ./run.sh
# cd ../../
cd Liang/Pathological/Aorta/
./run.sh
cd ../Iliac/
./run.sh
cd ../../../
# ./Liang/Iliac/run.sh
# ./Liang/Aorta/run.sh

# Avolio
# cd Avolio/Sane
# ./run.sh
# cd ../../
cd Avolio/Pathological/Aorta/
./run.sh
cd ../Iliac/
./run.sh
cd ../../../
# ./Avolio/Iliac/run.sh
# ./Avolio/Aorta/run.sh
