#!/usr/bin/python3
import  sys, getopt

from    bfS_libData     import *
from    bfS_libWrite    import *

def main(argv) :
    PATH = "";
    # COMMAND LINE ARGUMENTS
    #############################
    try :
        opts, args = getopt.getopt(argv,"hp:",["path="])
    except getopt.GetoptError:
          print ('plot.py -p <PATH>')
          sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print ('plot.py -p <PATH>')
            sys.exit()
        elif opt in ("-p", "--PATH"):
            PATH = arg

	if not os.path.exists(str(PATH)+"Figures"):
		os.makedirs(str(PATH)+"Figures")
	folderPath_store = str(PATH) + "Figures/"

    folderPath= str(PATH)

    # DATA CLASS :
    ##############

    wb = dataS_Opt(folderPath,folderPath_store,logo="Sane")

    # PLOTING :
    ###########
    nfig = 1

    L = [
            2.00000000, 	3.00000000, 	3.50000000, 	3.50000000, 	17.70000000, 	13.50000000, 	39.80000000, 	22.00000000, 	6.70000000, 	4.00000000,
         	20.80000000, 	5.50000000, 	10.50000000, 	7.30000000, 	3.50000000, 	13.50000000, 	39.80000000, 	6.70000000, 	22.00000000, 	2.00000000,
         	2.00000000, 	6.50000000, 	5.80000000, 	5.50000000, 	5.30000000, 	5.00000000, 	1.50000000, 	3.00000000, 	1.50000000, 	3.00000000,
         	12.50000000, 	3.80000000, 	8.00000000, 	5.80000000, 	14.50000000, 	4.50000000, 	11.30000000, 	44.30000000, 	4.10000000, 	17.60000000,
         	34.40000000, 	32.20000000, 	7.00000000, 	17.00000000, 	17.00000000, 	7.00000000, 	17.60000000, 	4.10000000, 	5.80000000, 	14.50000000,
         	4.50000000, 	11.30000000, 	44.30000000, 	32.20000000, 	34.40000000,
            2.90000000, 	0.50000000, 	8.60000000, 	1.50000000, 	0.50000000,
         	11.90000000, 	1.20000000, 	10.30000000, 	0.30000000, 	10.30000000, 	1.20000000, 	11.90000000, 	0.50000000, 	1.50000000, 	8.60000000,
         	0.50000000, 	6.10000000, 	6.10000000, 	10.10000000, 	10.10000000, 	6.10000000, 	6.10000000, 	9.10000000, 	9.10000000, 	10.00000000,
         	10.00000000, 	10.10000000, 	10.10000000
        ]

    for iArt in range(83) :

        lX = [ 0., L[iArt]/2., L[iArt]]

        for pType in ["Q","P"] :
            write_Opt_t(cls=wb,numArt=int(iArt),lX=lX,pType=pType)

        lXmid = [L[iArt]/2.]

        write_Opt_t_All(cls=wb,numArt=int(iArt),lX=lXmid)

if __name__ == "__main__":
   main(sys.argv[1:])
