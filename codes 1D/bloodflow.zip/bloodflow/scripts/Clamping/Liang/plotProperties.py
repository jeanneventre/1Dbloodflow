#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot_Network import *

def main(argv) :

    # PATHS
    ###########

    HOME    = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Clamping/Liang/"

    nfig    = 1

    Nxstr       = "3"
    xOrderstr   = "2"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Conjstr     = "jS"

    nuvstr      = "0"

    for State in ["Sane"] :

        PATH    = PATH1D + State + "/" + NNstr + "/" + Conjstr + "/nuv=" + nuvstr + "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/"
        Store   = PATH1D + "Figures/"

        for pType in ["K","A0","Cv"] :

            pName,pLabel = out.getType(pType)

            # FILE :
            ###########

            lDag    = [
                        [0,1],[1,2],[1,3],[3,4],[3,5],[4,6],[4,7],[7,8],[7,9],[2,10],
                        [2,11],[10,12],[12,13],[12,14],[10,15],[15,6],[15,17],[17,18],[17,19],[13,20],
                        [20,21],[20,22],[21,23],[21,24],[13,25],[25,26],[25,27],[29,28],[27,29],[27,30],
                        [29,31],[31,32],[31,33],[33,34],[34,35],[34,36],[35,37],[35,38],[5,39],[11,40],
                        [38,41],[38,42],[9,43],[9,44],[18,45],[18,46],[5,47],[11,48],[33,49],[49,50],
                        [49,51],[50,52],[50,53],[53,54],[53,55],
                        [6,56],[56,57],[57,58],[57,47],[47,60],
                        [60,61],[60,62],[62,63],[62,66],[66,65],[68,66],[68,67],[40,68],[71,40],[71,70],
                        [56,71],[48,72],[39,73],[48,74],[39,75],[72,76],[73,77],[72,78],[73,79],[76,80],
                        [77,81],[76,82],[77,83]
                      ]

            # Length of the vessels (cm)
            lL  =   [
                    2.00000000, 	3.00000000, 	3.50000000, 	3.50000000, 	17.70000000, 	13.50000000, 	39.80000000, 	22.00000000, 	6.70000000, 	4.00000000,
                 	20.80000000, 	5.50000000, 	10.50000000, 	7.30000000, 	3.50000000, 	13.50000000, 	39.80000000, 	6.70000000, 	22.00000000, 	2.00000000,
                 	2.00000000, 	6.50000000, 	5.80000000, 	5.50000000, 	5.30000000, 	5.00000000, 	1.50000000, 	3.00000000, 	1.50000000, 	3.00000000,
                 	12.50000000, 	3.80000000, 	8.00000000, 	5.80000000, 	14.50000000, 	4.50000000, 	11.30000000, 	44.30000000, 	4.10000000, 	17.60000000,
                 	34.40000000, 	32.20000000, 	7.00000000, 	17.00000000, 	17.00000000, 	7.00000000, 	17.60000000, 	4.10000000, 	5.80000000, 	14.50000000,
                 	4.50000000, 	11.30000000, 	44.30000000, 	32.20000000, 	34.40000000,
                    2.90000000, 	0.50000000, 	8.60000000, 	1.50000000, 	0.50000000,
                 	11.90000000, 	1.20000000, 	10.30000000, 	0.30000000, 	10.30000000, 	1.20000000, 	11.90000000, 	0.50000000, 	1.50000000, 	8.60000000,
                 	0.50000000, 	6.10000000, 	6.10000000, 	10.10000000, 	10.10000000, 	6.10000000, 	6.10000000, 	9.10000000, 	9.10000000, 	10.00000000,
                 	10.00000000, 	10.10000000, 	10.10000000
                    ]
            # Radius of the artery (cm)
            lR  =   [
                    1.52500000, 	1.42000000, 	0.65000000, 	0.42500000, 	0.40000000, 	0.15000000, 	0.40700000, 	0.17500000, 	0.21500000, 	1.34200000,
                 	0.40000000, 	1.24600000, 	1.12400000, 	0.30000000, 	0.42500000, 	0.15000000, 	0.40700000, 	0.21500000, 	0.17500000, 	0.35000000,
                 	0.30000000, 	0.27500000, 	0.17500000, 	0.20000000, 	0.92400000, 	0.40000000, 	0.83800000, 	0.27500000, 	0.81400000, 	0.27500000,
                 	0.79200000, 	0.20000000, 	0.62700000, 	0.40000000, 	0.37000000, 	0.20000000, 	0.20000000, 	0.31400000, 	0.20000000, 	0.25000000,
                 	0.17500000, 	0.25000000, 	0.10000000, 	0.20300000, 	0.20300000, 	0.10000000, 	0.25000000, 	0.20000000, 	0.40000000, 	0.37000000,
                 	0.20000000, 	0.20000000, 	0.31400000, 	0.17500000, 	0.25000000,
                    0.16200000, 	0.10700000, 	0.10500000, 	0.07300000, 	0.20000000,
                 	0.14300000, 	0.11700000, 	0.12000000, 	0.10000000, 	0.12000000, 	0.11700000, 	0.14300000, 	0.20000000, 	0.07300000, 	0.10500000,
                 	0.10700000, 	0.20000000, 	0.20000000, 	0.10000000, 	0.10000000, 	0.16000000, 	0.16000000, 	0.11000000, 	0.11000000, 	0.11000000,
                 	0.11000000, 	0.11000000, 	0.11000000
                    ]
            lAngle  = [
                        np.pi,          np.pi/2.,       -np.pi/2.,      -np.pi/2.,      np.pi*5./4.,    np.pi*12.5/16., -np.pi/4.,   -np.pi/8.,      np.pi/8.,       np.pi/2.,
                        np.pi*14.3/20., np.pi*1./8.,    0.,             np.pi*1./4.,    np.pi*1./2.,    np.pi*9./8.,    np.pi/4.,    -np.pi/8.,      np.pi/8.,       -np.pi/2.,
                        -np.pi/2.,      np.pi*9./8.,    -np.pi*1./4.,   -np.pi*3./4.,   0.,             np.pi*1./2.,    0.,             -np.pi*1./2.,   0.,             np.pi*1./2.,
                        0.,             np.pi/2.,       0.,             -np.pi*3./8.,   -np.pi*1./8.,   np.pi*1./8.,    -np.pi*1./8.,   0.,             np.pi*17./16.,  np.pi*14.1/10.,
                        -np.pi*1./16.,  np.pi*1./16.,   -np.pi/8.,      0.,             0.,             np.pi/8.,       np.pi*6./10.,   np.pi*15./16.,  np.pi*3./8.,    np.pi*1./8.,
                        -np.pi*1./8.,   np.pi*1./8.,    0.,             -np.pi*1./16.,  np.pi*1./16.,
                        np.pi,          -np.pi/2.,      -np.pi/2.,      np.pi,          -np.pi/2.,
                        -np.pi/2.,      np.pi*11./16.,  np.pi*5./4.,    np.pi/2.,       np.pi*3./4.,    np.pi*1./4.,    np.pi/2.,       np.pi/2.,       -np.pi/4.,      np.pi/2.,
                        np.pi/2.,       np.pi*3./4.,    np.pi*5./4.,    np.pi*1./2.,    -np.pi*1./2.,   np.pi*3./4.,    np.pi*5./4.,    np.pi*1./2.,    -np.pi*1./2.,   np.pi*3./4.,
                        np.pi*5./4.,    np.pi*2./4.,    np.pi*6./4.
                        ]

            xRange  = [-50.,55.]
            yRange  = [-145.,55.]

            xStart  = 0.
            yStart  = 0.

            if (pType == "K") :
                cbScale = 1.e7
                cbRange = [0,7]
                cbMid   = 0.5
                colorMap = "Segmented3"
            elif (pType == "A0") :
                cbScale = 1.
                cbRange = [0,8]
                cbMid   = 0.05
                colorMap = "Segmented"
            elif (pType == "Cv") :
                cbScale = 1.e3
                cbRange = [3.5,11.5]
                cbMid   = 0.5
                colorMap = "Segmented3"
            else :
                cbScale = 1.
                cbRange = []
                cbMid   = 0.5
                colorMap = "Segmented"

            if (pType == "K") :
                cbLabel = r"$K$ $10^{7} \left[ \frac{g}{cm^{2}.s^{2}} \right]$"
            elif (pType == "Cv") :
                cbLabel = r"$C_\nu$ $10^{3} \left[ \frac{cm^2}{s} \right]$"
            else :
                cbLabel = pLabel

            liX         = []
            liY         = []
            lFileSep    = []
            lFile       = []
            for i in range(83) :
                liX.append(0)
                liY.append([1,2,3])
                lFileSep.append(",")
                lFile.append( PATH + "Figures/" + "Artery_" + str(i) + "_t_"  + pName )

            T_c = 1.
            ts  = 9. * T_c

            for Time in [ ts ] :

                lText       = [r"$Liang$ $83$-$Artery$ $Network$"]
                lTextPos    = [[0.5,.01]]
                lTextAlign  = ["center"]
                lTextColor  = ["black"]

                title   = "Properties-Liang-" + State + "-" + pType + ".pdf"

                nfig = plot_csv_network(pathStore=Store,title=title,
                                        Time = Time,
                                        lFile=lFile,lFileSep=lFileSep,
                                        liX=liX,liY=liY,
                                        cbLabel=cbLabel,
                                        lDag=lDag,
                                        lL=lL,lR=lR,lAngle=lAngle,
                                        xStart=xStart,yStart=yStart,
                                        xRange=xRange,yRange=yRange,
                                        cbScale=cbScale,cbRange=cbRange,cbMid=cbMid,colorMap=colorMap,
                                        lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                        nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
