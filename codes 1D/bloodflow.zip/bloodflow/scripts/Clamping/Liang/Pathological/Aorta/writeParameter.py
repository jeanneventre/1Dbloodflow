#! /usr/bin/python2.7
import sys, getopt
import os
import numpy    as np
import math     as mt

from bfS_libDef import *

from help_Input     import *

from help_Sum       import *
from help_Wave      import *
from help_Geometry  import *
from help_Inlet     import *
from help_Network   import *

from scipy.interpolate import interp1d

def main(argv) :

    # Read input parameters and store them in hd
    hd = header()
    hd.headerInput(argv) ;

    # Fluid properties
    ##################
    rho_c   = 1. ;

    if      (hd.NNstr == "Newtonian") :
        phi_c   = -4. ;
        mu0_c   = 0. ;
        mu1_c   = 0.05 ;
        kmu_c   = 0. ;
        amu_c   = 0. ;
    elif    (hd.NNstr == "NonNewtonian") :
        phi_c   = -4. ;
        mu0_c   = 1.3    ;
        mu1_c   = 0.05 ;
        kmu_c   = 0.2 ;
        amu_c   = 1.5  ;
    elif    (hd.NNstr == "Inviscid") :
        phi_c   = 0. ;
        mu0_c   = 0. ;
        mu1_c   = 0. ;
        kmu_c   = 0. ;
        amu_c   = 0. ;

    # Mechanical properties
    # Cv_c    = 0.
    nuv_c   = float(hd.Cvstr)
    Knl_c   = 0.

    # Numerical properties
    Nx_c        = float (hd.Nxstr)
    xOrder_c    = int   (hd.xOrderstr)
    dt_c        = float (hd.dtstr)
    tOrder_c    = int   (hd.tOrderstr)
    hd.Nxmax    = 200

    # Time properties
    T_c     = 1. ;
    ts_c    = 9. * T_c
    te_c    = 10.* T_c

    # Boundary properties
    # Inlet
    Q_c = 300.
    # Outlet
    Pout_c  = 0. ; # Capillary pressure (used in RLC outflow bc)
    # Junction
    fact_c  = 1. ;

    # Rheology
    if (hd.NNstr == "NonNewtonian") :
        F_c     = 1.
        H_c     = 0.45
    else :
        F_c     = 0.
        H_c     = 0.

    # Passive Transport
    C_c    = 0. ;
    O_c    = 0. ;

    # Stenosis and aneursym
    iPatho  = 30 ;
    dR_c    = float(hd.dRstr) ;
    dK_c    = float(hd.dKstr) ;

    print ("---->Pathology dR (s)                : ", dR_c)
    print ("---->Pathology dK (s)                : ", dK_c)

    ############################################################################
    ############################################################################
    # Network
    ############################################################################
    ############################################################################

    # Angle of bifurcation
    # Angle = array( [ [0.*np.pi,np.pi], [1./4.*np.pi,np.pi], [7./4.*np.pi,np.pi] ] )

    #############################
    # Geometrical parameters
    #############################

    # Length of the vessels (cm)
    L   = np.array([
        	2.00000000, 	3.00000000, 	3.50000000, 	3.50000000, 	17.70000000, 	13.50000000, 	39.80000000, 	22.00000000, 	6.70000000, 	4.00000000,
         	20.80000000, 	5.50000000, 	10.50000000, 	7.30000000, 	3.50000000, 	13.50000000, 	39.80000000, 	6.70000000, 	22.00000000, 	2.00000000,
         	2.00000000, 	6.50000000, 	5.80000000, 	5.50000000, 	5.30000000, 	5.00000000, 	1.50000000, 	3.00000000, 	1.50000000, 	3.00000000,
         	12.50000000, 	3.80000000, 	8.00000000, 	5.80000000, 	14.50000000, 	4.50000000, 	11.30000000, 	44.30000000, 	4.10000000, 	17.60000000,
         	34.40000000, 	32.20000000, 	7.00000000, 	17.00000000, 	17.00000000, 	7.00000000, 	17.60000000, 	4.10000000, 	5.80000000, 	14.50000000,
         	4.50000000, 	11.30000000, 	44.30000000, 	32.20000000, 	34.40000000,
            2.90000000, 	0.50000000, 	8.60000000, 	1.50000000, 	0.50000000,
         	11.90000000, 	1.20000000, 	10.30000000, 	0.30000000, 	10.30000000, 	1.20000000, 	11.90000000, 	0.50000000, 	1.50000000, 	8.60000000,
         	0.50000000, 	6.10000000, 	6.10000000, 	10.10000000, 	10.10000000, 	6.10000000, 	6.10000000, 	9.10000000, 	9.10000000, 	10.00000000,
         	10.00000000, 	10.10000000, 	10.10000000
        ]) ;
    # Radius of the artery (cm)
    Rp   = np.array([
        	1.52500000, 	1.42000000, 	0.65000000, 	0.42500000, 	0.40000000, 	0.15000000, 	0.40700000, 	0.17500000, 	0.21500000, 	1.34200000,
         	0.40000000, 	1.24600000, 	1.12400000, 	0.30000000, 	0.42500000, 	0.15000000, 	0.40700000, 	0.21500000, 	0.17500000, 	0.35000000,
         	0.30000000, 	0.27500000, 	0.17500000, 	0.20000000, 	0.92400000, 	0.40000000, 	0.83800000, 	0.27500000, 	0.81400000, 	0.27500000,
         	0.79200000, 	0.20000000, 	0.62700000, 	0.40000000, 	0.37000000, 	0.20000000, 	0.20000000, 	0.31400000, 	0.20000000, 	0.25000000,
         	0.17500000, 	0.25000000, 	0.10000000, 	0.20300000, 	0.20300000, 	0.10000000, 	0.25000000, 	0.20000000, 	0.40000000, 	0.37000000,
         	0.20000000, 	0.20000000, 	0.31400000, 	0.17500000, 	0.25000000,
            0.16200000, 	0.10700000, 	0.10500000, 	0.07300000, 	0.20000000,
         	0.14300000, 	0.11700000, 	0.12000000, 	0.10000000, 	0.12000000, 	0.11700000, 	0.14300000, 	0.20000000, 	0.07300000, 	0.10500000,
         	0.10700000, 	0.20000000, 	0.20000000, 	0.10000000, 	0.10000000, 	0.16000000, 	0.16000000, 	0.11000000, 	0.11000000, 	0.11000000,
         	0.11000000, 	0.11000000, 	0.11000000
        ]) ;
    Rd   = np.array([
        	1.42000000, 	1.34200000, 	0.62000000, 	0.40700000, 	0.37000000, 	0.13600000, 	0.23000000, 	0.14000000, 	0.21500000, 	1.24600000,
         	0.37000000, 	1.12400000, 	0.92400000, 	0.30000000, 	0.40700000, 	0.13600000, 	0.23000000, 	0.21500000, 	0.14000000, 	0.30000000,
         	0.25000000, 	0.25000000, 	0.15000000, 	0.20000000, 	0.83800000, 	0.35000000, 	0.81400000, 	0.27500000, 	0.79200000, 	0.27500000,
         	0.62700000, 	0.17500000, 	0.55000000, 	0.37000000, 	0.31400000, 	0.20000000, 	0.20000000, 	0.27500000, 	0.15000000, 	0.20000000,
         	0.17500000, 	0.25000000, 	0.10000000, 	0.18000000, 	0.18000000, 	0.10000000, 	0.20000000, 	0.15000000, 	0.37000000, 	0.31400000,
         	0.20000000, 	0.20000000, 	0.27500000, 	0.17500000, 	0.25000000,
            0.16200000, 	0.10700000, 	0.10500000, 	0.07300000, 	0.20000000,
         	0.14300000, 	0.11700000, 	0.12000000, 	0.10000000, 	0.12000000, 	0.11700000, 	0.14300000, 	0.20000000, 	0.07300000, 	0.10500000,
         	0.10700000, 	0.20000000, 	0.20000000, 	0.10000000, 	0.10000000, 	0.16000000, 	0.16000000, 	0.11000000, 	0.11000000, 	0.11000000,
         	0.11000000, 	0.11000000, 	0.11000000
        ]) ;

    R   = meanR(Rp,Rd)
    A   = np.pi * R * R

    NArt = len(L)

    # Check length of array
    if NArt != len(Rp) or NArt != len(Rd) :
        print ('Dimension error in geometric parameters Rd, Rp or L')
        sys.exit()

    #############################
    # Mechanical parameters
    #############################

    # Density (g/cm^3)
    rho = rho_c
    # Stiffness coefficient beta (g/cm^2/s^2 ~ Pa/m = 0.1 g/(cm*s)^2)
    K   = np.array([
        	200937.20416446, 	215795.23686676, 	630594.24617966, 	772699.82277445, 	1028186.31868410, 	11078757.65376610, 	834561.87426640, 	6867700.93630915, 	4207643.83107510, 	228337.73200506,
         	1028186.31868410, 	245930.36625264, 	272623.87575693, 	1988594.36116355, 	772699.82277445, 	11078757.65376610, 	834561.87426640, 	4207643.83107510, 	6867700.93630915, 	1151371.79474997,
         	1673102.85595587, 	2008186.00516080, 	3495624.26268472, 	2403357.35558007, 	331633.37267402, 	976742.38407705, 	365667.34648066, 	1561947.57826029, 	376448.69330564, 	1561947.57826029,
         	386905.60145302, 	2292020.18316276, 	488722.86499329, 	887470.21492062, 	1576394.49120722, 	5985509.85944149, 	3643433.42237137, 	2452046.98851153, 	4647703.51893305, 	2929561.18284673,
         	9624185.51941391, 	4489790.73612237, 	28448909.50150210, 	9076000.32346087, 	9076000.32346087, 	28448909.50150210, 	2929561.18284673, 	4647703.51893305, 	887470.21492062, 	1576394.49120722,
         	5985509.85944149, 	3643433.42237137, 	2452046.98851153, 	9624185.51941391, 	4489790.73612237,
            6305748.88208172, 	18335876.31228640, 	19267641.26182120, 	47779330.66458800, 	4003303.32796814,
         	8588229.24626400, 	14515559.87585000, 	13547528.65416820, 	34234511.19418430, 	13547528.65416820, 	14515559.87585000, 	8588229.24626400, 	4003303.32796814, 	47779330.66458800, 	19267641.26182120,
         	18335876.31228640, 	4269297.95443423, 	4269297.95443423, 	32220584.57026890, 	32220584.57026890, 	6787636.24443801, 	6787636.24443801, 	24292610.84251430, 	24292610.84251430, 	24292610.84251430,
         	24292610.84251430, 	24292610.84251430, 	24292610.84251430
        ]) ;
    # Viscoelasticity coefficient C_v (cm^2/s)
    h   = network_h(R)
    nuv = nuv_c
    Cv  = viscoelasticity(rho,nuv,h,R)
    # Nonlinear stiffness coefficient beta (g/cm^3/s^2)
    Knl = Knl_c * np.ones(NArt)
    # Moens-Korteweg celerity (cm/s)
    c   = celerity(rho,K,A)

    # Check length of array
    if NArt != len(K) or NArt != len(Cv) or NArt != len(Knl) or NArt != len(c) :
        print ('Dimension error in geometric parameters K, Cv, Knl, c or L')
        sys.exit()

    #############################
    # Rheology
    #############################

    # Profile coefficient phi
    phi = phi_c * np.ones(NArt)
    # Newtonian viscosities
    mu0 = mu0_c * np.ones(NArt)
    mu1 = mu1_c * np.ones(NArt)
    # Aggregation coefficient
    kmu = kmu_c * np.ones(NArt)
    # Desaggregation coefficient
    amu = amu_c * np.ones(NArt)

    #############################
    # Specific shapes
    #############################

    def patho_R(x,xs,xe,dR) :
        N = len(x)
        shape = np.ones(N)
        for ix in range(N) :
            shape[ix] = cosStenosis(dr=dR,xs=xs,xe=xe,x=x[ix])
        return shape ;

    def patho_K(x,xs,xe,dK) :
        N = len(x)
        shape = np.ones(N)
        for ix in range(N) :
            shape[ix] = cosStenosis(dr=dK,xs=xs,xe=xe,x=x[ix])
        return shape ;

    #############################
    # Artery
    #############################

    arts = [artery(i) for i in range(NArt)]

    # Define default arterial properties
    hd.headerNum    (arts,L,c)

    hd.headerProp   (arts,rho,L,R,K,Cv,Knl)
    # Specific properties
    for i in range(NArt) :
        for ix in range(arts[i].N) :
            arts[i].R[ix] = Rp[i] * Tapper( (Rd[i]-Rp[i])/Rp[i],0.,arts[i].L,arts[i].x[ix])

    arts[iPatho].R =  R[iPatho] * patho_R(x=arts[iPatho].x,xs=1./3.*arts[iPatho].L,xe=2./3.*arts[iPatho].L,dR=dR_c)
    arts[iPatho].K =  K[iPatho] * patho_K(x=arts[iPatho].x,xs=1./3.*arts[iPatho].L,xe=2./3.*arts[iPatho].L,dK=dK_c)

    hd.headerRheo   (arts,phi,mu0,mu1,kmu,amu)
    hd.headerInit   (arts,F_c,H_c,C_c,O_c)
    hd.headerBC     (arts,fact_c,Pout_c)

    hd.headerOutput (arts)
    # Specific output
    for i in range(NArt) :
        arts[i].outPut = []
        arts[i].outPut.append(0)
        arts[i].outPut.append(arts[i].N/2)
        arts[i].outPut.append(arts[i].N-1)

    #############################
    # Time setup
    #############################

    # CFL
    Ct      = 1.
    dt_CFL  = hd.headerCFL(arts,Ct)

    # Analytic input signal
    t_start = ts_c
    t_end   = te_c

    # Time step
    dt        = float(dt_c)
    if (dt > dt_CFL) :
        print("Error dt>dt_CFL", dt, dt_CFL)
        sys.exit()

    timeSteps = int(t_end/dt)
    tt = np.ones(timeSteps)
    for it in range(timeSteps) :
        tt[it] = float(it) * dt

    #######################

    dt_store    = 1.e-3 * (t_end-t_start)
    storeStep   = max(1,int(dt_store / dt))

    print ("---->Time step dt = ", dt)
    print ("---->CFL Time step dt_CFL = ",dt_CFL)

    tS              = timeSetup()
    tS.tt           = tt
    tS.dt           = dt
    tS.t_start      = t_start
    tS.t_end        = t_end
    tS.Nt           = timeSteps
    tS.storeStep    = storeStep
    tS.CFL          = Ct
    tS.timeOrder    = int(hd.tOrderstr)

    #############################
    # Boundary condition
    #############################

    # Inlet
    Q_Input = Q_c * PulseSin(T_c,tt)

    # Heart model
    V_c         = integrate(tt,Q_Input) / ( te_c / T_c)
    print ("---->Ejection period (s)                : ", T_c)
    print ("---->Stroke Volume (cm^3)               : ", V_c)
    print ("---->Cardiac Output (L/min)             : ", V_c / T_c * 60./1000.)
    print ("---->Maximum Input Flow Rate (cm^3/s)   : ", Q_c)
    print ("---->Maximum Input Speed (cm/s)         : ", Q_c / A[0] )
    print ("---->Reynolds number                    : ", Reynolds(rho_c,mu1_c,R[0],Q_c/A[0]))
    print ("---->Womersley number                   : ", Womersley(rho_c,mu1_c,R[0],T_c))

    # Rheology
    H_Input     = H_c * np.ones(timeSteps)
    F_Input     = np.zeros(timeSteps)

    # Passive transport
    C_Input   = np.zeros(timeSteps)
    O_Input   = np.zeros(timeSteps)
    C_Output  = np.zeros(timeSteps)
    O_Output  = np.zeros(timeSteps)

    #############################
    # Construct network
    #############################

    # Right cerebral
    arts[4].jDAG    (hConj=3, dArts=[arts[38],arts[46]],tConj=hd.CONJ,nt=timeSteps)
    arts[38].jDAG   (hConj=5, dArts=[arts[72],arts[74]],tConj=hd.CONJ,nt=timeSteps)
    arts[72].jDAG   (hConj=39,dArts=[arts[76],arts[78]],tConj=hd.CONJ,nt=timeSteps)
    arts[76].jDAG   (hConj=73,dArts=[arts[80],arts[82]],tConj=hd.CONJ,nt=timeSteps)
    arts[46].jDAG   (hConj=5, dArts=[arts[59]],         tConj=hd.CONJ,nt=timeSteps)

    arts[74].RDAG   (hConj=39,R1=300775.31184,          tConj=hd.CONJ,nt=timeSteps)
    arts[78].RDAG   (hConj=73,R1=250646.0932,           tConj=hd.CONJ,nt=timeSteps)
    arts[80].RDAG   (hConj=77,R1=250646.0932,           tConj=hd.CONJ,nt=timeSteps)
    arts[82].RDAG   (hConj=77,R1=250646.0932,           tConj=hd.CONJ,nt=timeSteps)

    # Left cerebral
    arts[10].jDAG   (hConj=2, dArts=[arts[39],arts[47]],tConj=hd.CONJ,nt=timeSteps)
    arts[47].jDAG   (hConj=11,dArts=[arts[71],arts[73]],tConj=hd.CONJ,nt=timeSteps)
    arts[71].jDAG   (hConj=48,dArts=[arts[75],arts[77]],tConj=hd.CONJ,nt=timeSteps)
    arts[75].jDAG   (hConj=72,dArts=[arts[79],arts[81]],tConj=hd.CONJ,nt=timeSteps)
    arts[39].jDAG   (hConj=11,dArts=[arts[67]],         tConj=hd.CONJ,nt=timeSteps)

    arts[73].RDAG   (hConj=48,R1=300775.31184,    tConj=hd.CONJ,nt=timeSteps)
    arts[77].RDAG   (hConj=72,R1=250646.0932,     tConj=hd.CONJ,nt=timeSteps)
    arts[79].RDAG   (hConj=76,R1=250646.0932,     tConj=hd.CONJ,nt=timeSteps)
    arts[81].RDAG   (hConj=76,R1=250646.0932,     tConj=hd.CONJ,nt=timeSteps)


    # Upper Right Willis circle
    arts[59].jDAG (hConj=47,dArts=[arts[60],arts[61]],  tConj=hd.CONJ,nt=timeSteps)
    arts[61].jDAG (hConj=60,dArts=[arts[62],arts[63]],  tConj=hd.CONJ,nt=timeSteps)

    arts[60].RDAG   (hConj=60,R1=25611.231119,    tConj=hd.CONJ,nt=timeSteps)
    arts[62].RDAG   (hConj=62,R1=51662.426125,    tConj=hd.CONJ,nt=timeSteps)

    # Upper Left Willis circle
    arts[67].jDAG (hConj=40,dArts=[arts[65],arts[66]],  tConj=hd.CONJ,nt=timeSteps)
    arts[65].jDAG (hConj=68,dArts=[arts[64]],           tConj=hd.CONJ,nt=timeSteps)

    arts[64].RDAG   (hConj=66,R1=51662.426125,    tConj=hd.CONJ,nt=timeSteps)
    arts[66].RDAG   (hConj=68,R1=25611.231119,    tConj=hd.CONJ,nt=timeSteps)

    # Connect Upper Left and Right Willis circle
    arts[63].aDAG (hConj=62,tlConj=66,dArts=[arts[64]], tConj=hd.CONJ,nt=timeSteps)

    # Lower Willis circle
    arts[5].jDAG  (hConj=4,          dArts=[arts[55]],  tConj=hd.CONJ,nt=timeSteps)
    arts[15].aDAG (hConj=15,tlConj=6,dArts=[arts[55]],  tConj=hd.CONJ,nt=timeSteps)

    arts[55].jDAG (hConj=6, dArts=[arts[56],arts[70]],  tConj=hd.CONJ,nt=timeSteps)
    arts[56].jDAG (hConj=56,dArts=[arts[57],arts[58]], tConj=hd.CONJ,nt=timeSteps)
    arts[70].jDAG (hConj=56,dArts=[arts[68],arts[69]], tConj=hd.CONJ,nt=timeSteps)

    arts[57].RDAG   (hConj=57,R1=52169.051207,    tConj=hd.CONJ,nt=timeSteps)
    arts[69].RDAG   (hConj=71,R1=52169.051207,    tConj=hd.CONJ,nt=timeSteps)

    # Connect Upper and Lower Willis circle
    arts[58].aDAG (hConj=57,tlConj=47,dArts=[arts[59]], tConj=hd.CONJ,nt=timeSteps)
    arts[68].aDAG (hConj=71,tlConj=40,dArts=[arts[67]], tConj=hd.CONJ,nt=timeSteps)

    # Aorta
    arts[0].iDAG(   hConj=0,        dArts=[arts[1]],
                    xType="inQ",    xData=Q_Input,
                    FData=F_Input,  HData=H_Input,          tConj=hd.CONJ,nt=timeSteps)
    arts[1].jDAG    (hConj=1, dArts=[arts[9],arts[10]], tConj=hd.CONJ,nt=timeSteps)
    arts[9].jDAG    (hConj=2, dArts=[arts[11],arts[14]],tConj=hd.CONJ,nt=timeSteps)
    arts[11].jDAG   (hConj=10,dArts=[arts[12],arts[13]],tConj=hd.CONJ,nt=timeSteps)
    arts[12].jDAG   (hConj=12,dArts=[arts[19],arts[24]],tConj=hd.CONJ,nt=timeSteps)
    arts[24].jDAG   (hConj=13,dArts=[arts[25],arts[26]],tConj=hd.CONJ,nt=timeSteps)
    arts[26].jDAG   (hConj=25,dArts=[arts[28],arts[29]],tConj=hd.CONJ,nt=timeSteps)
    arts[28].jDAG   (hConj=27,dArts=[arts[27],arts[30]],tConj=hd.CONJ,nt=timeSteps)
    arts[30].jDAG   (hConj=29,dArts=[arts[31],arts[32]],tConj=hd.CONJ,nt=timeSteps)
    arts[32].jDAG   (hConj=31,dArts=[arts[33],arts[48]],tConj=hd.CONJ,nt=timeSteps)

    # Intercostals
    arts[13].RCRDAG (hConj=12,R1=2693.112278,C1=5.00291061388863e-5,R2=6186.158896,     tConj=hd.CONJ,nt=timeSteps)

    # Celiac, Spleen, Hepatic
    arts[19].jDAG   (hConj=13,dArts=[arts[20],arts[21]],tConj=hd.CONJ,nt=timeSteps)
    arts[20].jDAG   (hConj=20,dArts=[arts[22],arts[23]],tConj=hd.CONJ,nt=timeSteps)
    arts[21].RCRDAG (hConj=20,R1=3733.02692,C1=1.5601280475095e-5,R2=23304.753772,      tConj=hd.CONJ,nt=timeSteps)
    arts[22].RCRDAG (hConj=21,R1=11452.393301,C1=1.04258557021067e-5,R2=30624.152983,   tConj=hd.CONJ,nt=timeSteps)
    arts[23].RCRDAG (hConj=21,R1=5399.556795,C1=2.43770007423359e-5,R2=12785.617201,    tConj=hd.CONJ,nt=timeSteps)

    # Renal
    arts[27].RCRDAG (hConj=29,R1=2693.112278,C1=5.00291061388863e-5,R2=6186.158896,     tConj=hd.CONJ,nt=timeSteps)
    arts[29].RCRDAG (hConj=27,R1=2693.112278,C1=5.00291061388863e-5,R2=6186.158896,     tConj=hd.CONJ,nt=timeSteps)

    # Mesentric
    arts[25].RCRDAG (hConj=25,R1=1599.86868,C1=6.07549864655142e-5,R2=5532.879185,      tConj=hd.CONJ,nt=timeSteps)
    arts[31].RCRDAG (hConj=31,R1=7159.412343,C1=8.25067717432908e-6,R2=44129.71109,     tConj=hd.CONJ,nt=timeSteps)

    # Right arm
    arts[2].jDAG    (hConj=1, dArts=[arts[3],arts[4]],  tConj=hd.CONJ,nt=timeSteps)
    arts[3].jDAG    (hConj=3, dArts=[arts[5],arts[6]],  tConj=hd.CONJ,nt=timeSteps)
    arts[6].jDAG    (hConj=4, dArts=[arts[7],arts[8]],  tConj=hd.CONJ,nt=timeSteps)
    arts[8].jDAG    (hConj=7, dArts=[arts[42],arts[43]],tConj=hd.CONJ,nt=timeSteps)
    arts[7].RCRDAG  (hConj=7,R1=18945.111619,C1=1.07258803266278e-5,R2=24451.326326,    tConj=hd.CONJ,nt=timeSteps)
    arts[42].RCRDAG (hConj=9,R1=52569.018377,C1=6.75055405172379e-7,R2=565300.265839,   tConj=hd.CONJ,nt=timeSteps)
    arts[43].RCRDAG (hConj=9,R1=13492.225868,C1=1.07258803266278e-5,R2=28264.34668,     tConj=hd.CONJ,nt=timeSteps)

    # Left arm
    arts[14].jDAG   (hConj=10,dArts=[arts[15],arts[16]],  tConj=hd.CONJ,nt=timeSteps)
    arts[16].jDAG   (hConj=15,dArts=[arts[17],arts[18]],tConj=hd.CONJ,nt=timeSteps)
    arts[17].jDAG   (hConj=17,dArts=[arts[44],arts[45]],tConj=hd.CONJ,nt=timeSteps)
    arts[18].RCRDAG (hConj=17,R1=18945.111619,C1=1.07258803266278e-5,R2=24451.326326,   tConj=hd.CONJ,nt=timeSteps)
    arts[44].RCRDAG (hConj=18,R1=13492.225868,C1=1.07258803266278e-5,R2=28264.34668,    tConj=hd.CONJ,nt=timeSteps)
    arts[45].RCRDAG (hConj=18,R1=52569.018377,C1=6.75055405172379e-7,R2=565300.265839,  tConj=hd.CONJ,nt=timeSteps)

    # Right leg
    arts[33].jDAG   (hConj=33,dArts=[arts[34],arts[35]],tConj=hd.CONJ,nt=timeSteps)
    arts[34].jDAG   (hConj=34,dArts=[arts[36],arts[37]],tConj=hd.CONJ,nt=timeSteps)
    arts[37].jDAG   (hConj=35,dArts=[arts[40],arts[41]],tConj=hd.CONJ,nt=timeSteps)
    arts[35].RCRDAG (hConj=34,R1=8532.63296,C1=1.0200837233716e-5,R2=33703.900192,      tConj=hd.CONJ,nt=timeSteps)
    arts[36].RCRDAG (hConj=35,R1=6652.787261,C1=1.69513912854398e-5,R2=19198.42416,     tConj=hd.CONJ,nt=timeSteps)
    arts[40].RCRDAG (hConj=38,R1=13198.91661,C1=7.65062792528697e-6,R2=43703.079442,    tConj=hd.CONJ,nt=timeSteps)
    arts[41].RCRDAG (hConj=38,R1=5279.566644,C1=1.69513912854398e-5,R2=20145.013129,    tConj=hd.CONJ,nt=timeSteps)

    # Left leg
    arts[48].jDAG   (hConj=33,dArts=[arts[49],arts[50]],tConj=hd.CONJ,nt=timeSteps)
    arts[49].jDAG   (hConj=49,dArts=[arts[51],arts[52]],tConj=hd.CONJ,nt=timeSteps)
    arts[52].jDAG   (hConj=50,dArts=[arts[53],arts[54]],tConj=hd.CONJ,nt=timeSteps)
    arts[50].RCRDAG (hConj=49,R1=8532.63296,C1=1.0200837233716e-5,R2=33703.900192,      tConj=hd.CONJ,nt=timeSteps)
    arts[51].RCRDAG (hConj=50,R1=6652.787261,C1=1.69513912854398e-5,R2=19198.42416,     tConj=hd.CONJ,nt=timeSteps)
    arts[53].RCRDAG (hConj=53,R1=13198.91661,C1=7.65062792528697e-6,R2=43703.079442,    tConj=hd.CONJ,nt=timeSteps)
    arts[54].RCRDAG (hConj=53,R1=5279.566644,C1=1.69513912854398e-5,R2=20145.013129,    tConj=hd.CONJ,nt=timeSteps)

    #############################
    # Network definition
    #############################

    net=network(ARTS=arts,tS=tS)

    #############################
    # Create necessary files
    #############################

    hd.headerFile() ;

    #############################
    # Write parameters
    #############################

    net.writeParam(str(hd.PATH)+"parameters_"+str(hd.LOGO))

if __name__ == "__main__":
   main(sys.argv[1:])
