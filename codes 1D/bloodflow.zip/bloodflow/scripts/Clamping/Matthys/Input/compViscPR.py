#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *
from    help_Wave   import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Clamping/Matthys/Input/"

    nfig = 1

    Nxstr       = "3"
    xOrderstr   = "2"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Conjstr     = "jS"

    nuvstr      = "5e4"

    T_c         = 1. ;
    ts          = 9.*T_c;
    te          = 10.*T_c;

    PATH    = PATH1D
    Store   = PATH1D + "Figures/"

    PATHEND = "/" + NNstr + "/" + Conjstr + "/nuv=" + nuvstr + "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/"

    lTitle  = [ "RUlnar","AorticArch2","LSubclavian1","LUlnar",
                "ThoracicAorta2","Splenic","RIliacFemoral2","RAnteriorTibial"]

    lName   = [ "Right Ulnar","Aortic Arch 2","Left Subclavian 1","Left Ulnar",
                "Thoracic Aorta 2","Splenic","Right Iliac-Femoral 2","Right Anterior Tibial"]

    lNum    = [6,9,10,13,16,19,28,33]

    for Input in ["Sin","Phy"] :

        for i in range(len(lNum)) :

            dName   = "Artery_" + str(lNum[i]) + "_t.csv"

            Data   = PATH + Input + PATHEND + "Figures/" + dName

            ######################################
            ######################################

            lCol        = [ "blue","red" ]
            lMark       = [ "",""]
            lMarkSize   = [ 5,5]
            lMarkWidth  = [ 2,2]
            MarkPoints  = 40

            lLineSize   = [ 3,3]
            lStyle      = [ "-","--"]
            lAlpha      = [ 1,0.8]

            LegLoc      = 2
            LegPos      = [0.,1.]
            LegCol      = 1
            LegSize     = 25

            xRange      = []
            yRange      = []

            xBins       = 2 ;
            yBins       = 2 ;

            lHline      = []
            lHlineColor = []
            lHlineWidth = []
            lHlineStyle = []

            lVline      = []
            lVlineColor = []
            lVlineWidth = []
            lVlineStyle = []

            # Convert to mmHg
            yScale = 1./0.0007500615613026439

            lXScale     = [ 1.,1.]
            lYScale     = [ yScale,yScale]

            lXOffset    = [ 0.,0.]
            lYOffset    = [ 0.,0.]

            lText       = [lName[i]]
            lTextAlign  = ["center"]
            lTextPos    = [[0.5,0.05]]
            lTextColor  = ["black"]

            xLabel      = r"$R$ [cm]"
            yLabel      = r"$p$ [mmHg]"
            lLabel      = [ Input ]

            liX         = [ 5,5]
            liY         = [ 10,10]
            lFileSep    = [ ",","," ]

            lFile       = [ Data ]

            title       = "PR-Matthys-Input-" + Input + "-" + lTitle[i] + ".pdf"

            nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                                liX=liX,liY=liY,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
