#!/usr/bin/python3
import  sys, getopt
import  numpy       as np

import  help_Output as out

from    csv_libPlot import *
from    help_Wave   import *

def main(argv) :

    # PATHS
    ###########

    HOME = "/Users/Arthur/"
    PATH1D  = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Clamping/Matthys/Reference/"
    PATHEXP = HOME + "Documents/UPMC/These/Codes/bloodflow/Examples/Network/SuppMaterial_1DBenchmark_Boileau_etal/Benchmark5_37ArteryNetwork/"

    nfig = 1

    Nxstr       = "3"
    xOrderstr   = "2"

    dtstr       = "1e-5"
    tOrderstr   = "2"

    NNstr       = "Newtonian"

    HRstr       = "HRQ"
    Solverstr   = "KIN_HAT"

    Conjstr     = "jS"

    nuvstr      = "0"

    T_c         = 0.827 ;
    ts          = 9.*T_c;
    te          = 10.*T_c;

    PATH    = PATH1D
    Store   = PATH1D + "Figures/"

    PATHMID = "/" + NNstr + "/" + Conjstr
    PATHEND = "/Nx=" + Nxstr + "/xOrder=" + xOrderstr + "/dt=" + dtstr + "/tOrder=" + tOrderstr + "/" + Solverstr + "/" + HRstr + "/"

    lTitle      = [     "RUlnar","AorticArch2","LSubclavian1","LUlnar",
                        "ThoracicAorta2","Splenic","RIliacFemoral2","RAnteriorTibial"]

    lName       = [     "Right Ulnar","Aortic Arch 2","Left Subclavian 1","Left Ulnar",
                        "Thoracic Aorta 2","Splenic","Right Iliac-Femoral 2","Right Anterior Tibial"]

    lArtNum     = [6,9,10,13,16,19,28,33]

    lYSim       = [     7,1,3,5,2,8,4,6]

    ltsSim      = [     14.136 , 14.075, 14.097, 14.138, 14.09, 14.134, 14.162, 14.200]
    lts         = [     14.136 , 14.075, 14.097, 14.138, 14.09, 14.134, 14.162, 14.200] - 17.*T_c * np.ones(8)

    lYRangeP    = [     [8.9e4,16.e4],  [8.9e4,16.e4],      [8.9e4,16.e4],  [8.9e4,16.e4],
                        [8.9e4,16.e4],  [8.9e4,16.e4],      [7.e4,18.e4],  [7.5e4,19.e4]    ]
    lYRangeQ    = [     [1.9,5.5],      [-131.,200.],       [-3.,23.],      [1.2,5.5],
                        [-90.,150.],    [1.,6.],            [-5.,16.],      [0.7,5.2]   ]

    for pType in ["P","Q"] :

        pName,pLabel = out.getType(pType)

        EXP_RUlnar          = PATHEXP + "ExpData/" + "RUlnar_"          + pType + ".txt"
        EXP_AorticArch2     = PATHEXP + "ExpData/" + "AorticArchII_"    + pType + ".txt"
        EXP_LSubclavian1    = PATHEXP + "ExpData/" + "LSubclavianI_"    + pType + ".txt"
        EXP_LUlnar          = PATHEXP + "ExpData/" + "LUlnar_"          + pType + ".txt"
        EXP_ThoracicAorta2  = PATHEXP + "ExpData/" + "ThoracicAortaII_" + pType + ".txt"
        EXP_Splenic         = PATHEXP + "ExpData/" + "Splenic_"         + pType + ".txt"
        EXP_RIliacFemoral2  = PATHEXP + "ExpData/" + "RIliacFemoralII_" + pType + ".txt"
        EXP_RAnteriorTibial = PATHEXP + "ExpData/" + "RAnteriorTibial_" + pType + ".txt"

        lFileExp    = [     EXP_RUlnar,EXP_AorticArch2,EXP_LSubclavian1,EXP_LUlnar,
                            EXP_ThoracicAorta2,EXP_Splenic,EXP_RIliacFemoral2,EXP_RAnteriorTibial]

        SIM                 = PATHEXP + "NumData/" + "FVM_"             + pType + ".txt"

        for i in range(len(lArtNum)) :

            dName   = "Artery_" + str(lArtNum[i]) + "_t_"

            BC1 = "R"; N1 = "0"
            Data1   = PATH + BC1 + PATHMID + "/nuv=" + N1 + PATHEND + "Figures/" + dName + pName

            BC2 = "RCR"; N2 = "0"
            Data2   = PATH + BC2 + PATHMID + "/nuv=" + N2 + PATHEND + "Figures/" + dName + pName

            BC3 = "R"; N3 = "5e4"
            Data3   = PATH + BC3 + PATHMID + "/nuv=" + N3 + PATHEND + "Figures/" + dName + pName

            BC4 = "RCR"; N4 = "5e4"
            Data4   = PATH + BC4 + PATHMID + "/nuv=" + N4 + PATHEND + "Figures/" + dName + pName

            ######################################
            ######################################

            lCol        = [ "black","blue","red","seagreen","orange","green" ]
            lMark       = [ "","","","","",""]
            lMarkSize   = [ 5,5,5,5,5,5]
            lMarkWidth  = [ 2,2,2,2,2,2]
            MarkPoints  = 40

            lLineSize   = [ 3,3,3,3,3,3]
            lStyle      = [ "--",":","-","-","-","-"]
            lAlpha      = [ 1,1,1,1,1,1]

            LegLoc      = 1
            LegPos      = [1.,1.]
            LegCol      = 1
            LegSize     = 25

            xRange      = [0.,0.8]
            if (pType == "P") :
                yRange      = lYRangeP[i]
            else :
                yRange      = lYRangeQ[i]

            xBins       = 2 ;
            yBins       = 2 ;

            lHline      = []
            lHlineColor = []
            lHlineWidth = []
            lHlineStyle = []

            lVline      = []
            lVlineColor = []
            lVlineWidth = []
            lVlineStyle = []

            if (pType == "P") :
                yScale = 1.e-4
            else :
                yScale = 1.

            lXScale     = [ 1.,1.,1.,1.,1.]
            lYScale     = [ yScale,1.,1.,1.,1.]

            lXOffset    = [ 0.,ts + lts[i],ts + lts[i],ts + lts[i],ts + lts[i]]
            lYOffset    = [ 0.,0.,0.,0.,0.,0.]

            lText       = [lName[i]]
            lTextAlign  = ["center"]
            lTextPos    = [[0.5,0.05]]
            lTextColor  = ["black"]

            xLabel      = r"$t$ $\left[s\right]$"
            yLabel      = pLabel
            lLabel      = [ r"$Exp$",
                            BC1 + r", $\nu_v$=" + str(N1),
                            BC2 + r", $\nu_v$=" + str(N2),
                            BC3 + r", $\nu_v$=" + str(N3),
                            BC4 + r", $\nu_v$=" + str(N4)]

            liX         = [ 0,0,0,0,0,0]

            iYSim       = lYSim[i]
            iY          = 2
            liY         = [ 1,iY,iY,iY,iY ]

            lFileSep    = [ "",",",",",",",",","," ]

            lFile       = [ lFileExp[i],Data1,Data2,Data3,Data4 ]

            title       = "Viscoelasticity-" + lTitle[i] + "-" + pType + "-t.pdf"

            nfig = plot_csv_adim(pathStore=Store,title=title,lFile=lFile,lFileSep=lFileSep,
                                liX=liX,liY=liY,
                                xLabel=xLabel,yLabel=yLabel,lLabel=lLabel,
                                xRange=xRange,yRange=yRange,
                                xBins=xBins,yBins=yBins,
                                lHline=lHline,lHlineColor=lHlineColor,lHlineWidth=lHlineWidth,lHlineStyle=lHlineStyle,
                                lVline=lVline,lVlineColor=lVlineColor,lVlineWidth=lVlineWidth,lVlineStyle=lVlineStyle,
                                lXScale=lXScale,lYScale=lYScale,lXOffset=lXOffset,lYOffset=lYOffset,
                                LegLoc=LegLoc,LegPos=LegPos,LegCol=LegCol,LegSize=LegSize,
                                lText=lText,lTextPos=lTextPos,lTextAlign=lTextAlign,lTextColor=lTextColor,
                                lCol=lCol,lMark=lMark,lMarkSize=lMarkSize,lMarkWidth=lMarkWidth,MarkPoints=MarkPoints,
                                lLineSize=lLineSize,lStyle=lStyle,lAlpha=lAlpha,nf=nfig)

if __name__ == "__main__":
   main(sys.argv[1:])
