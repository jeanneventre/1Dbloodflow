#!/usr/bin/python2.7
import  sys, getopt
import  numpy       as np
import help_Network as net
import help_Wave    as wa

import matplotlib.pyplot    as plt

def alpha(eps,eta) :
    return (1. + (eta**(eps/2.)))**(-1./eps)

def beta(eps,eta) :
    return alpha(eps,eta) * np.sqrt(eta)

def L(R,gamma) :
    return R*gamma ;

def Volume(R,L) :
    n = len(R)
    V = 0.
    for i in range(n) :
        V += np.pi * R[i]*R[i] * L[i]
    print("Volume (L)   = ",V*1.e-3)

eps = 2.76
eta = 0.41
a   = alpha(eps,eta)
b   = beta(eps,eta)

# Plot the evolution of the volume

Rv = np.linspace(1.e-4,0.1,1e5)
Vv = np.pi*Rv*Rv*L(Rv,50.)

nv = np.linspace(1,10)
Vv = []
Ra = 1.
Rb = 1.
for i in range(len(nv)) :
    Ra = a*Ra
    Rb = b*Rb
    Vv.append( np.pi * (Ra*Ra*L(Ra,50.) + Rb*Rb*L(Rb,50.)) * (2**(i-1)) )

plt.plot(nv,Vv)
plt.show()

# R = 1
# A = np.pi*R*R
# K = net.network_K([R])[0]

# Ra = a*R
# Aa = np.pi*Ra*Ra
# Ka = net.network_K([Ra])[0]
#
# Rb = b*R
# Ab = np.pi*Rb*Rb
# Kb = net.network_K([Rb])[0]
#
# Rt,Tt = wa.Reflection_3Arteries(1.,A,Aa,Ab,K,Ka,Kb)
# print(Rt,Tt)
# Rv = np.linspace(1.e-4,1,1e5)
# Rtv = [] ; Ttv = [] ;
# for i in range(len(Rv)) :
#
#     R = Rv[i]
#     A = np.pi*R*R
#     K = net.network_K([R])[0]
#
#     Ra = a*R
#     Aa = np.pi*Ra*Ra
#     Ka = net.network_K([Ra])[0]
#
#     Rb = b*R
#     Ab = np.pi*Rb*Rb
#     Kb = net.network_K([Rb])[0]
#
#     Rt,Tt = wa.Reflection_3Arteries(1.,A,Aa,Ab,K,Ka,Kb)
#     Rtv.append(Rt)
#     Ttv.append(Tt)
#
# plt.plot(Rv,Rtv)
# plt.plot(Rv,Ttv)
# plt.show()

# R = [
#                     1.44,   1.1,    0.537,  0.436,  0.334,
#                     0.207,  0.21,   1.3,    0.558,  1.25,
#                     0.442,  0.339,  0.207,  0.207,  1.18,
#                     0.412,  1.1,    0.397,  0.431,  0.183,
#                     0.192,  0.331,  0.926,  0.259,  0.79,
#                     0.255,  0.78,   0.39,   0.338,  0.231,
#                     0.402,  0.334,  0.226,  0.155,  0.153,
#                     0.158,  0.155
#                     ]
#
# L = [
#                     3.6,    2.8,    14.5,   21.8,   16.5,
#                     23.5,   17.7,   2.1,    17.8,   2.9,
#                     22.7,   17.5,   24.5,   19.1,   5.6,
#                     19.5,   7.2,    3.8,    1.3,    19.1,
#                     19.8,   18.6,   6.2,    12.0,   0.7,
#                     11.8,   10.4,   20.5,   21.6,   20.6,
#                     20.1,   19.5,   20.7,   16.3,   15.1,
#                     14.9,   12.6
#                     ]
#
# Volume(R,L)
# print( 0.13*(70*75)*1.e-3 - 0.3048880506462322)
#
# eps = 2.76
# eta = 0.41
# print("alpha    = ", alpha(eps,eta))
# print("beta     = ", beta(eps,eta))
#
# Rmin    = 300.e-4
# Vmax    = 0.377611949354 *1.e3 #0.02 * (70*75)
# a       = alpha(eps,eta)
# b       = beta(eps,eta)
#
# Rinit       = 0.3
#
# # Reflection coefficient
# ################################
#
#
#
#
# # Target : Rmin
# ################################
#
# nalpha = 0
# Ralpha = Rinit
# nArtalpha = 1
# while (Ralpha > Rmin) :
#     Ralpha      = a * Ralpha ;
#     nalpha      += 1 ;
#     nArtalpha   += 2**nalpha
#
# nbeta = 0
# Rbeta = Rinit
# nArtbeta = 1
# while (Rbeta > Rmin) :
#     Rbeta       = b * Rbeta ;
#     nbeta       += 1 ;
#     nArtbeta    += 2**nbeta
#
# print("nalpha   = ", nalpha,", nArtalpha    = ", nArtalpha)
# print("nbeta    = ", nbeta,", nArtbeta    = ", nArtbeta)
#
# # Target : Vmax
# ################################
#
# nalpha = 0
# Ralpha = R
# Valpha = np.pi * (Ralpha**2.) * L(Ralpha,50.)
# nArtalpha = 1
# while (Valpha < Vmax) :
#
#     Ralpha      = a * Ralpha ;
#     Valpha      += np.pi * (Ralpha**2.) * L(Ralpha,50.) * (2.**nalpha)
#
#     nalpha      += 1 ;
#     nArtalpha   += 2**nalpha
#
# nbeta = 0
# Rbeta = R
# Vbeta = np.pi * (Rbeta**2.) * L(Rbeta,50.)
# nArtbeta = 1
# # while (Vbeta < Vmax) :
# #
# #     Rbeta       = b * Rbeta ;
# #     Vbeta      += np.pi * (Rbeta**2.) * L(Rbeta,50.) * (2.**nbeta)
# #
# #     nbeta       += 1 ;
# #     nArtbeta    += 2**nbeta
#
# print("nalpha   = ", nalpha,", nArtalpha    = ", nArtalpha)
# print("nbeta    = ", nbeta,", nArtbeta    = ", nArtbeta)
